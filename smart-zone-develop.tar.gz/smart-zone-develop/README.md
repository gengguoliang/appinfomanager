# smart-zone

智慧园区项目

项目结构

````txt
smart-zone
  |——————smart-zone-auth                    鉴权服务        **待开发**
  |——————smart-zone-base                  公共依赖（工具类，全局共享变量，全局异常）**已使用**
            |——————smart-zone-common    全局工具类，共享静态变量
            |——————smart-zone-generator  统一代码生成
  |——————smart-zone-center                       **待开发**
            |——————smart-zone-config  配置中心
            |——————smart-zone-registry  服务注册中心
  |——————smart-zone-client                  feign客户端     **待开发**
            |——————smart-zone-client-userapi    调用用户api     **待开发**
  |——————smart-zone-control                 系统监控服务（链路追踪，admin控制台）**待开发**
            |——————smart-zone-zipkin    zip链路监控     **待开发**
            |——————smart-zone-admin     admin控制台     **待开发**
  |——————smart-zone-gate                                   **已使用**
            |——————smart-zone-gateway                  **待开发**
            |——————smart-zone-gateway-zuul             **待使用**
  |——————smart-zone-modules                 模块类（可以放公共模块）
  |——————smart-zone-monitor                 监控服务
  |——————smart-zone-servers                 子服务
            |——————smart-zone-api       用户api服务（提供用户-角色-权限-部门-api数据）
            |——————smart-zone-oa        oa办公子服务
            |——————smart-zone-rental    智能租赁服务


````
