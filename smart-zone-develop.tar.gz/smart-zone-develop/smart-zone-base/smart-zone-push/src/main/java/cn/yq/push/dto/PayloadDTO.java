package cn.yq.push.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: ggl
 * @Date: 2019/9/11 17:12
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayloadDTO {
    //地址
    private String pagePath;
}
