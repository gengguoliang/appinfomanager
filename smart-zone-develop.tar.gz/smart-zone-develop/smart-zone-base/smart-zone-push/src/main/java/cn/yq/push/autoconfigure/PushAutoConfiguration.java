package cn.yq.push.autoconfigure;

import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.push.aspect.NotificationAspect;
import cn.yq.push.aspect.StatusChangedNotificationAspect;
import cn.yq.push.service.PushService;
import com.gexin.rp.sdk.http.IGtPush;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author: yinqk
 * @date: 2019-08-21 16:14
 * @description: TODO
 */
@Configuration
@ConditionalOnClass(IGtPush.class)
@EnableConfigurationProperties(PushProperties.class)
public class PushAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(PushService.class)
    public PushService pushService(PushProperties properties) {
        IGtPush push = new IGtPush(properties.getAppKey(), properties.getMasterSecret());
        return new PushService(push);
    }

    @Bean
    @ConditionalOnMissingBean(NotificationAspect.class)
    public NotificationAspect notificationAspect() {
        return new NotificationAspect();
    }

    @Bean
    @ConditionalOnMissingBean(StatusChangedNotification.class)
    public StatusChangedNotificationAspect statusChangedNotificationAspect() {
        return new StatusChangedNotificationAspect();
    }

}
