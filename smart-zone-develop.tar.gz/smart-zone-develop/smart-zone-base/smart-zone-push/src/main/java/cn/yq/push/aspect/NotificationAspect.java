package cn.yq.push.aspect;

import cn.yq.push.annotations.Notification;
import cn.yq.push.annotations.Notifications;
import cn.yq.push.service.PushService;
import cn.yq.push.utils.PushUtil;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;

/**
 * @author: yinqk
 * @date: 2019-08-14 13:53
 * @description: 系统消息通知切面
 */
@Aspect
@Slf4j
public class NotificationAspect {
    @Autowired
    private MessageSourceAccessor messages;

    @Autowired
    private PushService pushService;

    /**
     * 切点
     */
    @Pointcut(value = "@annotation(cn.yq.push.annotations.Notification)||@annotation(cn.yq.push.annotations.Notifications)")
    public void pointcut() {
    }

    @Around("pointcut()")
    public Object handleNotificationMethod(ProceedingJoinPoint point) throws Throwable {    //point是一个 包含拦截方法信息的对象

        //1.先执行业务
        Object result = point.proceed();

        try {
            //2.执行aop方法
            handle(point);
        } catch (Exception e) {
            log.error("执行系统消息通知切面异常", e);
        }

        return result;
    }

    private void handle(ProceedingJoinPoint point) {
        //1.获取拦截的方法名
        val sig = point.getSignature();
        if (!(sig instanceof MethodSignature)) {
            throw new IllegalArgumentException("该注解只能用于方法");
        }

        val notificationAnns = AnnotationUtils.getAnnotation(((MethodSignature) sig).getMethod(), Notifications.class);
        if (ObjectUtils.isEmpty(notificationAnns)) {
            val notificationAnn = AnnotationUtils.getAnnotation(((MethodSignature) sig).getMethod(), Notification.class);
            this.push(notificationAnn);
        } else {
            Arrays.stream(notificationAnns.value()).forEach(notificationAnn -> {
                this.push(notificationAnn);
            });
        }


    }

    private void push(Notification notificationAnn) {
        String msg = "";
        if (!StringUtils.isEmpty(notificationAnn.description())) {
            msg = notificationAnn.description();
        } else {
            msg = messages.getMessage("NotificationAspect.Notification", new Object[]{notificationAnn.value()}, "您有一条新的{0}信息，请及时查看>>");
        }

        //2.发送消息

        log.debug(msg);
        val title = "亦城时代";

        // TODO 写入消息队列
        switch (notificationAnn.range()) {
            case USER:

                List<String> usernameList = Arrays.asList(notificationAnn.rangeVlue());

                if (ObjectUtils.isEmpty(usernameList)) {
                    usernameList = PushUtil.getTargetUsername(notificationAnn.no());
                }

                if (!ObjectUtils.isEmpty(usernameList)) {
                    pushService.pushMessageToUsernameList(title, msg, usernameList);
                }

                break;
            case ROLE:
                val roleNames = notificationAnn.rangeVlue();
                pushService.pushMessageToRoleNames(title, msg, Arrays.asList(roleNames));

                break;
        }
    }

}
