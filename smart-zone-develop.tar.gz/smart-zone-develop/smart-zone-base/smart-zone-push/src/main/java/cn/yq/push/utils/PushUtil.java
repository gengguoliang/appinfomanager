package cn.yq.push.utils;

import cn.yq.push.constant.PushConstant;
import cn.yq.push.service.PushService;
import org.springframework.util.ObjectUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * @author: yinqk
 * @date: 2019-08-27 11:12
 * @description: TODO
 */
public class PushUtil {


    public static void setTargetUsername(String... username) {
        setTargetUsername(PushConstant.DEFAULT_NO, Arrays.asList(username));
    }

    public static void setTargetUsername(String no, List<String> username) {
        Map<String, List<String>> map = getTargetInfoInner();
        map.put(no, username);
    }

    public static List<String> getTargetUsername() {
        return getTargetUsername(PushConstant.DEFAULT_NO);
    }

    public static List<String> getTargetUsername(String no) {
        Map<String, List<String>> map = getTargetInfoInner();
        return map.get(no);
    }


    private static Map<String, List<String>> getTargetInfoInner() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Map<String, List<String>> map = (Map<String, List<String>>) request.getAttribute(PushService.TARGET_USERNAME_LIST_ATTRIBUTE);
        if (ObjectUtils.isEmpty(map)) {
            map = new HashMap<>();
            request.setAttribute(PushService.TARGET_USERNAME_LIST_ATTRIBUTE, map);
        }
        return map;
    }

}
