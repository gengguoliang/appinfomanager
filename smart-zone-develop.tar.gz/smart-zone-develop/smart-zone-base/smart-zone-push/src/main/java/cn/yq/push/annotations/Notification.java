package cn.yq.push.annotations;

import cn.yq.push.constant.PushConstant;
import cn.yq.push.enumeration.PushRange;
import org.springframework.core.annotation.AliasFor;

import java.lang.annotation.*;

/**
 * @author: yinqk
 * @date: 2019-08-14 13:54
 * @description: 系统消息通知
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Repeatable(Notifications.class)
public @interface Notification {
    @AliasFor("name")
    String value() default "";

    @AliasFor("value")
    String name() default "";

    /**
     * 推送编号
     *
     * @return
     */
    String no() default PushConstant.DEFAULT_NO;

    /**
     * 推送范围
     *
     * @return
     */
    PushRange range() default PushRange.USER;

    /**
     * 推送范围值
     *
     * @return
     */
    String[] rangeVlue() default {};

    /**
     * 自定义描述
     * @return
     */
    String description() default "";


}
