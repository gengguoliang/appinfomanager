package cn.yq.push.constant;

/**
 * @program: smart-zone
 * @description: 推送常量类
 * @author: zhengjianhui
 **/
public class PushConstant {

    /**
     * 消息推送编号
     */
    public static final String DEFAULT_NO = "1";

}
