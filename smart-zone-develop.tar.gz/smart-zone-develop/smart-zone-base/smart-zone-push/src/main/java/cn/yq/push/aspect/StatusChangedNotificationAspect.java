package cn.yq.push.aspect;

import cn.yq.push.annotations.Notification;
import cn.yq.push.annotations.Notifications;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.push.annotations.StatusChangedNotifications;
import cn.yq.push.service.PushService;
import cn.yq.push.utils.PushUtil;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;

/**
 * @Author: ggl
 * @Date: 2019/8/27 18:17
 * @Description:
 */
@Aspect
@Slf4j
public class StatusChangedNotificationAspect {
    @Autowired
    private MessageSourceAccessor messages;

    @Autowired
    private PushService pushService;

    /**
     * 切点
     */
    @Pointcut(value = "@annotation(cn.yq.push.annotations.StatusChangedNotification)||@annotation(cn.yq.push.annotations.StatusChangedNotifications)")
    public void initPointcut() {
    }

    @Around("initPointcut()")
    public Object handleNotificationMethod(ProceedingJoinPoint point) throws Throwable {    //point是一个 包含拦截方法信息的对象

        //1.先执行业务
        Object result = point.proceed();

        try {
            //2.执行aop方法
            handle(point);
        } catch (Exception e) {
            log.error("执行系统消息通知切面异常", e);
        }

        return result;
    }

    private void handle(ProceedingJoinPoint point) {
        //1.获取拦截的方法名
        val sig = point.getSignature();
        if (!(sig instanceof MethodSignature)) {
            throw new IllegalArgumentException("该注解只能用于方法");
        }

        val statusChangedNotificationAnns = AnnotationUtils.getAnnotation(((MethodSignature) sig).getMethod(), StatusChangedNotifications.class);
        if (ObjectUtils.isEmpty(statusChangedNotificationAnns)) {
            val statusChangedNotificationAnn = AnnotationUtils.getAnnotation(((MethodSignature) sig).getMethod(), StatusChangedNotification.class);
            this.push(statusChangedNotificationAnn);
        } else {
            Arrays.stream(statusChangedNotificationAnns.value()).forEach(statusChangedNotificationAnn -> {
                this.push(statusChangedNotificationAnn);
            });
        }


    }

    private void push(StatusChangedNotification statusChangedNotificationAnn) {
        String msg = "";
        if (!StringUtils.isEmpty(statusChangedNotificationAnn.description())) {
            msg = statusChangedNotificationAnn.description();
        } else {
            msg = messages.getMessage("StatusChangedNotificationAspect.StatusChangedNotification", new Object[]{statusChangedNotificationAnn.value()}, "您所申请的{0}已被处理，请及时查看>>");
        }

        //2.发送消息

        log.debug(msg);
        val title = "亦城时代";

        // TODO 写入消息队列
        switch (statusChangedNotificationAnn.range()) {
            case USER:

                List<String> usernameList = Arrays.asList(statusChangedNotificationAnn.rangeVlue());

                if (ObjectUtils.isEmpty(usernameList)) {
                    usernameList = PushUtil.getTargetUsername(statusChangedNotificationAnn.no());
                }

                if (!ObjectUtils.isEmpty(usernameList)) {
                    pushService.pushMessageToUsernameList(title, msg, usernameList);
                }

                break;
            case ROLE:
                val roleNames = statusChangedNotificationAnn.rangeVlue();
                pushService.pushMessageToRoleNames(title, msg, Arrays.asList(roleNames));

                break;
        }
    }
}
