package cn.yq.push.autoconfigure;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author: yinqk
 * @date: 2019-08-21 16:08
 * @description: TODO
 */
@ConfigurationProperties(prefix = "push.unipush")
@Data
public class PushProperties {
    /**
     * App唯一标识
     */
    private String appId;

    /**
     * 预先分配的第三方应用对应的Key，是App与SDK通信的标识之一
     */
    private String appKey;

    /**
     * 个推服务端API鉴权码，用于验证调用方合法性
     */
    private String masterSecret;
}
