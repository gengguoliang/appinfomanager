package cn.yq.push.enumeration;

/**
 * @author: yinqk
 * @date: 2019-08-26 21:08
 * @description: 组织类型
 */
public enum OrganizationType {
    /**
     * 系统
     */
    SYSTEM,

    /**
     * 入驻企业
     */
    ENTERPRISE
}
