package cn.yq.push.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: ggl
 * @Date: 2019/9/11 17:08
 * @Description:
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomMsgDTO {
    //标题
    private String title;
    //内容
    private String content;

    private PayloadDTO payload;
}
