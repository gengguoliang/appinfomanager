package cn.yq.push.enumeration;

/**
 * @author: yinqk
 * @date: 2019-08-26 16:40
 * @description: 推送范围
 */
public enum PushRange {
    /**
     * 指定用户，默认为当前登录用户
     */
    USER,

    /**
     * 指定角色
     */
    ROLE
}
