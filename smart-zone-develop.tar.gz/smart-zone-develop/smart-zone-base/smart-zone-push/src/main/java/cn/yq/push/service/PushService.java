package cn.yq.push.service;

import cn.yq.push.autoconfigure.PushProperties;
import cn.yq.push.dto.CustomMsgDTO;
import cn.yq.push.dto.PayloadDTO;
import com.gexin.fastjson.JSON;
import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.impl.AppMessage;
import com.gexin.rp.sdk.base.impl.ListMessage;
import com.gexin.rp.sdk.base.impl.SingleMessage;
import com.gexin.rp.sdk.base.impl.Target;
import com.gexin.rp.sdk.base.uitls.AppConditions;
import com.gexin.rp.sdk.exceptions.RequestException;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.NotificationTemplate;
import com.gexin.rp.sdk.template.TransmissionTemplate;
import com.gexin.rp.sdk.template.style.Style0;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author: yinqk
 * @date: 2019-08-21 14:56
 * @description: TODO
 */
@Slf4j
public class PushService {
    @Autowired
    private PushProperties properties;
    private IGtPush push;

    public static final String CUSTOM_TAG_OID_PREFIX = PushService.class.getName() + ".CUSTOM_TAG_OID";
    public static final String TARGET_USERNAME_LIST_ATTRIBUTE = PushService.class.getName() + ".TARGET_USERNAME_LIST";

    public PushService(IGtPush push) {
        Assert.isTrue(!ObjectUtils.isEmpty(push), "IGtPush不能为空");

        this.push = push;
    }

    public void bind(String username, String clientId) {
        if (StringUtils.isEmpty(clientId)) {
            return;
        }

        val ret = push.bindAlias(properties.getAppId(), username, clientId);
        log.debug(ret.getResponse().toString());
    }

    public void setClientTag(String clientId, List<String> roleNames, String organizationId) {
        val tags = new ArrayList<String>();
        tags.addAll(roleNames);
        tags.add(String.format("%s:%s", CUSTOM_TAG_OID_PREFIX, organizationId));
        val ret = push.setClientTag(properties.getAppId(), clientId, tags);
        log.debug(ret.getResponse().toString());
    }

    public void pushMessageToApp(String title, String content) {
        Style0 style = new Style0();
        // STEP2：设置推送标题、推送内容
        style.setTitle(title);
        style.setText(content);
        //style.setLogo("push.png");  // 设置推送图标
        // STEP3：设置响铃、震动等推送效果
        //style.setRing(true);  // 设置响铃
        //style.setVibrate(true);  // 设置震动

        // STEP4：选择通知模板
        NotificationTemplate template = new NotificationTemplate();
        template.setAppId(properties.getAppId());
        template.setAppkey(properties.getAppKey());
        template.setStyle(style);

        // STEP5：定义"AppMessage"类型消息对象,设置推送消息有效期等推送参数
        List<String> appIds = new ArrayList<String>();
        appIds.add(properties.getAppId());
        AppMessage message = new AppMessage();
        message.setData(template);
        message.setAppIdList(appIds);
        message.setOffline(true);
        message.setOfflineExpireTime(1000 * 600);  // 时间单位为毫秒

        // STEP6：执行推送
        IPushResult ret = push.pushMessageToApp(message);
        System.out.println(ret.getResponse().toString());
    }

    public void pushMessageToRoleNames(String title, String content, List<String> roleNames) {
        Style0 style = new Style0();
        // STEP2：设置推送标题、推送内容
        style.setTitle(title);
        style.setText(content);
        //style.setLogo("push.png");  // 设置推送图标
        // STEP3：设置响铃、震动等推送效果
        //style.setRing(true);  // 设置响铃
        //style.setVibrate(true);  // 设置震动

        // STEP4：选择通知模板
        NotificationTemplate template = new NotificationTemplate();
        template.setAppId(properties.getAppId());
        template.setAppkey(properties.getAppKey());
        template.setStyle(style);

        AppMessage message = new AppMessage();
        message.setData(template);

        message.setOffline(true);
        // 离线有效时间，单位为毫秒
        message.setOfflineExpireTime(24 * 1000 * 3600);
        // 推送给App的目标用户需要满足的条件
        AppConditions cdt = new AppConditions();
        List<String> appIdList = new ArrayList<String>();
        appIdList.add(properties.getAppId());
        message.setAppIdList(appIdList);
        // 自定义tag
        List<String> tagList = new ArrayList<String>();
        tagList.addAll(roleNames);

        cdt.addCondition(AppConditions.TAG, tagList, AppConditions.OptType.and);
        message.setConditions(cdt);

        IPushResult ret = push.pushMessageToApp(message);
        log.debug(ret.getResponse().toString());
    }

    public void pushMessageToUsername(String title, String content, String username) {
        Style0 style = new Style0();
        // STEP2：设置推送标题、推送内容
        style.setTitle(title);
        style.setText(content);
        //style.setLogo("push.png");  // 设置推送图标
        // STEP3：设置响铃、震动等推送效果
        //style.setRing(true);  // 设置响铃
        //style.setVibrate(true);  // 设置震动

        // STEP4：选择通知模板
        NotificationTemplate template = new NotificationTemplate();
        template.setAppId(properties.getAppId());
        template.setAppkey(properties.getAppKey());
        template.setStyle(style);

        SingleMessage message = new SingleMessage();
        message.setOffline(true);
        // 离线有效时间，单位为毫秒
        message.setOfflineExpireTime(24 * 3600 * 1000);
        message.setData(template);
        // 可选，1为wifi，0为不限制网络环境。根据手机处于的网络情况，决定是否下发
        message.setPushNetWorkType(0);
        Target target = new Target();
        target.setAppId(properties.getAppId());
        //target.setClientId(clientId);
        target.setAlias(username);
        IPushResult ret = null;
        try {
            ret = push.pushMessageToSingle(message, target);
        } catch (RequestException e) {
            log.error(e.getMessage(), e);
            ret = push.pushMessageToSingle(message, target, e.getRequestId());
        }
        if (ret != null) {
            log.debug(ret.getResponse().toString());
        } else {
            log.debug("服务器响应异常");
        }
    }

    public void pushMessageToUsernameList(String title, String content, List<String> usernameList) {
        //Style0 style = new Style0();
        // STEP2：设置推送标题、推送内容
        //style.setTitle(title);
        //style.setText(content);
        //style.setLogo("push.png");  // 设置推送图标
        // STEP3：设置响铃、震动等推送效果
        //style.setRing(true);  // 设置响铃
        //style.setVibrate(true);  // 设置震动

        // STEP4：选择通知模板
        /*NotificationTemplate template = new NotificationTemplate();
        template.setAppId(properties.getAppId());
        template.setAppkey(properties.getAppKey());
        template.setStyle(style);*/
        //透传模板
        TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(properties.getAppId());
        template.setAppkey(properties.getAppKey());
        template.setTransmissionType(2);   //应用启动类型，1：强制应用启动 2：等待应用启动
        //设置自定义消息
        PayloadDTO payloadDTO = new PayloadDTO("/demo");
        CustomMsgDTO customMsgDTO = new CustomMsgDTO(title,content,payloadDTO);
        template.setTransmissionContent(JSON.toJSONString(customMsgDTO));  //透传内容


        val message = new ListMessage();
        message.setOffline(true);
        // 离线有效时间，单位为毫秒
        message.setOfflineExpireTime(24 * 3600 * 1000);
        message.setData(template);
        // 可选，1为wifi，0为不限制网络环境。根据手机处于的网络情况，决定是否下发
        message.setPushNetWorkType(0);

        List<Target> targetList = usernameList.stream().map(username -> {
            Target target = new Target();
            target.setAppId(properties.getAppId());
            target.setAlias(username);

            return target;
        }).collect(Collectors.toList());

        // taskId用于在推送时去查找对应的message
        String taskId = push.getContentId(message);
        IPushResult ret = push.pushMessageToList(taskId, targetList);
        log.debug(ret.getResponse().toString());
    }
}
