package cn.yq.push.annotations;


import java.lang.annotation.*;

/**
 * @author: yinqk
 * @date: 2019-08-14 13:54
 * @description: 系统消息通知容器注解
 */
@Target({ElementType.METHOD,ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface StatusChangedNotifications {

    StatusChangedNotification[] value() default {};

}
