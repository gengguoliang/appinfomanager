package cn.yq.autoconfigure;

import com.github.pagehelper.autoconfigure.PageHelperAutoConfiguration;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * @author: yinqk
 * @date: 2019-06-13 18:34
 * @description: TODO
 */
@Component
@ConditionalOnBean(SqlSessionFactory.class)

@AutoConfigureAfter(PageHelperAutoConfiguration.class)
public class PermissionAutoConfiguration {
    @Autowired
    private List<SqlSessionFactory> sqlSessionFactoryList;

    @PostConstruct
    public void addPermissionInterceptor() {
        PermissionQueryInterceptor interceptor = new PermissionQueryInterceptor();
        for (SqlSessionFactory sqlSessionFactory : sqlSessionFactoryList) {
            sqlSessionFactory.getConfiguration().addInterceptor(interceptor);
        }
    }
}
