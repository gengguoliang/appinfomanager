package cn.yq.autoconfigure;

import cn.yq.client.PermissionUtils;
import cn.yq.common.annotations.PermissionAop;
import cn.yq.common.datapermission.DataPermissionContext;
import cn.yq.common.enumeration.DataRange;
import cn.yq.common.utils.ReflectUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import java.util.Properties;

/**
 * @author: yinqk
 * @date: 2019-06-05 22:01
 * @description: mybatis数据权限拦截器
 */
@Intercepts({
        @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}),
        @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class})
})
public class PermissionQueryInterceptor implements Interceptor {
    /**
     * 日志
     */
    private static final Logger log = LoggerFactory.getLogger(PermissionQueryInterceptor.class);

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {
    }

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object[] args = invocation.getArgs();
        MappedStatement ms = (MappedStatement) args[0];
        Object parameter = args[1];
        RowBounds rowBounds = (RowBounds) args[2];
        ResultHandler resultHandler = (ResultHandler) args[3];
        Executor executor = (Executor) invocation.getTarget();
        CacheKey cacheKey;
        BoundSql boundSql;
        //由于逻辑关系，只会进入一次
        if (args.length == 4) {
            //4 个参数时
            boundSql = ms.getBoundSql(parameter);
            cacheKey = executor.createCacheKey(ms, parameter, rowBounds, boundSql);
        } else {
            //6 个参数时
            cacheKey = (CacheKey) args[4];
            boundSql = (BoundSql) args[5];
        }

        PermissionAop permissionAop = PermissionUtils.getPermissionByDelegate(ms);
        if (permissionAop == null) {
            if (log.isInfoEnabled()) {
                log.info("数据权限放行...");
            }
        } else {
            if (log.isInfoEnabled()) {
                log.info("数据权限处理【拼接SQL】...");
            }

            ReflectUtil.setFieldValue(boundSql, "sql", permissionSql(boundSql.getSql(), permissionAop));
        }
        //注：下面的方法可以根据自己的逻辑调用多次，在分页插件中，count 和 page 各调用了一次
        return executor.query(ms, parameter, rowBounds, resultHandler, cacheKey, boundSql);
    }

    /**
     * 权限sql包装
     */
    protected String permissionSql(String sql, PermissionAop permissionAop) {
        if (ObjectUtils.isEmpty(permissionAop)) {
            return sql;
        }

        //移除原SQL结尾的“;”号
        sql = StringUtils.stripEnd(sql, ";");
        StringBuilder sbSql = new StringBuilder(sql);
        DataPermissionContext dataPermissionContext = PermissionUtils.getDataPermissionContext();

        if (ObjectUtils.isEmpty(dataPermissionContext) || DataRange.ALL.equals(dataPermissionContext.getDataRange())) {
            return sbSql.toString();
        }

        switch (dataPermissionContext.getDataRange()) {
            case SELF:
                sbSql = new StringBuilder("select * from (").append(sbSql).append(" ) mb_inc_dp_t where mb_inc_dp_t." + permissionAop.userIdColumnName() + " = " + dataPermissionContext.getUserId() + " ");
                break;
            case DEPARTMENT_AND_CHILDREN:
            case DEPARTMENT:
            case CUSTOM:
                if (dataPermissionContext.getDepartmentIdList().size() == 1) {
                    sbSql = new StringBuilder("select * from (").append(sbSql).append(" ) mb_inc_dp_t where mb_inc_dp_t." + permissionAop.departmentIdColumnName() + " = " + dataPermissionContext.getDepartmentIdList().get(0) + " ");
                }

                if (dataPermissionContext.getDepartmentIdList().size() > 1) {
                    sbSql = new StringBuilder("select * from (").append(sbSql).append(" ) mb_inc_dp_t where mb_inc_dp_t." + permissionAop.departmentIdColumnName() + " in ( " + StringUtils.join(dataPermissionContext.getDepartmentIdList(), ",") + " )");
                }
                if (ObjectUtils.isEmpty(dataPermissionContext.getDepartmentIdList())) {
                    sbSql = new StringBuilder("select * from (").append(sbSql).append(" ) mb_inc_dp_t where 1=2");
                }
                break;
        }

        return sbSql.toString();
    }
}