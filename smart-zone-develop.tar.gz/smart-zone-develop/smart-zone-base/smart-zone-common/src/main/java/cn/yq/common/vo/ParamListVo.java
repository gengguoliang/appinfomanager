package cn.yq.common.vo;

import lombok.Data;

/**
 * @Author: houqijun
 * @Date: 2018/12/14 17:55
 * @Description:
 */
@Data
public class ParamListVo {

    private Integer id;
    private String name;
}
