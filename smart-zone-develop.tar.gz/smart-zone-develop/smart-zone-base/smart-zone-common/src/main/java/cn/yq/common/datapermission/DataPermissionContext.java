package cn.yq.common.datapermission;

import cn.yq.common.enumeration.DataRange;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author: yinqk
 * @date: 2019-06-06 14:22
 * @description: TODO
 */
@Data
@Builder(builderMethodName = "newBuilder")
@NoArgsConstructor
@AllArgsConstructor
public class DataPermissionContext {
    private DataRange dataRange;
    private int userId;
    private String username;
    private List<Integer> departmentIdList;
}
