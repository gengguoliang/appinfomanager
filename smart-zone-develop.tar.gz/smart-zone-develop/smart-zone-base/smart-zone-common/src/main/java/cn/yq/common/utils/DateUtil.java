package cn.yq.common.utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @Author: houqijun
 * @Date: 2018/12/21 16:06
 * @Description:
 */
public class DateUtil {
    public static void main(String[] args) throws ParseException {


        SimpleDateFormat sj = new SimpleDateFormat("yyyy-MM-dd");
        String today = "2018-12-21";
        Date d = sj.parse(today);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(d);
        calendar.add(Calendar.MONTH, 1);
        System.out.println("明天：" + sj.format(calendar.getTime()));
        //此时日期变为2015-12-01 ，所以下面的-2，
        //理论上讲应该是2015-11-29
        calendar.add(Calendar.DATE, -2);
        System.out.println("前天：" + sj.format(calendar.getTime()));
//        String startTime = "2018-02-08";
//        String endTime = "2020-06-08";
//        int monthSpace = getMonthSpace(startTime, endTime);
//        System.out.println(monthSpace);
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        Date d1 = sdf.parse(startTime);
//        Date d2 = sdf.parse(endTime);
//        long time1 = d2.getTime();
//        int months=(d2.getYear()-d1.getYear())*12+(d2.getMonth()-d1.getMonth());
    }

    /**
     *
     * @param date1 <String>
     * @param date2 <String>
     * @return int
     * @throws ParseException
     */
    public static int getMonthSpace(String date1, String date2)
            throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar bef = Calendar.getInstance();
        Calendar aft = Calendar.getInstance();
        bef.setTime(sdf.parse(date1));
        aft.setTime(sdf.parse(date2));
        int result = aft.get(Calendar.MONTH) - bef.get(Calendar.MONTH);
        int month = (aft.get(Calendar.YEAR) - bef.get(Calendar.YEAR)) * 12;
        System.out.println(Math.abs(month + result));
        return month+result;
    }

    /**
     * 获取当前日期字符串
     * @return
     */
    public static String getNowDateToString(){
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);
    }

}
