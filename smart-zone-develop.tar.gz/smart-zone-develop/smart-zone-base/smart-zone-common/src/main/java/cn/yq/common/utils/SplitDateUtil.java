package cn.yq.common.utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @Author: houqijun
 * @Date: 2018/12/21 15:58
 * @Description:切分时间工具类
 */
public class SplitDateUtil {

    public static int daysBetween(Date early, Date late) {

        java.util.Calendar calst = java.util.Calendar.getInstance();
        java.util.Calendar caled = java.util.Calendar.getInstance();
        calst.setTime(early);
        caled.setTime(late);
        //设置时间为0时
        calst.set(java.util.Calendar.HOUR_OF_DAY, 0);
        calst.set(java.util.Calendar.MINUTE, 0);
        calst.set(java.util.Calendar.SECOND, 0);
        caled.set(java.util.Calendar.HOUR_OF_DAY, 0);
        caled.set(java.util.Calendar.MINUTE, 0);
        caled.set(java.util.Calendar.SECOND, 0);
        //得到两个日期相差的天数
        int days = ((int) (caled.getTime().getTime() / 1000) - (int) (calst
                .getTime().getTime() / 1000)) / 3600 / 24;

        return days;
    }

    /**
     * 获取两个时间内有多少月
     *
     * @return int
     * @throws ParseException
     */
    public static int getMonthSpace(String date1, String date2)
            throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar bef = Calendar.getInstance();
        Calendar aft = Calendar.getInstance();
        bef.setTime(sdf.parse(date1));
        aft.setTime(sdf.parse(date2));
        int result = aft.get(Calendar.MONTH) - bef.get(Calendar.MONTH);
        int month = (aft.get(Calendar.YEAR) - bef.get(Calendar.YEAR)) * 12;
        System.out.println(Math.abs(month + result));
        return month + result;
    }

    /**
     * 获取两个日期相差几个月
     *
     * @param start
     * @param end
     * @return
     * @author 石冬冬-Heil Hilter(dd.shi02@zuche.com)
     * @date 2016-11-30 下午7:57:32
     */
    public static int getMonthBetween(Date start, Date end) {
        if (start.after(end)) {
            Date t = start;
            start = end;
            end = t;
        }
        Calendar startCalendar = Calendar.getInstance();
        startCalendar.setTime(start);
        Calendar endCalendar = Calendar.getInstance();
        endCalendar.setTime(end);
        Calendar temp = Calendar.getInstance();
        temp.setTime(end);
        temp.add(Calendar.DATE, 1);

        int year = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
        int month = endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);

        if ((startCalendar.get(Calendar.DATE) == 1) && (temp.get(Calendar.DATE) == 1)) {
            return year * 12 + month + 1;
        } else if ((startCalendar.get(Calendar.DATE) != 1) && (temp.get(Calendar.DATE) == 1)) {
            return year * 12 + month;
        } else if ((startCalendar.get(Calendar.DATE) == 1) && (temp.get(Calendar.DATE) != 1)) {
            return year * 12 + month;
        } else {
            return (year * 12 + month - 1) < 0 ? 0 : (year * 12 + month);
        }
    }

    /**
     * 查看两个时间段之内有多少个月份
     *
     * @param date1 <String>
     * @param date2 <String>
     * @return int
     * @throws ParseException
     */
    public static int getMonthSpace(Date date1, Date date2)
            throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar bef = Calendar.getInstance();
        Calendar aft = Calendar.getInstance();
        bef.setTime(date1);
        aft.setTime(date2);
        int result = aft.get(Calendar.MONTH) - bef.get(Calendar.MONTH);
        int month = (aft.get(Calendar.YEAR) - bef.get(Calendar.YEAR)) * 12;
        return month + result;

    }


    /**
     * 获取某个时间xx个月后的时间
     *
     * @param date
     * @return
     */
    public static Date getDateAfterMonthDate(Date date, Integer x) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, x);
        return calendar.getTime();
    }

    /**
     * 获取某个时间xx个月后的时间
     *
     * @param date
     * @return
     */
    public static Date getDateBeforeMonthDate(Date date, Integer x) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, -x);
        return calendar.getTime();
    }

    /**
     * 获取某个时间xx天前的日期
     * 例如 传入（2018-12-20，2） 得到 2018-12-18
     *
     * @param date
     * @return
     */
    public static Date getDateBeforeDay(Date date, Integer x) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, -x);
        return calendar.getTime();
    }

    /**
     * 获取某个时间xx天后的日期
     *
     * @param date
     * @return
     */
    public static Date getDateAfterDay(Date date, Integer x) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, +x);
        return calendar.getTime();
    }

    /**
     * 获取某个时间xx天后的日期
     *
     * @param date
     * @return
     */
    public static Date getDateAfterDate(Date date, Integer x) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, +x);
        return calendar.getTime();
    }

    /**
     * 通过时间秒毫秒数判断两个时间的间隔天数
     *
     * @param date1
     * @param date2
     * @return
     */
    public static int differentDaysByMillisecond(Date date1, Date date2) {
        int days = (int) ((date2.getTime() - date1.getTime()) / (1000 * 3600 * 24));
        return days;
    }

    public static void main(String[] args) throws ParseException {
        SimpleDateFormat sj = new SimpleDateFormat("yyyy-MM-dd");
        Date start = sj.parse("2018-11-20");
        Date end = sj.parse("2019-1-16");
        System.out.println(getMonthBetween(start,end));

//        SimpleDateFormat sj = new SimpleDateFormat("yyyy-MM-dd");
//        Date dateAfterDay = getDateAfterDay(new Date(), 3);
//        Date dateBeforeDay = getDateBeforeDay(new Date(), 3);
//        System.out.println(sj.format(dateAfterDay));
//        System.out.println(sj.format(dateBeforeDay));

//        SimpleDateFormat sj = new SimpleDateFormat("yyyy-MM-dd");


//        //2019-01-25,当前时间1个月后的时间
//        Date dateAfterDate = getDateAfterDate(new Date(), 1);
//        //2019-01-24，某个时间前一天的时间
//        Date dateBeforeDay = getDateBeforeDay(dateAfterDate, 1);
//
//        System.out.println(dateAfterDate.getTime()>dateBeforeDay.getTime());
//
//        System.out.println(sj.format(dateBeforeDay));
//        System.out.println(sj.format(dateAfterDate));

       /* SimpleDateFormat sj = new SimpleDateFormat("yyyy-MM-dd");
        Date before = sj.parse("2018-12-29");

        Date date = sj.parse("2019-3-29");

        Date after = sj.parse("2019-4-29");


        System.out.println(date.compareTo(after) >= 0);*/

//        System.out.println(new BigDecimal(-33.35).doubleValue());
//        System.out.println(date.compareTo(before)>=0 && date.compareTo(after)>=0);
//        System.out.println(date.compareTo(before)>=0);
//        System.out.println(date.compareTo(after)>=0);

//        if(true && true){
//            System.out.println(true);
//        }else{
//            System.out.println(false);
//        }

//        int monthSpace = getMonthBetween(startTime, endTime);
//        System.out.println(monthSpace);
//        Date date = DateUtils.addMonths(startTime, 0);

        //System.out.println(sj.format(date));

//        Date dateBeforeMonthDate = getDateBeforeMonthDate(startTime, 1);
//        System.out.println(sj.format(dateBeforeMonthDate));

//        for(int i=0;i<=100;i++){
//            System.out.println(String.format("%02d",i));
//        }
//        Date dateAfterDay = getDateAfterDay(startTime, 3);
//        System.out.println(sj.format(dateAfterDay));
//        int i = differentDaysByMillisecond(startTime, endTime);
//        System.out.println(i);
//
//        int monthSpace = getMonthSpace(startTime, endTime);
//        System.out.println(monthSpace%12==0);

    }

}
