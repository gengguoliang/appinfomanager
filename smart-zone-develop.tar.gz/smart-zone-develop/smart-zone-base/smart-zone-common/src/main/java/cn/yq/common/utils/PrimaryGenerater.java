package cn.yq.common.utils;

import org.apache.commons.lang.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: houqijun
 * @Date: 2018/12/27 16:37
 * @Description:
 */
public class PrimaryGenerater {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    private static Map<String,String> map = new HashMap<String,String>();
    private static Integer m = 0;
    private PrimaryGenerater(){};
    private static PrimaryGenerater primaryGenerater = null;
    /**
     * 取得PrimaryGenerater的单例实现
     *
     * @return
     */
    public static PrimaryGenerater getInstance() {
        if (primaryGenerater == null) {
            synchronized (PrimaryGenerater.class) {
                if (primaryGenerater == null) {
                    primaryGenerater = new PrimaryGenerater();
                }
            }
        }
        return primaryGenerater;
    }

        /**
         * 生成下一个编号
         */
    public static synchronized String geneterNextNumber(String date) {

        String valByKey = GuavaCacheUtil.getValByKey(date);
        //如果缓存中是空值 则设置m=0
        if(StringUtils.isEmpty(valByKey)){
            GuavaCacheUtil.setKeyVal(date,m.toString());
            return geneterNextNumber(sdf.format(new Date()));
        }else{
//            m=m+1;
            m = Integer.parseInt(valByKey);
            m=m+1;
            GuavaCacheUtil.setKeyVal(date,m.toString());
            return date+String.format("%03d",m);
        }

    }

    public static void main(String[] args) {
        String format = sdf.format(new Date());
        String s = geneterNextNumber(format);
        System.out.println(s);
    }

}
