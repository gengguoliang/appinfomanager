package cn.yq.common.result;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@Data
public class Result<T> implements Serializable {

    /**
     * 返回编码
     */
    private String code;
    /**
     * 返回描述
     */
    private String msg;

    /**
     * 返回实体数据
     */
    private T data;

    public Result() {
    }

    public Result(ResultEnum resultEnum) {
        this.code = resultEnum.getCode();
        this.msg = resultEnum.getDesc();
    }

    public Result(ResultEnum resultEnum, T data) {
        this.code = resultEnum.getCode();
        this.msg = resultEnum.getDesc();
        this.data = data;
    }

    public Result(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }


    public Result(String code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public static <T> Result<T> returnOk() {
        return new Result<>(ResultEnum.SUCCESS.getCode(), ResultEnum.SUCCESS.getDesc());
    }

    public static <T> Result<T> returnOk(T t) {
        return new Result<>(ResultEnum.SUCCESS.getCode(), ResultEnum.SUCCESS.getDesc(), t);
    }

    public static <T> Result<T> returnFail() {
        return new Result<>(ResultEnum.FAIL.getCode(), ResultEnum.FAIL.getDesc());
    }

    /*public static <T> Result<T> returnFail(T t) {
        return new Result<>(ResultEnum.FAIL.getCode(), ResultEnum.FAIL.getDesc(), t);
    }*/

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
