package cn.yq.common.enumeration;

/**
 * @program: smart-zone
 * @description: 单号枚举
 * @author: zhengjianhui
 **/
public enum  OrderNumberEnum {

    STOCK_OUT_NO("TK","出库单号"),
    APPLICATION_NO("LY","申请单号"),
    STOCK_IN_NO("RK","入库单号"),
    OABILL_NO("ZD","OA账单编号"),
    DECORA_NO("ZXSQ","装修申请单号");



    private String prefix;
    private String name;
    private OrderNumberEnum(String prefix,String name){
        this.prefix=prefix;
        this.name=name;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getName() {
        return name;
    }
}
