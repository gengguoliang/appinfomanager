package cn.yq.common.enumeration;

/**
 * @program: smart-zone
 * @description: 装修文件类型
 * @author: zhengjianhui
 **/
public enum  DecorationFileEnum {

    /**
     * 授权委托书
     */
    entrust,
    /**
     * 单位营业执照
     */
    license,
    /**
     * 单位资格证书
     */
    certificate,
    /**
     * 安全生产许可证
     */
    security,
    /**
     * 施工图
     */
    images,
    /**
     * 施工方案
     */
    programme;

}
