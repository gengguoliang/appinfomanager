package cn.yq.common.utils;

import cn.yq.common.vo.ContractTemplate;
import cn.yq.common.vo.Signers;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import okhttp3.*;
import org.junit.Test;
import sun.applet.Main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: houqijun
 * @Date: 2019/2/1 11:04
 * @Description:
 */
public class YhtUtil {

    public static final OkHttpClient okHttpClient = new OkHttpClient();

    public static final String apiUrl = "https://api.yunhetong.com/api";

    public static final MediaType type = MediaType.parse("application/x-www-form-urlencoded;charset=utf-8");
    public static final MediaType formType = MediaType.parse("application/json;charset=UTF-8");

    public static Map<String,Object> map = null;


    /**
     * 登录方法
     *
     * @return
     * @throws IOException
     */
    public static String authLogin(String signerId) throws IOException {
        return OKHttpUtil.authLogin(signerId);
    }


    @Test
    public void testLogin() throws IOException {
        System.out.println(OKHttpUtil.authLogin(null));
    }
    
    /**
    *@Description 下载合同
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void testDownLoad() throws IOException {
        File file=new File("C:/Users/ROY/Desktop/YHT.pdf");
        FileOutputStream fos=new FileOutputStream(file);
        Map<String,Object> map=new HashMap<>();
        map.put("idType","0");
        map.put("idContent","1906051139350376");//云合同ID

        String token = authLogin(null);
        //请求body
        RequestBody body = RequestBody.create(formType, JSON.toJSONString(map));
        //请求组合创建
        Request request = new Request.Builder()
                .url(apiUrl+"/download/contract")
                .post(body)
                .addHeader("token",token)
                .build();
        Response response = okHttpClient.newCall(request).execute();

        InputStream inputStream = response.body().byteStream();
        byte[] b = new byte[1024];
        int length = 0;
        while (true) {
            length = inputStream.read(b);
            if (length < 0)
                break;
            fos.write(b, 0, length);
        }

        inputStream.close();
        fos.close();
    }
    
    /**
    *@Description 获取签署验证码
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void testVerificationCode() throws IOException {
        System.out.println(authLogin(null));
        String s = OKHttpUtil.getRequest(apiUrl + "/contract/msg/verificationCode/0/1902271631076199", authLogin("4492619"));
        System.out.println(s);
    }

    /**
    *@Description 签署验证码校验
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @Test
    public void testCheckCode() throws IOException {
        map=new HashMap<>();
        map.put("idType","0");
        map.put("idContent","1902271631076199");
        map.put("verificationCode","2660");//验证码，四位数字
        String s=OKHttpUtil.postRequest(map,apiUrl+"/contract/msg/verificationCode",authLogin("4492619"));
        System.out.println(s);
    }

    /**
     * 创建个人用户
     * signerId：4228807
     *
     * 4234336
     * @throws IOException
     */
    @Test
    public void createUser() throws IOException {
        map = new HashMap<String,Object>();
        /*map.put("userName","毕晓梅");
        map.put("identityRegion","0");
        map.put("certifyType","a");
        map.put("certifyNum","110101199003070417");
        map.put("phoneRegion","0");
        map.put("phoneNo","15920584878");
        map.put("caType","B2");*/
        map.put("userName","zjh");
        map.put("identityRegion","0");
        map.put("certifyNum","110101199003078996");
        map.put("phoneRegion","0");
        map.put("phoneNo","11111111111");
        map.put("caType","B2");
        String s = OKHttpUtil.postRequest(map, apiUrl+"/user/person", authLogin(null));
        System.out.println(s);
        //李帅 "signerId":4434064
    }
    @Test
    public void getUser() throws IOException {
        map=new HashMap<>();
        List<String> list=new ArrayList<>();
        list.add("410423198902258035");
        list.add("430481199310109599");
        map.put("certifyNumList",list);
        String s=OKHttpUtil.postRequest(map,apiUrl+"/user/signerId/certifyNums",authLogin(null));
        System.out.println(s);
    }
    
    
    /**
    *@Description 查询用户信息
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test9() throws IOException {
        map=new HashMap<>();
        List<String> list=new ArrayList<>();
        list.add("5669992");
        //list.add("4480716");
        map.put("signerIdList",list);
        String s=OKHttpUtil.postRequest(map,apiUrl+"/user/userInfo/signerIds",authLogin(null));
        System.out.println(s);
    }
    
    /**
    *@Description 创建企业用户
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void createCompany() throws IOException {
        map = new HashMap<>();
        map.put("userName", "榆钱（北京）科技有限公司");
        map.put("certifyType", "1");//：1.社会信用代码
        map.put("certifyNum", "911101087877515792");
        map.put("caType", "B2");
        String s = OKHttpUtil.postRequest(map, apiUrl + "/user/company", authLogin(null));
        System.out.println(s);//4582057
    }
    
    
    /**
    *@Description 更新个人用户信息
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test10() throws IOException {
        map = new HashMap<>();
        map.put("signerId", "5447230");
        map.put("phoneRegion", "0");
        map.put("phoneNo", "13022091007");
        map.put("userName", "hui1");
        String s = OKHttpUtil.putRequest(map, apiUrl + "/user/companyNameAndPhone", authLogin(null));
        System.out.println(s);
    }
    
    /**
    *@Description 修改企业用户
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test6() throws IOException {
        map = new HashMap<>();
        map.put("signerId", "5669992");
        //map.put("userName", "榆钱（北京）科技有限公司");
        map.put("phoneRegion", "0");
        map.put("phoneNo", "13022091009");
        String s = OKHttpUtil.putRequest(map, apiUrl + "/user/companyNameAndPhone", authLogin(null));
        System.out.println(s);
    }
    
    /**
    *@Description 根据证件号批量查询signerId
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test1() throws IOException {
        map=new HashMap<>();
        List<String> list=new ArrayList<>();
        list.add("91110302096768056L");
        map.put("certifyNumList",list);
        String s = OKHttpUtil.postRequest(map, apiUrl + "/user/signerId/certifyNums", authLogin(null));
        System.out.println(s);
    }
    
    @Test
    public void getUserBySignerIds() throws IOException {
        map=new HashMap<>();
        List<String> list=new ArrayList<>();
        list.add("4480716");
        map.put("signerIdList",list);
        map.put("pageNum ",1);
        map.put("pageSize",12);
        String s=OKHttpUtil.postRequest(map,apiUrl+"/user/userInfo/signerIds",authLogin(null));
        System.out.println(s);
        JSONObject jsonObject = JSONObject.parseObject(s);
        String s1 = jsonObject.getString("data");
        JSONObject jsonObject1 = JSONObject.parseObject(s1);
        String total=jsonObject1.getString("total");
        System.out.println(total);
    }

    /**
    *@Description 创建企业印章
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test2() throws IOException {
        map = new HashMap<>();
        map.put("signerId", "5322930");
        map.put("styleType", "1");
        map.put("textContent", "合同专用章");
        map.put("color", "C1");
        //map.put("keyContent","3247928919031");
        String s = OKHttpUtil.postRequest(map, apiUrl + "/user/companyMoulage", authLogin(null));
        System.out.println(s);
    }
    
    /**
    *@Description 删除印章
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test5() throws IOException {
        String s = OKHttpUtil.deleteRequest(apiUrl + "/user/moulage/5970758", authLogin(null));
        System.out.println(s);//5954715 5956444 5955851 5955775 5956693 5956640 5970758
    }
    /**
     *@Description 获取印章列表
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    @Test
    public void test7() throws IOException {
        String s = OKHttpUtil.getRequest(apiUrl + "/user/moulageId/5670068/1/100", authLogin(null));
        System.out.println(s);
    }




    /**
     * 创建个人印章
     * signerId：4228807
     * @throws IOException
     */
    @Test
    public void personMoulage() throws IOException {
        map = new HashMap<String,Object>();
        map.put("signerId","4490857");
        map.put("borderType ","B1");
        map.put("fontFamily ","F1");
        map.put("color ","C1");
        map.put("mode ","0");
        map.put("zoomCode ","0");
        String s = OKHttpUtil.postRequest(map, apiUrl+"/user/personMoulage", authLogin(null));
        System.out.println(s);
    }

    /**
     * 查看合同
     * @throws IOException
     */
    public static void lookContract() throws IOException {
        System.out.println();
    }

    /**
     * 添加签署人
     * signerId：4228807
     * @throws IOException
     */
    @Test
    public void addSigner() throws IOException {
        map = new HashMap<String,Object>();
        map.put("idType","0");
        map.put("idContent","1905201626234285");
        List<Signers> list = new ArrayList<Signers>();
        Signers signers = new Signers();
        //签署者 id
        signers.setSignerId("5323350");
        //签署的定位方式：0=关键字定位，1=签名占位符
        //定位，2=签署坐标
        signers.setSignPositionType("0");
        ////对应定位方式的内容，如果用签名占位符定位可以
        //传多个签名占位符，并以分号隔开,最多 20 个;如果用签署坐标定位，则该参数包含三个
        //信息：“页面,x 轴坐标,y 轴坐标”（如 20,30,49）
        signers.setPositionContent("承租人手写章");
        //签署验证方式：0=不校验，1=短信验证
        signers.setSignValidateType("1");
        //印章使用类型（针对页面签署）：0=指定印章，1=每次绘制
        signers.setSignMode("1");
        //签署形态，0=JS 集成页面(默认)，1=独立 H5 页面
        signers.setSignForm("0");
        list.add(signers);
        map.put("signers",list);
        String s = OKHttpUtil.postRequest(map, apiUrl+"/contract/signer", authLogin(null));
        System.out.println(s);
    }

    /**
     *@Description 查看合同状态
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    @Test
    public void test4 () throws IOException{
        String s = OKHttpUtil.getRequest(apiUrl + "/contract/status/0/1907221831449896", authLogin(null));
        System.out.println(s);
    }

    /**
    *@Description 查看合同详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @Test
    public void test3() throws IOException {
        String s = OKHttpUtil.getRequest(apiUrl + "/contract/detail/0/1907221831449896", authLogin(null));
        System.out.println(s);
    }

    /**印章id5459947
     * 5460014
     * 合同签署
     * @throws IOException
     */
    @Test
    public void signatureContract() throws IOException {
        map = new HashMap<String,Object>();
        map.put("idType","0");
        map.put("idContent","1905311035561366");
        map.put("signerId","5410177");
        String s = OKHttpUtil.postRequest(map, apiUrl+"/contract/sign", authLogin(null));
        System.out.println(s);
    }



    /**
     * 查看合同状态
     * @throws IOException
     */
    @Test
    public void signStatus() throws IOException {
        String s = OKHttpUtil.getRequest(apiUrl+"/contract/status/0/1901311835082793",authLogin(null));
        System.out.println(s);
    }



}
