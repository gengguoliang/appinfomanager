package cn.yq.common.vo;

import lombok.Data;

/**
 * @Author: houqijun
 * @Date: 2019/2/1 10:43
 * @Description:
 */
@Data
public class Signers {
    private String signerId;
    private String signPositionType;
    private String positionContent;
    private String signValidateType;
    private String signMode;
    private String signForm;

}
