package cn.yq.common.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.MessageSourceAccessor;

/**
 * @author: yinqk
 * @date: 2019-08-14 16:58
 * @description: TODO
 */
@Configuration
public class MessageSourceConfiguration {

    @Autowired
    private MessageSource messageSource;

    @Bean
    @ConditionalOnMissingBean(MessageSourceAccessor.class)
    public MessageSourceAccessor messageSourceAccessor() {
        return new MessageSourceAccessor(messageSource);
    }
}
