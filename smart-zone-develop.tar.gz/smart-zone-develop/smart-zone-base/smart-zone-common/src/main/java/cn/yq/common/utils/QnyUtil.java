package cn.yq.common.utils;

import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * @program: smart-zone
 * @description: 七牛云
 * @author: zhengjianhui
 **/
@Slf4j
public class QnyUtil {

    private static final String accessKey = "your access key";
    private static final String secretKey = "your secret key";
    private static final String bucket = "yq-smart-zone";
    private static final String upToken = "z2p9DnMJwAc23uvM9OTuyxdtNTbqcorVDnXXwo_b:eArPnaWGfJVO_fzZcwzlGvN2yas=:eyJzY29wZSI6InlxLXNtYXJ0LXpvbmUiLCJkZWFkbGluZSI6MTYwODUxNjM2Nn0=";
    private static final String prefix = "http://kodo.smart-zone.51yuqian.net/";
    private static final UploadManager uploadManager;

    static {
        Configuration cfg = new Configuration(Zone.zone0());
        uploadManager = new UploadManager(cfg);
    }

    /**
     * @Description 七牛云数据流上传
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    public static String uploadByInputStream(InputStream inputStream) {
        //默认不指定key的情况下，以文件内容的hash值作为文件名
        String key = null;
        try {
            Response response = uploadManager.put(inputStream, key, upToken, null, null);
            //解析上传成功的结果
            DefaultPutRet putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
            System.out.println(putRet.key);
            System.out.println(putRet.hash);
            String url = prefix + putRet.key;
            return url;
        } catch (QiniuException ex) {
            Response r = ex.response;
            System.err.println(r.toString());
            try {
                System.err.println(r.bodyString());
            } catch (QiniuException ex2) {
                //ignore
            }
        }
        return null;
    }

    /**
     * @Description 请求访问网络文件得到输入流
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    public static InputStream getInputStream(String urlStr) {
        InputStream is = null;
        try {
            //URL url = new URL(UriUtils.encodePath(urlStr, "UTF-8"));
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Content-Type", "plain/text;charset=UTF-8");
            conn.setRequestProperty("charset", "UTF-8");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("GET");
            conn.connect();
            is = conn.getInputStream();
            return is;
        } catch (IOException e) {
            log.error("请求访问网络文件出现异常:", e);
            return null;
        }
    }

    /**
     * @Description 请求访问网络文件得到字节数组
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    public static byte[] getByte(String urlStr) {
        InputStream is = null;
        ByteArrayOutputStream os = null;
        byte[] buff = new byte[1024];
        int len = 0;
        try {
            is = getInputStream(urlStr);
            os = new ByteArrayOutputStream();
            while ((len = is.read(buff)) != -1) {
                os.write(buff, 0, len);
            }
            return os.toByteArray();
        } catch (IOException e) {
            return null;
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    log.error("【关闭流异常】");
                }
            }
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {
                    log.error("【关闭流异常】");
                }
            }
        }
    }


    private static final MediaType formType = MediaType.parse("application/json;charset=UTF-8");
    private static final String apiUrl = "https://api.yunhetong.com/api";
    private static final OkHttpClient okHttpClient = new OkHttpClient();

    /**
     * @Description 把云合同上传至七牛云
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    public static String uploadYht(String yhtId) throws IOException {
        Map<String, Object> map = new HashMap<>();
        map.put("idType", "0");
        map.put("idContent", yhtId);//云合同ID

        String token = OKHttpUtil.authLogin(null);
        //请求body
        RequestBody body = RequestBody.create(formType, JSON.toJSONString(map));
        //请求组合创建
        Request request = new Request.Builder()
                .url(apiUrl + "/download/contract")
                .post(body)
                .addHeader("token", token)
                .build();
        okhttp3.Response response = okHttpClient.newCall(request).execute();
        InputStream inputStream = response.body().byteStream();
        //System.out.println(inputStream);

        //上传
        String url = uploadByInputStream(inputStream);
        System.out.println(url);
        return url;

    }


    /**
     *@Description
     *@Param
     *@Return
     *@Author zhengjianhui
     */

}
