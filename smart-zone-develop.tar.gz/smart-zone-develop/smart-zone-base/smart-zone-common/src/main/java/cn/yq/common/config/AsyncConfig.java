package cn.yq.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Configuration
@EnableAsync // 开启异步事件的支持( 在定时任务的类或者方法上添加@Async)
public class AsyncConfig implements AsyncConfigurer {

    /**
     *  定时任务所用线程池
     * @return
     */
    @Bean
    public Executor springTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("SpringTask-Executor");//设置线程名前缀
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.DiscardPolicy());//策略，不能执行的任务将被丢弃
        executor.initialize();
        return executor;
    }

    /**
     *  springboot 异步任务所用线程池
     * @return
     */
    @Bean
    public Executor asyncTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(125);//估计设置10就行了
        executor.setThreadNamePrefix("AsyncTask-Executor");//设置线程名前缀
        //executor.setKeepAliveSeconds(2);
        //策略：主线程直接执行该任务，执行完之后尝试添加下一个任务到线程池中，可以有效降低向线程池内添加任务的速度
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }


}
