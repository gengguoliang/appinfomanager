package cn.yq.common.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * @program: smart-zone
 * @description: 单号
 * @author: zhengjianhui
 **/
public class NoRandom {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    public static String getNo(Date date) {
        String format = sdf.format(date);
        return format + getRandNum(4);
    }

    /**
     * @Description 生成leng长度的随机数
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    public static String getRandNum(int leng) {
        Random random = new Random();
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < leng; i++) {
            result.append(random.nextInt(10));
        }
        if (result.length() > 0) {
            return result.toString();
        }
        return null;
    }


    public static void main(String[] args) {
        System.out.println(getNo(new Date()));
    }
}
