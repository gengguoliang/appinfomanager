package cn.yq.common.enumeration;

/**
 * @author: yinqk
 * @date: 2019-04-04 10:43
 * @description: 支付方式
 */
public enum PaymentType {
    /**
     * 支付宝
     */
    ALIPAY,

    /**
     * 微信
     */
    WXPAY,

    /**
     * 现金
     */
    CASH,

    /**
     * 转账
     */
    TRANSFER
}
