package cn.yq.common.utils;

import com.alibaba.fastjson.JSON;
import okhttp3.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: houqijun
 * @Date: 2019/1/24 17:17
 * @Description:
 */
public class OKHttpUtil {
    public static final OkHttpClient okHttpClient = new OkHttpClient();
    public static final MediaType type = MediaType.parse("application/x-www-form-urlencoded;charset=utf-8");
    public static final MediaType formType = MediaType.parse("application/json;charset=UTF-8");


    /**
     * 登录方法
     *
     * @return
     * @throws IOException
     */
    public static String authLogin(String signerId) throws IOException {
        HashMap<Object, Object> map = new HashMap<>();
        map.put("appId", "2019012318264100030");
        map.put("appKey", "Oa1sBbcmky");
        map.put("signerId", signerId);
        String param = JSON.toJSONString(map);
        //请求body
        RequestBody body = RequestBody.create(formType, param);
        //请求组合创建
        Request request = new Request.Builder()
                .url("https://api.yunhetong.com/api/auth/login")
                .post(body)
                .build();
        Response response = okHttpClient.newCall(request).execute();
        return response.header("token");
    }


    public static String getRequest(String url,String token) throws IOException {
        //请求组合创建
        Request request = new Request.Builder().url(url).get().addHeader("token",token).build();
        Response response = okHttpClient.newCall(request).execute();
        String string = response.body().string();
        return string;
    }

    public static String deleteRequest(String url,String token) throws IOException {
        //请求组合创建
        Request request = new Request.Builder().url(url).delete().addHeader("token",token).build();
        Response response = okHttpClient.newCall(request).execute();
        String string = response.body().string();
        return string;
    }

    /**
     *
     * @param map 参数
     * @param url 请求路径
     * @param token 长效令牌
     * @return
     * @throws IOException
     */
    public static String postRequest(Map<String,Object> map,String url,String token) throws IOException {
        //请求body
        RequestBody body = RequestBody.create(formType, JSON.toJSONString(map));
        //请求组合创建
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("token",token)
                .build();
        Response response = okHttpClient.newCall(request).execute();
        String string = response.body().string();
        return string;
    }

    public static String putRequest(Map<String,Object> map,String url,String token) throws IOException {
        //请求body
        RequestBody body = RequestBody.create(formType, JSON.toJSONString(map));
        //请求组合创建
        Request request = new Request.Builder()
                .url(url)
                .patch(body)
                .addHeader("token",token)
                .build();
        Response response = okHttpClient.newCall(request).execute();
        String string = response.body().string();
        return string;
    }



}
