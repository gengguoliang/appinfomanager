package cn.yq.common.utils;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Author: houqijun
 * @Date: 2018/12/27 16:00
 * @Description:
 */
public class DateNumUtil {

    private static final SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
    private static final SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat sdf4 = new SimpleDateFormat("yyyy年MM月dd日 HH时mm分ss秒");
    private static final SimpleDateFormat sdf5 = new SimpleDateFormat("yyyyMMdd");

    public static String getDateNumber(){
        return null;
    }

}
