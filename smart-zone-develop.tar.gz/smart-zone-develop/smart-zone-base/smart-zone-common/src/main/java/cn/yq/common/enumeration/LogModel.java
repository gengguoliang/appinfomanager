package cn.yq.common.enumeration;

import lombok.Data;

/**
 * @Author: houqijun
 * @Date: 2019/1/9 15:38
 * @Description:
 */
public enum LogModel{

    /*
     * 操作的是那张表
     */
    CUSTOMER("rental_customer"),
    REPAIR("repair");

    private String tableName;

    LogModel(String tableName){
        this.tableName = tableName;
    }



}
