package cn.yq.common.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @program: smart-zone
 * @description: 云合同JSON解析工具类
 * @author: zhengjianhui
 **/
public class YhtJsonUtil {

    public static String getString(String json, String model) {
        try {
            JSONObject jsonObject = JSONObject.parseObject(json);
            String[] split = StringUtils.split(model, ".");
            String result = null;
            JSONArray jsonArray = null;
            for (int i = 0; i < split.length; i++) {
                if (StringUtils.contains(split[i], "[")) {
                    result = jsonArray.getString(getNum(split[i]));
                } else {
                    result = jsonObject.getString(split[i]);
                }
                if (i == split.length - 1) break;
                if (StringUtils.startsWith(result, "[")) {
                    jsonArray = JSONObject.parseArray(result);
                } else {
                    jsonObject = JSONObject.parseObject(result);
                }
            }
            return result;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取一个字符串中的数字
     */
    public static int getNum(String str) {
        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        String resultString = m.replaceAll("").trim();
        int result = Integer.parseInt(resultString);
        return result;
    }

    public static void main(String[] args) {
        String str = "{" +
                "\"code\": 200," +
                "\"msg\": true," +
                "\"data\": {" +
                "\"page\": 1," +
                "\"totalPages\": 1," +
                "\"pageSize\": 2," +
                "\"total\": 2," +
                "\"userList\": [{" +
                "\"signerId\": 1," +
                "\"userName\": \"张三\"," +
                "\"certifyNum\": \"123456789987654321\"," +
                "\"phoneNo\": \"13000000000\"," +
                "\"userType\": \"个人\"" +
                "}," +
                "{" +
                "\"signerId \": 2," +
                "\"userName\": \"浙江律讯网络科技有限公司\"," +
                "\"certifyNum\": \"123456789\"," +
                "\"phoneNo\": \"13000000000\"," +
                "\"userType\": \"企业\"" +
                "}" +
                "]" +
                "}" +
                "}";
        System.out.println("========>"+getString(str, "data.userList.[1].userType"));
    }
}
