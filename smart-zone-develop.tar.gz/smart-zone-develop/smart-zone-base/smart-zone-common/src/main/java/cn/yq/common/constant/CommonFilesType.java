package cn.yq.common.constant;

/**
 * @Author: houqijun
 * @Date: 2019/1/5 11:14
 * @Description:
 */
public class CommonFilesType {

    public static final String CONTRACT = "contract";

    public static final String DECORATION = "decoration";//装修

    public static final String OABILL="aobill";//OA账单文件


}
