package cn.yq.common.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Author:houqijun houqijun
 * @Date: 2018/12/3 11:17
 * @Description:
 */
@Data
public class AuthUser implements Serializable {

    private Integer id;

    private Integer projectId;

    private Integer departmentId;

    private String username;

    private String name;

    private String password;

    private String mobile;

    private Boolean isLocked;

    private Boolean isDel;

    private Integer organizationId;

    private Integer isAdmin;

    private List<String> roles;

}
