package cn.yq.common.constant;

/**
 * @Author: houqijun
 * @Date: 2019/1/9 15:45
 * @Description:
 */
public class LogTableConstant {

    public static final String SYSTEM = "";

    public static final String CUSTOMER = "rental_customer";

    public static final String FOLLOW_UP_RECORD = "rental_customer_follow_up_record";

    public static final String NOTICE = "common_notice";

    public static final String MY_CONTACT_US = "my_contact_us";

    public static final String MY_ENTERPRISE_CERTIFICATION = "my_enterprise_certification";

    public static final String MY_FEEDBACK = "my_feedback";

    public static final String ADVERTISING = "oa_advertising_position_apply";

    public static final String SYS_DICT_DATA ="sys_dict_data";

    public static final String OA_BILL = "oa_bill";

    public static final String OA_BUSINESS_COOPERATIVE = "oa_business_cooperative";

    public static final String OA_BUSINESS_ACTIVITY = "oa_business_activity";

    public static final String OA_BUSINESS_CATEGORY = "oa_business_category";

    public static final String OA_CHANNEL = "oa_channel";

    public static final String CONFERENCE_RESERVATION = "oa_conference_reservation";

    public static final String CONFERENCEROOM = "oa_conferenceroom";

}
