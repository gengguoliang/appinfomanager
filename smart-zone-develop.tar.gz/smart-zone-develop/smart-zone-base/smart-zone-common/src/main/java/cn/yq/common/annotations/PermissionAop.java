package cn.yq.common.annotations;

import java.lang.annotation.*;

/**
 * @author: yinqk
 * @date: 2019-06-05 22:24
 * @description: 数据权限过滤
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface PermissionAop {
    String value() default "";

    String userIdColumnName() default "user_id";

    String departmentIdColumnName() default "department_id";
}