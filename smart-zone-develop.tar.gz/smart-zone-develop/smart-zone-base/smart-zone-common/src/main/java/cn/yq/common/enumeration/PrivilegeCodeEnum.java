package cn.yq.common.enumeration;

/**
 * @program: smart-zone
 * @description: 模块权限的Code值
 * @author: zhengjianhui
 **/
public enum PrivilegeCodeEnum {

    /**
     * 办公审批
     */
    office_approval,

    /**
     * 报修派工
     */
    repair_job,

    /**
     * 派工审核
     */
    job_audit;
}
