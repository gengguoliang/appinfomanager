package cn.yq.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @program: smart-zone 重置流指针，让其可重复读
 * @description:
 * @author: zhengjianhui
 **/
public class InputStreamFactory {

    private ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    private byte[] buffer = new byte[1024];

    public InputStreamFactory(InputStream input) throws IOException {
        int len;
        while ((len = input.read(buffer)) > -1) {
            byteArrayOutputStream.write(buffer, 0, len);
        }
        byteArrayOutputStream.flush();
    }

    public InputStream newInputStream() {
        return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
    }

}
