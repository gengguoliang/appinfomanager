package cn.yq.common.constant;

import org.omg.CORBA.PUBLIC_MEMBER;

/**
 * @Author: houqijun
 * @Date: 2018/12/14 14:09
 * @Description:
 */
public class CustomerConstant {

    //客户已签约
    public static final Integer SIGNED = 1;
}
