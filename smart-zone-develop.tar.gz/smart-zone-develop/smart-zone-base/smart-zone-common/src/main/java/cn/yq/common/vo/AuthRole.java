package cn.yq.common.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author:houqijun houqijun
 * @Date: 2018/12/3 14:45
 * @Description:
 */
@Data
public class AuthRole implements Serializable {

    private Integer id;
    private String code;
    private String roleName;

}
