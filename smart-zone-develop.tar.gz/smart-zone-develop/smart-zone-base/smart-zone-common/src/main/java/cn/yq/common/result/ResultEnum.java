package cn.yq.common.result;

public enum ResultEnum {

    SUCCESS("0", "成功"),
    IS_LOCKED("01", "账户被禁用"),
    FAILM("01", "删除失败，该部门有所属人员"),
    DATA_NULL("02", "没有数据"),
    FAIL("0001", "失败"),
    UNAUTHENTICATED("0002", "没有权限"),
    //SERVER_ERROR("0003", "系统服务异常"),
    SERVER_ERROR("0003", "系统繁忙，请稍后再试"),
    LOGIN_SESSION_MISS("0004", "会话失效"),
    LOGIN_SUCCESS("0005", "登录成功"),
    LOGIN_FAIL("0006", "登录失败"),
    LOGIN_USER_ERR("0007", "用户名或密码错误"),
    LOGOUT_FAIL("0008", "注销失败"),
    TOKEN_MISS("0009", "令牌缺失"),
    FEIGN_FAIL("0010", "feign远程调用失败"),
    TOKEN_FAIL("0011", "token校验失败"),
    ZUUL_FAIL("0012", "服务调用异常"),
    UNAUTHORIZED_FAIL("400", "未授权"),
    FROZEN("0016", "账户被冻结");


    ResultEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    private String code;
    private String desc;

    public String getCode() {
        return this.code;
    }

    public String getDesc() {
        return this.desc;
    }

}
