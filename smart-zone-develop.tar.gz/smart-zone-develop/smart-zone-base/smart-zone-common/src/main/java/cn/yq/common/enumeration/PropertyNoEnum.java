package cn.yq.common.enumeration;

/**
*@Description 业务办理单号
*@Param 
*@Return 
*@Author zhengjianhui
*/
public enum PropertyNoEnum {

    CART_APPLICATION_NO("ZXSQ","推车申请单号"),
    AD_APPLICATION_NO("ADSF","广告申请编号"),
    CW_APPLICATION_NO("CWSQ","车位申请编号");


    private String prefix;
    private String name;
    PropertyNoEnum(String prefix,String name){
        this.prefix=prefix;
        this.name=name;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getName() {
        return name;
    }
    
}
