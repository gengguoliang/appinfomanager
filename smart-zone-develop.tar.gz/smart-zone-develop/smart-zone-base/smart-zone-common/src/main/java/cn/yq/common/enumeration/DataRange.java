package cn.yq.common.enumeration;

/**
 * @author: yinqk
 * @date: 2019-06-06 14:23
 * @description: TODO
 */
public enum DataRange {
    ALL(1, "所有数据"),
    DEPARTMENT_AND_CHILDREN(2, "所在部门及以下数据"),
    DEPARTMENT(3, "所在部门数据"),
    SELF(4, "仅本人数据"),
    CUSTOM(5, "按明细设计");

    public int getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }

    private final int value;
    private final String desc;

    DataRange(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }
}