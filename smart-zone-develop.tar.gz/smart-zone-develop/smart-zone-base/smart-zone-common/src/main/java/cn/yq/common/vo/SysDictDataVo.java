package cn.yq.common.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Auther: houqijun
 * @Date: 2018/12/13 14:16
 * @Description:
 */
@Data
public class SysDictDataVo implements Serializable {

    private static final long serialVersionUID = 4558917482027657592L;
    private String dictLabel;

    private String dictValue;
}
