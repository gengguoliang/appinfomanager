package cn.yq.common.enumeration;

/**
 * 字典类型
 */
public enum DictionaryType {
    /**
     * 楼宇地块
     */
    rental_massif,
    /**
     *楼宇分期
     */
    rental_stages,
    /**
     *业态
     */
    biz_model,
    /**
     * 客户状态
     */
    customer_status,
    /**
     * 客户类型
     *
     */
    customer_type,
    /**
     *所属行业
     */
    customer_profession,
    /**
     *客户来源
     */
    customer_from,
    /**
     * 客户来源名称
     *
     */
    customer_from_name,
    /**
     * 客户有效期
     */
    customer_effective,

    /**
     * 退租状态
     */
    exit_lease,

    /**
     * 费用类型
     */
    cost_type,

    /**
     *支付状态
     */
    payment_status,

    /**
     * 账单类型
     */

    bill_type,

    /**
     * 报修区域
     */
    repair_area,

    /**
     * 报修类型
     */
    repair_type,

    /**
     * 紧急程度
     */
    emergency_level,
    /**
     * 报修状态
     */
    repair_status,
    /**
     * 人员专业
     */
    person_major,
    /**
     * 费项名称
     */
    cost_name,
    zdcy,
    gxjsqy,
    ssdd,
    /**
     * 公区类别
     */
    public_area_type,
    /**
     * 合同账单支付的方式
     */
    payment_type;

}
