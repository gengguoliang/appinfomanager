package cn.yq.common.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * @author: yinqk
 * @date: 2019-04-30 13:09
 * @description: TODO
 */
public class SecurityUtils {

    /*public static user getPrincipal() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal != null) {
            if (principal instanceof User) {
                return (User) principal;
            } else {
                throw new IllegalStateException("获取用户数据失败");
            }
        }
        return null;
    }*/
}