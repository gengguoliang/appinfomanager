package cn.yq.common.annotations;

import java.lang.annotation.*;

/**
 * 当前登陆用户的信息注解
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LoginUser {


}
