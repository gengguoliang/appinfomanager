package cn.yq.common.constant;

/**
 * @Author: houqijun
 * @Date: 2019/1/3 08:49
 * @Description:
 */
public class ContractStatus {

    public static final Integer DRAFT = 1;
}
