package cn.yq.common.base;

/**
 * @author Administrator
 * @Package cocom.mycloud.admin.base
 * @Description: BaseController
 * @date 2018/4/17 11:08
 */
public class BaseController {


}
