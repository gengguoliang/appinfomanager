package cn.yq.common.utils;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

import java.util.concurrent.TimeUnit;

/**
 * @Author: houqijun
 * @Date: 2018/12/28 10:57
 * @Description:
 */
public class GuavaCacheUtil {
    private static Cache<String, String> loadingCache = CacheBuilder.newBuilder()
            /*设置缓存容器的初始容量大小为10*/
            .initialCapacity(10)
            /*设置缓存容器的最大容量大小为100*/
            .maximumSize(100)
            /*设置记录缓存命中率*/
            .recordStats()
            /*设置并发级别为8，智并发基本值可以同事些缓存的线程数*/
            .concurrencyLevel(8)
            /*设置过期时间为1天*/
            .expireAfterAccess(1, TimeUnit.DAYS).build();

    public static void setKeyVal(String key, String value){
        loadingCache.put(key, value);
    }

    public static String getValByKey(String key){
        String value = loadingCache.getIfPresent(key);
        return value;
    }
    public static void delKey(String key){
        loadingCache.invalidate(key);
    }
}
