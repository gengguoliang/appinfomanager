package cn.yq.common.annotations;


import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.enumeration.LogModel;

import java.lang.annotation.*;

/**
 * 系统日志自定义注解
 * @author houqijun
 */
@Target({ElementType.PARAMETER, ElementType.METHOD})//作用于参数或方法上
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SystemLog {

        /**
         * 日志名称
         * @return
         */
        String description() default "" ;

        /**
         * 操作模块名称(默认为系统日志)
         */
        String table() default LogTableConstant.SYSTEM;
}
