package cn.yq.common.vo;

import lombok.Data;

import javax.naming.directory.SearchResult;
import java.io.Serializable;
import java.util.Map;

/**
 * @Author: houqijun
 * @Date: 2019/1/23 19:18
 * @Description:
 */
@Data
public class ContractTemplate implements Serializable {

    /*合同标题*/
    private String contractTitle;

    /*模板id*/
    private String templateId;

    /*合同自定义编号",可选参数，不传时默认与合同 id 相同*/
    private String templateNo;

    /*占位符里面的数据必传参数*/
//    private ContractVo contractData;

    private Map<String,String> contractData;

}
