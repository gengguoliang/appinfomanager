package cn.yq.common.aspect;

import cn.yq.common.utils.GsonUtil;
import cn.yq.common.utils.ObjectConvertUtil;
import cn.yq.common.vo.AuthUser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;

/**
 * @Author:houqijun houqijun
 * @Date: 2018/12/12 12:05
 * @Description: 给controller层注入当前用户信息
 * 使用方法
 * 使方法的第一个参数是当前操作用户的信息
 * @postMapping("xxxxxxxx") public void test(AuthUser authUser){
 * log.debug(authUser);
 * }
 */
@Slf4j
@Aspect
@Component
public class LoginUserSessionAspect {


    @Autowired(required = false)
    private HttpServletRequest request;

    /**
     * 定义切入点，
     * 定义切入点，切入点为带有@LoginUser下的所有函数
     */
    @Pointcut("@annotation(cn.yq.common.annotations.LoginUser)")
    public void initLoginUser() {
    }


    /**
     * 前置通知：在连接点之前执行的通知
     *
     * @param joinPoint
     * @throws Throwable
     */
    @Before("initLoginUser()")
    public void doBefore(JoinPoint joinPoint) throws Throwable {
        String header = request.getHeader("X-AUTH-ID");
        AuthUser authUser = null;

        if (!StringUtils.isBlank(header)) {
            String authUserString = URLDecoder.decode(header, "UTF-8");
            log.debug("header==>{}", header);
            authUser = GsonUtil.changeGsonToBean(authUserString, AuthUser.class);
            log.debug("authUser==>{}", authUser);
        }

        Object args = joinPoint.getArgs()[0];
        if (args instanceof AuthUser) {
            if (authUser == null) {
                args = null;
            } else {
                BeanUtils.copyProperties(authUser, args);
            }
        }
    }
}
