package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.model.AuthPrivilegeByRoleId;
import cn.yq.sysapi.service.AuthRolePrivilegeService;
import cn.yq.sysapi.dao.AuthMoudelRolePrivilege;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuthRolePrivilegeServiceImpl implements AuthRolePrivilegeService {

    @Autowired
    AuthMoudelRolePrivilege authMoudelRolePrivilege;

    /**
     * 根据角色Id授予角色权限
     * @param roleid
     * @param privilegeIds
     */
    public void addPrivilegeByRoleId(int roleId,int[] privilegeIds) {

         authMoudelRolePrivilege.addPrivilegeByRoleId(roleId,privilegeIds);
    }
    /**
     * 根据角色ID获取角色权限及相对应的模块
     * @param roleId
     * @return
     */
    public List<AuthPrivilegeByRoleId> selectPrivilegeByRoleId(int roleId) {

        return authMoudelRolePrivilege.selectPrivilegeByRoleId(roleId);
    }

    /**
     * 根据角色ID和权限ID列表,进行保存
     * @param roleId
     * @param privilegeIds
     */

    public void addRolePrivilege(int roleId,int[] privilegeIds){

        //删除角色对应的权限
        authMoudelRolePrivilege.delRolePrivilege(roleId);
        //查找与角色Id对应的权限id
        List<Integer> integerList=authMoudelRolePrivilege.selectPrivilegeIds(roleId);
            System.out.println(integerList);
            List list1=new ArrayList();
            List list3=new ArrayList();
            List list2=new ArrayList();
        for(int i=0;i<privilegeIds.length;i++){
            list1.add(privilegeIds[i]);
            list2.add(privilegeIds[i]);
        }
        for (int i=0;i<list1.size();i++){
            for (int j=0;j<integerList.size();j++){
                if (list1 .get(i).equals(integerList.get(j))) {
                    list3 .add(list1 .get(i));
                }
            }
        }
        //存放不同的ID
        list2.removeAll(list3);
        System.out.println("原先角色权限没有的ID"+list2+"相同的ID"+list3);

        //添加角色的新权限
            //具有相同权限ID的进行修改
            authMoudelRolePrivilege.updateRolePrivilege(roleId,list3);
            //没有的权限ID进行添加新增角色权限
            authMoudelRolePrivilege.addRolePrivilege(roleId,list2);

    }
}
