package cn.yq.sysapi.vo;

import java.io.Serializable;

public class AuthModulePrivilegeVo implements Serializable {
    private static final long serialVersionUID = -1434758830088234654L;

    private int id;

    private int parentId;

    private String name;

    private String url;

    private String path;

    private String Component;

    private String type;

    private String iconCls;

    private String isDel;

    public String getIsDel() {
        return isDel;
    }

    public void setDel(String del) {
        isDel = del;
    }

    public String getIconCls() {
        return iconCls;
    }

    public void setIconCls(String iconCls) {
        this.iconCls = iconCls;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getComponent() {
        return Component;
    }

    public void setComponent(String component) {
        Component = component;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
