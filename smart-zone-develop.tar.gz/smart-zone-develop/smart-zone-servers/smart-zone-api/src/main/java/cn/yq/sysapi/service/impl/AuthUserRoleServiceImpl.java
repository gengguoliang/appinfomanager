package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthUserRoleMapper;
import cn.yq.sysapi.dao.AuthModuleDelUser;
import cn.yq.sysapi.dao.AuthModuleSelectUser;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.service.AuthUserRoleService;
import cn.yq.sysapi.model.AuthUserRole;
import cn.yq.sysapi.model.AuthUserRoleCriteria;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthUserRoleServiceImpl implements AuthUserRoleService {

    @Autowired
    AuthUserRoleMapper authUserRoleMapper;
    @Autowired
    AuthModuleDelUser authModuleDelUser;
    @Autowired
    AuthModuleSelectUser authModuleSelectUser;

    @Override
    public List<AuthUser> getUsersByRoleId(int roleId) {
        return null;
    }

    @Override
    public int addUsersByRoleId(int roleId, int[] userids) {

        //循环插入记录
        int count=0;
        for(int i=0;i<userids.length;i++){
            AuthUserRole authUserRole = new AuthUserRole();
            authUserRole.setRoleId(roleId);
            authUserRole.setUserId(userids[i]);
            authUserRoleMapper.insertSelective(authUserRole);
            count++;
        }
        return count;
    }

    @Override
    public int removeUsersByRoleId(int roleId) {
        AuthUserRoleCriteria example = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria = example.createCriteria();
        criteria.andRoleIdEqualTo(roleId);
        AuthUserRole authUserRole = new AuthUserRole();
        authUserRole.setIsDel(true);
        int num = authUserRoleMapper.updateByExampleSelective(authUserRole,example);
        return num;
    }

    @Override
    public int removeUserByRoleIdAndUserid(@Param("roleId") int roleId, @Param("userId") int userId) {
        int num=authModuleDelUser.removeUserByRoleIdAndUserid(roleId,userId);
        return num;
    }

    /**
     * 根据角色ID拿非角色ID的用户信息
     * @param roleId
     * @return
     */
    @Override
    public List<AuthUser> getOutUsersByRoleId(int orgid,int roleId) {

        return authModuleSelectUser.getOutUsersByRoleId(orgid,roleId);
    }

    /*@Override
    public List<AuthUser> selectUserByRoleId(){}
*/
}
