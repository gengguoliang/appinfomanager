package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthRoleCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthRoleMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(AuthRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(AuthRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(AuthRole record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(AuthRole record);

    /**
     *
     * @mbg.generated
     */
    List<AuthRole> selectByExample(AuthRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    AuthRole selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") AuthRole record, @Param("example") AuthRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") AuthRole record, @Param("example") AuthRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(AuthRole record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(AuthRole record);
}