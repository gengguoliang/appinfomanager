package cn.yq.sysapi.vo;

import cn.yq.sysapi.model.AuthOrganizationRole;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class OrganizationShowVO {

    /**
     * ID id
     */
    private Integer id;
    /**
     * 用户名 username
     */
    private String username;
    /**
     * 手机号 mobile
     */
    private String mobile;
    /**
     * 创建时间 create_time
     */
    private Date createTime;
    /**
     * 企业名称
     */
    private String organizationName;
    /**
     * 所属分类 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
     */
    private Integer type;
    /**
     * 状态 0：正常 1：冻结
     */
    private Integer status;
    /**
     * 用户状态 0：正常 1：锁定
     */
    private Integer totalStatus;
    /**
     * 所属角色
     */
    private String roles;
    /**
     * 0:启用   1：禁用
     */
    private Integer isLocked;
    /**
     * 组织ID
     */
    private Integer organizationId;
    /**
     * 角色ID
     */
    private List<Integer> roleIds;

}
