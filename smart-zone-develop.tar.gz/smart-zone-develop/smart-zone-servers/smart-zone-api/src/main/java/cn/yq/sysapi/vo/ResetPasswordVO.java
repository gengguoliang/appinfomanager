package cn.yq.sysapi.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: yinqk
 * @date: 2019-04-28 18:19
 * @description: 重置密码信息
 */
@ApiModel(description = "重置密码信息")
@Data
public class ResetPasswordVO {
    @ApiModelProperty(value = "手机号码", name = "phoneNo", required = true, position = 0, example = "13838383838")
    private String phoneNo;

    @ApiModelProperty(value = "密码", name = "password", required = true, position = 1)
    private String password;

    @ApiModelProperty(value = "验证码", name = "verificationCode", required = true, position = 2)
    private String verificationCode;
}
