package cn.yq.sysapi.config;

import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.GsonUtil;
import cn.yq.common.utils.IpInfoUtil;
import cn.yq.common.utils.ThreadPoolUtil;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.model.SysLog;
import cn.yq.sysapi.service.SysService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NamedThreadLocal;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author: yinqk
 * @date: 2019-09-05 13:46
 * @description: TODO
 */
@Aspect
@Component
@Slf4j
public class SystemLogAspect {

    private static final ThreadLocal<Date> beginTimeThreadLocal = new NamedThreadLocal<Date>("ThreadLocal beginTime");

    @Autowired(required = false)
    private HttpServletRequest request;

    @Autowired
    private SysService sysService;


    /**
     * Controller层切点,注解方式
     */
    //@pointcut("execution(* *..controller..*Controller*.*(..))")
    @Pointcut("@annotation(cn.yq.common.annotations.SystemLog)")
    public void controllerAspect() {

    }


    /**
     * 前置通知 (在方法执行之前返回)用于拦截Controller层记录用户的操作的开始时间
     *
     * @param joinPoint 切点
     * @throws InterruptedException
     */
    @Before("controllerAspect()")
    public void doBefore(JoinPoint joinPoint) throws InterruptedException {

        //线程绑定变量（该数据只有当前请求的线程可见）
        Date beginTime = new Date();
        beginTimeThreadLocal.set(beginTime);
    }


    @AfterReturning(value = "controllerAspect()", returning = "result")
    public void after(JoinPoint joinPoint, Result result) throws UnsupportedEncodingException {
        try {
            String operator = StringUtils.EMPTY;
            String header = request.getHeader("X-AUTH-ID");

            if (!StringUtils.isEmpty(header)) {
                String authUserString = URLDecoder.decode(header, "UTF-8");
                AuthUser authUser = GsonUtil.changeGsonToBean(authUserString, AuthUser.class);
                operator = authUser.getUsername();
            }

            SysLog sysLog = new SysLog();
            //操作信息
            sysLog.setTitle(getControllerMethodInfo(joinPoint).get("description").toString());
            //操作人
            sysLog.setOperator(operator);
            //操作时间
            sysLog.setOperatorTime(new Date());
            //执行时间
            long beginTime = beginTimeThreadLocal.get().getTime();
            long endTime = System.currentTimeMillis();
            //请求耗时
            Long logElapsedTime = endTime - beginTime;
            sysLog.setCostTime(logElapsedTime.intValue());
            //客户端ip
            sysLog.setIp(IpInfoUtil.getIpAddr(request));
            //请求方法名
            sysLog.setRequestMethod(request.getMethod());
            //请求路径
            sysLog.setRequestUrl(request.getRequestURL().toString());
            //请求表名称
            MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
            String tableName = getControllerMethodInfo(joinPoint).get("table").toString();
            sysLog.setTalbeName(tableName);
            //操作表id

            //获取相关参数
            Map<String, String[]> requestParams = new HashMap<>(request.getParameterMap());

            requestParams.forEach((key, value) -> {
                if (StringUtils.endsWithIgnoreCase(key, "password")) {
                    requestParams.put(key, new String[]{"******"});
                }
            });

            sysLog.setRequestParam(GsonUtil.createGsonString(requestParams));

            //将RequestAttributes对象设置为子线程共享
            ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            RequestContextHolder.setRequestAttributes(sra, true);
            ThreadPoolUtil.getPool().execute(new SaveSysLogThread(sysLog, sysService));
        } catch (Exception e) {
            log.error("处理系统日志异常");
        }
    }


    private static class SaveSysLogThread implements Runnable {

        private SysLog sysLog;
        private SysService sysService;

        public SaveSysLogThread(SysLog sysLog, SysService sysService) {
            this.sysLog = sysLog;
            this.sysService = sysService;
        }

        @Override
        public void run() {
            sysService.insertSysLog(sysLog);
        }
    }


    /**
     * 获取注解中对方法的描述信息 用于Controller层注解
     *
     * @param joinPoint 切点
     * @return 方法描述
     * @throws Exception
     */
    public static Map<String, Object> getControllerMethodInfo(JoinPoint joinPoint) throws Exception {

        Map<String, Object> map = new HashMap<String, Object>(16);
        //获取目标类名
        String targetName = joinPoint.getTarget().getClass().getName();
        //获取方法名
        String methodName = joinPoint.getSignature().getName();
        //获取相关参数
        Object[] arguments = joinPoint.getArgs();
        //生成类对象
        Class targetClass = Class.forName(targetName);
        //获取该类中的方法
        Method[] methods = targetClass.getMethods();

        String description = "";
        String table;

        for (Method method : methods) {
            if (!method.getName().equals(methodName)) {
                continue;
            }
            Class[] clazzs = method.getParameterTypes();
            if (clazzs.length != arguments.length) {
                //比较方法中参数个数与从切点中获取的参数个数是否相同，原因是方法可以重载哦
                continue;
            }
            description = method.getAnnotation(SystemLog.class).description();
            table = method.getAnnotation(SystemLog.class).table();
            map.put("description", description);
            map.put("table", table);
        }
        return map;
    }
}
