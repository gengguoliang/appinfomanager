package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthDatarange;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthDatarangeCusMapper {

    AuthDatarange getDatarangeByRoleid(int roleid);

    List<AuthDatarange> getRangeByUser(String username);

    /**
     * 获取部门及以下部门id
     * @param deptId
     * @return
     */
    String getDepartmentChildList(@Param("deptId")Integer deptId);
}
