package cn.yq.sysapi.model;

import java.io.Serializable;

public class AuthPrivilegeByRoleId implements Serializable {

    private String modulename;
    private String privilegename;


    public AuthPrivilegeByRoleId() {
    }

    public AuthPrivilegeByRoleId(String modulename, String privilegename) {
        this.modulename = modulename;
        this.privilegename = privilegename;
    }

    public String getModulename() {
        return modulename;
    }

    public void setModulename(String modulename) {
        this.modulename = modulename;
    }

    public String getPrivilegename() {
        return privilegename;
    }

    public void setPrivilegename(String privilegename) {
        this.privilegename = privilegename;
    }

    @Override
    public String toString() {
        return "AuthPrivilegeByRoleId{" +
                "modulename='" + modulename + '\'' +
                ", privilegename='" + privilegename + '\'' +
                '}';
    }
}
