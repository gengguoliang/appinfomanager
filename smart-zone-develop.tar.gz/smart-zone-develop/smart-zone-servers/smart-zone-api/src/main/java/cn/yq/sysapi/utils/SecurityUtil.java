package cn.yq.sysapi.utils;

import cn.yq.sysapi.model.AuthDatarange;
import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.service.AuthDatarangeService;
import cn.yq.sysapi.service.AuthUserService;
import cn.yq.sysapi.service.UserDeptService;
import cn.yq.sysapi.vo.TreeNode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther: houqijun
 * @Date: 2018/11/23 16:13
 * @Description:
 */
@Component
public class SecurityUtil {

    @Resource
    private AuthUserService userService;

    @Autowired
    private AuthDatarangeService authDatarangeService;

    @Autowired
    private UserDeptService userDeptService;


    /**
     * 获取当前登录用户所拥有的部门ids
     *
     * @return
     */
    public String getUserDeptids(String username) {

        //调用service方法，根据用户名进行查询
        return userService.getUserRoleDeptIdsByUserName(username);
    }

    /**
     * 获取当前登录用户的角色，根据角色获取角色数据范围
     * 根据数据范围，获取当前登录用户该有的数据范围，返回
     */
    public Map getRangeByUser(String username) {
        //存储结果数据
        Map map = new HashMap<Integer, Integer>();
        //获取当前登录用户的角色范围列表
//        UserDetails user = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//        String username = user.getUsername();
        List<AuthDatarange> list = authDatarangeService.getRangeByUser(username);
        List rangelist = new ArrayList();
        //根据数据范围，获取当前登录用户该有的数据范围，
        //1 所有数据 2 所在部门及以下数据 3 所在部门数据 4 仅本人数据 5 按明细设计
        for (AuthDatarange temp : list) {
            if (null != temp && null != temp.getValue()) {
                rangelist.add(temp.getValue());
            }

        }
        //根据数据范围判断，返回数据
        //1 所有数据
        if (rangelist.contains("1")) {
            map.put(10000, 10000);
            return map;
        }
        //2 所在部门及以下数据，找到该用户所属部门，与所有子部门
        if (rangelist.contains("2")) {
            //所在部门id
            UserDepartment dept = userService.getDeptByUsername(username);
            if (dept != null && dept.getId() != null && dept.getId() != 0) {
                //通过函数获取部门及以下id集合
                List<Integer> deptList = authDatarangeService.getDepartmentChildList(dept.getId());
                for (Integer id : deptList) {
                    map.put(id, id);
                }
            }
/*            //存储本部门与以下部门id
            List resultlist = new ArrayList();
            resultlist.add(deptid);
            //获取迭代数据
            UserDepartment userDepartment = new UserDepartment();
            userDepartment.setOrganizationId(dept.getOrganizationId());
            //获取数据
            List<UserDepartment> dlist = userDeptService.getDeptTreeData(userDepartment);
            //存储树结构
            Map<String, TreeNode> TreeNodes = new HashMap();
            for (UserDepartment temp: dlist) {
                TreeNode node = new TreeNode();
                node.setId(temp.getId().toString());
                node.setName(temp.getName());
                node.setParentId(temp.getParentId().toString());
                TreeNodes.put(temp.getId().toString(),node);
            }
            DeptRecursion.getTreeNodeJson(String.valueOf(deptid),TreeNodes,resultlist);
            for(int i=0;i<resultlist.size();i++){
               resultlist.get(i);
               map.put(Integer.valueOf(resultlist.get(i).toString()),Integer.valueOf(resultlist.get(i).toString()));
            }*/

        }
        //3所在部门数据
        if (rangelist.contains("3")) {
            UserDepartment dept = userService.getDeptByUsername(username);
            if (dept != null && dept.getId() != null && dept.getId() != 0) {
                map.put(dept.getId(), dept.getId());
            }
        }
        //4仅本人数据
        if (rangelist.contains("4")) {
            map.put(10001, 10001);

        }
        //5 按明细设计
        if (rangelist.contains("5")) {
            String str = userService.getUserRoleDeptIdsByUserName(username);
            if (StringUtils.isNotBlank(str)) {
                String[] s = str.split(",");
                for (int i = 0; i < s.length; i++) {
                    map.put(Integer.valueOf(s[i]), Integer.valueOf(s[i]));
                }
            }
        }

        return map;

    }


}
