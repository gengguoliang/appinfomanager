package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthRolePrivilege;
import cn.yq.sysapi.model.AuthRolePrivilegeCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthRolePrivilegeMapper {
    long countByExample(AuthRolePrivilegeCriteria example);

    int deleteByExample(AuthRolePrivilegeCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthRolePrivilege record);

    int insertSelective(AuthRolePrivilege record);

    List<AuthRolePrivilege> selectByExample(AuthRolePrivilegeCriteria example);

    AuthRolePrivilege selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthRolePrivilege record, @Param("example") AuthRolePrivilegeCriteria example);

    int updateByExample(@Param("record") AuthRolePrivilege record, @Param("example") AuthRolePrivilegeCriteria example);

    int updateByPrimaryKeySelective(AuthRolePrivilege record);

    int updateByPrimaryKey(AuthRolePrivilege record);
}