package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthUserUserGroup;
import cn.yq.sysapi.model.AuthUserUserGroupCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthUserUserGroupMapper {
    long countByExample(AuthUserUserGroupCriteria example);

    int deleteByExample(AuthUserUserGroupCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthUserUserGroup record);

    int insertSelective(AuthUserUserGroup record);

    List<AuthUserUserGroup> selectByExample(AuthUserUserGroupCriteria example);

    AuthUserUserGroup selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthUserUserGroup record, @Param("example") AuthUserUserGroupCriteria example);

    int updateByExample(@Param("record") AuthUserUserGroup record, @Param("example") AuthUserUserGroupCriteria example);

    int updateByPrimaryKeySelective(AuthUserUserGroup record);

    int updateByPrimaryKey(AuthUserUserGroup record);
}