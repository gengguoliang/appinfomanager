package cn.yq.sysapi.dao;

import cn.yq.sysapi.vo.AuthModulePrivilegeVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthModulePrivilegeCusMapper {

   List<AuthModulePrivilegeVo> getTreeDataByRoleids(@Param("list") List roleids,@Param("category") Integer category);

   List<AuthModulePrivilegeVo> getTreeModuleDataByRoleids(@Param("orgid") Integer orgid,@Param("roleids") List roleids,@Param("category") Integer category);

    public List<AuthModulePrivilegeVo> getTreeModuleDataShengyuan(@Param("roleids") List roleids,@Param("category") Integer category);
    List<String> selectPrivilegeCode(List roleids);
    List<String>selectPrivilegeAPPCode(@Param("list") List roleids,@Param("category") Integer category);
    List<Integer>selectPrivilegePcOrApp(@Param("roleId")Integer roleId,@Param("category") Integer category);
}
