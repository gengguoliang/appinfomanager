package cn.yq.sysapi.model;

import java.io.Serializable;
import java.util.Date;

public class AuthUser implements Serializable {
    /**
     * ID id
     */
    private Integer id;

    /**
     * 项目ID project_id
     */
    private Integer projectId;

    /**
     *  is_system
     */
    private Boolean isSystem;

    /**
     *  organization_id
     */
    private Integer organizationId;

    /**
     * 所属部门 department_id
     */
    private Integer departmentId;

    /**
     * 用户名 username
     */
    private String username;

    /**
     * 密码 password
     */
    private String password;

    /**
     * 姓名 name
     */
    private String name;

    /**
     * 性别，0：男 1：女 gender
     */
    private Boolean gender;

    /**
     * 手机号 mobile
     */
    private String mobile;

    /**
     * 证件类型，0：身份证 certify_type
     */
    private Integer certifyType;

    /**
     *  certify_num
     */
    private String certifyNum;

    /**
     *  is_admin
     */
    private Boolean isAdmin;

    /**
     * 审核状态，0：待审核，1：审核通过，2：审核不通过 audited_status
     */
    private Byte auditedStatus;

    /**
     * 审核备注 audited_remark
     */
    private String auditedRemark;

    /**
     * 是否锁定 is_locked
     */
    private Boolean isLocked;

    /**
     * 加入组织方式，0：管理后台添加，1：企业邀请，2：用户申请 join_type
     */
    private Byte joinType;

    /**
     * 是否删除 is_del
     */
    private Boolean isDel;

    /**
     * 创建时间 create_time
     */
    private Date createTime;

    /**
     * 最后更新时间 last_update_time
     */
    private Date lastUpdateTime;

    /**
     * auth_user
     */
    private static final long serialVersionUID = 1L;

    /**
     * ID
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return id ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * ID
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param id ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 项目ID
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return project_id 项目ID
     */
    public Integer getProjectId() {
        return projectId;
    }

    /**
     * 项目ID
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param projectId 项目ID
     */
    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return is_system 
     */
    public Boolean getIsSystem() {
        return isSystem;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param isSystem 
     */
    public void setIsSystem(Boolean isSystem) {
        this.isSystem = isSystem;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return organization_id 
     */
    public Integer getOrganizationId() {
        return organizationId;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param organizationId 
     */
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    /**
     * 所属部门
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return department_id 所属部门
     */
    public Integer getDepartmentId() {
        return departmentId;
    }

    /**
     * 所属部门
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param departmentId 所属部门
     */
    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * 用户名
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return username 用户名
     */
    public String getUsername() {
        return username;
    }

    /**
     * 用户名
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param username 用户名
     */
    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    /**
     * 密码
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return password 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 密码
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    /**
     * 姓名
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return name 姓名
     */
    public String getName() {
        return name;
    }

    /**
     * 姓名
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param name 姓名
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 性别，0：男 1：女
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return gender 性别，0：男 1：女
     */
    public Boolean getGender() {
        return gender;
    }

    /**
     * 性别，0：男 1：女
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param gender 性别，0：男 1：女
     */
    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    /**
     * 手机号
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return mobile 手机号
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * 手机号
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param mobile 手机号
     */
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    /**
     * 证件类型，0：身份证
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return certify_type 证件类型，0：身份证
     */
    public Integer getCertifyType() {
        return certifyType;
    }

    /**
     * 证件类型，0：身份证
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param certifyType 证件类型，0：身份证
     */
    public void setCertifyType(Integer certifyType) {
        this.certifyType = certifyType;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return certify_num 
     */
    public String getCertifyNum() {
        return certifyNum;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param certifyNum 
     */
    public void setCertifyNum(String certifyNum) {
        this.certifyNum = certifyNum == null ? null : certifyNum.trim();
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return is_admin 
     */
    public Boolean getIsAdmin() {
        return isAdmin;
    }

    /**
     * 
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param isAdmin 
     */
    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    /**
     * 审核状态，0：待审核，1：审核通过，2：审核不通过
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return audited_status 审核状态，0：待审核，1：审核通过，2：审核不通过
     */
    public Byte getAuditedStatus() {
        return auditedStatus;
    }

    /**
     * 审核状态，0：待审核，1：审核通过，2：审核不通过
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param auditedStatus 审核状态，0：待审核，1：审核通过，2：审核不通过
     */
    public void setAuditedStatus(Byte auditedStatus) {
        this.auditedStatus = auditedStatus;
    }

    /**
     * 审核备注
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return audited_remark 审核备注
     */
    public String getAuditedRemark() {
        return auditedRemark;
    }

    /**
     * 审核备注
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param auditedRemark 审核备注
     */
    public void setAuditedRemark(String auditedRemark) {
        this.auditedRemark = auditedRemark == null ? null : auditedRemark.trim();
    }

    /**
     * 是否锁定
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return is_locked 是否锁定
     */
    public Boolean getIsLocked() {
        return isLocked;
    }

    /**
     * 是否锁定
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param isLocked 是否锁定
     */
    public void setIsLocked(Boolean isLocked) {
        this.isLocked = isLocked;
    }

    /**
     * 加入组织方式，0：管理后台添加，1：企业邀请，2：用户申请
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return join_type 加入组织方式，0：管理后台添加，1：企业邀请，2：用户申请
     */
    public Byte getJoinType() {
        return joinType;
    }

    /**
     * 加入组织方式，0：管理后台添加，1：企业邀请，2：用户申请
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param joinType 加入组织方式，0：管理后台添加，1：企业邀请，2：用户申请
     */
    public void setJoinType(Byte joinType) {
        this.joinType = joinType;
    }

    /**
     * 是否删除
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return is_del 是否删除
     */
    public Boolean getIsDel() {
        return isDel;
    }

    /**
     * 是否删除
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param isDel 是否删除
     */
    public void setIsDel(Boolean isDel) {
        this.isDel = isDel;
    }

    /**
     * 创建时间
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return create_time 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 最后更新时间
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @return last_update_time 最后更新时间
     */
    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    /**
     * 最后更新时间
     * @author ROY
     * @date 2019-03-19 11:12:59
     * @param lastUpdateTime 最后更新时间
     */
    public void setLastUpdateTime(Date lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AuthUser other = (AuthUser) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getProjectId() == null ? other.getProjectId() == null : this.getProjectId().equals(other.getProjectId()))
            && (this.getIsSystem() == null ? other.getIsSystem() == null : this.getIsSystem().equals(other.getIsSystem()))
            && (this.getOrganizationId() == null ? other.getOrganizationId() == null : this.getOrganizationId().equals(other.getOrganizationId()))
            && (this.getDepartmentId() == null ? other.getDepartmentId() == null : this.getDepartmentId().equals(other.getDepartmentId()))
            && (this.getUsername() == null ? other.getUsername() == null : this.getUsername().equals(other.getUsername()))
            && (this.getPassword() == null ? other.getPassword() == null : this.getPassword().equals(other.getPassword()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getGender() == null ? other.getGender() == null : this.getGender().equals(other.getGender()))
            && (this.getMobile() == null ? other.getMobile() == null : this.getMobile().equals(other.getMobile()))
            && (this.getCertifyType() == null ? other.getCertifyType() == null : this.getCertifyType().equals(other.getCertifyType()))
            && (this.getCertifyNum() == null ? other.getCertifyNum() == null : this.getCertifyNum().equals(other.getCertifyNum()))
            && (this.getIsAdmin() == null ? other.getIsAdmin() == null : this.getIsAdmin().equals(other.getIsAdmin()))
            && (this.getAuditedStatus() == null ? other.getAuditedStatus() == null : this.getAuditedStatus().equals(other.getAuditedStatus()))
            && (this.getAuditedRemark() == null ? other.getAuditedRemark() == null : this.getAuditedRemark().equals(other.getAuditedRemark()))
            && (this.getIsLocked() == null ? other.getIsLocked() == null : this.getIsLocked().equals(other.getIsLocked()))
            && (this.getJoinType() == null ? other.getJoinType() == null : this.getJoinType().equals(other.getJoinType()))
            && (this.getIsDel() == null ? other.getIsDel() == null : this.getIsDel().equals(other.getIsDel()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getLastUpdateTime() == null ? other.getLastUpdateTime() == null : this.getLastUpdateTime().equals(other.getLastUpdateTime()));
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getProjectId() == null) ? 0 : getProjectId().hashCode());
        result = prime * result + ((getIsSystem() == null) ? 0 : getIsSystem().hashCode());
        result = prime * result + ((getOrganizationId() == null) ? 0 : getOrganizationId().hashCode());
        result = prime * result + ((getDepartmentId() == null) ? 0 : getDepartmentId().hashCode());
        result = prime * result + ((getUsername() == null) ? 0 : getUsername().hashCode());
        result = prime * result + ((getPassword() == null) ? 0 : getPassword().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getGender() == null) ? 0 : getGender().hashCode());
        result = prime * result + ((getMobile() == null) ? 0 : getMobile().hashCode());
        result = prime * result + ((getCertifyType() == null) ? 0 : getCertifyType().hashCode());
        result = prime * result + ((getCertifyNum() == null) ? 0 : getCertifyNum().hashCode());
        result = prime * result + ((getIsAdmin() == null) ? 0 : getIsAdmin().hashCode());
        result = prime * result + ((getAuditedStatus() == null) ? 0 : getAuditedStatus().hashCode());
        result = prime * result + ((getAuditedRemark() == null) ? 0 : getAuditedRemark().hashCode());
        result = prime * result + ((getIsLocked() == null) ? 0 : getIsLocked().hashCode());
        result = prime * result + ((getJoinType() == null) ? 0 : getJoinType().hashCode());
        result = prime * result + ((getIsDel() == null) ? 0 : getIsDel().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getLastUpdateTime() == null) ? 0 : getLastUpdateTime().hashCode());
        return result;
    }
}