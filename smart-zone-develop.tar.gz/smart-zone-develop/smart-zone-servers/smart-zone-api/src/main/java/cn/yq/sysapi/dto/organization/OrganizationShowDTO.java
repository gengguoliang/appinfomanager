package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
@ApiModel(value = "PC端列表展示DTO")
public class OrganizationShowDTO {

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "所属分类")
    private Integer type;

    @ApiModelProperty(value = "所属角色")
    private Integer roleId;

    @ApiModelProperty(value = "创建开始时间")
    private Date beginTime;

    @ApiModelProperty(value = "创建结束时间")
    private Date endTime;

    @ApiModelProperty(value = "状态，0：启用，1：禁用")
    private Integer isLocked;
}
