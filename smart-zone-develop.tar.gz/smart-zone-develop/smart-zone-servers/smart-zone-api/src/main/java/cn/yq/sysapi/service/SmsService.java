package cn.yq.sysapi.service;

/**
 * @author: yinqk
 * @date: 2019-04-29 13:56
 * @description: 短信服务
 */
public interface SmsService {
    /**
     * 发送短信
     *
     * @param phoneNo
     * @param content
     */
    void sendSms(String phoneNo, String content);
}
