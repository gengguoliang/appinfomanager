package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthRoleDepartmentMapper;
import cn.yq.sysapi.model.AuthRoleDepartment;
import cn.yq.sysapi.model.AuthRoleDepartmentCriteria;
import cn.yq.sysapi.service.AuthRoleDeptService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Auther: houqijun
 * @Date: 2018/11/23 17:53
 * @Description:
 */
@Service
public class AuthRoleDeptServiceImpl implements AuthRoleDeptService {

    @Resource
    private AuthRoleDepartmentMapper authRoleDepartmentMapper;

    @Override
    public List<Integer> getDeptIdsByRoleId(int roleId) {

        List<Integer> ids = authRoleDepartmentMapper.getDeptIdsByRoleId(roleId);
        return ids;
    }

    @Override
    public Integer updateRoleDept(int roleId, int[] deptids) {

        //删除此角色所拥有的部门权限
        AuthRoleDepartmentCriteria departmentCriteria = new AuthRoleDepartmentCriteria();
        AuthRoleDepartmentCriteria.Criteria criteria = departmentCriteria.createCriteria();
        criteria.andRoleIdEqualTo(roleId);
        authRoleDepartmentMapper.deleteByExample(departmentCriteria);

        AuthRoleDepartment authRoleDepartment = new AuthRoleDepartment();

        Integer count = 0;
        //重新赋值
        for(Integer deptid: deptids){
            authRoleDepartment.setRoleId(roleId);
            authRoleDepartment.setDepartmentId(deptid);
            count += authRoleDepartmentMapper.insertSelective(authRoleDepartment);
        }

        return count;
    }
}
