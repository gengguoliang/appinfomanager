package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthPrivilegeMapper;
import cn.yq.sysapi.dao.AuthUserGroupMapper;
import cn.yq.sysapi.dao.AuthUserGroupPrivilegeMapper;
import cn.yq.sysapi.service.AuthUserGroupService;
import cn.yq.sysapi.model.AuthPrivilege;
import cn.yq.sysapi.model.AuthUserGroup;
import cn.yq.sysapi.model.AuthUserGroupCriteria;
import cn.yq.sysapi.model.AuthUserGroupPrivilege;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthUserGroupServiceImpl implements AuthUserGroupService {

    @Autowired
    private AuthUserGroupMapper mapper;

    @Autowired
    private AuthPrivilegeMapper authPrivilegeMapper;

    @Autowired
    private AuthUserGroupPrivilegeMapper authUserGroupPrivilegeMapper;

    @Override
    public int add(AuthUserGroup userGroup) {
        return mapper.insertSelective(userGroup);
    }

    @Override
    public int remove(int id) {
        AuthUserGroupCriteria example = new AuthUserGroupCriteria();
        AuthUserGroupCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(id);
        return mapper.deleteByExample(example);
    }

    @Override
    public int update(AuthUserGroup userGroup) {
        AuthUserGroupCriteria example = new AuthUserGroupCriteria();
        AuthUserGroupCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(userGroup.getId());
        return mapper.updateByExampleSelective(userGroup, example);
    }

    @Override
    public List<AuthUserGroup> query(AuthUserGroup userGroup) {
        AuthUserGroupCriteria example = new AuthUserGroupCriteria();
        AuthUserGroupCriteria.Criteria criteria = example.createCriteria();
            criteria.andIsDelEqualTo(false);
        if(null!=userGroup.getGroupName()&&!"".equals(userGroup.getGroupName())){
            criteria.andGroupNameEqualTo(userGroup.getGroupName());
        }
        return mapper.selectByExample(example);
    }

    /**
     * 获取用户组信息列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public List<AuthUserGroup> getListByPage(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return mapper.selectByExample(null);
    }

    @Override
    public boolean deleteUserGroup(int userGroupId) {
        AuthUserGroup userGroup = new AuthUserGroup();
        userGroup.setId(userGroupId);
        userGroup.setIsDel(true);
        mapper.updateByPrimaryKeySelective(userGroup);
        return true;
    }

    @Override
    public int userGroupAuthorization(String authInfo) {

        //        {
        //            "usergroupid":"222",
        //                authGroup:{
        //                    "14":true,
        //                    "28":false
        //                         }
        //        }

        //根据授权信息组织数据，插入到数据库
        JSONObject jsonObject = JSON.parseObject(authInfo);
        AuthPrivilege authPrivilege = new AuthPrivilege();
        AuthUserGroupPrivilege authUserGroupPrivilege = new AuthUserGroupPrivilege();
        authPrivilegeMapper.insertSelective(authPrivilege);
        authUserGroupPrivilegeMapper.insertSelective(authUserGroupPrivilege);
        return 0;
    }




}
