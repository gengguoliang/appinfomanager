package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.service.HomeService;
import org.springframework.stereotype.Service;

@Service
public class HomeServiceImpl implements HomeService {
    @Override
    public String sayHi() {
        return "hi";
    }
}
