package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.vo.ResetPasswordVO;
import cn.yq.sysapi.vo.UserRegistVO;

public interface AuthService {
    int register(AuthUser userToAdd);

    /**
     * 判断手机号是否已注册
     *
     * @param phoneNo
     * @return
     */
    boolean isExist(String phoneNo);

    /**
     * @Description 添加用户
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    void registUser(UserRegistVO userRegistVO);
    
    /**
    *@Description 重置密码
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void resetPassword(ResetPasswordVO resetPasswordVO);

//    String login(String username, String password);

}
//    String refresh(String oldToken);


