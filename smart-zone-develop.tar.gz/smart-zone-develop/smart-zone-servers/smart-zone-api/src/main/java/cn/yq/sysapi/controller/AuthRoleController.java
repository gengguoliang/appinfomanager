package cn.yq.sysapi.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.dao.AuthRoleMapper;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthPrivilegeByRoleId;
import cn.yq.sysapi.model.AuthRoleCriteria;
import cn.yq.sysapi.service.AuthDatarangeService;
import cn.yq.sysapi.service.AuthRoleService;
import cn.yq.sysapi.service.AuthUserRoleService;
import cn.yq.sysapi.service.AuthRolePrivilegeService;
import cn.yq.sysapi.vo.RoleVo;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "角色信息管理", description = "角色信息管理 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/role")
public class AuthRoleController {

    @Autowired
    AuthRoleService authRoleService;

    @Autowired
    AuthUserRoleService authUserRoleService;

    @Autowired
    AuthRolePrivilegeService authRolePrivilegeService;
    @Autowired
    AuthRoleMapper authRoleMapper;

    @Autowired
    AuthDatarangeService authDatarangeService;

    @ApiOperation(value = "角色列表", notes = "完整的角色信息列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "页码，从1开始", required = true, dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "pageSize", value = "页面大小", required = true, dataType = "int", paramType = "path")
    })
    @LoginUser
    @GetMapping("/{pageNum}/{pageSize}")
    @SystemLog(description = "角色列表")
    public BaseResult<PageInfo<List<AuthRole>>> getListByPage(AuthUser authUser, @PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize) {
        int organizationId = authUser.getOrganizationId();
        return BaseResult.successWithData(new PageInfo(authRoleService.getListByPage(organizationId, pageNum, pageSize)));
    }

    @ApiOperation(value = "添加角色信息", notes = "添加角色信息")
    @PostMapping(value = "/", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加角色信息")
    public BaseResult addRole(AuthUser authUser, @RequestBody RoleVo roleVo) {
        AuthRole authRole = new AuthRole();
        authRole.setOrganizationId(authUser.getOrganizationId());
        BeanUtils.copyProperties(roleVo, authRole);
        List<AuthRole> list = authRoleService.query(authRole);
        if (list.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "角色名称不能重复");
        }
        int id = authRoleService.add(authRole);
        //新增角色添加角色权限范围
        authDatarangeService.initRangeByRoleId(id);
        return BaseResult.successWithData("添加成功");
    }

    @ApiOperation(value = "删除角色", notes = "删除角色")
    @ApiImplicitParam(name = "roleId", value = "角色ID", dataType = "int", paramType = "path")
    @PutMapping(value = "/deleteRole/{roleId}")
    @SystemLog(description = "删除角色")
    public BaseResult<Boolean> deleteRole(@PathVariable("roleId") int roleId) {
        AuthRoleCriteria example = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(roleId)
                .andIsSystemEqualTo(true);
        long count = authRoleMapper.countByExample(example);
        if (count > 0) {
            return BaseResult.failWithCodeAndMsg(1, "内置角色不能删除");
        }
        return BaseResult.successWithData(authRoleService.deleteRole(roleId));
    }

    @ApiOperation(value = "编辑角色名称信息", notes = "编辑角色名称信息")
    @PutMapping(value = "/updateRoleName", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "编辑角色名称信息")
    public BaseResult updateRoleName(AuthUser authUser, @RequestBody RoleVo roleVo) {
        AuthRole authRole = new AuthRole();
        int organizationId = authUser.getOrganizationId();
        authRole.setOrganizationId(organizationId);
        BeanUtils.copyProperties(roleVo, authRole);
        List<AuthRole> list = authRoleService.query(authRole);
        if (list.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "角色名称不能重复");
        }
        authRoleService.update(authRole);
        return BaseResult.successWithData("修改成功");
    }

    @ApiOperation(value = "根据角色Id添加用户", notes = "根据角色Id添加用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "userids", value = "用户ID数组", dataType = "int[]", paramType = "path")
    })
    @PostMapping("/addUsersByRoleId/{roleId}/{userids}")
    @SystemLog(description = "根据角色Id添加用户")
    public BaseResult addUsersByRoleId(@PathVariable("roleId") int roleId, @PathVariable("userids") int[] userids) {
        authUserRoleService.addUsersByRoleId(roleId, userids);
        return BaseResult.successWithData("添加成功");
    }


    @ApiOperation(value = "根据角色Id移除用户", notes = "根据角色Id移除用户")
    @ApiImplicitParam(name = "roleId", value = "角色ID", dataType = "int", paramType = "path")
    @PutMapping("/removeUsersByRoleId/{roleId}")
    @SystemLog(description = "根据角色Id移除用户")
    public BaseResult removeUsersByRoleId(@PathVariable("roleId") int roleId) {
        authUserRoleService.removeUsersByRoleId(roleId);
        return BaseResult.successWithData("删除成功");
    }


    @ApiOperation(
            value = "查询角色信息",
            notes = "查询角色信息",
            produces = "application/json",
            consumes = "application/json",
            response = BaseResult.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user", value = "角色对象", required = true, dataType = "AuthRole", paramType = "path"),
    })
    @PostMapping("/queryRole")
    @LoginUser
    @SystemLog(description = "查询角色信息")
    public BaseResult queryRole(AuthUser authUser, AuthRole role) {
        int organizationId = authUser.getOrganizationId();
        role.setOrganizationId(authUser.getOrganizationId());
        List<AuthRole> list = authRoleService.query(role);
        return BaseResult.successWithData(list);
    }


    @ApiOperation(value = "根据角色ID获取指定下的用户", notes = "根据角色ID获取指定下的用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleid", value = "角色ID", required = true, dataType = "int", paramType = "path"),
    })
    @PostMapping("/selectUserByUserId/{roleid}")
    @SystemLog(description = "根据角色ID获取用户")
    public BaseResult selectUserByRoleId(@PathVariable("roleid") int roleid) {
        List<cn.yq.sysapi.model.AuthUser> list = authRoleService.selectUserByRoleId(roleid);
        return BaseResult.successWithData(list);
    }


    @ApiOperation(value = "根据角色ID和用户ID移除用户", notes = "根据角色ID和用户ID移除用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "userId", value = "用户ID", required = true, dataType = "int", paramType = "path")
    })
    @PutMapping("/removeUserByRoleIdAndUserId/{userId}/{roleId}")
    @SystemLog(description = "根据角色ID和用户ID移除用户")
    public BaseResult removeUserByRoleIdAndUserId(@PathVariable("userId") int userId, @PathVariable("roleId") int roleId) {

        authUserRoleService.removeUserByRoleIdAndUserid(roleId, userId);
        return BaseResult.successWithData("删除成功");
    }


    @ApiOperation(value = "根据角色ID查找非角色ID用户", notes = "根据角色ID查找非角色ID用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "int", paramType = "path")
    })
    @PostMapping("/getOutUsersByRoleId/{roleId}")
    @LoginUser
    @SystemLog(description = "根据角色ID查找非角色ID用户")
    public BaseResult getOutUsersByRoleId(cn.yq.common.vo.AuthUser authUser, @PathVariable("roleId") int roleId) {
        int orgid = authUser.getOrganizationId();
        List<cn.yq.sysapi.model.AuthUser> list = authUserRoleService.getOutUsersByRoleId(orgid, roleId);
        return BaseResult.successWithData(list);
    }


    @ApiOperation(value = "根据角色ID赋予角色权限", notes = "根据角色ID赋予角色权限")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "privilegeIds", value = "权限ID数组", required = true, allowMultiple = true, dataType = "int", paramType = "path")
    })
    @PutMapping("/addPrivilege/{roleId}/{privilegeIds}")
    @SystemLog(description = "根据角色ID赋予角色权限")
    public BaseResult addPrivilegeByRoleId(@PathVariable("roleId") int roleId, @PathVariable("privilegeIds") int[] privilegeIds) {

        authRolePrivilegeService.addPrivilegeByRoleId(roleId, privilegeIds);
        return BaseResult.successWithData("添加成功");
    }


    @ApiOperation(value = "根据角色id查找权限及相应模块", notes = "根据角色id查找权限及相应模块")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "int", paramType = "path")
    })
    @PostMapping("/selectPrivilegeByRoleId/{roleId}")
    @SystemLog(description = "根据角色id查找权限及相应模块")
    public BaseResult selectPrivilegeByRoleId(@PathVariable("roleId") int roleId) {

        List<AuthPrivilegeByRoleId> list = authRolePrivilegeService.selectPrivilegeByRoleId(roleId);
        return BaseResult.successWithData(list);
    }


    @ApiOperation(value = "根据角色ID和权限ID列表,进行保存", notes = "根据角色ID和权限ID列表,进行保存")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "角色ID", required = true, dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "privilegeIds", value = "权限ID列表", required = true, allowMultiple = true, dataType = "int", paramType = "path")
    })
    @PostMapping("/addRolePrivilege/{roleId}/{privilegeIds}")
    @SystemLog(description = "根据角色ID和权限ID列表,进行保存")
    public BaseResult addRolePrivilege(@PathVariable("roleId") int roleId, @PathVariable("privilegeIds") int[] privilegeIds) {

        authRolePrivilegeService.addRolePrivilege(roleId, privilegeIds);
        return BaseResult.successWithData("添加成功");
    }


}
