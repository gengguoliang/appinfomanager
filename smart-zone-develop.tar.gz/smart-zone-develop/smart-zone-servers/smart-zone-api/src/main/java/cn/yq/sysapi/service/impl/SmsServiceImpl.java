package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.service.SmsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author: yinqk
 * @date: 2019-04-29 13:59
 * @description: 短信服务
 */
@Slf4j
@Service
public class SmsServiceImpl implements SmsService {
    @Value("${sms.service.wsdlUrl}")
    private String wsdlUrl;

    private final String platformId = "smart-zone";

    /**
     * 发送短信
     *
     * @param phoneNo
     * @param content
     */
    @Override
    public void sendSms(String phoneNo, String content) {
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client = dcf.createClient(wsdlUrl);
        Object[] res = new Object[0];

        try {
            res = client.invoke("SendMsg", phoneNo, content, platformId);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        log.debug("Echo response: " + res[0]);
    }
}
