package cn.yq.sysapi.service;

import cn.yq.common.result.Result;
import cn.yq.sysapi.dto.organization.*;
import cn.yq.sysapi.model.AuthOrganization;
import org.springframework.web.bind.annotation.RequestParam;

public interface IAuthOrganizationService {
    Result addAuthOrg(AddAuthOrganizationDto authOrganizationDto);

    Result updateAuthOrg(UpdateAuthOrganizationDto authOrganizationDto);

    Result forbidden(Integer id);

    Result delAuthOrg(Integer id);

    Result query(GetInfoAuthOrgDto query);

    Result frozen(Integer orgId);

    Result addRoleForOrg(AddRoleForOrgDto addRole);

    Result getOrgRoles(Integer orgId);

    Result getUsersByOrg(Integer orgId);

    Result getOrgByAudited(int auditedType);

    Result audited(AuditedOrgDto auditedOrgDto);

    Result getOrgById(Integer orgId);

    AuthOrganization getCertifyNum(Integer userId);

    Result queryUnit(String unitName);

    Result isExistCode(Integer userId,String code);
}
