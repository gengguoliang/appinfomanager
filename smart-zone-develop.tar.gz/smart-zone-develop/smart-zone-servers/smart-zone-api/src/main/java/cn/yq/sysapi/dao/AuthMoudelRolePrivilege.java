package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthPrivilegeByRoleId;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthMoudelRolePrivilege {

    /**
     * 根据角色Id授予角色权限
     * @param roleId
     * @param privilegeIds
     */
    void addPrivilegeByRoleId(@Param("roleId")int roleId,@Param("privilegeIds") int[] privilegeIds);

    /**
     * 根据角色ID获取角色权限及相对应的模块
     * @param roleId
     * @return
     */
    List<AuthPrivilegeByRoleId> selectPrivilegeByRoleId(@Param("roleId") int roleId);

    /**
     * 删除角色ID对应的权限
     * @param roleId
     */
    void delRolePrivilege(@Param("roleId") int roleId);

    /**
     * 添加角色的新权限
     * @param roleId
     * @param list2
     */
    void addRolePrivilege(@Param("roleId")int roleId, @Param("list2") List list2);

    /**
     * 查找与角色Id对应的权限ids
     * @param roleId
     */
    List<Integer> selectPrivilegeIds(@Param("roleId") int roleId);

    /**
     *相同权限ID的修改
     * @param roleId
     * @param list3
     */
    void updateRolePrivilege(@Param("roleId") int roleId,@Param("list3")List list3);
}
