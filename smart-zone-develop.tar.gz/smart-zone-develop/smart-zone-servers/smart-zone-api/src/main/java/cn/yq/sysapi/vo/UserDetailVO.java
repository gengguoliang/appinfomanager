package cn.yq.sysapi.vo;

import lombok.Data;

import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class UserDetailVO {

    private Integer id;
    private Integer organizationId;
    private String organizationName;
    private String departmentName;
    private List<Integer> roleIds;
    private String name;
    private String mobile;
    private String userName;
    private Integer isLocked;//是否锁定  0：未锁定 1：锁定
    private List<Integer> departmentIds;
    private Integer auditedStatus;
}
