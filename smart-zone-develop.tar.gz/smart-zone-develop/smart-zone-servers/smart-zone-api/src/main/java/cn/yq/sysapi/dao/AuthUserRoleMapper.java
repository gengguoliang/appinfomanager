package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthUserRole;
import cn.yq.sysapi.model.AuthUserRoleCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthUserRoleMapper {
    long countByExample(AuthUserRoleCriteria example);

    int deleteByExample(AuthUserRoleCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthUserRole record);

    int insertSelective(AuthUserRole record);

    List<AuthUserRole> selectByExample(AuthUserRoleCriteria example);

    AuthUserRole selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthUserRole record, @Param("example") AuthUserRoleCriteria example);

    int updateByExample(@Param("record") AuthUserRole record, @Param("example") AuthUserRoleCriteria example);

    int updateByPrimaryKeySelective(AuthUserRole record);

    int updateByPrimaryKey(AuthUserRole record);

}