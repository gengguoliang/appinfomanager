package cn.yq.sysapi.dto.organization;

import lombok.Data;

import java.util.Date;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class SysLogDTO {

    private Date operatorTimeStart;//操作时间  起始
    private Date operatorTimeEnd;//操作时间  结束
    private String operator;//操作人

}
