package cn.yq.sysapi.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UnitVo {
    private Integer unitId;
    private Integer unitName;
}
