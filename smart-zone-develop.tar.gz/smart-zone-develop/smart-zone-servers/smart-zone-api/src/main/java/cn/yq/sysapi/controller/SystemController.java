package cn.yq.sysapi.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.sysapi.enumeration.VerificationCodeType;
import cn.yq.sysapi.service.AuthService;
import cn.yq.sysapi.service.SmsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: yinqk
 * @date: 2019-04-28 16:57
 * @description: 系统级API
 */
@Api(value = "系统级API", description = "系统级API")
@RestController
@RequestMapping(value = "/system")
public class SystemController {

    @Autowired
    private AuthService authService;

    @Autowired
    private SmsService smsService;

    @Autowired
    private RedisTemplate redisTemplate;

    @ApiOperation("获取校验码")
    @RequestMapping(value = "/verification-code/{type}/{phoneNo}", method = RequestMethod.GET)
    @SystemLog(description = "获取校验码")
    public Result<String> getVerificationCode(@PathVariable("type") VerificationCodeType type, @PathVariable("phoneNo") String phoneNo) {
        if (VerificationCodeType.RESET_PASSWORD == type) {
            boolean isExist = authService.isExist(phoneNo);

            if (!isExist) {
                return new Result(ResultEnum.FAIL.getCode(), "手机号不存在");
            }
        }

        String verificationCode = RandomStringUtils.randomNumeric(6);
        System.out.println(verificationCode);

        redisTemplate.opsForHash().put("verification_code:" + type, phoneNo, verificationCode);
        String content = String.format("【亦城时代】您的验证码为%s，请勿告诉他人！", verificationCode);
        smsService.sendSms(phoneNo, content);

        return Result.returnOk(verificationCode);
    }


}
