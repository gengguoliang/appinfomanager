package cn.yq.sysapi.service.impl;

import cn.yq.common.utils.BCryptUtil;
import cn.yq.sysapi.dao.AuthRoleMapper;
import cn.yq.sysapi.dao.AuthUserCusMapper;
import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.dao.AuthUserRoleMapper;
import cn.yq.sysapi.model.*;
import cn.yq.sysapi.service.AuthService;
import cn.yq.sysapi.vo.ResetPasswordVO;
import cn.yq.sysapi.vo.TimelineProfileVO;
import cn.yq.sysapi.vo.UserRegistVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AuthServiceImpl implements AuthService {
    @Autowired
    private AuthUserMapper authUserMapper;
    @Resource
    private AuthUserCusMapper authUserCusMapper;
    @Resource
    private AuthRoleMapper authRoleMapper;
    @Resource
    private AuthUserRoleMapper authUserRoleMapper;

    @Override
    public int register(AuthUser userToAdd) {
        final String username = userToAdd.getUsername();
        AuthUserCriteria authUserCriteria = new AuthUserCriteria();
        authUserCriteria.createCriteria().andIsDelEqualTo(false).andUsernameEqualTo(username);
        if (authUserMapper.selectByExample(authUserCriteria).size() > 0) {
            return 0;
        }
        final String rawPassword = userToAdd.getPassword();
        userToAdd.setPassword(BCryptUtil.encode(rawPassword));
        /*userToAdd.setLastPasswordResetDate(new Date());
        userToAdd.setRoles(asList("ROLE_USER"));*/
        return authUserMapper.insert(userToAdd);
    }

    /**
     * 判断手机号是否已注册
     *
     * @param phoneNo
     * @return
     */
    @Override
    public boolean isExist(String phoneNo) {
        AuthUserCriteria authUserCriteria = new AuthUserCriteria();
        authUserCriteria.createCriteria().andIsDelEqualTo(false).andMobileEqualTo(phoneNo);

        boolean isExist = authUserMapper.selectByExample(authUserCriteria).size() > 0;
        return isExist;
    }

    /**
     * @param userRegistVO
     * @Description 添加用户
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void registUser(UserRegistVO userRegistVO) {
        AuthUser authUser = new AuthUser();
        authUser.setMobile(userRegistVO.getPhoneNo());
        String encode = BCryptUtil.encode(userRegistVO.getPassword());
        authUser.setPassword(encode);
        //设置默认值
        authUser.setOrganizationId(0);
        authUser.setProjectId(1);
        authUser.setIsSystem(false);
        authUser.setIsAdmin(false);
        authUser.setAuditedStatus((byte) 1);
        authUser.setIsLocked(false);
        authUser.setUsername(userRegistVO.getPhoneNo());
        authUserMapper.insertSelective(authUser);
        //给默认角色
//        AuthRoleCriteria example=new AuthRoleCriteria();
//        AuthRoleCriteria.Criteria criteria = example.createCriteria();
//        criteria.andIsSystemEqualTo(true)
//                .andOrganizationIdEqualTo(0)
//                .andIsDelEqualTo(false);
//        List<AuthRole> authRoles = authRoleMapper.selectByExample(example);
        AuthUserRole authUserRole = new AuthUserRole();
        authUserRole.setUserId(authUser.getId());
//        if(!ObjectUtils.isEmpty(authRoles)){
//            authUserRole.setRoleId(authRoles.get(0).getId());
//        }
        //从字典表查询app内置角色
        Integer role = authUserCusMapper.getAppRole();
        authUserRole.setRoleId(role);
        authUserRoleMapper.insertSelective(authUserRole);
        //入库生活圈个人资料表
        TimelineProfileVO profileVO = new TimelineProfileVO();
        profileVO.setUserId(authUser.getId());
        profileVO.setNickname(authUser.getUsername());
        profileVO.setHeadImgUrl("http://kodo.smart-zone.51yuqian.net/FtOSnvyPUfIYhpFi_xhR2HXlBCXS");
        profileVO.setCoverImgUrl("http://kodo.smart-zone.51yuqian.net/Fg7COFW3QdRQ0Tgy7Me08S5LVV30?attname=微信图片_20190517175252.png");
        profileVO.setSlogon("此人很懒，没有留下任何信息");
        profileVO.setStatus(0);//状态0：正常，1：禁用，2：封号
        authUserCusMapper.insertProfileVO(profileVO);
    }


    /**
     * @param resetPasswordVO
     * @Description 重置密码
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void resetPassword(ResetPasswordVO resetPasswordVO) {
        AuthUser authUser = new AuthUser();
        String encode = BCryptUtil.encode(resetPasswordVO.getPassword());
        authUser.setPassword(encode);
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andMobileEqualTo(resetPasswordVO.getPhoneNo())
                .andIsDelEqualTo(false);
        authUserMapper.updateByExampleSelective(authUser, example);
    }

//    @Override
//    public String login(String username, String password) {
//        UsernamePasswordAuthenticationToken upToken = new UsernamePasswordAuthenticationToken(username, password);
//        // Perform the security
//        final Authentication authentication = authenticationManager.authenticate(upToken);
//        SecurityContextHolder.getContext().setAuthentication(authentication);
//
//        // Reload password post-security so we can generate token
//        final UserDetails userDetails = userDetailsService.loadUserByUsername(username);
//        final String token = jwtTokenUtil.generateToken(userDetails);
//        return token;
//    }

//    @Override
//    public String refresh(String oldToken) {
//        final String token = oldToken.substring(tokenHead.length());
//        String username = jwtTokenUtil.getUsernameFromToken(token);
//        JwtUser user = (JwtUser) userDetailsService.loadUserByUsername(username);
//        /*if (jwtTokenUtil.canTokenBeRefreshed(token, user.getLastPasswordResetDate())) {
//            return jwtTokenUtil.refreshToken(token);
//        }*/
//        return null;
//    }
}