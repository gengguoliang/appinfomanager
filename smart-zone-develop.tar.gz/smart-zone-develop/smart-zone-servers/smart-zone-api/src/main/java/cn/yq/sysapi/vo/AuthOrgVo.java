package cn.yq.sysapi.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author banzhiguo
 * @Description 组织信息vo
 * @date 2019/2/28 11:30:55
 */
@ApiModel(value = "组织信息vo")
@Getter
@Setter
public class AuthOrgVo {
    @ApiModelProperty(value = "组织id")
    private Integer orgId;
    @ApiModelProperty(value = "用户id")
    private Integer userId;
    @ApiModelProperty(value = "状态")
    private Integer status;
    @ApiModelProperty(value = "状态名")
    private String statusName;// = status == 0 ? "禁用" : status == 1 ? "启用" : "";
    @ApiModelProperty(value = "角色id")
    private Integer roleId;
    @ApiModelProperty(value = "角色名")
    private String roleName;
    @ApiModelProperty(value = "组织类型")
    private Integer type;
    @ApiModelProperty(value = "组织类型名")
    private String typeName;// = type == 0 ? "租赁企业" : type == 1 ? "租赁个人" : type == 2 ? "物业公司" : "装修施工单位";
    @ApiModelProperty(value = "组织名称")
    private String name;
    @ApiModelProperty(value = "手机号")
    private String mobile;
    @ApiModelProperty(value = "用户名")
    private String username;
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date createTime;
}
