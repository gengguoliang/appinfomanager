package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * 修改密码dto
 */
@Setter
@Getter
@ToString
@ApiModel(value = "修改密码dto")
public class UpdatePasswordDto implements Serializable {
    @ApiModelProperty(value = "用户id")
    private Integer userId;

    /*@ApiModelProperty(value = "原密码")
    private String originalPassword;
    @ApiModelProperty(value = "新密码")
    private String newPassword;*/
}
