package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthUserGroupPrivilege;
import cn.yq.sysapi.model.AuthUserGroupPrivilegeCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthUserGroupPrivilegeMapper {
    long countByExample(AuthUserGroupPrivilegeCriteria example);

    int deleteByExample(AuthUserGroupPrivilegeCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthUserGroupPrivilege record);

    int insertSelective(AuthUserGroupPrivilege record);

    List<AuthUserGroupPrivilege> selectByExample(AuthUserGroupPrivilegeCriteria example);

    AuthUserGroupPrivilege selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthUserGroupPrivilege record, @Param("example") AuthUserGroupPrivilegeCriteria example);

    int updateByExample(@Param("record") AuthUserGroupPrivilege record, @Param("example") AuthUserGroupPrivilegeCriteria example);

    int updateByPrimaryKeySelective(AuthUserGroupPrivilege record);

    int updateByPrimaryKey(AuthUserGroupPrivilege record);
}