package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthUserGroup;

import java.util.List;

public interface AuthUserGroupService {

    /**
     * 增加用户组
     */
    int add(AuthUserGroup userGroup);

    /**
     * 删除用户组
     */
    int remove(int id);

    /**
     * 修改用户组
     */
    int update(AuthUserGroup userGroup);

    /**
     * 查询用户组
     */
    List<AuthUserGroup> query(AuthUserGroup userGroup);

    /**
     * 获取用户组信息列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    List<AuthUserGroup> getListByPage(int pageNum, int pageSize);

    /**
     * 删除用户组信息
     */

    boolean deleteUserGroup(int userGroupId);

    /**
     * 向用户组授权
     */
    int userGroupAuthorization(String authInfo);
}
