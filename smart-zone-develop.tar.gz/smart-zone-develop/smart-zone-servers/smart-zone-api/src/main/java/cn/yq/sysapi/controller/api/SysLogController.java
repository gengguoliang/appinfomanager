package cn.yq.sysapi.controller.api;

import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.sysapi.dto.organization.SysLogDTO;
import cn.yq.sysapi.model.SysLog;
import cn.yq.sysapi.service.SysService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @Author: houqijun
 * @Date: 2019/1/9 15:26
 * @Description:
 */
@RestController
public class SysLogController {

    @Resource
    private SysService sysService;

    @PostMapping(value = "/syslog")
    public Result insertSyslog(@RequestBody SysLog sysLog) {
        Integer i = sysService.insertSysLog(sysLog);
        return Result.returnOk();
    }


    /**
     * @Description 系统日志查询
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "系统日志查询", notes = "系统日志查询")
    @PostMapping("/sysLogShow/{pageNum}/{pageSize}")
    @SystemLog(description = "系统日志查询")
    public Result<PageInfo<SysLog>> sysLogShow(@PathVariable("pageNum") Integer pageNum,
                                               @PathVariable("pageSize") Integer pageSize,
                                               @RequestBody SysLogDTO dto) {
        PageInfo<SysLog> pageInfo = new PageInfo<>(sysService.sysLogShow(pageNum, pageSize, dto));
        return Result.returnOk(pageInfo);
    }


}
