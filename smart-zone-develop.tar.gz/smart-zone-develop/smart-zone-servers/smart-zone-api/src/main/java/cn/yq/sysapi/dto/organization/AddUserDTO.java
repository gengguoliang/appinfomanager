package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
@ApiModel(value = "新增用户DTO")
public class AddUserDTO {

    @ApiModelProperty(value = "用户Id")
    private Integer id;

    @ApiModelProperty(value = "所属企业")
    private Integer organizationId;

    @ApiModelProperty(value = "所属部门")
    private List<Integer> departmentIds;

    @ApiModelProperty(value = "所属角色")
    private List<Integer> roleIds;

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "联系电话")
    private String mobile;

    @ApiModelProperty(value = "账号")
    private String userName;

    @ApiModelProperty(value = "密码")
    private String password;

    @ApiModelProperty(value = "状态")
    private Integer isLocked;

    private Integer departmentId;
}
