package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthDatarange;
import cn.yq.sysapi.model.AuthDatarangeCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthDatarangeMapper {
    long countByExample(AuthDatarangeCriteria example);

    int deleteByExample(AuthDatarangeCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthDatarange record);

    int insertSelective(AuthDatarange record);

    List<AuthDatarange> selectByExample(AuthDatarangeCriteria example);

    AuthDatarange selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthDatarange record, @Param("example") AuthDatarangeCriteria example);

    int updateByExample(@Param("record") AuthDatarange record, @Param("example") AuthDatarangeCriteria example);

    int updateByPrimaryKeySelective(AuthDatarange record);

    int updateByPrimaryKey(AuthDatarange record);
}