package cn.yq.sysapi.service;

import cn.yq.sysapi.model.UserDepartment;

import java.util.List;

public interface UserDeptService {

    /**
     * 查询部门列表
     * @param userDepartment
     * @return
     */
    public List<UserDepartment> getDeptTreeData(UserDepartment userDepartment);

    /**
     * 查询部门列表
     * @param userDepartment
     * @return
     */
    public List<UserDepartment> getDeptTreeData2(UserDepartment userDepartment);


    /**
     * 新增部门信息
     * @param userDepartment
     * @return
     */
    public int addDept(UserDepartment userDepartment);


    /**
     * 修改部门信息
     * @param userDepartment
     * @return
     */
    public int updateDept(UserDepartment userDepartment);



    /**
     * 删除部门
     * @param id
     * @return
     */
    public boolean deleteUserDept(int id);

    /**
     * 重置部门状态
     */
    public boolean updateUserDept(int id);


    List<UserDepartment> getDeptList(int organizationId);

   public  UserDepartment getDeptById(Integer id);
}
