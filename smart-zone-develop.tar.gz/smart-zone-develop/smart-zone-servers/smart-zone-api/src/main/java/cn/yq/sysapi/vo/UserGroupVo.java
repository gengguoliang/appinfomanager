package cn.yq.sysapi.vo;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class UserGroupVo  implements Serializable {

    private static final long serialVersionUID = 6106410906115055268L;

    @ApiModelProperty(value = "id", name = "id", required = true, position = 0)
    private int id;

    @ApiModelProperty(value = "parentId", name = "parentid", required = true, position = 0)
    private int parentId;

    @ApiModelProperty(value = "groupName", name = "groupName", required = true, position = 0)
    private String groupName;

    @ApiModelProperty(value = "projectId", name = "projectId", required = true, position = 0)
    private int projectId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
}
