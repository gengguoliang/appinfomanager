package cn.yq.sysapi.service;

import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.model.AuthDatarange;
import com.alibaba.fastjson.JSONObject;

import java.util.List;

public interface AuthDatarangeService {

     JSONObject getRangeDataByRoleid(int roleid);

     int addRangeByRoleId(AuthUser authUser,int roleid, int rangeid);

     int initRangeByRoleId(int roleid);

     List<AuthDatarange>  getRangeByUser(String username);

     List<Integer> getDepartmentChildList(Integer deptId);
}
