package cn.yq.sysapi.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.dao.AuthOrganizationMapper;
import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.dto.organization.AddRoleDTO;
import cn.yq.sysapi.dto.organization.OrganizationAddDTO;
import cn.yq.sysapi.dto.organization.OrganizationShowDTO;
import cn.yq.sysapi.dto.organization.PasswordDTO;
import cn.yq.sysapi.model.AuthOrganization;
import cn.yq.sysapi.model.AuthOrganizationCriteria;
import cn.yq.sysapi.model.AuthUserCriteria;
import cn.yq.sysapi.service.OrganizationInfoService;
import cn.yq.sysapi.vo.OrganizationDetailVO;
import cn.yq.sysapi.vo.OrganizationShowVO;
import cn.yq.sysapi.vo.OrganizationUnitVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * @program: smart-zone
 * @description: 企业信息管理
 * @author: zhengjianhui
 **/
@Slf4j
@Api(value = "企业信息管理", description = "企业信息管理")
@RestController
@RequestMapping("/organizationInfo")
public class OrganizationInfoController {

    @Autowired
    private OrganizationInfoService organizationInfoService;
    @Autowired
    private AuthUserMapper authUserMapper;
    @Autowired
    private AuthOrganizationMapper organizationMapper;


    /**
    *@Description PC装修模块新增时的客户模糊查询
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC装修模块新增时的客户模糊查询", notes = "PC装修模块新增时的客户模糊查询")
    @GetMapping("/getOrgName")
    @SystemLog(description = "新增装修物业时的客户模糊查询")
    public Result getOrgName(@RequestParam("orgName")String orgName){
        AuthOrganizationCriteria example=new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria = example.createCriteria();
        criteria.andNameLike("%"+orgName+"%")
                .andIsDelEqualTo(false);
        List<AuthOrganization> authOrganizations = organizationMapper.selectByExample(example);
        return Result.returnOk(authOrganizations);
    }

    /**
     * @Description PC端新增企业
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC端新增企业)", notes = "PC端新增企业")
    @PostMapping("/organizationAdd")
    @SystemLog(description = "新增企业")
    public Result organizationAdd(@RequestBody OrganizationAddDTO organizationAddDTO) {
        AuthUserCriteria exmaple = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = exmaple.createCriteria();
        criteria.andUsernameEqualTo(organizationAddDTO.getUsername())
                .andIsDelEqualTo(false);
        long row = authUserMapper.countByExample(exmaple);
        if (row > 0) {
            return new Result(ResultEnum.FAIL.getCode(), "账号已存在");
        }
        AuthOrganizationCriteria exmaple1 = new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria1 = exmaple1.createCriteria();
        criteria1.andNameEqualTo(organizationAddDTO.getName())
                .andIsDelEqualTo(false);
        long row1 = organizationMapper.countByExample(exmaple1);
        if (row1 > 0) {
            return new Result(ResultEnum.FAIL.getCode(), "企业名称已存在");
        }
        AuthUserCriteria exmaple2 = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria2 = exmaple2.createCriteria();
        criteria2.andMobileEqualTo(organizationAddDTO.getMobile())
                .andIsDelEqualTo(false);
        long row2 = authUserMapper.countByExample(exmaple2);
        if (row2 > 0) {
            return new Result(ResultEnum.FAIL.getCode(), "手机号已存在");
        }
        organizationInfoService.organizationAdd(organizationAddDTO);
        return Result.returnOk();
    }

    /**
    *@Description PC端列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端列表展示", notes = "PC端列表展示")
    @PostMapping("/showPage/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "企业列表查询")
    public Result showPage(AuthUser authUser, @PathVariable("pageNum")Integer pageNum,
                           @PathVariable("pageSize")Integer pageSize,
                           @RequestBody OrganizationShowDTO organizationShowDTO){
        PageHelper.startPage(pageNum,pageSize);
        PageInfo<OrganizationShowVO> pageInfo=
                new PageInfo<>(organizationInfoService.showPage(organizationShowDTO,authUser.getId()));
        return Result.returnOk(pageInfo);
    }
    
    /**
    *@Description PC端禁用启用
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端禁用启用", notes = "PC端禁用启用")
    @GetMapping("/changeIsLocked/{id}/{isLocked}")
    @SystemLog(description = "企业禁用或启用")
    public Result changeIsLocked(@PathVariable("id")Integer id,
                               @PathVariable("isLocked")Integer isLocked){
        organizationInfoService.changeIsLocked(id,isLocked);
        return Result.returnOk();
    }
    
    /**
    *@Description PC端冻结
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端冻结", notes = "PC端冻结")
    @GetMapping("/changeStatus/{id}/{status}")
    @SystemLog(description = "企业冻结或解冻")
    public Result changeStatus(@PathVariable("id")Integer id,
                               @PathVariable("status")Integer status){
        organizationInfoService.changeStatus(id,status);
        return Result.returnOk();
    }
    
    /**
    *@Description PC端删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端删除", notes = "PC端删除")
    @GetMapping("/remove/{id}")
    @SystemLog(description = "删除企业")
    public Result remove(@PathVariable("id")Integer id){
        organizationInfoService.remove(id);
        return Result.returnOk();
    }
    
    /**
    *@Description PC端重置密码
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端重置密码", notes = "PC端重置密码")
    @GetMapping("/resetPassword/{id}")
    @SystemLog(description = "企业信息管理的重置密码")
    public Result resetPassword(@PathVariable("id")Integer id){
        organizationInfoService.resetPassword(id);
        return Result.returnOk();
    }
    
    
    /**
    *@Description PC端修改密码
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端修改密码", notes = "PC端修改密码")
    @PostMapping("/updatePassword")
    @LoginUser
    @SystemLog(description = "修改密码")
    public Result updatePassword(@ApiIgnore AuthUser authUser, @RequestBody PasswordDTO dto){
        Result result = organizationInfoService.updatePassword(authUser, dto);
        return result;
    }
    
    /**
    *@Description PC端添加角色
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端添加角色", notes = "PC端添加角色")
    @PostMapping("/addRole")
    @SystemLog(description = "企业信息管理的添加角色")
    public Result addRole(@RequestBody AddRoleDTO addRoleDTO){
        organizationInfoService.addRole(addRoleDTO);
        return Result.returnOk();
    }
    
    /**
    *@Description PC获取拼接单元
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC获取拼接单元", notes = "PC获取拼接单元")
    @GetMapping("/getUnit")
    @SystemLog(description = "添加企业时获取承租单元")
    public Result getUnit(@RequestParam("orgId")Integer orgId){
        List<OrganizationUnitVO> units = organizationInfoService.getUnit(orgId);
        return Result.returnOk(units);
    }
    
    /**
    *@Description PC编辑时详情展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC编辑时详情展示", notes = "PC编辑时详情展示")
    @GetMapping("/detail/{id}")
    @SystemLog(description = "企业的详情展示")
    public Result detail(@PathVariable("id")Integer id){
        OrganizationDetailVO organizationDetailVO = organizationInfoService.detail(id);
        return Result.returnOk(organizationDetailVO);
    }
    
    /**
    *@Description PC编辑
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC编辑", notes = "PC编辑")
    @PostMapping("/edit")
    @SystemLog(description = "编辑企业")
    public Result edit(@RequestBody OrganizationAddDTO organizationAddDTO){
        organizationInfoService.edit(organizationAddDTO);
        return Result.returnOk();
    }
}
