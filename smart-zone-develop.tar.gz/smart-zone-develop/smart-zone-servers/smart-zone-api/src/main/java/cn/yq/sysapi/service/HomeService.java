package cn.yq.sysapi.service;

public interface HomeService {
    /**
     * say hi
     *
     * @return
     */
    String sayHi();
}
