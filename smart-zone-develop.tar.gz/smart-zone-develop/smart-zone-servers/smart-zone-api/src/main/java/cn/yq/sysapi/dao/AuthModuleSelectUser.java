package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthModuleSelectUser {

    List<AuthUser> selectUserByRoleId(int roleId);
    List<AuthUser> getOutUsersByRoleId(@Param("orgid") int orgid, @Param("roleId") int roleId);
}
