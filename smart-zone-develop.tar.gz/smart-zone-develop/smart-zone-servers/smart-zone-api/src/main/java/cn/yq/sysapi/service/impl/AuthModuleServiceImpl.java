package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthModuleMapper;
import cn.yq.sysapi.dao.AuthModulePrivilegeCusMapper;
import cn.yq.sysapi.dao.AuthRolePrivilegeMapper;
import cn.yq.sysapi.model.*;
import cn.yq.sysapi.service.AuthModuleService;
import cn.yq.sysapi.vo.AuthModulePrivilegeVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.security.auth.login.CredentialException;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class AuthModuleServiceImpl implements AuthModuleService {

    @Autowired
    AuthModuleMapper authModuleMapper;

    @Autowired
    AuthModulePrivilegeCusMapper authModulePrivilegeCusMapper;

    @Autowired
    AuthRolePrivilegeMapper authRolePrivilegeMapper;

    @Override
    public List<AuthModule> getTreeData(String username, String method) {
        AuthModuleCriteria example = new AuthModuleCriteria();
        AuthModuleCriteria.Criteria criteria = example.createCriteria();
        criteria.andIsDelEqualTo(false);
        if(method.equals("getTreeData")){
//            criteria.andTypeEqualTo("1");
        }else if(method.equals("getTreeModuleData")){
//            criteria.andTypeEqualTo("2");
        }
        example.setOrderByClause("id asc");
        return authModuleMapper.selectByExample(example);
    }

    /**
     * 根据角色获取树结构数据
     * @param roleids
     * @return
     */
    @Override
    public List<AuthModulePrivilegeVo> getTreeDataByRoleids(List roleids,Integer category) {
        return authModulePrivilegeCusMapper.getTreeDataByRoleids(roleids,category);
    }


    @Override
    public List<AuthModulePrivilegeVo> getTreeModuleDataByRoleids(Integer orgid,List roleids,Integer category) {
        return authModulePrivilegeCusMapper.getTreeModuleDataByRoleids(orgid,roleids,category);
    }

    @Override
    public List<AuthModulePrivilegeVo> getTreeModuleDataShengyuan(List roleids,Integer category) {
        return authModulePrivilegeCusMapper.getTreeModuleDataShengyuan(roleids,category);
    }

    @Override
    public int authorizeByRoleid(int roleId,int category,int[] auth) {
        //解析json数据
//        JSONObject object = JSON.parseObject(info);
//        String roleid = (String)object.get("roleid");
//        int[] auth = (int[])object.get("auth");
        //获取当前角色下的app或者pc功能id集合
        List<Integer> privilegeIds = authModulePrivilegeCusMapper.selectPrivilegePcOrApp(roleId,category);
        //把所有这个角色下的数据删除
        //修改把这个角色下的非模块，菜单数据删除
        List templist = new ArrayList();
        log.debug("size=================>"+privilegeIds.size());
        if (privilegeIds.size() != 0) {
            AuthRolePrivilegeCriteria example = new AuthRolePrivilegeCriteria();
            AuthRolePrivilegeCriteria.Criteria criteria = example.createCriteria();
            criteria.andRoleIdEqualTo(Integer.valueOf(roleId));
            criteria.andPrivilegeIdIn(privilegeIds);
            AuthRolePrivilege authRolePrivilege = new AuthRolePrivilege();
            authRolePrivilege.setIsDel(true);
            authRolePrivilegeMapper.updateByExampleSelective(authRolePrivilege,example);
        }
        if(auth.length==1 && auth[0]==100000){
            return 0;
        }
        for(int i=0;i<auth.length;i++) {
            templist.add(auth[i]);
        }
        //查到该角色下的数据
        AuthRolePrivilegeCriteria example2 = new AuthRolePrivilegeCriteria();
        AuthRolePrivilegeCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andRoleIdEqualTo(Integer.valueOf(roleId));
        criteria2.andPrivilegeIdIn(templist);
        List<AuthRolePrivilege> list = authRolePrivilegeMapper.selectByExample(example2);
        //根据privilege_id数组更新数据
        //循环，如果数据库存在数组里的记录，isdel设置为false，如果不存在，添加一条记录
        List ids = new ArrayList();
        List ids3 = new ArrayList();
        List ids2 = new ArrayList();
        for(int i=0;i<auth.length;i++){
            ids3.add(auth[i]);
            for(AuthRolePrivilege temp:list){
                int privilegeId = temp.getPrivilegeId();
                if(auth[i] == privilegeId){
                    //如果数据库存在数组里的记录
                   ids.add(privilegeId);
                }else{

                }
            }
        }
        //ids2存放不存在的值
        ids3.removeAll(ids);

        //如果数据库存在数组里的记录，isdel设置为false
        AuthRolePrivilegeCriteria example3 = new AuthRolePrivilegeCriteria();
        AuthRolePrivilegeCriteria.Criteria criteria3 = example3.createCriteria();
        criteria3.andPrivilegeIdIn(ids);
        criteria3.andRoleIdEqualTo(roleId);
        AuthRolePrivilege authRolePrivilege1 = new AuthRolePrivilege();
        authRolePrivilege1.setIsDel(false);
        if(ids.size()>0){
            authRolePrivilegeMapper.updateByExampleSelective(authRolePrivilege1,example3);
        }
        //如果不存在，添加一条记录
        for(int i=0;i<ids3.size();i++){
            AuthRolePrivilege temp = new AuthRolePrivilege();
            temp.setRoleId(Integer.valueOf(roleId));
            temp.setPrivilegeId((int)ids3.get(i));
            temp.setIsDel(false);
            authRolePrivilegeMapper.insertSelective(temp);
        }

        return 0;

    }
    /**
     * 根据角色ID查找用户角色对应的权限code
     * @param roleids
     * @return
     */
    @Override
    public List selectPrivilegeCode(List roleids) {

        return authModulePrivilegeCusMapper.selectPrivilegeCode(roleids);

    }

    @Override
    public List<String> selectPrivilegeAPPCode(List roleids, Integer category) {
        return authModulePrivilegeCusMapper.selectPrivilegeAPPCode(roleids,category);
    }
}
