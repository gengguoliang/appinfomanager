package cn.yq.sysapi.service.impl;

import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.dao.AuthDatarangeCusMapper;
import cn.yq.sysapi.dao.AuthDatarangeMapper;
import cn.yq.sysapi.dao.AuthRoleDatarangeMapper;
import cn.yq.sysapi.dao.AuthUserRoleMapper;
import cn.yq.sysapi.model.*;
import cn.yq.sysapi.service.AuthDatarangeService;
import cn.yq.sysapi.utils.RedisKeyUtil;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class AuthDatarangeServiceImpl implements AuthDatarangeService {

    @Autowired
    AuthDatarangeMapper mapper;

    @Autowired
    AuthDatarangeCusMapper cusMapper;

    @Autowired
    AuthRoleDatarangeMapper authRoleDatarangeMapper;

    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private AuthUserRoleMapper authUserRoleMapper;

    /**
     * 根据角色id获取范围数据
     *
     * @param roleid
     * @return
     */
    @Override
    public JSONObject getRangeDataByRoleid(int roleid) {

        JSONObject object = new JSONObject();
        //获取范围数据集合
        AuthDatarangeCriteria example = new AuthDatarangeCriteria();
        AuthDatarangeCriteria.Criteria criteria = example.createCriteria();
        example.setOrderByClause("sort_num asc");
        List<AuthDatarange> list = mapper.selectByExample(example);
        object.put("authRange", list);

        //根据角色id获取该角色的数据范围
        AuthDatarange authDatarange = cusMapper.getDatarangeByRoleid(roleid);
        object.put("authRangeVal", authDatarange);

        //按明细设计
        AuthDatarangeCriteria example1 = new AuthDatarangeCriteria();
        AuthDatarangeCriteria.Criteria criteria1 = example1.createCriteria();
        criteria1.andNameEqualTo("按明细设计");
        List<AuthDatarange> resultlist = mapper.selectByExample(example1);
        AuthDatarange datarange = resultlist.get(0);
        object.put("theKeyOfDetail", datarange);

        return object;
    }

    @Override
    public int addRangeByRoleId(AuthUser authUser, int roleid, int rangeid) {
        AuthUserRoleCriteria example1 = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria1 = example1.createCriteria();
        criteria1.andIsDelEqualTo(false)
                .andRoleIdEqualTo(roleid);
        List<AuthUserRole> authUserRoles = authUserRoleMapper.selectByExample(example1);
        List<String> ids = new ArrayList<>();
        authUserRoles.forEach(authUserRole ->
                ids.add(RedisKeyUtil.getKey(authUserRole.getUserId()))
        );
        //清除缓存权限数据
        redisTemplate.delete(ids);
        //数据库有默认记录，根据roleid查询出记录，修改
        AuthRoleDatarangeCriteria example = new AuthRoleDatarangeCriteria();
        AuthRoleDatarangeCriteria.Criteria criteria = example.createCriteria();
        criteria.andRoleIdEqualTo(roleid);
        List<AuthRoleDatarange> list = authRoleDatarangeMapper.selectByExample(example);
        int result = 0;
        //如果list>0修改  否则新增
        if (list.size() > 0) {
            AuthRoleDatarange authRoleDatarange = new AuthRoleDatarange();
            authRoleDatarange.setRangeId(rangeid);
            authRoleDatarange.setRoleId(roleid);
            result = authRoleDatarangeMapper.updateByExampleSelective(authRoleDatarange, example);
        } else {
            //新增记录
            AuthRoleDatarange authRoleDatarange = new AuthRoleDatarange();
            authRoleDatarange.setRangeId(rangeid);
            authRoleDatarange.setRoleId(roleid);
            result = authRoleDatarangeMapper.insertSelective(authRoleDatarange);
        }
        return result;
    }

    @Override
    public int initRangeByRoleId(int roleid) {
        AuthRoleDatarange authRoleDatarange = new AuthRoleDatarange();
        authRoleDatarange.setRangeId(5);
        authRoleDatarange.setRoleId(roleid);
        int result = authRoleDatarangeMapper.insertSelective(authRoleDatarange);
        return result;
    }

    @Override
    public List<AuthDatarange> getRangeByUser(String username) {
        return cusMapper.getRangeByUser(username);
    }

    @Override
    public List<Integer> getDepartmentChildList(Integer deptId) {
        String depts = cusMapper.getDepartmentChildList(deptId);
        String[] dept = depts.split(",");
        List<Integer> list = new ArrayList<>();
        for (String deptid : dept) {
            list.add(new Integer(deptid));
        }
        return list;
    }
}
