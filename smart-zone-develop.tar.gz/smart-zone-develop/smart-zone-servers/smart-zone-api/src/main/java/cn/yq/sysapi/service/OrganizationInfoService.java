package cn.yq.sysapi.service;

import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.dto.organization.AddRoleDTO;
import cn.yq.sysapi.dto.organization.OrganizationAddDTO;
import cn.yq.sysapi.dto.organization.OrganizationShowDTO;
import cn.yq.sysapi.dto.organization.PasswordDTO;
import cn.yq.sysapi.vo.OrganizationDetailVO;
import cn.yq.sysapi.vo.OrganizationShowVO;
import cn.yq.sysapi.vo.OrganizationUnitVO;

import java.util.List;

/**
 * @program: smart-zone
 * @description: 组织信息管理
 * @author: zhengjianhui
 **/
public interface OrganizationInfoService {

    /**
    *@Description PC端新增企业
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    void organizationAdd(OrganizationAddDTO organizationAddDTO);
    
    /**
    *@Description PC端列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    List<OrganizationShowVO> showPage(OrganizationShowDTO organizationShowDTO,Integer userId);
    
    /**
    *@Description PC端启用禁用
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void changeIsLocked(Integer id,Integer isLocked);
    
    /**
    *@Description PC端冻结
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void changeStatus(Integer id,Integer status);
    
    /**
    *@Description PC端删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void remove(Integer id);
    
    /**
    *@Description 重置密码
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void resetPassword(Integer id);
    Result updatePassword(AuthUser authUser, PasswordDTO dto);
    
    /**
    *@Description 添加角色
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void addRole(AddRoleDTO addRoleDTO);
    
    /**
    *@Description 获取拼接单元
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    List<OrganizationUnitVO> getUnit(Integer orgId);
    
    /**
    *@Description PC编辑时详情展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    OrganizationDetailVO detail(Integer id);
    
    /**
    *@Description PC编辑
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void edit(OrganizationAddDTO organizationAddDTO);
}
