package cn.yq.sysapi.common.exception;

/**
 * @Auther: houqijun
 * @Date: 2018/11/23 16:40
 * @Description:
 */
public class SmartApiException extends RuntimeException {

    private String message;

    public SmartApiException(String message){
        super();
        this.message = message;
    }
}
