package cn.yq.sysapi.service;

import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.dto.organization.AddRoleDTO;
import cn.yq.sysapi.dto.organization.AddUserDTO;
import cn.yq.sysapi.dto.organization.UserShowDTO;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.vo.AddUserShowVO;
import cn.yq.sysapi.vo.UserDetailVO;
import cn.yq.sysapi.vo.UserShowVO;

import java.util.List;

/**
 * 园区用户管理
 */
public interface UserService {

    /**
    *@Description 部门回显需要的List
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    List<Integer> getDeptIds(AuthUser authUser);

    /**
     *@Description 部门回显需要的List  2
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    List<Integer> getDeptIds2(AuthUser authUser);
    
    
    /**
    *@Description 当前用户组织的所有角色
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    List<AuthRole> getRoleByUserId(AuthUser authUser);
    
    /**
    *@Description PC添加和编辑用户
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void addUser(AddUserDTO addUserDTO);
    
    /**
    *@Description PC列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    List<UserShowVO> showPage(AuthUser authUser,UserShowDTO userShowDTO);
    
    /**
    *@Description PC端审核
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void changeAuditedStatus(Integer id,Integer auditedStatus,String remark);
    
    /**
    *@Description PC冻结
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void changeIsLocked(Integer id,Integer isLocked);
    
    /**
    *@Description PC删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void remove(Integer id);
    
    /**
    *@Description PC详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    UserDetailVO detail(Integer id);

    /**
    *@Description PC端添加时的信息展示
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    AddUserShowVO addUserShow(AuthUser authUser);
    
    /**
    *@Description PC给用户添加角色
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    void addUserRole(AddRoleDTO addRoleDTO);
}
