package cn.yq.sysapi.model;

import java.io.Serializable;
import java.util.Date;

public class AuthOrganizationUnit implements Serializable {
    /**
     * 主键 id
     */
    private Integer id;

    /**
     * 组织id organization_id
     */
    private Integer organizationId;

    /**
     * 楼宇id building_id
     */
    private Integer buildingId;

    /**
     * 楼层id storey_id
     */
    private Integer storeyId;

    /**
     * 单元id unit_id
     */
    private Integer unitId;

    /**
     * 创建时间 create_time
     */
    private Date createTime;

    /**
     * 创建人 create_by
     */
    private String createBy;

    /**
     * 修改时间 update_time
     */
    private Date updateTime;

    /**
     * 修改人 update_by
     */
    private String updateBy;

    /**
     * 是否删除 is_del
     */
    private Boolean isDel;

    /**
     * auth_organization_unit
     */
    private static final long serialVersionUID = 1L;

    /**
     * 主键
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return id 主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 主键
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param id 主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 组织id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return organization_id 组织id
     */
    public Integer getOrganizationId() {
        return organizationId;
    }

    /**
     * 组织id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param organizationId 组织id
     */
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    /**
     * 楼宇id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return building_id 楼宇id
     */
    public Integer getBuildingId() {
        return buildingId;
    }

    /**
     * 楼宇id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param buildingId 楼宇id
     */
    public void setBuildingId(Integer buildingId) {
        this.buildingId = buildingId;
    }

    /**
     * 楼层id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return storey_id 楼层id
     */
    public Integer getStoreyId() {
        return storeyId;
    }

    /**
     * 楼层id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param storeyId 楼层id
     */
    public void setStoreyId(Integer storeyId) {
        this.storeyId = storeyId;
    }

    /**
     * 单元id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return unit_id 单元id
     */
    public Integer getUnitId() {
        return unitId;
    }

    /**
     * 单元id
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param unitId 单元id
     */
    public void setUnitId(Integer unitId) {
        this.unitId = unitId;
    }

    /**
     * 创建时间
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return create_time 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 创建人
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return create_by 创建人
     */
    public String getCreateBy() {
        return createBy;
    }

    /**
     * 创建人
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param createBy 创建人
     */
    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    /**
     * 修改时间
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return update_time 修改时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 修改时间
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 修改人
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return update_by 修改人
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * 修改人
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param updateBy 修改人
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    /**
     * 是否删除
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @return is_del 是否删除
     */
    public Boolean getIsDel() {
        return isDel;
    }

    /**
     * 是否删除
     * @author ROY
     * @date 2019-03-14 10:16:14
     * @param isDel 是否删除
     */
    public void setIsDel(Boolean isDel) {
        this.isDel = isDel;
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AuthOrganizationUnit other = (AuthOrganizationUnit) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getOrganizationId() == null ? other.getOrganizationId() == null : this.getOrganizationId().equals(other.getOrganizationId()))
            && (this.getBuildingId() == null ? other.getBuildingId() == null : this.getBuildingId().equals(other.getBuildingId()))
            && (this.getStoreyId() == null ? other.getStoreyId() == null : this.getStoreyId().equals(other.getStoreyId()))
            && (this.getUnitId() == null ? other.getUnitId() == null : this.getUnitId().equals(other.getUnitId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getIsDel() == null ? other.getIsDel() == null : this.getIsDel().equals(other.getIsDel()));
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getOrganizationId() == null) ? 0 : getOrganizationId().hashCode());
        result = prime * result + ((getBuildingId() == null) ? 0 : getBuildingId().hashCode());
        result = prime * result + ((getStoreyId() == null) ? 0 : getStoreyId().hashCode());
        result = prime * result + ((getUnitId() == null) ? 0 : getUnitId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getIsDel() == null) ? 0 : getIsDel().hashCode());
        return result;
    }
}