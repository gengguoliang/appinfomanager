package cn.yq.sysapi.common.Constant;

/**
 * 常量类
 */
public class GlobalConstant {
    /**
     * 以下是组织模块使用
     * 0启用1禁用2冻结
     */
    public static final int START_USE = 0;// 启用
    public static final int FORBIDDEN = 1;// 禁用
    public static final int FROZEN = 2;// 冻结


    /**
     * 1删除0不删除
     */
    public static final byte  DEL_YES = 1;
    public static final byte  DEL_NO = 0;

    /**
     * 1是组织管理员0不是组织管理员
     */
    public static final byte IS_ADMIN = 1;

    /**
     * 以下是用户模块使用
     * 1启用0禁用
     */
    public static final byte USER_USE = 1;
    public static final byte USER_FORBIDDEN = 0;

    /**
     * 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位
     */
    public static final byte ORG_RENT = 0;
    public static final byte ORG_RENT_PERSION = 1;

    /**
     * 用户证件类型1身份证
     */
    public static final int USER_CERTIFY_TYPE_IDENT = 1;

    /**
     * 添加方式1pc2app
     */
    public static final byte UADD_METHOD_PC = 1;
    public static final byte UADD_METHOD_APP = 2;

    /**
     * 组织审核状态
     */
    public static final byte TO_BE_AUDITED = 0;
    public static final byte PASS_AUDITED = 1;
    public static final byte FAILED_AUDITED = 2;

    /**
     * 是否已审核
     * 1审核通过0审核不通过
     */
    public static final byte USER_AUDITED_FAILED = 0;
    public static final byte USER_PASS_AUDITED = 1;

    public static final int CERTIFY_TYPE_CODE = 1;// 统一社会信用代码
}
