package cn.yq.sysapi.service;

import cn.yq.common.datapermission.DataPermissionContext;


/**
 * @Author: ggl
 * @Date: 2019/6/5 14:29
 * @Description:
 */
public interface DataAuthService {
    public DataPermissionContext getDeptIds() throws Throwable;
}
