package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthPrivilege;
import cn.yq.sysapi.model.AuthPrivilegeCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthPrivilegeMapper {
    long countByExample(AuthPrivilegeCriteria example);

    int deleteByExample(AuthPrivilegeCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthPrivilege record);

    int insertSelective(AuthPrivilege record);

    List<AuthPrivilege> selectByExample(AuthPrivilegeCriteria example);

    AuthPrivilege selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthPrivilege record, @Param("example") AuthPrivilegeCriteria example);

    int updateByExample(@Param("record") AuthPrivilege record, @Param("example") AuthPrivilegeCriteria example);

    int updateByPrimaryKeySelective(AuthPrivilege record);

    int updateByPrimaryKey(AuthPrivilege record);
}