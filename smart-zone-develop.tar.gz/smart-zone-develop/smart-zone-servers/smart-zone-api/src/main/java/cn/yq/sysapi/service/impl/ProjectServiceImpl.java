package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthProjectMapper;
import cn.yq.sysapi.model.AuthProject;
import cn.yq.sysapi.service.ProjectService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectServiceImpl implements ProjectService {
    @Autowired
    private AuthProjectMapper authProjectMapper;

    /**
     * 获取项目列表
     *
     * @return
     */
    @Override
    public List<AuthProject> getListByPage(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return authProjectMapper.selectByExample(null);
    }

    /**
     * 新增项目
     *
     * @param project
     * @return
     */
    @Override
    public int add(AuthProject project) {
        return authProjectMapper.insertSelective(project);
    }
}
