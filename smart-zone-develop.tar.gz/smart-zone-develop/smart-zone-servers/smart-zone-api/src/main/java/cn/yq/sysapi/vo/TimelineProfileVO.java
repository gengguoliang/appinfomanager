package cn.yq.sysapi.vo;

import lombok.Data;

/**
 * <p>
 * 生活圈个人资料
 * </p>
 *
 * @author LWL
 * @since 2019-03-15
 */
@Data
public class TimelineProfileVO{

    /**
     * 用户ID
     */
	private Integer userId;
    /**
     * 昵称
     */
	private String nickname;
    /**
     * 头像
     */
	private String headImgUrl;
    /**
     * 主页封面图
     */
	private String coverImgUrl;
    /**
     * 个性签名
     */
	private String slogon;
    /**
     * 状态，0：正常，1：禁用，2：封号
     */
	private Integer status;




}
