package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthRoleDepartment;
import cn.yq.sysapi.model.AuthRoleDepartmentCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthRoleDepartmentMapper {
    long countByExample(AuthRoleDepartmentCriteria example);

    int deleteByExample(AuthRoleDepartmentCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthRoleDepartment record);

    int insertSelective(AuthRoleDepartment record);

    List<AuthRoleDepartment> selectByExample(AuthRoleDepartmentCriteria example);

    AuthRoleDepartment selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthRoleDepartment record, @Param("example") AuthRoleDepartmentCriteria example);

    int updateByExample(@Param("record") AuthRoleDepartment record, @Param("example") AuthRoleDepartmentCriteria example);

    int updateByPrimaryKeySelective(AuthRoleDepartment record);

    int updateByPrimaryKey(AuthRoleDepartment record);

    List<Integer> getDeptIdsByRoleId(Integer roleId);
}