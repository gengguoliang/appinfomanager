package cn.yq.sysapi.vo;

/**
 * @author: yinqk
 * @date: 2019-03-11 22:56
 * @description: TODO
 */
public class AuthOrganizationUserVO {

}
