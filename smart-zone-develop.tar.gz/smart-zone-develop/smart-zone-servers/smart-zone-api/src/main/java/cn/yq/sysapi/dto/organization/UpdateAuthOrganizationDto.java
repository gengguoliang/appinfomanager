package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author banzhiguo
 * @Description 组织信息dto 更新使用
 * @date 2019/2/28 11:30:55
 */
@ApiModel(value = "更新组织信息dto")
@Setter
@Getter
public class UpdateAuthOrganizationDto implements Serializable {
    @ApiModelProperty(value = "id", required = true)
    private Integer id;
    @ApiModelProperty(value = "组织类型")
    private Integer type;
    @ApiModelProperty(value = "证件类型")
    private Integer certifyType;
    @ApiModelProperty(value = "证件号码")
    private String certifyNum;
    @ApiModelProperty(value = "状态")
    private Integer status;
    @ApiModelProperty(value = "备注")
    private String remark;
}
