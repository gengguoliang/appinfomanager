package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthOrganizationUnit;
import cn.yq.sysapi.model.AuthOrganizationUnitCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthOrganizationUnitMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(AuthOrganizationUnitCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(AuthOrganizationUnitCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(AuthOrganizationUnit record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(AuthOrganizationUnit record);

    /**
     *
     * @mbg.generated
     */
    List<AuthOrganizationUnit> selectByExample(AuthOrganizationUnitCriteria example);

    /**
     *
     * @mbg.generated
     */
    AuthOrganizationUnit selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") AuthOrganizationUnit record, @Param("example") AuthOrganizationUnitCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") AuthOrganizationUnit record, @Param("example") AuthOrganizationUnitCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(AuthOrganizationUnit record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(AuthOrganizationUnit record);
}