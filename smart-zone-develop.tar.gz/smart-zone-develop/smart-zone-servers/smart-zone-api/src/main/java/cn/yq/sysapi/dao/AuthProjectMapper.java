package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthProject;
import cn.yq.sysapi.model.AuthProjectCriteria;
import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface AuthProjectMapper {
    long countByExample(AuthProjectCriteria example);

    int deleteByExample(AuthProjectCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthProject record);

    int insertSelective(AuthProject record);

    List<AuthProject> selectByExample(AuthProjectCriteria example);

    AuthProject selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthProject record, @Param("example") AuthProjectCriteria example);

    int updateByExample(@Param("record") AuthProject record, @Param("example") AuthProjectCriteria example);

    int updateByPrimaryKeySelective(AuthProject record);

    int updateByPrimaryKey(AuthProject record);
}