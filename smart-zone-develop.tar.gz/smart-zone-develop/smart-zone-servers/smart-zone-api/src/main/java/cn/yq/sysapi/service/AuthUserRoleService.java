package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthUser;

import java.util.List;

public interface AuthUserRoleService {


    List<AuthUser> getUsersByRoleId(int roleId);

    int addUsersByRoleId(int roleId,int[] userids);

    int removeUsersByRoleId(int roleId);

    int removeUserByRoleIdAndUserid(int roleId,int userId);

    List<AuthUser> getOutUsersByRoleId(int orgid,int roleId);


}
