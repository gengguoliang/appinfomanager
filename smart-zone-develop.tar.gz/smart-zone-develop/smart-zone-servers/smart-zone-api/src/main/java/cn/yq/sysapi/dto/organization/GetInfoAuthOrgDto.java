package cn.yq.sysapi.dto.organization;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

/**
 * @description 查询组织信息dto
 * @author banzhiguo
 * @date 2019/2/28 11:30:55
 */
@ApiModel(value = "查询组织信息dto")
@Setter
@Getter
public class GetInfoAuthOrgDto implements Serializable {
    @ApiModelProperty(value = "所属类型")
    private Integer type;
    @ApiModelProperty(value = "角色id")
    private Integer roleId;
    @ApiModelProperty(value = "状态")
    private Integer status;
    @ApiModelProperty(value = "起始时间")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date startTime;
    @ApiModelProperty(value = "截至时间")
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private Date endTime;
    @ApiModelProperty(value = "姓名")
    private String username;
    private Integer pageNum;
    private Integer pageSize;
}
