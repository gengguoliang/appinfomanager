package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthUser;

import java.util.List;

public interface AuthUserUserGroupService {

     List<AuthUser> getUsersByUserGroupId(int userGroupId);

     int addUsersByUserGroupId(int userGroupId,int[] userids);

     int removeUsersByUserGroupId(int userGroupId);

     int removeUserByUserGroupIdAndUserid(int userGroupId,int userId);

     List<AuthUser> getOutUsersByUserGroupId(int userGroupId);

}
