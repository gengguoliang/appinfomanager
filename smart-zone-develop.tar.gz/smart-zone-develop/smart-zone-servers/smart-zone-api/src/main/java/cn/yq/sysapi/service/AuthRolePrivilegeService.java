package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthPrivilegeByRoleId;

import java.util.List;

public interface AuthRolePrivilegeService {
    /**
     * 根据角色Id授予角色权限
     * @param roleId
     * @param privilegeIds
     */
    void addPrivilegeByRoleId(int roleId, int[] privilegeIds);
    /**
     * 根据角色ID获取角色权限及相对应的模块
     * @param roleId
     * @return
     */
    List<AuthPrivilegeByRoleId> selectPrivilegeByRoleId(int roleId);

    /**
     * 根据角色ID和权限ID列表,进行保存
     * @param roleId
     * @param privilegeIds
     */
    void addRolePrivilege(int roleId, int[] privilegeIds);
}
