package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.UserDepartmentMapper;
import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.model.UserDepartmentCriteria;
import cn.yq.sysapi.service.UserDeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDeptServiceImpl implements UserDeptService {

    @Autowired
    UserDepartmentMapper mapper;

    @Override
    public List<UserDepartment> getDeptTreeData(UserDepartment userDepartment) {

        UserDepartmentCriteria example = new UserDepartmentCriteria();
        UserDepartmentCriteria.Criteria criteria = example.createCriteria();
        if(null!=userDepartment.getName()&&!"".equals(userDepartment.getName())){
            criteria.andNameEqualTo(userDepartment.getName());
        }
        if(null!=userDepartment.getOrganizationId()){
            criteria.andOrganizationIdEqualTo(userDepartment.getOrganizationId());
        }
        if(null==userDepartment.getOrganizationId()){
            criteria.andOrganizationIdEqualTo(1658469);
        }
        criteria.andIsDelEqualTo(false);
        return mapper.selectByExample(example);
    }

    @Override
    public List<UserDepartment> getDeptTreeData2(UserDepartment userDepartment) {
        UserDepartmentCriteria example = new UserDepartmentCriteria();
        UserDepartmentCriteria.Criteria criteria = example.createCriteria();
        if(null!=userDepartment.getName()&&!"".equals(userDepartment.getName())){
            criteria.andNameEqualTo(userDepartment.getName());
        }
        if(null!=userDepartment.getOrganizationId()){
            criteria.andOrganizationIdEqualTo(userDepartment.getOrganizationId());
        }
        criteria.andIsDelEqualTo(true);
        criteria.andParentIdEqualTo(userDepartment.getParentId());
        return mapper.selectByExample(example);
    }

    @Override
    public int addDept(UserDepartment userDepartment) {
        return mapper.insertSelective(userDepartment);
    }


    @Override
    public UserDepartment getDeptById(Integer id) {
        return mapper.selectByPrimaryKey(id);
    }

    @Override
    public boolean deleteUserDept(int id) {
        UserDepartment userDepartment = new UserDepartment();
        userDepartment.setId(id);
        userDepartment.setIsDel(true);
        mapper.updateByPrimaryKeySelective(userDepartment);
        return true;
    }

    @Override
    public boolean updateUserDept(int id) {
        UserDepartment userDepartment = new UserDepartment();
        userDepartment.setId(id);
        userDepartment.setIsDel(false);
        mapper.updateByPrimaryKeySelective(userDepartment);
        return true;
    }

    @Override
    public List<UserDepartment> getDeptList(int organizationId) {
        UserDepartmentCriteria example = new UserDepartmentCriteria();
        UserDepartmentCriteria.Criteria criteria = example.createCriteria();
        criteria.andOrganizationIdEqualTo(organizationId);
        return mapper.selectByExample(example);
    }

    @Override
    public int updateDept(UserDepartment userDepartment) {
        UserDepartmentCriteria example = new UserDepartmentCriteria();
        UserDepartmentCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(userDepartment.getId());
        return mapper.updateByExampleSelective(userDepartment, example);
    }

}
