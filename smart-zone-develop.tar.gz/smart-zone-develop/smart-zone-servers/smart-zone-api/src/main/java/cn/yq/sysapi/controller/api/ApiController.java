package cn.yq.sysapi.controller.api;

import cn.yq.common.annotations.SystemLog;
import cn.yq.common.enumeration.DictionaryType;
import cn.yq.common.result.Result;
import cn.yq.common.utils.ObjectConvertUtil;
import cn.yq.common.vo.SysDictDataVo;
import cn.yq.sysapi.model.SysDictData;
import cn.yq.sysapi.service.SysService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Auther: houqijun
 * @Date: 2018/12/11 18:30
 * @Description:
 */
@Api(value = "系统数据", description = "系统数据 API")
@RestController
@RequestMapping(value = "/api")
public class ApiController {

    @Resource
    private SysService sysService;

    /**
     * 根据字典类型获取字典数据列表
     */
    @ApiOperation("根据字典类型获取字典数据列表")
    @ApiImplicitParam(value = "字典类型", example = "biz_model")
    @GetMapping(value = "/dict/{dictionaryType}")
    @SystemLog(description = "根据字典类型获取字典数据列表")
    public Result<List<SysDictDataVo>> getSysDictData(@PathVariable("dictionaryType") DictionaryType dictionaryType) {
        List<SysDictData> list = sysService.getSysDictData(dictionaryType);
        List<SysDictDataVo> lists = ObjectConvertUtil.convertList(list, SysDictDataVo.class);
        return Result.returnOk(lists);
    }
}
