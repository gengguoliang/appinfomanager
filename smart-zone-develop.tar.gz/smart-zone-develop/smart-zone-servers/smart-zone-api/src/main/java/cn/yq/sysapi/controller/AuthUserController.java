package cn.yq.sysapi.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.BCryptUtil;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.dao.AuthOrganizationMapper;
import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.dto.organization.AuthUserDTO;
import cn.yq.sysapi.dto.organization.UpdatePasswordDto;
import cn.yq.sysapi.enumeration.VerificationCodeType;
import cn.yq.sysapi.model.AuthOrganization;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.service.AuthService;
import cn.yq.sysapi.service.AuthUserService;
import cn.yq.sysapi.vo.AuthUserSearchVo;
import cn.yq.sysapi.vo.AuthUserVO;
import cn.yq.sysapi.vo.UserAppParam;
import cn.yq.sysapi.vo.UserVO;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(value = "用户信息管理", description = "用户信息管理 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/user")
@Slf4j
public class AuthUserController {
    private final static Logger LOGGER = LoggerFactory.getLogger(AuthUserController.class);

    @Autowired
    AuthUserService authUserService;
    @Autowired
    private AuthUserMapper authUserMapper;
    @Resource
    private AuthOrganizationMapper authOrganizationMapper;

    @Autowired
    private RedisTemplate redisTemplate;


    @Autowired
    private AuthService authService;

    @ApiOperation(value = "用户列表", notes = "完整的用户信息列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "页码，从1开始", required = true, dataType = "int", paramType = "path", example = "1"),
            @ApiImplicitParam(name = "pageSize", value = "页面大小", required = true, dataType = "int", paramType = "path", example = "10")
    })
    @PostMapping("/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "用户列表")
    public BaseResult<PageInfo<List<AuthUserVO>>> getListByPage(cn.yq.common.vo.AuthUser authUser, @PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody AuthUserSearchVo authUserSearchVo) {
        LOGGER.info("以分页方式获取用户列表");
        return BaseResult.successWithData(new PageInfo(authUserService.getListByPage(pageNum, pageSize, new HashMap<>(), authUserSearchVo, authUser)));
    }

    //<editor-fold desc="添加用户信息">
    @ApiOperation(value = "添加用户信息", notes = "添加用户信息")
    @PostMapping(value = "/", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加用户信息")
    public BaseResult<String> addUser(@RequestBody UserVO userVO) {
        AuthUser authUser = new AuthUser();
        BeanUtils.copyProperties(userVO, authUser);
        if (null != userVO.getIsLock()) {
            if (0 == userVO.getIsLock()) {
                authUser.setIsLocked(false);
            } else {
                authUser.setIsLocked(true);
            }
        }

        //根据用户名判断，用户名不能存在重复
        List<AuthUser> userlist = authUserService.query(authUser);
        if (userlist.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "用户名不能重复");
        }
        authUserService.add(authUser, userVO.getRoleids());
        return BaseResult.successWithData("添加成功");
    }
    //</editor-fold>

    @ApiOperation(
            value = "删除用户信息",
            notes = "删除用户信息",
            produces = "application/json",
            consumes = "application/json",
            response = BaseResult.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户id", required = true, dataType = "int", paramType = "path"),
    })
    @DeleteMapping("/")
    @SystemLog(description = "删除用户信息")
    public BaseResult removeUser(int id) {
        authUserService.remove(id);
        return BaseResult.successWithData("删除成功");
    }

    @ApiOperation(value = "修改用户信息", notes = "修改用户信息")
    @PutMapping(value = "/", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "修改用户信息")
    public BaseResult updateUser(@RequestBody UserVO userVO) {
        AuthUser authUser = new AuthUser();
        BeanUtils.copyProperties(userVO, authUser);
        if (null != userVO.getIsLock()) {
            if (0 == userVO.getIsLock()) {
                authUser.setIsLocked(false);
            } else {
                authUser.setIsLocked(true);
            }
        }
        if ("".equals(userVO.getPassword())) {
            authUser.setPassword(null);
        }
        authUserService.update(authUser, userVO.getRoleids());
        return BaseResult.successWithData("修改成功");
    }

    @ApiOperation(
            value = "查询用户信息",
            notes = "查询用户信息",
            produces = "application/json",
            consumes = "application/json",
            response = BaseResult.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user", value = "用户对象", required = true, dataType = "AuthUser", paramType = "path"),
    })
    @PostMapping("/queryUser")
    @SystemLog(description = "查询用户信息")
    public BaseResult queryUser(AuthUser user) {
        List<AuthUser> list = authUserService.query(user);
        return BaseResult.successWithData(list);
    }

    //<editor-fold desc="设置用户账号锁定状态">
    @ApiOperation(value = "用户锁定", notes = "锁定用户账号")
    @ApiImplicitParam(name = "userId", value = "用户ID", dataType = "int", paramType = "path")
    @PutMapping(value = "/{userId}/lock")
    @SystemLog(description = "用户锁定")
    public BaseResult<Boolean> lockUser(@PathVariable("userId") int userId) {
        return BaseResult.successWithData(authUserService.setIsLocked(userId, true));
    }

    @ApiOperation(value = "用户解锁", notes = "解除用户账号锁定")
    @ApiImplicitParam(name = "userId", value = "用户ID", dataType = "int", paramType = "path")
    @PutMapping(value = "/{userId}/unlock")
    @SystemLog(description = "用户解锁")
    public BaseResult<Boolean> unlockUser(@PathVariable("userId") int userId) {
        return BaseResult.successWithData(authUserService.setIsLocked(userId, false));
    }
    //</editor-fold>

    @ApiOperation(value = "获取角色列表", notes = "获取角色列表")
    @GetMapping("/getAllRoles")
    @LoginUser
    @SystemLog(description = "获取角色列表")
    public BaseResult getAllRoles(cn.yq.common.vo.AuthUser authUser) {
        int orgid = authUser.getOrganizationId();
        return BaseResult.successWithData(authUserService.getRoles(orgid));
    }

    @ApiOperation(value = "根据用户id获取权限集合", notes = "根据用户id获取权限集合")
    @ApiImplicitParam(name = "userId", value = "用户ID", dataType = "int", paramType = "path")
    @GetMapping(value = "/getRolesByUserid/{userId}")
    @SystemLog(description = "根据用户id获取权限集合")
    public BaseResult getRolesByUserid(@PathVariable("userId") int userId) {

        return BaseResult.successWithData(authUserService.getRolesByUserid(userId));
    }

    @GetMapping(value = "/users/{deptId}")
    public Result getUsersListByDeptId(@PathVariable("deptId") Integer id) {
        List<AuthUserVO> list = authUserService.getUserListByDeptid(id);
        return Result.returnOk(list);
    }

    /**
     * 重置密码
     *
     * @param updPwd
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "重置密码", notes = "重置密码")
    @PostMapping("/resetPassword")
    @ResponseBody
    @SystemLog(description = "重置密码")
    public Result resetPassword(@RequestBody UpdatePasswordDto updPwd) {
        try {
            return authUserService.updatePassword(updPwd);
        } catch (Exception e) {
            LOGGER.error("修改密码异常,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "修改密码异常,原因:" + e.getMessage());
        }
    }

    /**
     * 禁用企业-员工账户的功能，禁用该企业-员工账户时，该企业-员工账户不能登录
     *
     * @param userId
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "禁用企业-员工账户的功能", notes = "禁用企业-员工账户的功能")
    @GetMapping("/forbiddenUser")
    @SystemLog(description = "禁用企业-员工账户的功能")
    public Result forbiddenUser(@RequestParam("userId") Integer userId) {
        try {
            return authUserService.forbiddenUser(userId);
        } catch (Exception e) {
            LOGGER.error("禁用企业-员工账户的功能异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "禁用企业-员工账户的功能异常,原因：" + e.getMessage());
        }
    }

    /**
     * 删除企业-员工账号的功能
     *
     * @param userId
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "删除企业-员工账号的功能", notes = "删除企业-员工账号的功能")
    @GetMapping("/deleteUser")
    @SystemLog(description = "删除企业-员工账号的功能")
    public Result deleteUser(@RequestParam("userId") Integer userId) {
        try {
            return authUserService.deleteUser(userId);
        } catch (Exception e) {
            LOGGER.error("删除企业-员工账号的功能异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "删除企业-员工账号的功能异常,原因：" + e.getMessage());
        }
    }

    @ApiOperation(value = "审核用户", notes = "审核用户")
    @GetMapping("/auditedUser")
    @SystemLog(description = "审核用户")
    public Result auditedUser(@RequestParam("userId") Integer userId, @RequestParam("isAudited") boolean isAudited) {
        try {
            return authUserService.auditedUser(userId, isAudited);
        } catch (Exception e) {
            LOGGER.error("审核用户异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "审核用户异常,原因：" + e.getMessage());
        }
    }

    /**
     * @Description 查询用户身份证号
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @GetMapping("/getIdentityNum/{userId}")
    public Result<String> getIdentityNum(@PathVariable("userId") Integer userId) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(userId);
        log.debug("authUser============{}" + authUser);
        return Result.returnOk(authUser.getCertifyNum());
    }

    @GetMapping("/getOrgType/{orgId}")
    public Result<Integer> getOrgType(@PathVariable("orgId") Integer orgId) {
        AuthOrganization organization = authOrganizationMapper.selectByPrimaryKey(orgId);
        return Result.returnOk(organization.getType());
    }

    @GetMapping("/getUname/{userId}")
    public Result<String> getUname(@PathVariable("userId") Integer userId) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(userId);
        return Result.returnOk(authUser.getUsername());
    }


    @GetMapping("/getOrgInfo/{orgid}")
    public Result<String> getOrgInfo(@PathVariable("orgid") Integer id) {
        AuthOrganization authOrganization = authOrganizationMapper.selectByPrimaryKey(id);
        String result1 = "";
        if (null != authOrganization) {
            Integer result = authOrganization.getStatus();
            result1 = String.valueOf(result);
        }

        return Result.returnOk(result1);
    }

    @GetMapping("/getCurrentUserApp")
    @LoginUser
    public Result getCurrentUserApp(@ApiIgnore cn.yq.common.vo.AuthUser authUser) {
        Map map = new HashMap<>();
        map.put("id", authUser.getId());
        map.put("username", authUser.getUsername());
        map.put("mobile", authUser.getMobile());
        return Result.returnOk(map);
    }

    //修改账户
    @PostMapping("/updateAccount")
    @LoginUser
    @SystemLog(description = "修改账户")
    public Result updateAccount(@ApiIgnore cn.yq.common.vo.AuthUser currentUser, @RequestBody UserAppParam param) {
        AuthUser authUser = new AuthUser();
        authUser.setId(param.getId());
        //修改用户名
        if (null != param.getUsername() && !"".equals(param.getUsername())) {
            authUser.setUsername(param.getUsername());
        }
        //修改手机号
        if (null != param.getVerificationCode() && !"".equals(param.getVerificationCode())) {
            //验证验证码
            String phoneNo = param.getMobile();
            String key = "verification_code:" + VerificationCodeType.RESET_MOBILE;
            String verificationCode = redisTemplate.opsForHash().get(key, phoneNo).toString();

            if (verificationCode.equals(param.getVerificationCode())) {
                redisTemplate.opsForHash().delete(key, phoneNo);
            } else {
                return new Result(ResultEnum.FAIL.getCode(), "校验码不正确");
            }

            boolean isExist = authService.isExist(phoneNo);

            if (!isExist) {
                //更新手机号
                if (null != param.getMobile() && !"".equals(param.getMobile())) {
                    authUser.setMobile(param.getMobile());
                }
                authUserMapper.updateByPrimaryKeySelective(authUser);
                return Result.returnOk(true);
            }

            return new Result(ResultEnum.FAIL.getCode(), "该手机号已注册");

        }
        //修改密码
        // BCryptUtil.isMatch(authUser.getPassword(),user.getPassword()
        //判断当前密码是否正确
        if (null != param.getCurrentPassword() && !"".equals(param.getCurrentPassword())) {
            //数据库中存的密码
            String password = currentUser.getPassword();
            if (BCryptUtil.isMatch(param.getCurrentPassword(), password)) {
                if (null != param.getNewPassword() && !"".equals(param.getNewPassword())) {
                    authUser.setPassword(BCryptUtil.encode(param.getNewPassword()));
                }
            } else {
                return new Result(ResultEnum.FAIL.getCode(), "密码不正确!");
            }
        }
        authUserMapper.updateByPrimaryKeySelective(authUser);
        return Result.returnOk("操作成功");
    }

    /**
     * 是否实名
     *
     * @param authUser
     * @return
     * @author ggl
     */
    @ApiOperation(value = "是否实名", notes = "是否实名")
    @GetMapping("/isNameExist")
    @LoginUser
    @SystemLog(description = "判断是否实名")
    public Result isNameExist(@ApiIgnore cn.yq.common.vo.AuthUser authUser) {
        return authUserService.isNameExist(authUser.getId());
    }

    /**
     * 实名认证
     *
     * @param dto
     * @return
     * @author ggl
     */
    @ApiOperation(value = "实名认证", notes = "实名认证")
    @PostMapping("/nameCertification")
    @LoginUser
    @SystemLog(description = "实名认证")
    public Result nameCertification(@ApiIgnore cn.yq.common.vo.AuthUser authUser, @RequestBody AuthUserDTO dto) {
        return authUserService.nameCertification(dto,authUser);
    }


}
