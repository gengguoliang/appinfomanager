package cn.yq.sysapi.model;

import java.io.Serializable;
import java.util.Date;

public class AuthOrganization implements Serializable {
    /**
     * ID id
     */
    private Integer id;

    /**
     * 是否内置 1：内置 0：非内置 is_system
     */
    private Boolean isSystem;

    /**
     *  no
     */
    private Integer no;

    /**
     * 企业认证邀请码 code
     */
    private String code;

    /**
     * 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元 type
     */
    private Integer type;

    /**
     *  name
     */
    private String name;

    /**
     * 企业相关证件类型包含：1.社会信用代码，2.营业执照注             册号，3.组织机构代码 certify_type
     */
    private Integer certifyType;

    /**
     * 认证号码，应用内唯一：1.社会统一信用代码，长度为             18；2.营业执照，长度为 18；3.组织机构代码，长度为 9 certify_num
     */
    private String certifyNum;

    /**
     * 地址 address
     */
    private String address;

    /**
     * 审核状态，0：待审核，1：审核通过，2：审核不通过 audited_status
     */
    private Byte auditedStatus;

    /**
     * 状态，0：正常，1：冻结 status
     */
    private Integer status;

    /**
     * 备注 remark
     */
    private String remark;

    /**
     * 数据来源，0：管理后台添加，1：APP注册 from_type
     */
    private Byte fromType;

    /**
     * 创建时间 create_time
     */
    private Date createTime;

    /**
     * 创建人 create_by
     */
    private String createBy;

    /**
     * 修改时间 update_time
     */
    private Date updateTime;

    /**
     * 修改人 update_by
     */
    private String updateBy;

    /**
     * 是否删除 is_del
     */
    private Boolean isDel;

    /**
     * auth_organization
     */
    private static final long serialVersionUID = 1L;

    /**
     * ID
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return id ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * ID
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param id ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 是否内置 1：内置 0：非内置
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return is_system 是否内置 1：内置 0：非内置
     */
    public Boolean getIsSystem() {
        return isSystem;
    }

    /**
     * 是否内置 1：内置 0：非内置
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param isSystem 是否内置 1：内置 0：非内置
     */
    public void setIsSystem(Boolean isSystem) {
        this.isSystem = isSystem;
    }

    /**
     * 
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return no 
     */
    public Integer getNo() {
        return no;
    }

    /**
     * 
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param no 
     */
    public void setNo(Integer no) {
        this.no = no;
    }

    /**
     * 企业认证邀请码
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return code 企业认证邀请码
     */
    public String getCode() {
        return code;
    }

    /**
     * 企业认证邀请码
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param code 企业认证邀请码
     */
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    /**
     * 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return type 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
     */
    public Integer getType() {
        return type;
    }

    /**
     * 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param type 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * 
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return name 
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param name 
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 企业相关证件类型包含：1.社会信用代码，2.营业执照注             册号，3.组织机构代码
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return certify_type 企业相关证件类型包含：1.社会信用代码，2.营业执照注             册号，3.组织机构代码
     */
    public Integer getCertifyType() {
        return certifyType;
    }

    /**
     * 企业相关证件类型包含：1.社会信用代码，2.营业执照注             册号，3.组织机构代码
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param certifyType 企业相关证件类型包含：1.社会信用代码，2.营业执照注             册号，3.组织机构代码
     */
    public void setCertifyType(Integer certifyType) {
        this.certifyType = certifyType;
    }

    /**
     * 认证号码，应用内唯一：1.社会统一信用代码，长度为             18；2.营业执照，长度为 18；3.组织机构代码，长度为 9
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return certify_num 认证号码，应用内唯一：1.社会统一信用代码，长度为             18；2.营业执照，长度为 18；3.组织机构代码，长度为 9
     */
    public String getCertifyNum() {
        return certifyNum;
    }

    /**
     * 认证号码，应用内唯一：1.社会统一信用代码，长度为             18；2.营业执照，长度为 18；3.组织机构代码，长度为 9
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param certifyNum 认证号码，应用内唯一：1.社会统一信用代码，长度为             18；2.营业执照，长度为 18；3.组织机构代码，长度为 9
     */
    public void setCertifyNum(String certifyNum) {
        this.certifyNum = certifyNum == null ? null : certifyNum.trim();
    }

    /**
     * 地址
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return address 地址
     */
    public String getAddress() {
        return address;
    }

    /**
     * 地址
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param address 地址
     */
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    /**
     * 审核状态，0：待审核，1：审核通过，2：审核不通过
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return audited_status 审核状态，0：待审核，1：审核通过，2：审核不通过
     */
    public Byte getAuditedStatus() {
        return auditedStatus;
    }

    /**
     * 审核状态，0：待审核，1：审核通过，2：审核不通过
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param auditedStatus 审核状态，0：待审核，1：审核通过，2：审核不通过
     */
    public void setAuditedStatus(Byte auditedStatus) {
        this.auditedStatus = auditedStatus;
    }

    /**
     * 状态，0：正常，1：冻结
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return status 状态，0：正常，1：冻结
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 状态，0：正常，1：冻结
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param status 状态，0：正常，1：冻结
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 备注
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return remark 备注
     */
    public String getRemark() {
        return remark;
    }

    /**
     * 备注
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param remark 备注
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * 数据来源，0：管理后台添加，1：APP注册
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return from_type 数据来源，0：管理后台添加，1：APP注册
     */
    public Byte getFromType() {
        return fromType;
    }

    /**
     * 数据来源，0：管理后台添加，1：APP注册
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param fromType 数据来源，0：管理后台添加，1：APP注册
     */
    public void setFromType(Byte fromType) {
        this.fromType = fromType;
    }

    /**
     * 创建时间
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return create_time 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 创建人
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return create_by 创建人
     */
    public String getCreateBy() {
        return createBy;
    }

    /**
     * 创建人
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param createBy 创建人
     */
    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    /**
     * 修改时间
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return update_time 修改时间
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * 修改时间
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param updateTime 修改时间
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * 修改人
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return update_by 修改人
     */
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * 修改人
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param updateBy 修改人
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    /**
     * 是否删除
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @return is_del 是否删除
     */
    public Boolean getIsDel() {
        return isDel;
    }

    /**
     * 是否删除
     * @author YQ-HP0709
     * @date 2019-05-05 11:44:21
     * @param isDel 是否删除
     */
    public void setIsDel(Boolean isDel) {
        this.isDel = isDel;
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AuthOrganization other = (AuthOrganization) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getIsSystem() == null ? other.getIsSystem() == null : this.getIsSystem().equals(other.getIsSystem()))
            && (this.getNo() == null ? other.getNo() == null : this.getNo().equals(other.getNo()))
            && (this.getCode() == null ? other.getCode() == null : this.getCode().equals(other.getCode()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getCertifyType() == null ? other.getCertifyType() == null : this.getCertifyType().equals(other.getCertifyType()))
            && (this.getCertifyNum() == null ? other.getCertifyNum() == null : this.getCertifyNum().equals(other.getCertifyNum()))
            && (this.getAddress() == null ? other.getAddress() == null : this.getAddress().equals(other.getAddress()))
            && (this.getAuditedStatus() == null ? other.getAuditedStatus() == null : this.getAuditedStatus().equals(other.getAuditedStatus()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getRemark() == null ? other.getRemark() == null : this.getRemark().equals(other.getRemark()))
            && (this.getFromType() == null ? other.getFromType() == null : this.getFromType().equals(other.getFromType()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getIsDel() == null ? other.getIsDel() == null : this.getIsDel().equals(other.getIsDel()));
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getIsSystem() == null) ? 0 : getIsSystem().hashCode());
        result = prime * result + ((getNo() == null) ? 0 : getNo().hashCode());
        result = prime * result + ((getCode() == null) ? 0 : getCode().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getCertifyType() == null) ? 0 : getCertifyType().hashCode());
        result = prime * result + ((getCertifyNum() == null) ? 0 : getCertifyNum().hashCode());
        result = prime * result + ((getAddress() == null) ? 0 : getAddress().hashCode());
        result = prime * result + ((getAuditedStatus() == null) ? 0 : getAuditedStatus().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getRemark() == null) ? 0 : getRemark().hashCode());
        result = prime * result + ((getFromType() == null) ? 0 : getFromType().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getIsDel() == null) ? 0 : getIsDel().hashCode());
        return result;
    }
}