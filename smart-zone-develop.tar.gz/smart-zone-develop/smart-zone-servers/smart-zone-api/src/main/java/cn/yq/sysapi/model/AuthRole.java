package cn.yq.sysapi.model;

import java.io.Serializable;
import java.util.Date;

public class AuthRole implements Serializable {
    /**
     * ID id
     */
    private Integer id;

    /**
     *  is_system
     */
    private Boolean isSystem;

    /**
     *  organization_id
     */
    private Integer organizationId;

    /**
     * 项目id project_id
     */
    private Integer projectId;

    /**
     * 角色名称 role_name
     */
    private String roleName;

    /**
     * 描述 description
     */
    private String description;

    /**
     * 是否删除 is_del
     */
    private Boolean isDel;

    /**
     * 创建时间 create_time
     */
    private Date createTime;

    /**
     * 最后更新时间 last_update_time
     */
    private Date lastUpdateTime;

    /**
     * auth_role
     */
    private static final long serialVersionUID = 1L;

    /**
     * ID
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return id ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * ID
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param id ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return is_system 
     */
    public Boolean getIsSystem() {
        return isSystem;
    }

    /**
     * 
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param isSystem 
     */
    public void setIsSystem(Boolean isSystem) {
        this.isSystem = isSystem;
    }

    /**
     * 
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return organization_id 
     */
    public Integer getOrganizationId() {
        return organizationId;
    }

    /**
     * 
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param organizationId 
     */
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    /**
     * 项目id
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return project_id 项目id
     */
    public Integer getProjectId() {
        return projectId;
    }

    /**
     * 项目id
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param projectId 项目id
     */
    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    /**
     * 角色名称
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return role_name 角色名称
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * 角色名称
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param roleName 角色名称
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName == null ? null : roleName.trim();
    }

    /**
     * 描述
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return description 描述
     */
    public String getDescription() {
        return description;
    }

    /**
     * 描述
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param description 描述
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * 是否删除
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return is_del 是否删除
     */
    public Boolean getIsDel() {
        return isDel;
    }

    /**
     * 是否删除
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param isDel 是否删除
     */
    public void setIsDel(Boolean isDel) {
        this.isDel = isDel;
    }

    /**
     * 创建时间
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return create_time 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 最后更新时间
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @return last_update_time 最后更新时间
     */
    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    /**
     * 最后更新时间
     * @author YQ-DGZ
     * @date 2019-03-13 16:07:33
     * @param lastUpdateTime 最后更新时间
     */
    public void setLastUpdateTime(Date lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AuthRole other = (AuthRole) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getIsSystem() == null ? other.getIsSystem() == null : this.getIsSystem().equals(other.getIsSystem()))
            && (this.getOrganizationId() == null ? other.getOrganizationId() == null : this.getOrganizationId().equals(other.getOrganizationId()))
            && (this.getProjectId() == null ? other.getProjectId() == null : this.getProjectId().equals(other.getProjectId()))
            && (this.getRoleName() == null ? other.getRoleName() == null : this.getRoleName().equals(other.getRoleName()))
            && (this.getDescription() == null ? other.getDescription() == null : this.getDescription().equals(other.getDescription()))
            && (this.getIsDel() == null ? other.getIsDel() == null : this.getIsDel().equals(other.getIsDel()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getLastUpdateTime() == null ? other.getLastUpdateTime() == null : this.getLastUpdateTime().equals(other.getLastUpdateTime()));
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getIsSystem() == null) ? 0 : getIsSystem().hashCode());
        result = prime * result + ((getOrganizationId() == null) ? 0 : getOrganizationId().hashCode());
        result = prime * result + ((getProjectId() == null) ? 0 : getProjectId().hashCode());
        result = prime * result + ((getRoleName() == null) ? 0 : getRoleName().hashCode());
        result = prime * result + ((getDescription() == null) ? 0 : getDescription().hashCode());
        result = prime * result + ((getIsDel() == null) ? 0 : getIsDel().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getLastUpdateTime() == null) ? 0 : getLastUpdateTime().hashCode());
        return result;
    }
}