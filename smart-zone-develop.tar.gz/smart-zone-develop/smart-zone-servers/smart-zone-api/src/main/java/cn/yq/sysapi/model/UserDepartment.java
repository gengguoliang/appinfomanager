package cn.yq.sysapi.model;

import java.io.Serializable;
import java.util.Date;

public class UserDepartment implements Serializable {
    /**
     * ID id
     */
    private Integer id;

    /**
     *  organization_id
     */
    private Integer organizationId;

    /**
     * 项目ID project_id
     */
    private Integer projectId;

    /**
     * 父级ID parent_id
     */
    private Integer parentId;

    /**
     * 级别 level
     */
    private String level;

    /**
     * 部门名称 name
     */
    private String name;

    /**
     * 描述 description
     */
    private String description;

    /**
     * 是否删除 is_del
     */
    private Boolean isDel;

    /**
     * 创建时间 create_time
     */
    private Date createTime;

    /**
     * 最后更新时间 last_update_time
     */
    private Date lastUpdateTime;

    /**
     * user_department
     */
    private static final long serialVersionUID = 1L;

    /**
     * ID
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return id ID
     */
    public Integer getId() {
        return id;
    }

    /**
     * ID
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param id ID
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return organization_id 
     */
    public Integer getOrganizationId() {
        return organizationId;
    }

    /**
     * 
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param organizationId 
     */
    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    /**
     * 项目ID
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return project_id 项目ID
     */
    public Integer getProjectId() {
        return projectId;
    }

    /**
     * 项目ID
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param projectId 项目ID
     */
    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    /**
     * 父级ID
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return parent_id 父级ID
     */
    public Integer getParentId() {
        return parentId;
    }

    /**
     * 父级ID
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param parentId 父级ID
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    /**
     * 级别
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return level 级别
     */
    public String getLevel() {
        return level;
    }

    /**
     * 级别
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param level 级别
     */
    public void setLevel(String level) {
        this.level = level == null ? null : level.trim();
    }

    /**
     * 部门名称
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return name 部门名称
     */
    public String getName() {
        return name;
    }

    /**
     * 部门名称
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param name 部门名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 描述
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return description 描述
     */
    public String getDescription() {
        return description;
    }

    /**
     * 描述
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param description 描述
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * 是否删除
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return is_del 是否删除
     */
    public Boolean getIsDel() {
        return isDel;
    }

    /**
     * 是否删除
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param isDel 是否删除
     */
    public void setIsDel(Boolean isDel) {
        this.isDel = isDel;
    }

    /**
     * 创建时间
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return create_time 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 创建时间
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 最后更新时间
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @return last_update_time 最后更新时间
     */
    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    /**
     * 最后更新时间
     * @author YQ-DGZ
     * @date 2019-03-13 14:05:45
     * @param lastUpdateTime 最后更新时间
     */
    public void setLastUpdateTime(Date lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        UserDepartment other = (UserDepartment) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getOrganizationId() == null ? other.getOrganizationId() == null : this.getOrganizationId().equals(other.getOrganizationId()))
            && (this.getProjectId() == null ? other.getProjectId() == null : this.getProjectId().equals(other.getProjectId()))
            && (this.getParentId() == null ? other.getParentId() == null : this.getParentId().equals(other.getParentId()))
            && (this.getLevel() == null ? other.getLevel() == null : this.getLevel().equals(other.getLevel()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getDescription() == null ? other.getDescription() == null : this.getDescription().equals(other.getDescription()))
            && (this.getIsDel() == null ? other.getIsDel() == null : this.getIsDel().equals(other.getIsDel()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getLastUpdateTime() == null ? other.getLastUpdateTime() == null : this.getLastUpdateTime().equals(other.getLastUpdateTime()));
    }

    @Override
    public String toString() {
        return "UserDepartment{" +
                "id=" + id +
                ", organizationId=" + organizationId +
                ", projectId=" + projectId +
                ", parentId=" + parentId +
                ", level='" + level + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", isDel=" + isDel +
                ", createTime=" + createTime +
                ", lastUpdateTime=" + lastUpdateTime +
                '}';
    }

    /**
     *
     * @mbg.generated
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getOrganizationId() == null) ? 0 : getOrganizationId().hashCode());
        result = prime * result + ((getProjectId() == null) ? 0 : getProjectId().hashCode());
        result = prime * result + ((getParentId() == null) ? 0 : getParentId().hashCode());
        result = prime * result + ((getLevel() == null) ? 0 : getLevel().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getDescription() == null) ? 0 : getDescription().hashCode());
        result = prime * result + ((getIsDel() == null) ? 0 : getIsDel().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getLastUpdateTime() == null) ? 0 : getLastUpdateTime().hashCode());
        return result;
    }
}