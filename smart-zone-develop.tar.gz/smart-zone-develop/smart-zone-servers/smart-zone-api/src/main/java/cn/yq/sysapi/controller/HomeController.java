package cn.yq.sysapi.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.service.HomeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "首页", description = "首页操作 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/home")
public class HomeController {
    private final static Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    private HomeService homeService;

    @ApiOperation(
            value = "消息列表",
            notes = "完整的消息内容列表",
            produces = "application/json",
            consumes = "application/json",
            response = BaseResult.class)
    @GetMapping("/")
    @SystemLog(description = "消息列表")
    public BaseResult<String> index() {
        LOGGER.debug("This is a debug message");
        LOGGER.info("This is an info message");
        LOGGER.warn("This is a warn message");
        LOGGER.error("This is an error message");

        return BaseResult.successWithData("this is index " + homeService.sayHi());
    }
}
