package cn.yq.sysapi.service.impl;

import cn.yq.common.enumeration.DictionaryType;
import cn.yq.sysapi.dao.SysDictDataMapper;
import cn.yq.sysapi.dao.SysLogMapper;
import cn.yq.sysapi.dto.organization.SysLogDTO;
import cn.yq.sysapi.model.SysDictData;
import cn.yq.sysapi.model.SysDictDataCriteria;
import cn.yq.sysapi.model.SysLog;
import cn.yq.sysapi.model.SysLogCriteria;
import cn.yq.sysapi.service.SysService;
import com.github.pagehelper.PageHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Auther: houqijun
 * @Date: 2018/12/11 18:47
 * @Description:
 */
@Service
public class SysServiceImpl implements SysService {

    @Resource
    private SysDictDataMapper sysDictDataMapper;

    @Resource
    private SysLogMapper sysLogMapper;

    /**
     * 根据字典类型获取字典数据列表
     *
     * @param dictionaryType
     * @return
     */
    @Override
    public List<SysDictData> getSysDictData(DictionaryType dictionaryType) {
        SysDictDataCriteria sysDictDataCriteria = new SysDictDataCriteria();
        SysDictDataCriteria.Criteria criteria = sysDictDataCriteria.createCriteria();
        criteria.andIsDelEqualTo(false)
                .andDictTypeEqualTo(dictionaryType.name());

        sysDictDataCriteria.setOrderByClause("`sort` ASC, `id` ASC");
        List<SysDictData> sysDictData = sysDictDataMapper.selectByExample(sysDictDataCriteria);
        return sysDictData;
    }

    /**
     * 新增系统操作日志
     *
     * @param sysLog
     * @return
     */
    @Override
    public Integer insertSysLog(SysLog sysLog) {
        return sysLogMapper.insertSelective(sysLog);
    }

    /**
     * @param pageNum
     * @param pageSize
     * @param dto
     * @Description 系统日志查询
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<SysLog> sysLogShow(Integer pageNum, Integer pageSize, SysLogDTO dto) {
        SysLogCriteria sysLogCriteria = new SysLogCriteria();
        SysLogCriteria.Criteria criteria = sysLogCriteria.createCriteria();
        if (dto.getOperatorTimeStart() != null) {
            criteria.andOperatorTimeGreaterThanOrEqualTo(dto.getOperatorTimeStart());
        }
        if (dto.getOperatorTimeEnd() != null) {
            criteria.andOperatorTimeLessThanOrEqualTo(dto.getOperatorTimeEnd());
        }
        if (StringUtils.isNotBlank(dto.getOperator())) {
            criteria.andOperatorLike("%" + dto.getOperator() + "%");
        }
        criteria.andIsDelEqualTo(false);
        sysLogCriteria.setOrderByClause("`create_time` DESC");
        PageHelper.startPage(pageNum, pageSize);
        List<SysLog> sysLogs = sysLogMapper.selectByExample(sysLogCriteria);
        return sysLogs;
    }
}
