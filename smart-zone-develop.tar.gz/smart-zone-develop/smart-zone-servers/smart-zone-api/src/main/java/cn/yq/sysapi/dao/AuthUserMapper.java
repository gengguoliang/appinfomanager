package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.model.AuthUserCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthUserMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(AuthUserCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(AuthUserCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(AuthUser record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(AuthUser record);

    /**
     *
     * @mbg.generated
     */
    List<AuthUser> selectByExample(AuthUserCriteria example);

    /**
     *
     * @mbg.generated
     */
    AuthUser selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") AuthUser record, @Param("example") AuthUserCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") AuthUser record, @Param("example") AuthUserCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(AuthUser record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(AuthUser record);
}