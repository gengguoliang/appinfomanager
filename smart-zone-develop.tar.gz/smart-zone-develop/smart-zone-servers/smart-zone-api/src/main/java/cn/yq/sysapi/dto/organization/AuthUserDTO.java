package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author: ggl
 * @Date: 2019/4/29 17:08
 * @Description:
 */
@Data
@ApiModel(description = "实名认证")
public class AuthUserDTO {
    @ApiModelProperty(value = "id", name = "id", required = true, position = 0)
    private Integer id;
    @ApiModelProperty(value = "名称", name = "名称", required = true, position = 0)
    private String name;
    @ApiModelProperty(value = "性别，0：男 1：女", name = "性别，0：男 1：女", required = true, position = 0)
    private Boolean gender;
    @ApiModelProperty(value = "证件类型，0：身份证", name = "证件类型，0：身份证", required = true, position = 0)
    private Integer certifyType;
    @ApiModelProperty(value = "证件号码", name = "证件号码", required = true, position = 0)
    private String certifyNum;

}
