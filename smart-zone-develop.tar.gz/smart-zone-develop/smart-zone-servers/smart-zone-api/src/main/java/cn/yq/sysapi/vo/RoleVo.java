package cn.yq.sysapi.vo;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class RoleVo implements Serializable {

    private static final long serialVersionUID = 3192760820174668392L;


    @ApiModelProperty(value = "id", name = "id", required = false, position = 0)
    private int id;

    @ApiModelProperty(value = "roleName", name = "roleName", required = true, position = 0)
    private String roleName;

    @ApiModelProperty(value = "projectId", name = "projectId", required = true, position = 0)
    private int projectId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
}
