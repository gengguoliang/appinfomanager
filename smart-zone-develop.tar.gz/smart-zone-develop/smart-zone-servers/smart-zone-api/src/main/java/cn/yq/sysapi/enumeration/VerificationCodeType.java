package cn.yq.sysapi.enumeration;

/**
 * @author: yinqk
 * @date: 2019-04-28 16:33
 * @description: 验证码类型
 */
public enum VerificationCodeType {
    /**
     * 注册
     */
    REGISTER,

    /**
     * 重置密码
     */
    RESET_PASSWORD,

    /**
     * 更换手机号
     */
    RESET_MOBILE


}
