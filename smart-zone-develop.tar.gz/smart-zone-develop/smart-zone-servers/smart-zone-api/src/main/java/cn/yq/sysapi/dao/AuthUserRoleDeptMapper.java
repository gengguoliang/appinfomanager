package cn.yq.sysapi.dao;

/**
 * 这个mapper是用来提供，用户-角色-部门关联信息
 * @author：houqijun
 */
public interface AuthUserRoleDeptMapper {

    //根据用户名获取 角色绑定的部门ids
    String getUserRoleDeptIdsByUserName(String username);
}
