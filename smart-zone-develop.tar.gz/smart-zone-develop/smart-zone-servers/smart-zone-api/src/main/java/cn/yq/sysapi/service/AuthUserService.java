package cn.yq.sysapi.service;

import cn.yq.common.result.Result;
import cn.yq.sysapi.dto.organization.AuthUserDTO;
import cn.yq.sysapi.dto.organization.UpdatePasswordDto;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.vo.AuthUserSearchVo;
import cn.yq.sysapi.vo.AuthUserVO;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;

public interface AuthUserService {

    /**
     * 增加用户
     */
    int add(AuthUser user, int[] roleids);

    /**
     * 删除用户
     */
    int remove(int id);

    /**
     * 修改用户
     */
    int update(AuthUser user,int[] roleids);

    /**
     * 查询用户
     */
    List<AuthUser> query(AuthUser user);

    List<AuthUser> getUserByDept(Integer id);

    /**
     * 获取用户信息列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    List<AuthUserVO> getListByPage(int pageNum, int pageSize, HashMap map, AuthUserSearchVo authUserSearchVo,cn.yq.common.vo.AuthUser authUser);

    /**
     * 设置用户账号锁定状态
     *
     * @param userId
     * @param isLocked
     * @return
     */
    boolean setIsLocked(int userId, boolean isLocked);


    List<AuthRole> getRolesByUsername(String username);

    List<AuthRole> getRolesByUserid2(Integer userid);

    List<AuthRole> getRoles(Integer orgid);

    List getRolesByUserid(int userid);

    /**
     * 根据用户名获取用户角色所关联的部门id
     * @param username
     * @return
     */
    String getUserRoleDeptIdsByUserName(String username);

    /**
     * 根据用户名获取该用户所在部门
     */
    UserDepartment getDeptByUsername(String username);


    public int getUserByDeptid(int id);


    /**
     * 根据部门id获取用户列表
     * @param id
     * @return
     */
    List<AuthUserVO> getUserListByDeptid(Integer id);

    Result updatePassword(UpdatePasswordDto updPwd);

    Result forbiddenUser(Integer userId);

    Result deleteUser(Integer userId);

    Result auditedUser(Integer userId, boolean isAudited);

    Result nameCertification(AuthUserDTO dto, cn.yq.common.vo.AuthUser authUser);

    Result isNameExist(Integer userId);

    List getRoleByUserid(int userid);
}
