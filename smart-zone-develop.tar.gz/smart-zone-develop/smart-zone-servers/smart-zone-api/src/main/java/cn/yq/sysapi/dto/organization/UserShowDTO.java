package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
@ApiModel(value = "园区用户管理列表查询DTO")
public class UserShowDTO implements Serializable {

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "所属部门")
    private List<Integer> departmentId;

    @ApiModelProperty(value = "所属角色")
    private Integer roleId;

    @ApiModelProperty(value = "状态")
    private Integer isLocked;

    @ApiModelProperty(value = "起始时间")
    private String createTimeStart;

    @ApiModelProperty(value = "结束时间")
    private String createTimeEnd;

    private Integer did;
}
