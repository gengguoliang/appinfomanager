package cn.yq.sysapi.vo;

import lombok.Data;

import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class AddUserShowVO {
    private Integer organizationId;
    private String organizationName;
    private Integer departmentId;
    private String departmentName;
    private List<Integer> roleIds;
    private List<Integer> departmentIds;

}
