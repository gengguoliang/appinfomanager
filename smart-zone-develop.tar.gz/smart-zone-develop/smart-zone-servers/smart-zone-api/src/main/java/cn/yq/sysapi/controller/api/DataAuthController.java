package cn.yq.sysapi.controller.api;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.datapermission.DataPermissionContext;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.common.annotation.DataFilter;
import cn.yq.sysapi.service.DataAuthService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.HashMap;

/**
 * @Author: ggl
 * @Date: 2019/6/5 14:05
 * @Description:
 */
@Api(value = "数据权限", description = "数据权限 API")
@RestController
@RequestMapping(value = "/data")
@AllArgsConstructor
@Slf4j
public class DataAuthController {

    private DataAuthService dataAuthService;

    @ApiOperation(value = "获取当前用户数据权限", notes = "获取当前用户数据权限")
    @PostMapping("/auth")
    @SystemLog(description = "获取当前用户数据权限")
    public Result<DataPermissionContext> getDataAuth(){
        DataPermissionContext dataPermissionContext = null;
        try {
            dataPermissionContext = dataAuthService.getDeptIds();
        } catch (Throwable throwable) {
            log.error(throwable.getMessage(),throwable.getStackTrace());
        }
        return Result.returnOk(dataPermissionContext);
    }
}
