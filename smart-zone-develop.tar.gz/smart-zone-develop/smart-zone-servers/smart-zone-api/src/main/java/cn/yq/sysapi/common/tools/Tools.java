package cn.yq.sysapi.common.tools;

import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 实用工具 ps：可自行添加
 *
 * @author banzhiguo
 */
public class Tools {
    /**
     * 验证手机号
     *
     * @param phone
     * @return
     */
    public static Result isPhone(String phone) {
        String regex = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}$";
        if (phone.length() != 11) {
            return new Result(ResultEnum.FAIL.getCode(), "不是正确的手机号位数!");
        } else {
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(phone);
            boolean isMatch = m.matches();
            if (!isMatch) {
                return new Result(ResultEnum.FAIL.getCode(), "请填入正确的手机号!");
            }
            return Result.returnOk();
        }
    }

    /**
     * 验证用户名只能为数字家字母
     * @param userName
     * @return
     */
    public static Result userNameUseable(String userName) {
        String regex = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,30}$";
        boolean matches = userName.matches(regex);
        if (matches) {
            return Result.returnOk();
        }
        return new Result(ResultEnum.FAIL.getCode(), "用户名只能是字母加数字组合且长度为6到30!");
    }
}
