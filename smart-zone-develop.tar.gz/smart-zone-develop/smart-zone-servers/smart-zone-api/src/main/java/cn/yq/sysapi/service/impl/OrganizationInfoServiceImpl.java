package cn.yq.sysapi.service.impl;

import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.BCryptUtil;
import cn.yq.common.utils.ShareCodeUtils;
import cn.yq.sysapi.dao.*;
import cn.yq.sysapi.dto.organization.AddRoleDTO;
import cn.yq.sysapi.dto.organization.OrganizationAddDTO;
import cn.yq.sysapi.dto.organization.OrganizationShowDTO;
import cn.yq.sysapi.dto.organization.PasswordDTO;
import cn.yq.sysapi.model.*;
import cn.yq.sysapi.service.OrganizationInfoService;
import cn.yq.sysapi.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @program: smart-zone
 * @description: 组织信息管理
 * @author: zhengjianhui
 **/
@Service
@Transactional
@Slf4j
public class OrganizationInfoServiceImpl implements OrganizationInfoService {

    @Resource
    private AuthOrganizationMapper authOrganizationMapper;
    @Resource
    private AuthUserMapper authUserMapper;
    @Resource
    private AuthOrganizationRoleMapper authOrganizationRoleMapper;
    @Resource
    private AuthOrganizationUnitMapper authOrganizationUnitMapper;
    @Resource
    private AuthOrganizationCusMapper authOrganizationCusMapper;
    @Resource
    private AuthUserRoleMapper authUserRoleMapper;
    @Resource
    private AuthUserCusMapper authUserCusMapper;


    /**
     * @param organizationAddDTO
     * @Description PC端新增企业
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void organizationAdd(OrganizationAddDTO organizationAddDTO) {
        //插入组织信息表
        AuthOrganization authOrganization = new AuthOrganization();
        BeanUtils.copyProperties(organizationAddDTO, authOrganization);
        authOrganization.setIsSystem(false);//是否内置
        //authOrganization.setNo();
        authOrganization.setCertifyType(1);//证件类型：1.社会信用代码
        authOrganization.setAuditedStatus((byte) 1);//1.审核通过
        authOrganization.setFromType((byte) 0);//0:后台管理员添加
        if (organizationAddDTO.getType() == 1) {
            //如果是个人租赁
            authOrganization.setCertifyType(1);
            authOrganization.setCertifyNum(organizationAddDTO.getIdentityCard());
        }
        authOrganizationMapper.insertSelective(authOrganization);
        /**
         * begin
         * ggl添加业务生成code码
         */
        //生成企业邀请码并更新到当前企业下
        String code = ShareCodeUtils.idToCode(authOrganization.getId().longValue());
        AuthOrganization authOrg = new AuthOrganization();
        authOrg.setId(authOrganization.getId());
        authOrg.setCode(code);
        authOrganizationMapper.updateByPrimaryKeySelective(authOrg);
        /**
         * end
         */
        //插入用户表
        AuthUser authUser = new AuthUser();
        BeanUtils.copyProperties(organizationAddDTO, authUser);
        authUser.setProjectId(1);
        authUser.setIsSystem(false);//是否内置
        authUser.setOrganizationId(authOrganization.getId());
        String passwordEncode = BCryptUtil.encode(organizationAddDTO.getPassword());
        authUser.setPassword(passwordEncode);
        authUser.setCertifyType(0);//证件类型 0：身份证
        if (organizationAddDTO.getType() != 1) {
            //企业租赁或者装修公司
            authUser.setCertifyType(null);
            authUser.setCertifyNum(null);
        } else {
            authUser.setCertifyType(0);//证件类型，0：身份证
            authUser.setCertifyNum(organizationAddDTO.getIdentityCard());
        }
        authUser.setIsAdmin(true);//是否为管理员
        authUser.setAuditedStatus((byte) 1);//审核状态 1：已审核
        authUser.setIsLocked(organizationAddDTO.getStatus() == 0 ? false : true);//是否锁定
        authUser.setJoinType((byte) 0);//加入组织方式 0：后台添加
        //如果是个人还要插入姓名
        if (organizationAddDTO.getType() == 1) {
            authUser.setName(organizationAddDTO.getName());
        } else {
            authUser.setName(organizationAddDTO.getUsername());
        }
        authUserMapper.insertSelective(authUser);

        //入库生活圈个人资料表
        TimelineProfileVO profileVO = new TimelineProfileVO();
        profileVO.setUserId(authUser.getId());
        profileVO.setNickname(authUser.getUsername());
        profileVO.setHeadImgUrl("http://kodo.smart-zone.51yuqian.net/FtOSnvyPUfIYhpFi_xhR2HXlBCXS");
        profileVO.setCoverImgUrl("http://kodo.smart-zone.51yuqian.net/Fg7COFW3QdRQ0Tgy7Me08S5LVV30?attname=微信图片_20190517175252.png");
        profileVO.setSlogon("此人很懒，没有留下任何信息");
        profileVO.setStatus(0);//状态0：正常，1：禁用，2：封号
        authUserCusMapper.insertProfileVO(profileVO);

        //插入组织角色关系表
        for (Integer roleId : organizationAddDTO.getRoleIds()) {
            AuthOrganizationRole authOrganizationRole = new AuthOrganizationRole();
            authOrganizationRole.setOrganizationId(authOrganization.getId());
            authOrganizationRole.setRoleId(roleId);
            authOrganizationRoleMapper.insertSelective(authOrganizationRole);
        }
        //插入用户角色关系表
        for (Integer roleId : organizationAddDTO.getRoleIds()) {
            AuthUserRole authUserRole = new AuthUserRole();
            authUserRole.setUserId(authUser.getId());
            authUserRole.setRoleId(roleId);
            authUserRoleMapper.insertSelective(authUserRole);
        }
        //如果是装修公司就没有单元
        if (ObjectUtils.isEmpty(organizationAddDTO.getUnitIds()))
            return;
        //插入组织单元关系表
        for (Integer unitId : organizationAddDTO.getUnitIds()) {
            AuthOrganizationUnit authOrganizationUnit = new AuthOrganizationUnit();
            authOrganizationUnit.setOrganizationId(authOrganization.getId());
            BuildingIdStoreyIdVO buildingIdStoreyId = authOrganizationCusMapper.getBuildingIdStoreyId(unitId);
            authOrganizationUnit.setBuildingId(buildingIdStoreyId.getBuildingId());
            authOrganizationUnit.setStoreyId(buildingIdStoreyId.getStoreyId());
            authOrganizationUnit.setUnitId(unitId);
            authOrganizationUnitMapper.insertSelective(authOrganizationUnit);
        }

    }

    /**
     * @param organizationShowDTO
     * @Description PC端列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<OrganizationShowVO> showPage(OrganizationShowDTO organizationShowDTO, Integer userId) {
        List<OrganizationShowVO> organizationShowVOS = authOrganizationCusMapper.showPage(organizationShowDTO, userId);
        //加入角色ID
        for (OrganizationShowVO organizationShowVO : organizationShowVOS) {
            AuthOrganizationRoleCriteria roleCriteria = new AuthOrganizationRoleCriteria();
            AuthOrganizationRoleCriteria.Criteria criteria = roleCriteria.createCriteria();
            criteria.andOrganizationIdEqualTo(organizationShowVO.getOrganizationId())
                    .andIsDelEqualTo(false);
            List<AuthOrganizationRole> authOrganizationRoles = authOrganizationRoleMapper.selectByExample(roleCriteria);
            List<Integer> roleIds = new ArrayList<>();
            for (AuthOrganizationRole authOrganizationRole : authOrganizationRoles) {
                roleIds.add(authOrganizationRole.getRoleId());
            }
            organizationShowVO.setRoleIds(roleIds);
        }
        return organizationShowVOS;
    }

    /**
     * @param id
     * @param isLocked
     * @Description PC端领用禁用
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void changeIsLocked(Integer id, Integer isLocked) {
        AuthUser authUser = new AuthUser();
        authUser.setId(id);
        authUser.setIsLocked(isLocked == 0 ? false : true);
        authUserMapper.updateByPrimaryKeySelective(authUser);
    }

    /**
     * @param id
     * @param status
     * @Description PC端冻结
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void changeStatus(Integer id, Integer status) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(id);
        AuthOrganization authOrganization = new AuthOrganization();
        authOrganization.setId(authUser.getOrganizationId());
        authOrganization.setStatus(status);//状态，0：正常，1：冻结
        authOrganizationMapper.updateByPrimaryKeySelective(authOrganization);
        AuthUserCriteria userCriteria = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = userCriteria.createCriteria();
        criteria.andOrganizationIdEqualTo(authOrganization.getId());
        AuthUser authUser1 = new AuthUser();
        if (status == 1) {
            //冻结
            //禁用该企业下所有的用户
            authUser1.setIsLocked(true);
        } else {
            //解禁该企业下所有的用户
            authUser1.setIsLocked(false);
        }
        authUserMapper.updateByExampleSelective(authUser1, userCriteria);
    }

    /**
     * @param id
     * @Description PC端删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void remove(Integer id) {
        //查询用户的企业ID
        AuthUser authUser = authUserMapper.selectByPrimaryKey(id);
        //删除企业
        AuthOrganization authOrganization = new AuthOrganization();
        authOrganization.setId(authUser.getOrganizationId());
        authOrganization.setIsDel(true);
        authOrganizationMapper.updateByPrimaryKeySelective(authOrganization);
        //删除企业下所有的用户
        AuthUserCriteria userCriteria = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = userCriteria.createCriteria();
        criteria.andOrganizationIdEqualTo(authUser.getOrganizationId());
        AuthUser authUser1 = new AuthUser();
        authUser1.setIsDel(true);
        authUserMapper.updateByExampleSelective(authUser1, userCriteria);
        //删除组织单元关系表
        AuthOrganizationUnitCriteria example = new AuthOrganizationUnitCriteria();
        AuthOrganizationUnitCriteria.Criteria criteria1 = example.createCriteria();
        criteria1.andOrganizationIdEqualTo(authUser.getOrganizationId())
                .andIsDelEqualTo(false);
        AuthOrganizationUnit unit = new AuthOrganizationUnit();
        unit.setIsDel(true);
        authOrganizationUnitMapper.updateByExampleSelective(unit, example);
    }

    /**
     * @param id
     * @Description 重置密码
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void resetPassword(Integer id) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(id);
        String mobile = authUser.getMobile();
        if (StringUtils.isNotBlank(mobile) && mobile.length() >= 6) {
            String password = mobile.substring(mobile.length() - 6);
            AuthUser authUser1 = new AuthUser();
            authUser1.setId(authUser.getId());
            String passwordEncode = BCryptUtil.encode(password);
            authUser1.setPassword(passwordEncode);
            authUserMapper.updateByPrimaryKeySelective(authUser1);
        }
    }

    @Override
    public Result updatePassword(cn.yq.common.vo.AuthUser authUser, PasswordDTO dto) {
        AuthUser authUser2 = authUserMapper.selectByPrimaryKey(authUser.getId());
        if (!BCryptUtil.isMatch(dto.getOriginalPwd(), authUser2.getPassword())) {
            return new Result(ResultEnum.FAIL.getCode(), "原密码不正确");
        }
        authUser2.setPassword(BCryptUtil.encode(dto.getNewPwd()));
        authUserMapper.updateByPrimaryKeySelective(authUser2);
        return Result.returnOk("修改密码成功");
    }

    /**
     * @param addRoleDTO
     * @Description 添加角色
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void addRole(AddRoleDTO addRoleDTO) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(addRoleDTO.getId());
        //删除
        AuthOrganizationRoleCriteria roleCriteria = new AuthOrganizationRoleCriteria();
        AuthOrganizationRoleCriteria.Criteria criteria1 = roleCriteria.createCriteria();
        criteria1.andOrganizationIdEqualTo(authUser.getOrganizationId());
        AuthOrganizationRole authOrganizationRole1 = new AuthOrganizationRole();
        authOrganizationRole1.setIsDel(true);
        authOrganizationRoleMapper.updateByExampleSelective(authOrganizationRole1, roleCriteria);
        //添加
        for (Integer roleId : addRoleDTO.getRoleIds()) {
            AuthOrganizationRole authOrganizationRole = new AuthOrganizationRole();
            authOrganizationRole.setOrganizationId(authUser.getOrganizationId());
            authOrganizationRole.setRoleId(roleId);
            authOrganizationRoleMapper.insertSelective(authOrganizationRole);
        }
        //删除用户角色关系表
        AuthUserRoleCriteria userRoleCriteria = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = userRoleCriteria.createCriteria();
        criteria2.andUserIdEqualTo(addRoleDTO.getId());
        AuthUserRole userRole = new AuthUserRole();
        userRole.setIsDel(true);
        authUserRoleMapper.updateByExampleSelective(userRole, userRoleCriteria);
        //插入用户角色关系表
        for (Integer roleId : addRoleDTO.getRoleIds()) {
            AuthUserRole authUserRole = new AuthUserRole();
            authUserRole.setUserId(authUser.getId());
            authUserRole.setRoleId(roleId);
            authUserRoleMapper.insertSelective(authUserRole);
        }
    }

    /**
     * @Description 获取拼接单元
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<OrganizationUnitVO> getUnit(Integer orgId) {
        return authOrganizationCusMapper.getUnit(orgId);
    }

    /**
     * @param id
     * @Description PC编辑时详情展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public OrganizationDetailVO detail(Integer id) {
        return authOrganizationCusMapper.getOrganizationDetailVO(id);
    }

    /**
     * @param organizationAddDTO
     * @Description PC编辑
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void edit(OrganizationAddDTO organizationAddDTO) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(organizationAddDTO.getId());
        //修改组织表
        if (StringUtils.isNotBlank(organizationAddDTO.getAddress())) {
            AuthOrganization authOrganization = new AuthOrganization();
            authOrganization.setId(authUser.getOrganizationId());
            authOrganization.setAddress(organizationAddDTO.getAddress());
            authOrganizationMapper.updateByPrimaryKeySelective(authOrganization);
        }
        //修改用户表
        AuthUser authUser1 = new AuthUser();
        authUser1.setId(organizationAddDTO.getId());
        authUser1.setMobile(organizationAddDTO.getMobile());
        authUser1.setIsLocked(organizationAddDTO.getStatus() == 0 ? false : true);
        authUserMapper.updateByPrimaryKeySelective(authUser1);
        //修改组织单元表
        if (organizationAddDTO.getUnitIds() != null && organizationAddDTO.getUnitIds().size() > 0) {
            //删除
            AuthOrganizationUnitCriteria unitCriteria = new AuthOrganizationUnitCriteria();
            AuthOrganizationUnitCriteria.Criteria criteria = unitCriteria.createCriteria();
            criteria.andOrganizationIdEqualTo(authUser.getOrganizationId());
            AuthOrganizationUnit authOrganizationUnit = new AuthOrganizationUnit();
            authOrganizationUnit.setIsDel(true);
            authOrganizationUnitMapper.updateByExampleSelective(authOrganizationUnit, unitCriteria);
            //添加
            for (Integer unitId : organizationAddDTO.getUnitIds()) {
                AuthOrganizationUnit authOrganizationUnit1 = new AuthOrganizationUnit();
                authOrganizationUnit1.setOrganizationId(authUser.getOrganizationId());
                BuildingIdStoreyIdVO buildingIdStoreyId = authOrganizationCusMapper.getBuildingIdStoreyId(unitId);
                authOrganizationUnit1.setBuildingId(buildingIdStoreyId.getBuildingId());
                authOrganizationUnit1.setStoreyId(buildingIdStoreyId.getStoreyId());
                authOrganizationUnit1.setUnitId(unitId);
                authOrganizationUnitMapper.insertSelective(authOrganizationUnit1);
            }
        }
        //修改组织角色关系表
        //删除
        AuthOrganizationRoleCriteria roleCriteria = new AuthOrganizationRoleCriteria();
        AuthOrganizationRoleCriteria.Criteria criteria1 = roleCriteria.createCriteria();
        criteria1.andOrganizationIdEqualTo(authUser.getOrganizationId());
        AuthOrganizationRole authOrganizationRole = new AuthOrganizationRole();
        authOrganizationRole.setIsDel(true);
        authOrganizationRoleMapper.updateByExampleSelective(authOrganizationRole, roleCriteria);
        //添加
        if (organizationAddDTO.getRoleIds() != null && organizationAddDTO.getRoleIds().size() > 0) {
            for (Integer roleId : organizationAddDTO.getRoleIds()) {
                AuthOrganizationRole authOrganizationRole1 = new AuthOrganizationRole();
                authOrganizationRole1.setOrganizationId(authUser.getOrganizationId());
                authOrganizationRole1.setRoleId(roleId);
                authOrganizationRoleMapper.insertSelective(authOrganizationRole1);
            }
        }
        //删除用户角色关系表
        AuthUserRoleCriteria userRoleCriteria = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = userRoleCriteria.createCriteria();
        criteria2.andUserIdEqualTo(organizationAddDTO.getId());
        AuthUserRole userRole = new AuthUserRole();
        userRole.setIsDel(true);
        authUserRoleMapper.updateByExampleSelective(userRole, userRoleCriteria);
        //插入用户角色关系表
        for (Integer roleId : organizationAddDTO.getRoleIds()) {
            AuthUserRole authUserRole = new AuthUserRole();
            authUserRole.setUserId(authUser.getId());
            authUserRole.setRoleId(roleId);
            authUserRoleMapper.insertSelective(authUserRole);
        }
    }
}
