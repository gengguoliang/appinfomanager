package cn.yq.sysapi.service.impl;

import cn.yq.common.datapermission.DataPermissionContext;
import cn.yq.common.enumeration.DataRange;
import cn.yq.common.utils.GsonUtil;
import cn.yq.common.utils.ShareCodeUtils;
import cn.yq.sysapi.service.DataAuthService;
import cn.yq.sysapi.utils.RedisKeyUtil;
import cn.yq.sysapi.utils.SecurityUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author: ggl
 * @Date: 2019/6/5 14:29
 * @Description:
 */
@Service
public class DataAuthServiceImpl implements DataAuthService {

    @Resource
    private SecurityUtil securityUtil;
    @Resource
    private RedisTemplate redisTemplate;

    @Override
    public DataPermissionContext getDeptIds() throws Throwable {
        //获取当前用户上下文
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String header = request.getHeader("X-AUTH-ID");
        cn.yq.sysapi.model.AuthUser authUser = null;
        if (StringUtils.isNotBlank(header)) {
            String authUserString = URLDecoder.decode(header, "UTF-8");
            authUser = GsonUtil.changeGsonToBean(authUserString, cn.yq.sysapi.model.AuthUser.class);
        }
        if (redisTemplate.hasKey(RedisKeyUtil.getKey(authUser.getId()))) {
            String dateAuth = redisTemplate.opsForValue().get(RedisKeyUtil.getKey(authUser.getId())).toString();
            return JSON.parseObject(dateAuth,DataPermissionContext.class);
        }
        Map rangemap = securityUtil.getRangeByUser(authUser.getUsername());
        //判断如果是所有权限
        if (rangemap.size() == 1 && rangemap.get(10000) != null) {
            redisTemplate.opsForValue().set(RedisKeyUtil.getKey(authUser.getId()), JSON.toJSONString(DataPermissionContext.newBuilder().dataRange(DataRange.ALL).build()));
            return DataPermissionContext.newBuilder().dataRange(DataRange.ALL).build();
        } else if (rangemap.size() == 1 && rangemap.get(10001) != null) {
            //本人数据
            redisTemplate.opsForValue().set(RedisKeyUtil.getKey(authUser.getId()), JSON.toJSONString(DataPermissionContext.newBuilder().dataRange(DataRange.SELF).userId(authUser.getId()).username(authUser.getUsername()).build()));
            return DataPermissionContext.newBuilder().dataRange(DataRange.SELF).userId(authUser.getId()).username(authUser.getUsername()).build();
        } else {
            //如果是部分权限
            List<Integer> list = new ArrayList<>();
            list = (List<Integer>) rangemap.values().stream().collect(Collectors.toList());
            redisTemplate.opsForValue().set(RedisKeyUtil.getKey(authUser.getId()),JSON.toJSONString(DataPermissionContext.newBuilder().dataRange(DataRange.DEPARTMENT_AND_CHILDREN).departmentIdList(list).build()));
            return DataPermissionContext.newBuilder().dataRange(DataRange.DEPARTMENT_AND_CHILDREN).departmentIdList(list).build();
        }


    }
}

