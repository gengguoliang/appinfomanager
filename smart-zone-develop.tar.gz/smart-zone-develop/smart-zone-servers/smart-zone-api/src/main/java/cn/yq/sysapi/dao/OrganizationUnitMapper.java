package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.OrganizationUnit;
import cn.yq.sysapi.model.OrganizationUnitCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrganizationUnitMapper {
    long countByExample(OrganizationUnitCriteria example);

    int deleteByExample(OrganizationUnitCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(OrganizationUnit record);

    int insertSelective(OrganizationUnit record);

    List<OrganizationUnit> selectByExample(OrganizationUnitCriteria example);

    OrganizationUnit selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") OrganizationUnit record, @Param("example") OrganizationUnitCriteria example);

    int updateByExample(@Param("record") OrganizationUnit record, @Param("example") OrganizationUnitCriteria example);

    int updateByPrimaryKeySelective(OrganizationUnit record);

    int updateByPrimaryKey(OrganizationUnit record);
}