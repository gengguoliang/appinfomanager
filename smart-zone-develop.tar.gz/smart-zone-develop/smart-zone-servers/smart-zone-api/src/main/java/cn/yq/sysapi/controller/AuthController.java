package cn.yq.sysapi.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.sysapi.dao.AuthOrganizationMapper;
import cn.yq.sysapi.dao.AuthUserCusMapper;
import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.enumeration.VerificationCodeType;
import cn.yq.sysapi.model.AuthOrganization;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.service.AuthService;
import cn.yq.sysapi.vo.LoginUserVO;
import cn.yq.sysapi.vo.ResetPasswordVO;
import cn.yq.sysapi.vo.UserRegistVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Api(value = "用户登录认证", description = "用户登录认证 API")
@RestController
@RequestMapping(value = "/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Resource
    private AuthUserMapper authUserMapper;
    @Resource
    private AuthUserCusMapper authUserCusMapper;
    @Autowired
    private AuthOrganizationMapper authOrganizationMapper;

    @Autowired
    private RedisTemplate redisTemplate;


    /**
    *@Description 根据组织ID查询所有角色名
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @GetMapping("/queryRoleName/{orgId}")
    @SystemLog(description = "根据组织ID查询所有角色名")
    public Result<List<String>> queryRoleName(@PathVariable("orgId")Integer orgId){
        List<String> list = authUserCusMapper.queryRoleName(orgId);
        return Result.returnOk(list);
    }

    /**
     * 用户登陆的方法
     *
     * @param name
     * @return
     * @author banzhiguo
     */
    @PostMapping("/query")
    public Result<cn.yq.common.vo.AuthUser> queryByName(@RequestParam("name") String name) {
        cn.yq.common.vo.AuthUser authUser = authUserCusMapper.getUserByUserName(name);
        if (ObjectUtils.isEmpty(authUser)) {
            return new Result(ResultEnum.FAIL.getCode(), "根据用户名密码查询为空!");
        }
        // 查看企业账户是否冻结如果冻结则该账号不能使用并且提示用户账户已冻结
        AuthOrganization authOrganization = authOrganizationMapper.selectByPrimaryKey(authUser.getOrganizationId());
        /*if (authOrganization.getStatus().equals(GlobalConstant.FROZEN)) {
        .
            return new Result(ResultEnum.FAIL.getCode(), "该账号已冻结!");
        }
        if (authOrganization.getStatus().equals(GlobalConstant.FORBIDDEN)) {
            return new Result(ResultEnum.FAIL.getCode(), "该账号已禁用!");
        }*/

        //若用户名为空，则将手机号作为用户名
        if (StringUtils.isBlank(authUser.getUsername())) {
            authUser.setUsername(authUser.getMobile());
        }

        return Result.returnOk(authUser);
    }

//    @ApiOperation(value = "用户登录认证", notes = "获取访问令牌")
//    @RequestMapping(value = "${jwt.route.authentication.path}", method = RequestMethod.POST)
//    public BaseResult<?> createAuthenticationToken(
//            @RequestBody JwtAuthenticationRequest authenticationRequest) throws AuthenticationException {
//        final String token = authService.login(authenticationRequest.getUsername(), authenticationRequest.getPassword());
//
//        // Return the token
//        return BaseResult.successWithData(new JwtAuthenticationResponse(token));
//    }

    /*@RequestMapping(value = "${jwt.route.authentication.refresh}", method = RequestMethod.GET)
    public ResponseEntity<?> refreshAndGetAuthenticationToken(
            HttpServletRequest request) throws AuthenticationException{
        String token = request.getHeader(tokenHeader);
        String refreshedToken = authService.refresh(token);
        if(refreshedToken == null) {
            return ResponseEntity.badRequest().body(null);
        } else {
            return ResponseEntity.ok(new JwtAuthenticationResponse(refreshedToken));
        }
    }*/

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public int register(@RequestBody AuthUser addedUser) {
        return authService.register(addedUser);
    }

    @ApiOperation("通过手机号进行注册")
    @RequestMapping(value = "/register-by-phone", method = RequestMethod.POST)
    @SystemLog(description = "通过手机号进行注册")
    public Result<Boolean> registerByPhone(@RequestBody UserRegistVO userRegistVO) {
        String phoneNo = userRegistVO.getPhoneNo();
        String key = "verification_code:" + VerificationCodeType.REGISTER;
        String verificationCode = redisTemplate.opsForHash().get(key, phoneNo).toString();

        if (verificationCode.equals(userRegistVO.getVerificationCode())) {
            redisTemplate.opsForHash().delete(key, phoneNo);
        } else {
            return new Result(ResultEnum.FAIL.getCode(), "校验码不正确");
        }

        boolean isExist = authService.isExist(phoneNo);

        if (!isExist) {
            //  添加用户
            authService.registUser(userRegistVO);
            return Result.returnOk(true);
        }

        return new Result(ResultEnum.FAIL.getCode(), "该手机号已注册");
    }

    @ApiOperation("检查手机号是否已注册")
    @RequestMapping(value = "/exist/{phoneNo}", method = RequestMethod.POST)
    @SystemLog(description = "检查手机号是否已注册")
    public Result<Boolean> registerByPhone(@PathVariable("phoneNo") String phoneNo) {
        boolean isExist = authService.isExist(phoneNo);

        return Result.returnOk(isExist);
    }

    @ApiOperation("重置密码")
    @RequestMapping(value = "/reset-password", method = RequestMethod.POST)
    @SystemLog(description = "重置密码")
    public Result<Boolean> resetPassword(@RequestBody ResetPasswordVO resetPasswordVO) {
        String phoneNo = resetPasswordVO.getPhoneNo();
        String key = "verification_code:" + VerificationCodeType.RESET_PASSWORD;
        String verificationCode = redisTemplate.opsForHash().get(key, phoneNo).toString();

        if (verificationCode.equals(resetPasswordVO.getVerificationCode())) {
            redisTemplate.opsForHash().delete(key, phoneNo);
        } else {
            return new Result(ResultEnum.FAIL.getCode(), "校验码不正确");
        }

        boolean isExist = authService.isExist(resetPasswordVO.getPhoneNo());

        if (isExist) {
            //  重置密码
            authService.resetPassword(resetPasswordVO);
            return Result.returnOk(true);
        }

        return new Result(ResultEnum.FAIL.getCode(), "该手机号尚未注册");
    }

    @ApiOperation("登录")
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @SystemLog(description = "登录")
    public Result<String> login(@RequestBody LoginUserVO loginUserVO) {
        /**
         * TODO  判断手机号/用户名与密码是否匹配
         * 若匹配则颁发 Token
         */

        return Result.returnOk("");
    }
}
