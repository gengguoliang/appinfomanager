package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.model.UserDepartmentCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserDepartmentMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(UserDepartmentCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(UserDepartmentCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(UserDepartment record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(UserDepartment record);

    /**
     *
     * @mbg.generated
     */
    List<UserDepartment> selectByExample(UserDepartmentCriteria example);

    /**
     *
     * @mbg.generated
     */
    UserDepartment selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") UserDepartment record, @Param("example") UserDepartmentCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") UserDepartment record, @Param("example") UserDepartmentCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(UserDepartment record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(UserDepartment record);
}