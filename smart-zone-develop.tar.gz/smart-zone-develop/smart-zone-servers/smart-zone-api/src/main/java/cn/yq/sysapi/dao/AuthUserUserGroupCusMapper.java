package cn.yq.sysapi.dao;

public interface AuthUserUserGroupCusMapper {

}