package cn.yq.sysapi.vo;

import lombok.Data;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class OrganizationUnitVO {

    private Integer id;
    private String unit;
}
