package cn.yq.sysapi.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.service.AuthRoleDeptService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @Auther: houqijun
 * @Date: 2018/11/23 17:23
 * @Description:
 */
@Api(value = "角色部门授权管理", description = "角色部门授权管理 API", position = 100, protocols = "http")
@RestController
@RequestMapping(value = "/role/dept")
public class AuthRoleDeptController {

    private final static Logger log = LoggerFactory.getLogger(AuthRoleDeptController.class);

    @Resource
    private AuthRoleDeptService authRoleDeptService;


    @ApiOperation(value = "根据角色id获取该角色下的部门ids", notes = "根据角色id获取该角色下的部门ids")
    @GetMapping(value = "/getDeptIdsByRoleId/{roleId}")
    @SystemLog(description = "根据角色id获取该角色下的部门ids")
    public BaseResult getDeptIdsByRoleId(@PathVariable("roleId") int roleId){
        log.debug("roleId=======>{}",roleId);
        return BaseResult.successWithData(authRoleDeptService.getDeptIdsByRoleId(roleId));
    }

    @ApiOperation(value = "携带角色id和部门ids将配置的部门保存到角色中", notes = "携带角色id和部门ids将配置的部门保存到角色中")
    @PostMapping(value = "/authorizeByRoleid/{roleId}/{deptids}")
    @SystemLog(description = "携带角色id和部门ids将配置的部门保存到角色中")
    public BaseResult updateRoleDept(@PathVariable("roleId") int roleId, @PathVariable("deptids") int[] deptids){
        log.debug("roleId=======>{}",roleId);
        log.debug("roleId=======>{}",deptids);
        return BaseResult.successWithData(authRoleDeptService.updateRoleDept(roleId,deptids));
    }

}
