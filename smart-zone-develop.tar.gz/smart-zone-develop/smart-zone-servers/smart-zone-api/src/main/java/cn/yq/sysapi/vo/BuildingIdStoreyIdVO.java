package cn.yq.sysapi.vo;

import lombok.Data;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class BuildingIdStoreyIdVO {

    private Integer buildingId;
    private Integer storeyId;
}
