package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.SysDictType;
import cn.yq.sysapi.model.SysDictTypeCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysDictTypeMapper {
    long countByExample(SysDictTypeCriteria example);

    int deleteByExample(SysDictTypeCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysDictType record);

    int insertSelective(SysDictType record);

    List<SysDictType> selectByExample(SysDictTypeCriteria example);

    SysDictType selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysDictType record, @Param("example") SysDictTypeCriteria example);

    int updateByExample(@Param("record") SysDictType record, @Param("example") SysDictTypeCriteria example);

    int updateByPrimaryKeySelective(SysDictType record);

    int updateByPrimaryKey(SysDictType record);
}