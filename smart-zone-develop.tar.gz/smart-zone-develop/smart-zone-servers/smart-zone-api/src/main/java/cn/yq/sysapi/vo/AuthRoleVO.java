package cn.yq.sysapi.vo;

import lombok.Data;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class AuthRoleVO {

    private Integer id;
    private String roleName;
}
