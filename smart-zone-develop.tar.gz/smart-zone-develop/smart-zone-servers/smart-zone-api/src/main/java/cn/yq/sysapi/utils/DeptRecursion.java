package cn.yq.sysapi.utils;

import cn.yq.sysapi.vo.TreeNode;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DeptRecursion {

    /**
     * 递归处理   数据库树结构数据->树形json
     * @param TreeNodeId
     * @param TreeNodes
     * @return
     */
    public static JSONArray getTreeNodeJson(String TreeNodeId, Map<String, TreeNode> TreeNodes, List list){

        //当前层级当前TreeNode对象
        TreeNode cur = TreeNodes.get(TreeNodeId);
        //当前层级当前点下的所有子节点
        List<TreeNode> childList = getChildTreeNodes(TreeNodeId,TreeNodes);

        JSONArray childTree = new JSONArray();
        for (TreeNode TreeNode : childList) {
            //保存id
           // List list = new ArrayList();
            JSONObject o = new JSONObject();
            list.add(TreeNode.getId());
            o.put("id", TreeNode.getId());
            o.put("label", TreeNode.getName());
            //o.put("type", TreeNode.getType());
//            o.put("canDel",true);
//            o.put("canAdd",true);
            JSONArray childs = getTreeNodeJson(TreeNode.getId(),TreeNodes,list);  //递归调用该方法
            if(!childs.isEmpty()) {
                o.put("children",childs);
            }
            childTree.fluentAdd(o);
        }

        return childTree;
    }

    /**
     * 获取当前节点的所有子节点
     * @param TreeNodeId
     * @param TreeNodes
     * @return
     */
    public static List<TreeNode> getChildTreeNodes(String TreeNodeId, Map<String,TreeNode> TreeNodes){
        List<TreeNode> list = new ArrayList<>();
        for (String key : TreeNodes.keySet() ) {
            if(TreeNodes.get(key).getParentId().equals(TreeNodeId)){
                list.add(TreeNodes.get(key));
            }
        }
        return list;
    }

}




