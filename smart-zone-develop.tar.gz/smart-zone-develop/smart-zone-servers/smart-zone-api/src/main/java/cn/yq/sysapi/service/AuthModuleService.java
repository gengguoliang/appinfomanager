package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthModule;
import cn.yq.sysapi.vo.AuthModulePrivilegeVo;

import java.util.List;

public interface AuthModuleService {

    List<AuthModule> getTreeData(String username, String method);

    List<AuthModulePrivilegeVo> getTreeDataByRoleids(List roleids,Integer category);

    List<AuthModulePrivilegeVo> getTreeModuleDataByRoleids(Integer orgid,List roleids,Integer category);

    List<AuthModulePrivilegeVo> getTreeModuleDataShengyuan(List roleids,Integer category);

    int authorizeByRoleid(int roleId,int category,int[] auth);



    /**
     * 根据角色ID查找用户角色对应的权限code
     * @param roleids
     * @return
     */
    List selectPrivilegeCode(List roleids);

    List<String>selectPrivilegeAPPCode(List roleids,Integer category);
}
