package cn.yq.sysapi.vo;

import lombok.Data;

import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class OrganizationDetailVO {

    private Integer id;

    /**
     * 用户名 username
     */
    private String username;
    /**
     *  姓名
     */
    private String name;
    /**
     * 手机号 mobile
     */
    private String mobile;
    /**
     * 企业名称
     */
    private String organizationName;
    /**
     * 所属分类 组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
     */
    private Integer type;
    /**
     * 状态 0：正常 1：冻结
     */
    private Integer status;
    /**
     * 所属角色
     */
    private List<Integer> roleIds;
    /**
     * 单元
     */
    private List<Integer> unitIds;
    /**
     * 0:启用   1：禁用
     */
    private Integer isLocked;
    /**
     * 企业地址
     */
    private String address;
    /**
     *  组织信用代码
     */
    private String certifyNum;
}
