package cn.yq.sysapi.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: yinqk
 * @date: 2019-04-28 19:37
 * @description: 用户登录信息
 */
@Data
@ApiModel(description = "用户登录信息")
public class LoginUserVO {
    @ApiModelProperty(value = "手机号/用户名", name = "username", required = true, position = 0)
    private String username;

    @ApiModelProperty(value = "密码", name = "password", required = true, position = 1)
    private String password;
}
