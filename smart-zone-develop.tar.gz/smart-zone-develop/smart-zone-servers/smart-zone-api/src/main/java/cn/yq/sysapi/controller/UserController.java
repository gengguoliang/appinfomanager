package cn.yq.sysapi.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.dao.UserDepartmentMapper;
import cn.yq.sysapi.dto.organization.AddRoleDTO;
import cn.yq.sysapi.dto.organization.AddUserDTO;
import cn.yq.sysapi.dto.organization.UserShowDTO;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthUserCriteria;
import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.service.UserService;
import cn.yq.sysapi.vo.AddUserShowVO;
import cn.yq.sysapi.vo.UserDetailVO;
import cn.yq.sysapi.vo.UserShowVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * @program: smart-zone
 * @description: 园区用户管理
 * @author: zhengjianhui
 **/
@Slf4j
@Api(value = "园区用户管理", description = "园区用户管理")
@RestController
@RequestMapping("/parkUser")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private AuthUserMapper authUserMapper;
    @Autowired
    private UserDepartmentMapper userDepartmentMapper;
    
    /**
    *@Description 查询当前登录人所在组织下的所有用户
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "查询当前登录人所在组织下的所有用户", notes = "查询当前登录人所在组织下的所有用户")
    @GetMapping("/getUserByOrg")
    @LoginUser
    @SystemLog(description = "查询当前登录人所在组织下的所有用户")
    public Result getUserByOrg(@ApiIgnore AuthUser authUser){
        cn.yq.sysapi.model.AuthUserCriteria example=new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andOrganizationIdEqualTo(authUser.getOrganizationId())
                .andIsDelEqualTo(false);
        List<cn.yq.sysapi.model.AuthUser> authUsers = authUserMapper.selectByExample(example);
        return Result.returnOk(authUsers);
    }
    
    /**
    *@Description 部门回显需要的List<Integer>
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @PostMapping("/getDeptIds")
    public List<Integer> getDeptIds(@RequestBody AuthUser authUser){
        return userService.getDeptIds(authUser);
    }

    /**
     *@Description 部门回显需要的List<Integer>  2
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    @PostMapping("/getDeptIds2")
    public List<Integer> getDeptIds2(@RequestBody AuthUser authUser){
        return userService.getDeptIds2(authUser);
    }

    
    /**
    *@Description 根据部门ID查询部门名称
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "根据部门ID查询部门名称", notes = "根据部门ID查询部门名称")
    @GetMapping("/getDept/{id}")
    @SystemLog(description = "根据部门ID查询部门名称")
    public Result<UserDepartment> getDept(@PathVariable("id") Integer id){
        UserDepartment userDepartment = userDepartmentMapper.selectByPrimaryKey(id);
        return Result.returnOk(userDepartment);
    }

    
    /**
    *@Description 当前用户组织的所有角色
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "当前用户组织的所有角色", notes = "当前用户组织的所有角色")
    @PostMapping("/getRoleByUser")
    @LoginUser
    @SystemLog(description = "查询当前用户组织的所有角色")
    public Result<List<AuthRole>> getRoleByUser(@ApiIgnore AuthUser authUser){
        List<AuthRole> roles = userService.getRoleByUserId(authUser);
        return Result.returnOk(roles);
    }
    
    /**
     * @Description PC添加和编辑用户
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC添加和编辑用户", notes = "PC添加和编辑用户")
    @PostMapping("/addUser")
    @SystemLog(description = "添加和编辑用户")
    public Result addUser(@RequestBody AddUserDTO addUserDTO) {
        if (addUserDTO.getId() == null) {
            //验证账号唯一性
            AuthUserCriteria exmaple = new AuthUserCriteria();
            AuthUserCriteria.Criteria criteria = exmaple.createCriteria();
            criteria.andUsernameEqualTo(addUserDTO.getUserName())
                    .andIsDelEqualTo(false);
            long row = authUserMapper.countByExample(exmaple);
            if (row > 0) {
                return new Result(ResultEnum.FAIL.getCode(), "账号已存在");
            }
            //验证手机号唯一性
            AuthUserCriteria exmaple1 = new AuthUserCriteria();
            AuthUserCriteria.Criteria criteria1 = exmaple1.createCriteria();
            criteria1.andMobileEqualTo(addUserDTO.getMobile())
                    .andIsDelEqualTo(false);
            long count = authUserMapper.countByExample(exmaple1);
            if (count > 0) {
                return new Result(ResultEnum.FAIL.getCode(), "手机号已存在");
            }
        }else {
            AuthUserCriteria exmaple1 = new AuthUserCriteria();
            AuthUserCriteria.Criteria criteria1 = exmaple1.createCriteria();
            criteria1.andMobileEqualTo(addUserDTO.getMobile())
                    .andIdNotEqualTo(addUserDTO.getId())
                    .andIsDelEqualTo(false);
            long count = authUserMapper.countByExample(exmaple1);
            if (count > 0) {
                return new Result(ResultEnum.FAIL.getCode(), "手机号已存在");
            }
        }
        addUserDTO.setDepartmentId(addUserDTO.getDepartmentIds().get(addUserDTO.getDepartmentIds().size() - 1));
        userService.addUser(addUserDTO);
        return Result.returnOk();
    }

    /**
     * @Description PC列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC列表展示", notes = "PC列表展示")
    @PostMapping("/showPage/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "用户管理列表展示")
    public Result showPage(AuthUser authUser, @PathVariable("pageNum") Integer pageNum,
                           @PathVariable("pageSize") Integer pageSize,
                           @RequestBody UserShowDTO userShowDTO) {
        if (userShowDTO.getDepartmentId() != null && userShowDTO.getDepartmentId().size() > 0) {
            userShowDTO.setDid(userShowDTO.getDepartmentId().get(0));
        }
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<UserShowVO> pageInfo = new PageInfo<>(userService.showPage(authUser, userShowDTO));
        return Result.returnOk(pageInfo);
    }

    /**
     * @Description PC审核
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC审核", notes = "PC审核")
    @PostMapping("/changeAuditedStatus")
    @SystemLog(description = "用户管理的用户审核")
    public Result changeAuditedStatus(@RequestBody cn.yq.sysapi.model.AuthUser authUser) {
        userService.changeAuditedStatus(authUser.getId(), (int) authUser.getAuditedStatus(), authUser.getAuditedRemark());
        return Result.returnOk();
    }

    /**
     * @Description PC冻结
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC冻结", notes = "PC冻结")
    @GetMapping("/changeIsLocked/{id}/{isLocked}")
    @SystemLog(description = "用户管理的用户冻结/解冻")
    public Result changeIsLocked(@PathVariable("id") Integer id,
                                 @PathVariable("isLocked") Integer isLocked) {
        userService.changeIsLocked(id, isLocked);
        return Result.returnOk();
    }

    /**
     * @Description PC删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC删除", notes = "PC删除")
    @GetMapping("/remove/{id}")
    @SystemLog(description = "删除用户")
    public Result remove(@PathVariable("id") Integer id) {
        userService.remove(id);
        return Result.returnOk();
    }

    /**
     * @Description PC详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC详情", notes = "PC详情")
    @GetMapping("/detail/{id}")
    @SystemLog(description = "用户详情")
    public Result detail(@PathVariable("id") Integer id) {
        UserDetailVO userDetailVO = userService.detail(id);
        return Result.returnOk(userDetailVO);
    }

    /**
     * @Description PC端添加时的信息展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC端添加时的信息展示", notes = "PC端添加时的信息展示")
    @GetMapping("/addUserShow")
    @LoginUser
    @SystemLog(description = "添加用户时的信息展示")
    public Result addUserShow(AuthUser authUser) {
        AddUserShowVO addUserShowVO = userService.addUserShow(authUser);
        return Result.returnOk(addUserShowVO);
    }
    
    /**
    *@Description PC端给用户添加角色
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端给用户添加角色", notes = "PC端给用户添加角色")
    @PostMapping("/addUserRole")
    @SystemLog(description = "给用户添加角色")
    public Result addUserRole(@RequestBody AddRoleDTO addRoleDTO){
        userService.addUserRole(addRoleDTO);
        return Result.returnOk();
    }

}
