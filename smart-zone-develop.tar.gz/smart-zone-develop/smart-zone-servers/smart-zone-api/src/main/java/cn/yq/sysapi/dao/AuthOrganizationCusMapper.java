package cn.yq.sysapi.dao;

import cn.yq.sysapi.dto.organization.AuditedOrgDto;
import cn.yq.sysapi.dto.organization.GetInfoAuthOrgDto;
import cn.yq.sysapi.dto.organization.OrganizationShowDTO;
import cn.yq.sysapi.model.AuthOrganization;
import cn.yq.sysapi.vo.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthOrganizationCusMapper {
    int insertRtnKey(AuthOrganization authOrganization);

    List<AuthOrgVo> query(GetInfoAuthOrgDto query);

    AuthOrgVo getOrgById(@Param("orgId") Integer orgId);

    void insertOrgAdnUnit(@Param("auditedOrg") AuditedOrgDto auditedOrgDto);

    Integer queryTotal(GetInfoAuthOrgDto query);

    List<UnitVo> queryUnit(String unitName);
    
    /**
    *@Description 根据单元ID查询对应的楼层和楼宇ID
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    BuildingIdStoreyIdVO getBuildingIdStoreyId(Integer unitId);
    
    /**
    *@Description PC端列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    List<OrganizationShowVO> showPage(@Param("dto") OrganizationShowDTO dto,@Param("userId")Integer userId);
    
    /**
    *@Description 获取拼接单元
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    List<OrganizationUnitVO> getUnit(@Param("orgId") Integer orgId);
    
    /**
    *@Description 编辑中的详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    OrganizationDetailVO getOrganizationDetailVO(Integer id);
}