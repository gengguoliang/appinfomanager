package cn.yq.sysapi.dto.organization;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class AddRolesForUserDto {
    private Integer userId;
    private List<Integer> roleIds;
}
