package cn.yq.sysapi.service;

import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthUser;

import java.util.List;

public interface AuthRoleService {

    /**
     * 增加角色
     */
    int add(AuthRole role);

    /**
     * 删除角色
     */
    int remove(int id);

    /**
     * 修改角色
     */
    int update(AuthRole role);

    /**
     * 查询角色
     */
    List<AuthRole> query(AuthRole role);

    /**
     * 获取角色信息列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    List<AuthRole> getListByPage(int organizationId,int pageNum, int pageSize);

   public boolean  deleteRole(int roleId);

    /**
     * 根据角色id获取用户信息
     * @param roleid
     * @return
     */
    List<AuthUser> selectUserByRoleId(int roleid);
}
