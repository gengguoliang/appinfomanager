package cn.yq.sysapi.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.model.AuthUserGroup;
import cn.yq.sysapi.service.AuthUserGroupService;
import cn.yq.sysapi.service.AuthUserUserGroupService;
import cn.yq.sysapi.utils.TreeRecursion;
import cn.yq.sysapi.vo.TreeNode;
import cn.yq.sysapi.vo.UserGroupVo;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(value = "用户组信息管理", description = "用户组信息管理 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/usergroup")
public class AuthUserGroupController {

    @Autowired
    AuthUserGroupService authUserGroupService;

    @Autowired
    AuthUserUserGroupService authUserUserGroupService;

    @ApiOperation(value = "用户组列表", notes = "完整的用户组信息列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "pageNum", value = "页码，从1开始", required = true, dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "pageSize", value = "页面大小", required = true, dataType = "int", paramType = "path")
    })
    @GetMapping("/{pageNum}/{pageSize}")
    @SystemLog(description = "用户组列表")
    public BaseResult<PageInfo<List<AuthUserGroup>>> getListByPage(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize) {
        return BaseResult.successWithData(new PageInfo(authUserGroupService.getListByPage(pageNum, pageSize)));
    }

    @ApiOperation(value = "添加用户组信息", notes = "添加用户组信息")
    @PostMapping(value = "/", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加用户组信息")
    public BaseResult addUserGroup(@RequestBody UserGroupVo userGroupVo) {

        AuthUserGroup userGroup = new AuthUserGroup();
        BeanUtils.copyProperties(userGroupVo,userGroup);
        List<AuthUserGroup> list = authUserGroupService.query(userGroup);
        if (list.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "用户组名称不能重复");
        }
        authUserGroupService.add(userGroup);
        return BaseResult.successWithData("添加成功");
    }

    @ApiOperation(value = "删除用户组", notes = "删除用户组")
    @ApiImplicitParam(name = "userGroupId", value = "用户组ID", dataType = "int", paramType = "path")
    @PutMapping(value = "/{userGroupId}/deleteUserGroup")
    @SystemLog(description = "删除用户组")
    public BaseResult<Boolean> deleteUserGroup(@PathVariable("userGroupId") int userGroupId) {
        return BaseResult.successWithData(authUserGroupService.deleteUserGroup(userGroupId));
    }


    @ApiOperation(value = "编辑用户组名称信息", notes = "编辑用户组名称信息")
    @PutMapping(value = "/updateUserGroupName", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "编辑用户组名称信息")
    public BaseResult updateUserGroup(@RequestBody UserGroupVo userGroupVo) {
        AuthUserGroup userGroup = new AuthUserGroup();
        BeanUtils.copyProperties(userGroupVo,userGroup);
        //判断用户组是否重名，重名则修改失败
        List<AuthUserGroup> list = authUserGroupService.query(userGroup);
        if (list.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "用户组名称不能重复");
        }
        authUserGroupService.update(userGroup);
        return BaseResult.successWithData("修改成功");
    }

    @ApiOperation(
            value = "查询用户组信息",
            notes = "查询用户组信息",
            produces = "application/json",
            consumes = "application/json",
            response = BaseResult.class)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userGroup", value = "用户组对象", required = true, dataType = "AuthUserGroup", paramType = "path"),
    })
    @PostMapping("/queryUserGroup")
    @SystemLog(description = "查询用户组信息")
    public BaseResult queryUserGroup(AuthUserGroup userGroup) {
        List<AuthUserGroup> list = authUserGroupService.query(userGroup);
        return BaseResult.successWithData(list);
    }

    @ApiOperation(value = "获取用户组树数据", notes = "获取用户组树数据")
    @GetMapping("/getUserGroupTreeData")
    @SystemLog(description = "获取用户组树数据")
    public BaseResult getUserGroupTreeData(){
        AuthUserGroup userGroup = new AuthUserGroup();
        userGroup.setIsDel(false);
        //获取数据库表数据
        List<AuthUserGroup> list = authUserGroupService.query(userGroup);
        //存储树结构
        Map<String, TreeNode> TreeNodes = new HashMap();
        for(AuthUserGroup ug : list){
            TreeNode node = new TreeNode();
                node.setId(ug.getId().toString());
                node.setName(ug.getGroupName());
                node.setParentId(ug.getParentId().toString());
                node.setType(0);
            TreeNodes.put(ug.getId().toString(),node);
        }
        return BaseResult.successWithData(TreeRecursion.getTreeNodeJson("0",TreeNodes));
    }

    @ApiOperation(value = "根据组Id获取用户组下的用户", notes = "根据组Id获取用户组下的用户")
    @ApiImplicitParam(name = "userGroupId", value = "用户组ID", dataType = "int", paramType = "path")
    @GetMapping("/getUsersByUserGroupId/{userGroupId}")
    @SystemLog(description = "根据组Id获取用户组下的用户")
    public  BaseResult getUsersByUserGroupId(@PathVariable("userGroupId") int userGroupId){
        return BaseResult.successWithData(authUserUserGroupService.getUsersByUserGroupId(userGroupId));
    }

    @ApiOperation(value = "根据组Id添加组用户", notes = "根据组Id添加组用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userGroupId", value = "用户组ID", dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "userids", value = "用户ID数组", dataType = "int[]", paramType = "path")
    })
    @PostMapping("/addUsersByUserGroupId/{userGroupId}/{userids}")
    @SystemLog(description = "根据组Id添加组用户")
    public BaseResult addUsersByUserGroupId(@PathVariable("userGroupId") int userGroupId,@PathVariable("userids") int[] userids){
        authUserUserGroupService.addUsersByUserGroupId(userGroupId,userids);
        return BaseResult.successWithData("添加成功");
    }

    @ApiOperation(value = "根据组Id移除组用户", notes = "根据组Id移除组用户")
    @ApiImplicitParam(name = "userGroupId", value = "用户组ID", dataType = "int", paramType = "path")
    @PutMapping("/removeUsersByUserGroupId/{userGroupId}")
    @SystemLog(description = "根据组Id移除组用户")
    public BaseResult removeUsersByUserGroupId(@PathVariable("userGroupId") int userGroupId){
        authUserUserGroupService.removeUsersByUserGroupId(userGroupId);
        return BaseResult.successWithData("删除成功");
    }

    @ApiOperation(value = "根据组Id与用户Id移除组用户", notes = "根据组Id与用户Id移除组用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userGroupId", value = "用户组ID", dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "userId", value = "用户ID", dataType = "int", paramType = "path")
    })
    @PutMapping("/removeUserByUserGroupIdAndUserid/{userGroupId}/{userId}")
    @SystemLog(description = "根据组Id与用户Id移除组用户")
    public BaseResult removeUserByUserGroupIdAndUserid(@PathVariable("userGroupId") int userGroupId,@PathVariable("userId") int userId){
        authUserUserGroupService.removeUserByUserGroupIdAndUserid(userGroupId,userId);
        return BaseResult.successWithData("删除成功");
    }


    @ApiOperation(value = "根据组Id获取非本用户组下的用户", notes = "根据组Id获取非本用户组下的用户")
    @ApiImplicitParam(name = "userGroupId", value = "用户组ID", dataType = "int", paramType = "path")
    @GetMapping("/getOutUsersByUserGroupId/{userGroupId}")
    @SystemLog(description = "根据组Id获取非本用户组下的用户")
    public  BaseResult getOutUsersByUserGroupId(@PathVariable("userGroupId") int userGroupId){
        return BaseResult.successWithData(authUserUserGroupService.getOutUsersByUserGroupId(userGroupId));
    }

    @ApiOperation(value = "向用户组授权", notes = "向用户组授权")
    @ApiImplicitParam(name = "authInfo", value = "授权信息", dataType = "String", paramType = "path")
    @PostMapping("/userGroupAuthorization/{authInfo}")
    @SystemLog(description = "向用户组授权")
    public BaseResult userGroupAuthorization(@PathVariable("authInfo") String authInfo){
        //获取授权信息进行授权
        authUserGroupService.userGroupAuthorization(authInfo);
        return  BaseResult.successWithData("操作成功");
    }

















}
