package cn.yq.sysapi.common.aspect;

import cn.yq.common.utils.CopyUtils;
import cn.yq.common.utils.GsonUtil;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.utils.SecurityUtil;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.util.Iterator;
import java.util.Map;

/**
 * 数据过滤，切面处理类
 * @author chenshun
 * @email sunlightcs@gmail.com
 * @date 2017/9/17 15:02
 */
@Aspect
@Component
public class DataFilterAspect {
    private final static Logger log = LoggerFactory.getLogger(DataFilterAspect.class);
    @Resource
    private SecurityUtil securityUtil;


    @Pointcut("@annotation(cn.yq.sysapi.common.annotation.DataFilter)")
    public void dataFilterCut() {

    }

    @Before("dataFilterCut()")
    public void dataFilter(JoinPoint point) throws Throwable {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String header = request.getHeader("X-AUTH-ID");
        AuthUser authUser = null;
        if(StringUtils.isNotBlank(header)){
            String authUserString = URLDecoder.decode(header, "UTF-8");
            authUser = GsonUtil.changeGsonToBean(authUserString,AuthUser.class);
        }
        if(null == authUser){
            cn.yq.common.vo.AuthUser authuser = (cn.yq.common.vo.AuthUser)point.getArgs()[1];
            authUser = new AuthUser();
            CopyUtils.copyProperties(authuser,authUser);
        }
        Object params = point.getArgs()[0];
        if(params != null && params instanceof Map){
            Map map = (Map)params;
            StringBuffer ids = new StringBuffer();
            Map rangemap = securityUtil.getRangeByUser(authUser.getUsername());
            map.put("username",authUser.getUsername());
            //判断如果是所有权限
            if(rangemap.size()==1 && rangemap.get(10000)!=null){
                map.put("deptids",ids.toString());

            }else if(rangemap.size()==1 && rangemap.get(10001)!=null){
                //本人数据
                map.put("deptids","10001");

            }else{
                //如果是部分权限
                Iterator entries = rangemap.entrySet().iterator();
                while (entries.hasNext()) {
                    Map.Entry entry = (Map.Entry) entries.next();
                    Integer key = (Integer)entry.getKey();
                    Integer value = (Integer)entry.getValue();
//                    System.out.println("Key = " + key + ", Value = " + value);
                    ids.append(key).append(",");
                }
                if (!"".equals(ids.toString())){
                    ids.deleteCharAt(ids.length() - 1);
                }
                map.put("deptids",ids.toString());
            }
//            log.debug("部门ids========>{}",ids);
////            if(StringUtils.isBlank(ids)){
////                throw new SmartApiException("没有访问其他部门的权限！！！");
////                map.put("deptids",ids.toString());
////            }
            return ;
        }
    }


}
