package cn.yq.sysapi.service;


import cn.yq.sysapi.model.AuthProject;

import java.util.List;

public interface ProjectService {
    /**
     * 获取项目列表
     *
     * @return
     */
    List<AuthProject> getListByPage(int pageNum, int pageSize);

    /**
     * 新增项目
     *
     * @param project
     * @return
     */
    int add(AuthProject project);
}
