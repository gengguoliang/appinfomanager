package cn.yq.sysapi.service;

import cn.yq.common.enumeration.DictionaryType;
import cn.yq.sysapi.dto.organization.SysLogDTO;
import cn.yq.sysapi.model.SysDictData;
import cn.yq.sysapi.model.SysLog;

import java.util.List;

public interface SysService {

    /**
     * 根据字典类型获取字典数据列表
     *
     * @param dictionaryType
     * @return
     */
    List<SysDictData> getSysDictData(DictionaryType dictionaryType);

    /**
     * 新增系统操作日志
     *
     * @param sysLog
     * @return
     */
    Integer insertSysLog(SysLog sysLog);


    /**
     * @Description 系统日志查询
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    List<SysLog> sysLogShow(Integer pageNum, Integer pageSize, SysLogDTO dto);

}
