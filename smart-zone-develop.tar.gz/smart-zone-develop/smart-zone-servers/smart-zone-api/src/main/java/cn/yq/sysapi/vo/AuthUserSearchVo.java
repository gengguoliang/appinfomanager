package cn.yq.sysapi.vo;

import lombok.Data;

import java.util.Date;

/**
 * @author: YQ-DGZ
 * @date: 2019/3/22 10:28
 * @description: TODO
 */
@Data
public class AuthUserSearchVo {

    private String name;
    private String orgname;
    private Integer category;
    private Integer status;
    private Date begintime;
    private Date endtime;
}
