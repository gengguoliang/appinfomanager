package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthRoleMapper;
import cn.yq.sysapi.dao.AuthModuleSelectUser;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthRoleCriteria;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.service.AuthRoleService;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthRoleServiceImpl implements AuthRoleService {

    @Autowired
    private AuthRoleMapper mapper;
    @Autowired
    private AuthModuleSelectUser authModuleSelectUser;


    @Override
    public int add(AuthRole role) {
        return mapper.insertSelective(role);
    }

    @Override
    public int remove(int id) {
        AuthRoleCriteria example = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(id);
        return mapper.deleteByExample(example);
    }

    @Override
    public int update(AuthRole role) {
        AuthRoleCriteria example = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(role.getId());
        return mapper.updateByExampleSelective(role, example);
    }

    @Override
    public List<AuthRole> query(AuthRole role) {
        AuthRoleCriteria example = new AuthRoleCriteria();
        //example.setOrderByClause();
         AuthRoleCriteria.Criteria criteria = example.createCriteria();
         if(null!=role.getRoleName()&&!"".equals(role.getRoleName())){
             criteria.andRoleNameEqualTo(role.getRoleName());
         }
         if(null!=role.getOrganizationId()){
            criteria.andOrganizationIdEqualTo(role.getOrganizationId());
         }
         criteria.andIsDelEqualTo(false);
        return mapper.selectByExample(example);
    }

    /**
     * 获取用户信息列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public List<AuthRole> getListByPage(int organizationId,int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        AuthRoleCriteria example = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria = example.createCriteria();
        criteria.andIsDelEqualTo(false);
        criteria.andOrganizationIdEqualTo(organizationId);
        return mapper.selectByExample(example);
    }

    @Override
    public boolean deleteRole(int roleId) {

        AuthRole authRole = new AuthRole();
        authRole.setId(roleId);
        authRole.setIsDel(true);
        mapper.updateByPrimaryKeySelective(authRole);
        return true;
    }

    @Override
    public List<AuthUser> selectUserByRoleId(int roleid) {
        return authModuleSelectUser.selectUserByRoleId(roleid);
    }
}
