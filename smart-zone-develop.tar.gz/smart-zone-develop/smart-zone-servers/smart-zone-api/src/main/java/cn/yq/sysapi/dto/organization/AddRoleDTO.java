package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
@ApiModel(value = "PC端添加角色DTO")
public class AddRoleDTO {

    @ApiModelProperty(value = "用户id")
    private Integer id;
    @ApiModelProperty(value = "角色ID")
    private List<Integer> roleIds;
}
