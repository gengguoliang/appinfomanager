package cn.yq.sysapi.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.model.AuthModule;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.service.AuthModuleService;
import cn.yq.sysapi.service.AuthUserService;
import cn.yq.sysapi.vo.AuthModulePrivilegeVo;
import cn.yq.sysapi.vo.DynamicMenuTreeNode;
import cn.yq.sysapi.utils.DynamicMenuTreeRecursion;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.*;

@Slf4j
@Api(value = "动态菜单管理", description = "动态菜单管理API", position = 100, protocols = "http")
@RestController
@RequestMapping("/dynamicmenu")
public class DynamicMenuController{

    @Autowired
    AuthModuleService authModuleService;

    @Autowired
    AuthUserService authUserService;


    /**
     * 获取动态菜单树数据
     * @return
     */
    @ApiOperation(value = "获取菜单树数据", notes = "获取菜单树数据")
    @GetMapping("/getTreeData")
    @LoginUser
    @SystemLog(description = "获取菜单树数据")
    public BaseResult getTreeData(AuthUser authUser){
        String username = authUser.getUsername();
        //数据来源修改
//        List<AuthModule> list =authModuleService.getTreeData(username,"getTreeData");
        //获取当前用户的角色列表
        List<AuthRole> roleList = authUserService.getRolesByUsername(username);
        //根据角色id 获取该角色的菜单树数据
        List roleids = new ArrayList();
        for(AuthRole role:roleList){
            roleids.add(role.getId());
        }
        List<AuthModulePrivilegeVo> list = authModuleService.getTreeDataByRoleids(roleids,2);
        //存储树结构
        Map<String, DynamicMenuTreeNode> TreeNodes = new LinkedHashMap<>();
        for(AuthModulePrivilegeVo authModule : list){
            DynamicMenuTreeNode node = new DynamicMenuTreeNode();
            node.setId(String.valueOf(authModule.getId()));
            node.setName(authModule.getName());
            node.setParentId(String.valueOf(authModule.getParentId()));
            node.setType(Integer.valueOf(authModule.getType()));
            node.setPath(authModule.getUrl());
            String component = authModule.getComponent();
            node.setComponent(component);
            node.setIconCls(authModule.getIconCls());
            TreeNodes.put(String.valueOf(authModule.getId()),node);
        }
        return BaseResult.successWithData(DynamicMenuTreeRecursion.getTreeNodeJson("0",TreeNodes));
    }

    /**
     * 获取右侧菜单模块树
     */

    @ApiOperation(value = "获取PC菜单模块树数据", notes = "获取PC菜单模块树数据")
    @ApiImplicitParam(name = "roleid", value = "角色id", dataType = "int", paramType = "path")
    @GetMapping("/getTreeModuleData/{roleid}")
    @LoginUser
    @SystemLog(description = "获取PC菜单模块树数据")
    public BaseResult getTreeModuleData(cn.yq.common.vo.AuthUser authUser, @PathVariable("roleid") int roleid){
        //根据角色id 获取该角色的菜单树数据
        List roleids = new ArrayList();
            roleids.add(roleid);
        //获取菜单与模块数据
        int orgid = authUser.getOrganizationId();
        List<AuthModulePrivilegeVo> list = new ArrayList<>();
        if(orgid==12){
            //如果当前组织是盛元
           list = authModuleService.getTreeModuleDataShengyuan(roleids,2);
        }else{
            list= authModuleService.getTreeModuleDataByRoleids(orgid,roleids,2);
        }
        //存储树结构
        Map<String,DynamicMenuTreeNode> TreeNodes = new LinkedHashMap();
        for(AuthModulePrivilegeVo authModule : list){
            DynamicMenuTreeNode node = new DynamicMenuTreeNode();
            node.setId(String.valueOf(authModule.getId()));
            node.setName(authModule.getName());
            node.setParentId(String.valueOf(authModule.getParentId()));
            node.setType(Integer.valueOf(authModule.getType()));
            node.setPath(authModule.getUrl());
            String component = authModule.getComponent();
            node.setComponent(component);
            node.setIconCls(authModule.getIconCls());
            //给node的value赋值
            //判断如isdel 为null  或者为true 传 false   ，否则传 true
            if(null == authModule.getIsDel() || authModule.getIsDel().equals("1")){
                node.setValue(false);
            }
            else{
                node.setValue(true);
            }
            TreeNodes.put(String.valueOf(authModule.getId()),node);
        }
        return BaseResult.successWithData(DynamicMenuTreeRecursion.getTreeNodeJson("0",TreeNodes));
    }

    @ApiOperation(value = "根据角色id授权", notes = "根据角色id授权")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId", value = "roleId", dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "category", value = "category", dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "auth", value = "auth", allowMultiple = true, dataType = "int", paramType = "path")
    })
    @PostMapping("/authorizeByRoleid/{roleId}/{category}/{auth}")
    @LoginUser
    @SystemLog(description = "根据角色id授权")
    public BaseResult authorizeByRoleid(@PathVariable("roleId") int roleId,@PathVariable("category")int category,@PathVariable("auth") int[] auth){
        authModuleService.authorizeByRoleid(roleId,category,auth);
        return BaseResult.successWithData("操作成功!");
    }
    @ApiOperation(value = "查找用户角色对应权限的code",notes = "查找用户角色对应权限的code")
    @GetMapping("/selectPrivilegeCode")
    @LoginUser
    @SystemLog(description = "查找用户角色对应权限的code")
    public BaseResult selectPrivilegeCode(AuthUser authUser){

        String username = authUser.getUsername();
        log.debug("username=>{}",username);
        //数据来源修改
//        List<AuthModule> list =authModuleService.getTreeData(username,"getTreeData");
        //获取当前用户的角色列表
//        List<AuthRole> roleList = authUserService.getRolesByUsername(username);
        List<AuthRole> roleList = authUserService.getRolesByUserid2(authUser.getId());
                //根据角色id 获取该角色的菜单树数据
        List roleids = new ArrayList();
        for(AuthRole role:roleList){
            roleids.add(role.getId());
        }
        List listCodes=authModuleService.selectPrivilegeCode(roleids);
        listCodes.removeAll(Collections.singleton(null));
        listCodes.removeAll(Collections.singleton(""));
        return BaseResult.successWithData(listCodes);

    }



    /**
     * 获取APP树状菜单
     */

    @ApiOperation(value = "获取APP菜单模块树数据", notes = "获取APP菜单模块树数据")
    @ApiImplicitParam(name = "roleid", value = "角色id", dataType = "int", paramType = "path")
    @GetMapping("/getAPPTreeModuleData/{roleid}")
    @LoginUser
    @SystemLog(description = "获取APP菜单模块树数据")
    public BaseResult getAPPTreeModuleData(@ApiIgnore cn.yq.common.vo.AuthUser authUser, @PathVariable("roleid") int roleid){
        //根据角色id 获取该角色的菜单树数据
        List roleids = new ArrayList();
        roleids.add(roleid);
        //获取菜单与模块数据
        int orgid = authUser.getOrganizationId();
        List<AuthModulePrivilegeVo> list = new ArrayList<>();
        if(orgid==12){
            //如果当前组织是盛元
            list = authModuleService.getTreeModuleDataShengyuan(roleids,1);
        }else{
            list= authModuleService.getTreeModuleDataByRoleids(orgid,roleids,1);
        }
        //存储树结构
        Map<String,DynamicMenuTreeNode> TreeNodes = new HashMap();
        for(AuthModulePrivilegeVo authModule : list){
            DynamicMenuTreeNode node = new DynamicMenuTreeNode();
            node.setId(String.valueOf(authModule.getId()));
            node.setName(authModule.getName());
            node.setParentId(String.valueOf(authModule.getParentId()));
            node.setType(Integer.valueOf(authModule.getType()));
            node.setPath(authModule.getUrl());
            String component = authModule.getComponent();
            node.setComponent(component);
            node.setIconCls(authModule.getIconCls());
            //给node的value赋值
            //判断如isdel 为null  或者为true 传 false   ，否则传 true
            if(null == authModule.getIsDel() || authModule.getIsDel().equals("1")){
                node.setValue(false);
            }
            else{
                node.setValue(true);
            }
            TreeNodes.put(String.valueOf(authModule.getId()),node);
        }
        return BaseResult.successWithData(DynamicMenuTreeRecursion.getTreeNodeJson("0",TreeNodes));
    }

    /**
     * 获取动态菜单树数据
     * @return
     */
    @ApiOperation(value = "获取APP菜单树数据", notes = "获取APP菜单树数据")
    @GetMapping("/getAPPTreeData")
    @LoginUser
    @SystemLog(description = "获取APP菜单树数据")
    public BaseResult getAPPTreeData(@ApiIgnore AuthUser authUser){
        Integer userId = authUser.getId();
        //获取当前用户下的角色id列表
        List roleList =authUserService.getRolesByUserid(userId);

        List<AuthModulePrivilegeVo> list = authModuleService.getTreeDataByRoleids(roleList,1);
        //存储树结构
        Map<String, DynamicMenuTreeNode> TreeNodes = new LinkedHashMap<>();
        for(AuthModulePrivilegeVo authModule : list){
            DynamicMenuTreeNode node = new DynamicMenuTreeNode();
            node.setId(String.valueOf(authModule.getId()));
            node.setName(authModule.getName());
            node.setParentId(String.valueOf(authModule.getParentId()));
            node.setType(Integer.valueOf(authModule.getType()));
            node.setPath(authModule.getUrl());
            String component = authModule.getComponent();
            node.setComponent(component);
            node.setIconCls(authModule.getIconCls());
            TreeNodes.put(String.valueOf(authModule.getId()),node);
        }
        return BaseResult.successWithData(DynamicMenuTreeRecursion.getTreeNodeJson("0",TreeNodes));
    }

    @ApiOperation(value = "查找APP用户角色对应权限的code",notes = "查找APP用户角色对应权限的code")
    @GetMapping("/selectPrivilegeAPPCode")
    @LoginUser
    @SystemLog(description = "查找APP用户角色对应权限的code")
    public BaseResult selectPrivilegeAPPCode(@ApiIgnore AuthUser authUser){

        Integer userId = authUser.getId();
        //获取当前用户下的角色id列表
        List roleList =authUserService.getRoleByUserid(userId);
        if(roleList.size() >0){
            List listCodes=authModuleService.selectPrivilegeAPPCode(roleList,1);
            listCodes.removeAll(Collections.singleton(null));
            listCodes.removeAll(Collections.singleton(""));
            return BaseResult.successWithData(listCodes);
        }
        return BaseResult.success();
    }
}
