package cn.yq.sysapi.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.model.AuthProject;
import cn.yq.sysapi.service.ProjectService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(value = "项目管理", description = "项目操作 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/project")
public class ProjectController {
    @Autowired
    private ProjectService projectService;

    @ApiOperation(
            value = "项目列表",
            notes = "完整的项目内容列表",
            produces = "application/json",
            consumes = "application/json",
            response = BaseResult.class)
    @RequestMapping(value = "/", method = RequestMethod.GET)
    @SystemLog(description = "项目列表")
    public BaseResult<PageInfo<List<AuthProject>>> getListByPage() {
        return BaseResult.successWithData(new PageInfo(projectService.getListByPage(1, 10)));
    }

    @RequestMapping(value = "/", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public int add(@RequestBody AuthProject project) {
        return projectService.add(project);
    }
}
