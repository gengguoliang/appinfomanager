package cn.yq.sysapi.vo;

import lombok.Data;

/**
 * @author: YQ-DGZ
 * @date: 2019/4/29 13:38
 * @description: TODO
 */
@Data
public class UserAppParam {

    private Integer id;

    private String username;

    //验证码
    private String verificationCode;

    //新手机号
    private String mobile;

    private String currentPassword;

    private String newPassword;


}
