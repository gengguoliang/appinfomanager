package cn.yq.sysapi.service.impl;

import cn.yq.common.utils.BCryptUtil;
import cn.yq.sysapi.dao.AuthUserCusMapper;
import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.dao.AuthUserRoleMapper;
import cn.yq.sysapi.dto.organization.AddRoleDTO;
import cn.yq.sysapi.dto.organization.AddUserDTO;
import cn.yq.sysapi.dto.organization.UserShowDTO;
import cn.yq.sysapi.model.*;
import cn.yq.sysapi.service.UserService;
import cn.yq.sysapi.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @program: smart-zone
 * @description: 园区用户管理
 * @author: zhengjianhui
 **/
@Slf4j
@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Resource
    private AuthUserMapper authUserMapper;
    @Resource
    private AuthUserCusMapper authUserCusMapper;
    @Resource
    private AuthUserRoleMapper authUserRoleMapper;

    /**
     * @Description 部门回显需要的List, authUser 需要用户ID，和用户的部门ID
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<Integer> getDeptIds(cn.yq.common.vo.AuthUser authUser) {
        //部门处理
        List<Integer> deptIds = new ArrayList<>();
        List<UserDepartment> depts = authUserCusMapper.getDept(authUser.getId());
        if (depts != null && depts.size() > 0) {
            if (authUser.getDepartmentId() != null && authUser.getDepartmentId() != 0) {
                deptIds.add(authUser.getDepartmentId());
                this.getDeptParentId(deptIds, depts);
                //调换首尾
                this.revert(deptIds);
            }
        }
        return deptIds;
    }

    /**
     * @param authUser
     * @Description 部门回显需要的List  2
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<Integer> getDeptIds2(cn.yq.common.vo.AuthUser authUser) {
        if (authUser.getDepartmentId() == null || authUser.getDepartmentId() == 0) {
            return null;
        }
        String s = authUserCusMapper.getDeptIds2(authUser.getDepartmentId());
        String[] split = StringUtils.split(s, ",");
        List<Integer> depts = new ArrayList<>();
        for (String d : split) {
            depts.add(Integer.parseInt(d));
        }
        return depts;
    }

    /**
     * @param authUser
     * @Description 当前用户组织的所有角色
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<AuthRole> getRoleByUserId(cn.yq.common.vo.AuthUser authUser) {
        List<AuthRole> rolesByUser = authUserCusMapper.getRolesByUser(authUser.getId());
        return rolesByUser;
    }

    /**
     * @param addUserDTO
     * @Description PC添加和编辑用户
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void addUser(AddUserDTO addUserDTO) {
        AuthUser authUser = new AuthUser();
        BeanUtils.copyProperties(addUserDTO, authUser);
        //密码加密
        if (addUserDTO.getId() == null) {
            String encode = BCryptUtil.encode(addUserDTO.getPassword());
            authUser.setPassword(encode);
        }
        if (addUserDTO.getId() == null) {
            //插入用户表
            authUser.setProjectId(1);
            authUser.setIsSystem(false);
            authUser.setIsAdmin(false);
            authUser.setAuditedStatus((byte) 1);//审核状态 1：已通过
            authUser.setUsername(addUserDTO.getUserName());
            authUserMapper.insertSelective(authUser);

            //入库生活圈个人资料表
            TimelineProfileVO profileVO = new TimelineProfileVO();
            profileVO.setUserId(authUser.getId());
            profileVO.setNickname(authUser.getUsername());
            profileVO.setHeadImgUrl("http://kodo.smart-zone.51yuqian.net/FtOSnvyPUfIYhpFi_xhR2HXlBCXS");
            profileVO.setCoverImgUrl("http://kodo.smart-zone.51yuqian.net/Fg7COFW3QdRQ0Tgy7Me08S5LVV30?attname=微信图片_20190517175252.png");
            profileVO.setSlogon("此人很懒，没有留下任何信息");
            profileVO.setStatus(0);//状态0：正常，1：禁用，2：封号
            authUserCusMapper.insertProfileVO(profileVO);
        } else {
            //修改用户表
            authUserMapper.updateByPrimaryKeySelective(authUser);
            //删除关系表中对应的角色数据
            AuthUserRoleCriteria example = new AuthUserRoleCriteria();
            AuthUserRoleCriteria.Criteria criteria = example.createCriteria();
            criteria.andUserIdEqualTo(addUserDTO.getId());
            AuthUserRole authUserRole1 = new AuthUserRole();
            authUserRole1.setIsDel(true);
            authUserRoleMapper.updateByExampleSelective(authUserRole1, example);
        }
        //插入用户角色关系表
        for (Integer roleId : addUserDTO.getRoleIds()) {
            AuthUserRole authUserRole = new AuthUserRole();
            authUserRole.setUserId(authUser.getId());
            authUserRole.setRoleId(roleId);
            authUserRoleMapper.insertSelective(authUserRole);
        }

    }

    /**
     * @param userShowDTO
     * @Description PC列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<UserShowVO> showPage(cn.yq.common.vo.AuthUser authUser, UserShowDTO userShowDTO) {
        List<UserShowVO> userShowVOS = authUserCusMapper.showUserShowVOs(authUser.getOrganizationId(), authUser.getId(), userShowDTO);
        return userShowVOS;
    }

    /**
     * @param id
     * @param auditedStatus
     * @Description PC端审核
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void changeAuditedStatus(Integer id, Integer auditedStatus, String remark) {
        AuthUser authUser = new AuthUser();
        authUser.setId(id);
        authUser.setAuditedRemark(remark);
        authUser.setAuditedStatus((byte) auditedStatus.intValue());
        authUserMapper.updateByPrimaryKeySelective(authUser);

    }

    /**
     * @param id
     * @param isLocked
     * @Description PC冻结
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void changeIsLocked(Integer id, Integer isLocked) {
        AuthUser authUser = new AuthUser();
        authUser.setId(id);
        authUser.setIsLocked(isLocked == 0 ? false : true);
        authUserMapper.updateByPrimaryKeySelective(authUser);
    }

    /**
     * @param id
     * @Description PC删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void remove(Integer id) {
        //删除用户表
        AuthUser authUser = new AuthUser();
        authUser.setId(id);
        authUser.setIsDel(true);
        authUserMapper.updateByPrimaryKeySelective(authUser);
        //删除用户角色关系表
        AuthUserRoleCriteria userRoleCriteria = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria = userRoleCriteria.createCriteria();
        criteria.andUserIdEqualTo(id);
        AuthUserRole authUserRole = new AuthUserRole();
        authUserRole.setIsDel(true);
        authUserRoleMapper.updateByExampleSelective(authUserRole, userRoleCriteria);
    }

    /**
     * @param id
     * @Description PC详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public UserDetailVO detail(Integer id) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(id);
        UserDetailVO userDetailVO = authUserCusMapper.detail(id);
        //部门处理
        cn.yq.common.vo.AuthUser authUser1 = new cn.yq.common.vo.AuthUser();
        BeanUtils.copyProperties(authUser, authUser1);
        List<Integer> deptIds = this.getDeptIds2(authUser1);
        userDetailVO.setDepartmentIds(deptIds);
        return userDetailVO;
    }

    /**
     * @param authUser
     * @Description PC端添加时的信息展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public AddUserShowVO addUserShow(cn.yq.common.vo.AuthUser authUser) {
        AddUserShowVO addUserShowVO = authUserCusMapper.getAddUserShowVO(authUser.getId());
        List<Integer> roleIds = authUserCusMapper.getRoleIds(authUser.getId());
        if (!ObjectUtils.isEmpty(roleIds)) {
            addUserShowVO.setRoleIds(roleIds);
        }
        //部门处理
        List<Integer> deptIds = this.getDeptIds2(authUser);
        addUserShowVO.setDepartmentIds(deptIds);
        return addUserShowVO;
    }

    /**
     * @param addRoleDTO
     * @Description PC给用户添加角色
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public void addUserRole(AddRoleDTO addRoleDTO) {
        //删除用户角色关系表数据
        AuthUserRoleCriteria roleCriteria = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria = roleCriteria.createCriteria();
        criteria.andUserIdEqualTo(addRoleDTO.getId());
        AuthUserRole authUserRole = new AuthUserRole();
        authUserRole.setIsDel(true);
        authUserRoleMapper.updateByExampleSelective(authUserRole, roleCriteria);
        //插入数据
        for (Integer roleId : addRoleDTO.getRoleIds()) {
            AuthUserRole authUserRole1 = new AuthUserRole();
            authUserRole1.setUserId(addRoleDTO.getId());
            authUserRole1.setRoleId(roleId);
            authUserRoleMapper.insertSelective(authUserRole1);
        }
    }

    private void revert(List<Integer> ids) {
        for (int i = 0; i < (int) Math.ceil((ids.size() * 1.0) / 2); i++) {
            int t;
            t = ids.get(i);
            ids.set(i, ids.get(ids.size() - 1 - i));
            ids.set(ids.size() - 1 - i, t);
        }
    }

    /**
     * @Description 递归查询父ID
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    private void getDeptParentId(List<Integer> deptIds, List<UserDepartment> rootList) {
        log.debug("deptIds===============>" + deptIds);
        log.debug("rootList==============>" + rootList);
        for (UserDepartment userDepartment : rootList) {
            if (userDepartment.getId() == deptIds.get(deptIds.size() - 1) &&
                    userDepartment.getParentId() == 0) {
                return;
            }
        }
        for (UserDepartment userDepartment : rootList) {
            if (userDepartment.getId() == deptIds.get(deptIds.size() - 1)) {
                deptIds.add(userDepartment.getParentId());
                break;
            }
        }
        this.getDeptParentId(deptIds, rootList);
    }
}
