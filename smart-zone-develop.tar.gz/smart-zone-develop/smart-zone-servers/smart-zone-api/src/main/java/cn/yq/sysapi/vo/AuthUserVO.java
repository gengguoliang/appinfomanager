package cn.yq.sysapi.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

@ApiModel(value = "用户信息")
public class AuthUserVO implements Serializable {
    private static final long serialVersionUID = 9220076190821350465L;

    @ApiModelProperty(value = "ID", position = 0, example = "1")
    private Integer id;

    @ApiModelProperty(value = "项目ID", position = 1, example = "1")
    private Integer projectId;

    @ApiModelProperty(value = "部门ID", position = 2, example = "1")
    private Integer departmentId;

    @ApiModelProperty(value = "用户名", position = 3, example = "liubei")
    private String username;

    @ApiModelProperty(value = "姓名", position = 4, example = "刘备")
    private String name;

    @ApiModelProperty(value = "性别，true：男，false：女", position = 5)
    private Boolean gender;

    @ApiModelProperty(value = "手机号", position = 6, example = "158****7857")
    private String mobile;

    @ApiModelProperty(value = "是否锁定", position = 7)
    private Boolean isLocked;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    private String roles;

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    private String orgname;

    private Integer type;

    private String departmentName;

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Boolean getGender() {
        return gender;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public Boolean getIsLocked() {
        return isLocked;
    }

    public void setIsLocked(Boolean isLocked) {
        this.isLocked = isLocked;
    }

    @Override
    public String toString() {
        return "AuthUserVO{" +
                "id=" + id +
                ", projectId=" + projectId +
                ", departmentId=" + departmentId +
                ", username='" + username + '\'' +
                ", name='" + name + '\'' +
                ", gender=" + gender +
                ", mobile='" + mobile + '\'' +
                ", isLocked=" + isLocked +
                '}';
    }

}