package cn.yq.sysapi.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.BCryptUtil;
import cn.yq.sysapi.common.Constant.GlobalConstant;
import cn.yq.sysapi.common.tools.Tools;
import cn.yq.sysapi.dao.*;
import cn.yq.sysapi.dto.organization.*;
import cn.yq.sysapi.model.*;
import cn.yq.sysapi.service.IAuthOrganizationService;
import cn.yq.sysapi.vo.AuthOrgVo;
import cn.yq.sysapi.vo.UnitVo;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AuthOrganizationServiceImpl implements IAuthOrganizationService {
    @Autowired
    private AuthUserMapper authUserMapper;
    @Autowired
    private AuthUserCusMapper authUserCusMapper;
    @Autowired
    private AuthUserRoleMapper authUserRoleMapper;
    @Autowired
    private AuthOrganizationMapper authOrganizationMapper;
    @Autowired
    private AuthOrganizationCusMapper authOrganizationCusMapper;

    @Override
    @Transactional
    public Result addAuthOrg(AddAuthOrganizationDto authOrganizationDto) {
        Result result1 = validataParam(authOrganizationDto);
        if (!ObjectUtils.isEmpty(result1)) {
            return result1;
        }
        AuthOrganization authOrganization = new AuthOrganization();
        BeanUtils.copyProperties(authOrganizationDto, authOrganization);
        authOrganization.setCertifyType(GlobalConstant.CERTIFY_TYPE_CODE);

        int result = authOrganizationCusMapper.insertRtnKey(authOrganization);
        if (result > 0) {
            // 保存企业和承租单元的关系
            Result rtnUnit = createOrgAndUnitRelation(authOrganization.getId(), authOrganizationDto.getUnitIds());
            // 默认给该组织下生成一个超管
            Result rtn = createUserForOrg(authOrganization, authOrganizationDto);
            if (ObjectUtils.isEmpty(rtn)) {
                return new Result(ResultEnum.FAIL.getCode(), "生成超管失败!");
            }
            return Result.returnOk();
        }
        return Result.returnFail();
    }

    private Result createOrgAndUnitRelation(Integer orgId, List<Integer> unitIds) {
        AuditedOrgDto auditedOrgDto = new AuditedOrgDto();
        auditedOrgDto.setAudited(true);
        auditedOrgDto.setOrgId(orgId);
        auditedOrgDto.setUnitIds(unitIds);
        insertOrgAdnUnit(auditedOrgDto);
        return Result.returnOk();
    }

    // 默认给该组织下生成一个超管
    private Result createUserForOrg(AuthOrganization authOrganization, AddAuthOrganizationDto addAuthOrganizationDto) {
        AuthUser authUser = new AuthUser();
        authUser.setIsLocked(false);
        authUser.setMobile(addAuthOrganizationDto.getMobile());
        authUser.setOrganizationId(authOrganization.getId());
        authUser.setIsAdmin(true);
        authUser.setIsDel(false);
        authUser.setName(authOrganization.getName() + "超级管理员");
        authUser.setGender(true);
        authUser.setPassword(BCryptUtil.encode(addAuthOrganizationDto.getPassword()));
        authUser.setUsername(addAuthOrganizationDto.getUsername());
        authUser.setAuditedStatus((byte) 1);
        authUser.setIsLocked(false);
        authUser.setDepartmentId(0);
        authUser.setProjectId(0);
        authUser.setCreateTime(new Date());
        authUser.setLastUpdateTime(new Date());
        List<Integer> roleIds = addAuthOrganizationDto.getRoleIds();
        if (authOrganization.getType().equals(GlobalConstant.ORG_RENT_PERSION)) {
            authUser.setCertifyType(GlobalConstant.USER_CERTIFY_TYPE_IDENT);
            authUser.setCertifyNum(addAuthOrganizationDto.getCertifyNum());
        }
        int insert = authUserCusMapper.insert(authUser);
        if (insert > 0) {
            AddRolesForUserDto addRole = new AddRolesForUserDto();
            addRole.setUserId(authUser.getId());
            addRole.setRoleIds(addAuthOrganizationDto.getRoleIds());
            authUserCusMapper.addRolesForUser(addRole);
            return Result.returnOk();
        }
        return null;
    }

    @Override
    public Result updateAuthOrg(UpdateAuthOrganizationDto authOrganizationDto) {
        if (ObjectUtils.isEmpty(authOrganizationDto.getId())) {
            return new Result(ResultEnum.FAIL.getCode(), "id不能为空!");
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getCertifyNum())) {
            return new Result(ResultEnum.FAIL.getCode(), "证件号码不能为空!");
        }
        if (authOrganizationDto.getCertifyNum().length() > 32) {
            return new Result(ResultEnum.FAIL.getCode(), "证件号码不能超过32位!");
        }
        if (!ObjectUtils.isEmpty(authOrganizationDto.getRemark()) && authOrganizationDto.getRemark().length() > 250) {
            return new Result(ResultEnum.FAIL.getCode(), "备注文字长度不能超过256!");
        }
        AuthOrganization authOrganization = new AuthOrganization();
        BeanUtils.copyProperties(authOrganizationDto, authOrganization);
        int result = authOrganizationMapper.updateByPrimaryKeySelective(authOrganization);
        if (result > 0) {
            return Result.returnOk();
        }
        return new Result(ResultEnum.FAIL.getCode(), "无数据更新!");
    }

    @Override
    @Transactional
    public Result forbidden(Integer id) {
        AuthOrganization org = new AuthOrganization();
        org.setId(id);
        org.setStatus(GlobalConstant.FORBIDDEN);//禁用
        int i = authOrganizationMapper.updateByPrimaryKeySelective(org);
        if (i > 0) {
            authUserCusMapper.forbiddenOrgUser(id);
            return Result.returnOk();
        }
        return Result.returnFail();
    }

    @Override
    @Transactional
    public Result delAuthOrg(Integer id) {
        AuthOrganization org = new AuthOrganization();
        org.setId(id);
        org.setIsDel(true);
        int i = authOrganizationMapper.updateByPrimaryKeySelective(org);
        if (i > 0) {
            authUserCusMapper.delOrgUserByOrgId(id);
            return Result.returnOk();
        }
        return Result.returnFail();
    }

    @Override
    public Result query(GetInfoAuthOrgDto query) {
        if (!ObjectUtils.isEmpty(query.getEndTime())) {
            query.setEndTime(DateUtil.date(query.getEndTime()));
        }
        if (!ObjectUtils.isEmpty(query.getStartTime())) {
            query.setStartTime(DateUtil.date(query.getStartTime()));
        }

        Integer pageNum = ObjectUtils.isEmpty(query.getPageNum()) ? 0 : query.getPageNum();

        Integer nowPage = pageNum;

        query.setPageSize(ObjectUtils.isEmpty(query.getPageSize()) ? 10 : query.getPageSize());
        query.setPageNum(0 == pageNum ? 0 : (pageNum - 1) * query.getPageSize());

        Map<String, Object> data = new HashMap<>();

        List<AuthOrgVo> results = authOrganizationCusMapper.query(query);
        if (!ObjectUtils.isEmpty(results)) {
            results.stream().forEach(
                    e -> e.setStatusName(
                            null != e.getStatus() && e.getStatus() == 0 ? "禁用" : null != e.getStatus() && e.getStatus() == 1 ? "启用" : "")
            );
        }

        // 查询总条数
        Integer total = authOrganizationCusMapper.queryTotal(query);

        data.put("total", total);
        data.put("pageNum", nowPage);
        data.put("data", results);

        return Result.returnOk(data);
    }

    @Override
    public Result frozen(Integer orgId) {
        AuthOrganization org = new AuthOrganization();
        org.setId(orgId);
        org.setStatus(GlobalConstant.FROZEN);
        int i = authOrganizationMapper.updateByPrimaryKeySelective(org);
        if (i > 0) {
            return Result.returnOk();
        }
        return Result.returnFail();
    }

    @Override
    public Result addRoleForOrg(AddRoleForOrgDto addRole) {
        if (ObjectUtils.isEmpty(addRole.getOrgId())) {
            return new Result(ResultEnum.FAIL.getCode(), "组织(企业)id不能为空!");
        }
        if (ObjectUtils.isEmpty(addRole.getRoleIds())) {
            return new Result(ResultEnum.FAIL.getCode(), "角色不能为空!");
        }
        // 查询该组织下的超管
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andOrganizationIdEqualTo(addRole.getOrgId()).
                andIsAdminEqualTo(true).
                andIsDelEqualTo(false);

        List<AuthUser> authUsers = authUserMapper.selectByExample(example);
        if (!ObjectUtils.isEmpty(authUsers)) {
            return new Result(ResultEnum.FAIL.getCode(), "查询组织超管为空!");
        }
        AuthUser authUser = authUsers.get(0);
        AddRolesForUserDto addRolesDto = new AddRolesForUserDto();
        addRolesDto.setUserId(authUser.getId());
        addRolesDto.setRoleIds(addRole.getRoleIds());
        authUserCusMapper.addRolesForUser(addRolesDto);
        return Result.returnOk();
    }

    @Override
    public Result getOrgRoles(Integer orgId) {
        // 获取组织对应的超管
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andOrganizationIdEqualTo(orgId).
                andIsAdminEqualTo(true).
                andIsDelEqualTo(false);
        List<AuthUser> authUsers = authUserMapper.selectByExample(example);
        if (ObjectUtils.isEmpty(authUsers)) {
            return new Result(ResultEnum.FAIL.getCode(), "查询组织对应的超管为空!");
        }
        AuthUser authUser = authUsers.get(0);
        AuthUserRoleCriteria userRoleExample = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteriaRole = userRoleExample.createCriteria();
        criteriaRole.andUserIdEqualTo(authUser.getId()).andIsDelEqualTo(false);

        List<AuthUserRole> authUserRoles = authUserRoleMapper.selectByExample(userRoleExample);
        return Result.returnOk(authUserRoles);
    }

    @Override
    public Result getUsersByOrg(Integer orgId) {
        if (ObjectUtils.isEmpty(orgId)) {
            return new Result(ResultEnum.FAIL.getCode(), "组织id不能为空!");
        }
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andOrganizationIdEqualTo(orgId).andIsDelEqualTo(false);
        List<AuthUser> authUsers = authUserMapper.selectByExample(example);
        return Result.returnOk(authUsers);
    }

    @Override
    public Result getOrgByAudited(int auditedType) {
        // 查询全部
        if (auditedType == 1) {
            return getAllOrgForAudited();
        }
        // 查询待审核
        if (auditedType == 2) {
            return getToBeAudited();
        }
        // 查询审核通过
        if (auditedType == 3) {
            return getPassAudited();
        }
        // 查询审核未通过
        if (auditedType == 4) {
            return getFailedAudited();
        }
        return new Result(ResultEnum.FAIL.getCode(), "未知的查询类型!");
    }

    @Override
    public Result audited(AuditedOrgDto auditedOrgDto) {
        if (ObjectUtils.isEmpty(auditedOrgDto.getOrgId())) {
            return new Result(ResultEnum.FAIL.getCode(), "组织id不能为空");
        }
        if (ObjectUtils.isEmpty(auditedOrgDto.getUnitIds())) {
            return new Result(ResultEnum.FAIL.getCode(), "单元id不能为空");
        }
        AuthOrganization org = new AuthOrganization();
        org.setId(auditedOrgDto.getOrgId());
        // 审核通过
        if (auditedOrgDto.isAudited()) {
            org.setAuditedStatus(GlobalConstant.PASS_AUDITED);
            int i = authOrganizationMapper.updateByPrimaryKeySelective(org);
            if (i > 0) {
                // 插入承组单元和组织中间表
                insertOrgAdnUnit(auditedOrgDto);
                return Result.returnOk("审核通过");
            }
            return Result.returnOk("无数据被审核");
        }
        org.setAuditedStatus(GlobalConstant.FAILED_AUDITED);
        int i = authOrganizationMapper.updateByPrimaryKeySelective(org);
        if (i > 0) {
            return Result.returnOk("已修改该组织为审核不通过");
        }
        return new Result(ResultEnum.FAIL.getCode(), "参数不正确!");
    }

    private void insertOrgAdnUnit(AuditedOrgDto auditedOrgDto) {
        authOrganizationCusMapper.insertOrgAdnUnit(auditedOrgDto);
    }


    @Override
    public Result getOrgById(Integer orgId) {
        if (ObjectUtils.isEmpty(orgId)) {
            return new Result(ResultEnum.FAIL.getCode(), "组织id不能为空!");
        }
        AuthOrgVo orgInfo = authOrganizationCusMapper.getOrgById(orgId);
        return Result.returnOk(orgInfo);
    }

    @Override
    public AuthOrganization getCertifyNum(Integer userId) {
        AuthUser authUser = authUserMapper.selectByPrimaryKey(userId);
        AuthOrganization authOrganization = authOrganizationMapper.selectByPrimaryKey(authUser.getOrganizationId());
        return authOrganization;
    }

    @Override
    public Result queryUnit(String unitName) {
        // List<UnitVo> units = authOrganizationCusMapper.queryUnit(unitName);
        return null;
    }

    private Result getFailedAudited() {
        AuthOrganizationCriteria ex = new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria = ex.createCriteria();
        criteria.andFromTypeEqualTo(GlobalConstant.UADD_METHOD_APP).
                andIsDelEqualTo(false).andAuditedStatusEqualTo(GlobalConstant.FAILED_AUDITED);
        List<AuthOrganization> authOrganizations = authOrganizationMapper.selectByExample(ex);
        return Result.returnOk(authOrganizations);
    }

    private Result getPassAudited() {
        AuthOrganizationCriteria ex = new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria = ex.createCriteria();
        criteria.andFromTypeEqualTo(GlobalConstant.UADD_METHOD_APP).
                andIsDelEqualTo(false).andAuditedStatusEqualTo(GlobalConstant.PASS_AUDITED);
        List<AuthOrganization> authOrganizations = authOrganizationMapper.selectByExample(ex);
        return Result.returnOk(authOrganizations);
    }

    private Result getToBeAudited() {
        AuthOrganizationCriteria ex = new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria = ex.createCriteria();
        criteria.andFromTypeEqualTo(GlobalConstant.UADD_METHOD_APP).
                andIsDelEqualTo(false).andAuditedStatusEqualTo(GlobalConstant.TO_BE_AUDITED);
        List<AuthOrganization> authOrganizations = authOrganizationMapper.selectByExample(ex);
        return Result.returnOk(authOrganizations);
    }

    private Result getAllOrgForAudited() {
        AuthOrganizationCriteria ex = new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria = ex.createCriteria();
        criteria.andFromTypeEqualTo(GlobalConstant.UADD_METHOD_APP).
                andIsDelEqualTo(false);
        List<AuthOrganization> authOrganizations = authOrganizationMapper.selectByExample(ex);
        return Result.returnOk(authOrganizations);
    }

    private Result validataParam(AddAuthOrganizationDto authOrganizationDto) {
        if (ObjectUtils.isEmpty(authOrganizationDto.getCertifyNum())) {
            return new Result(ResultEnum.FAIL.getCode(), "证件号码不能为空!");
        }
        if (authOrganizationDto.getCertifyNum().length() > 32) {
            return new Result(ResultEnum.FAIL.getCode(), "证件号码长度不能超过32!");
        }
        /*if (ObjectUtils.isEmpty(authOrganizationDto.getCertifyType())) {
            return new Result(ResultEnum.FAIL.getCode(), "证件类型不能为空!");
        }*/
        if (ObjectUtils.isEmpty(authOrganizationDto.getAddress())) {
            return new Result(ResultEnum.FAIL.getCode(), "地址不能为空!");
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getName())) {
            return new Result(ResultEnum.FAIL.getCode(), "名称不能为空!");
        }
        if (authOrganizationDto.getName().length() > 32) {
            return new Result(ResultEnum.FAIL.getCode(), "name不能超过32!");
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getStatus())) {
            return new Result(ResultEnum.FAIL.getCode(), "状态不能为空!");
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getType())) {
            return new Result(ResultEnum.FAIL.getCode(), "类型不能为空!");
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getUsername())) {
            return new Result(ResultEnum.FAIL.getCode(), "超管用户名不能为空!");
        }
        if (authOrganizationDto.getUsername().length() > 50) {
            return new Result(ResultEnum.FAIL.getCode(), "用户名不能超过50!");
        }
        Result result = Tools.userNameUseable(authOrganizationDto.getUsername());
        if (result.getCode().equals(ResultEnum.FAIL.getCode())) {
            return result;
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getPassword())) {
            return new Result(ResultEnum.FAIL.getCode(), "超管密码不能为空!");
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getMobile())) {
            return new Result(ResultEnum.FAIL.getCode(), "手机号不能为空!");
        }
        Result isPhone = Tools.isPhone(authOrganizationDto.getMobile());
        if (isPhone.getCode().equals(ResultEnum.FAIL.getCode())) {
            return isPhone;
        }
        if (ObjectUtils.isEmpty(authOrganizationDto.getAddMethod())) {
            return new Result(ResultEnum.FAIL.getCode(), "添加方式不能为空!");
        }
        return null;
    }

    @Override
    public Result isExistCode(Integer userId,String code) {
        Map map = new HashMap();
        AuthOrganizationCriteria ex = new AuthOrganizationCriteria();
        AuthOrganizationCriteria.Criteria criteria = ex.createCriteria();
        criteria.andCodeEqualTo(code)
                .andIsDelEqualTo(false);
        List<AuthOrganization> orgList = authOrganizationMapper.selectByExample(ex);
        AuthUser authUser = authUserMapper.selectByPrimaryKey(userId);
        if(StringUtils.isNotBlank(authUser.getName())) {
            return new Result(ResultEnum.FAIL.getCode(), "请先进行实名认证");
        }
        if(null != orgList && orgList.size() > 0) {
            map.put("flag",true);
            map.put("orgName",orgList.get(0).getName());
            map.put("orgId",orgList.get(0).getId());
            map.put("authUser",authUser);
        }else{
            map.put("flag",false);
        }
        return Result.returnOk(map);
    }
}
