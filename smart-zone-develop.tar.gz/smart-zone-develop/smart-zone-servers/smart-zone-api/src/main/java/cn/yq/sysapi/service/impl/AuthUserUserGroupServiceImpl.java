package cn.yq.sysapi.service.impl;

import cn.yq.sysapi.dao.AuthUserMapper;
import cn.yq.sysapi.dao.AuthUserUserGroupMapper;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.model.AuthUserCriteria;
import cn.yq.sysapi.model.AuthUserUserGroup;
import cn.yq.sysapi.model.AuthUserUserGroupCriteria;
import cn.yq.sysapi.service.AuthUserUserGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class AuthUserUserGroupServiceImpl implements AuthUserUserGroupService {

    @Autowired
    AuthUserMapper userMapper;

    @Autowired
    AuthUserUserGroupMapper userUserGroupMapper;

    /**
     * 根据用户组Id，获取用户组下用户
     * @param userGroupId
     * @return
     */
    @Override
    public List<AuthUser> getUsersByUserGroupId(int userGroupId) {
        AuthUserUserGroupCriteria example = new AuthUserUserGroupCriteria();
        AuthUserUserGroupCriteria.Criteria criteria = example.createCriteria();
        criteria.andGroupIdEqualTo(userGroupId);
        criteria.andIsDelEqualTo(false);
        //获取关联表数据
        List<AuthUserUserGroup> list = userUserGroupMapper.selectByExample(example);
        List ids = new ArrayList();
        for(AuthUserUserGroup uug:list){
            ids.add(uug.getUserId());
        }
        AuthUserCriteria example2 = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andIdIn(ids);
        //获取用户数据
        List<AuthUser> resultlist = new ArrayList<>();
        if(ids.size()>0){
            resultlist = userMapper.selectByExample(example2);
        }
        return resultlist;
    }

    @Override
    public int addUsersByUserGroupId(int userGroupId,int[] userids) {
       //循环插入记录
        int count=0;
        for(int i=0;i<userids.length;i++){
            AuthUserUserGroup uug = new AuthUserUserGroup();
            uug.setGroupId(userGroupId);
            uug.setUserId(userids[i]);
            userUserGroupMapper.insertSelective(uug);
            count++;
        }
        return count;
    }

    @Override
    public int removeUsersByUserGroupId(int userGroupId) {
        AuthUserUserGroupCriteria example = new AuthUserUserGroupCriteria();
        AuthUserUserGroupCriteria.Criteria criteria = example.createCriteria();
        criteria.andGroupIdEqualTo(userGroupId);
        AuthUserUserGroup uug = new AuthUserUserGroup();
        uug.setIsDel(true);
        int num = userUserGroupMapper.updateByExampleSelective(uug,example);
        return num;
    }

    @Override
    public int removeUserByUserGroupIdAndUserid(int userGroupId, int userId) {

        AuthUserUserGroupCriteria example = new AuthUserUserGroupCriteria();
        AuthUserUserGroupCriteria.Criteria criteria = example.createCriteria();
        criteria.andGroupIdEqualTo(userGroupId);
        criteria.andUserIdEqualTo(userId);
        AuthUserUserGroup uug = new AuthUserUserGroup();
        uug.setIsDel(true);
        int num = userUserGroupMapper.updateByExampleSelective(uug,example);
        return num;
    }

    @Override
    public List<AuthUser> getOutUsersByUserGroupId(int userGroupId) {
        AuthUserUserGroupCriteria example = new AuthUserUserGroupCriteria();
        AuthUserUserGroupCriteria.Criteria criteria = example.createCriteria();
        criteria.andGroupIdEqualTo(userGroupId);
        criteria.andIsDelEqualTo(false);
        //获取关联表数据
        List<AuthUserUserGroup> list = userUserGroupMapper.selectByExample(example);
        List ids = new ArrayList();
        for(AuthUserUserGroup uug:list){
            ids.add(uug.getUserId());
        }
        AuthUserCriteria example2 = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andIdNotIn(ids);
        //获取用户数据
        List<AuthUser> resultlist = new ArrayList<>();
        if(ids.size()>0){
            resultlist = userMapper.selectByExample(example2);
        }else{
            resultlist = userMapper.selectByExample(null);
        }
        return resultlist;
    }
}
