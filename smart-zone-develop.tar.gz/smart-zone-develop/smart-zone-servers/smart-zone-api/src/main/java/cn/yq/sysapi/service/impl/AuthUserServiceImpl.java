package cn.yq.sysapi.service.impl;

import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.BCryptUtil;
import cn.yq.common.utils.CopyUtils;
import cn.yq.sysapi.common.Constant.GlobalConstant;
import cn.yq.sysapi.common.annotation.DataFilter;
import cn.yq.sysapi.dao.*;
import cn.yq.sysapi.dto.organization.AuthUserDTO;
import cn.yq.sysapi.dto.organization.UpdatePasswordDto;
import cn.yq.sysapi.service.AuthUserService;
import cn.yq.sysapi.vo.AuthUserSearchVo;
import cn.yq.sysapi.vo.AuthUserVO;
import cn.yq.sysapi.model.*;
import com.github.pagehelper.PageHelper;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AuthUserServiceImpl implements AuthUserService {

    @Autowired
    private AuthUserMapper mapper;

    @Autowired
    private AuthUserCusMapper authUserCusMapper;

    @Autowired
    private AuthUserRoleMapper authUserRoleMapper;

    @Autowired
    private AuthRoleMapper authRoleMapper;

    @Resource
    private AuthUserRoleDeptMapper authUserRoleDeptMapper;

    @Override
    public int add(AuthUser user, int[] roleids) {
        //添加用户信息
        final String rawPassword = user.getPassword();
        user.setPassword(BCryptUtil.encode(rawPassword));
        user.setIsSystem(false);
        user.setIsAdmin(false);
        user.setAuditedStatus((byte)1);
        mapper.insertSelective(user);
        int id = user.getId();
        //添加用户角色信息
        if (roleids.length > 0) {
            for (int temp : roleids) {
                AuthUserRole authUserRole = new AuthUserRole();
                authUserRole.setUserId(id);
                authUserRole.setRoleId(temp);
                authUserRoleMapper.insertSelective(authUserRole);
            }
        }
        return id;
    }

    @Override
    public int remove(int id) {
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(id);
        return mapper.deleteByExample(example);
    }

    @Override
    public int update(AuthUser user, int[] roleids) {
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(user.getId());
        //判断密码
        if (null != user.getPassword() && !"".equals(user.getPassword())) {
            final String rawPassword = user.getPassword();
            user.setPassword(BCryptUtil.encode(rawPassword));
        }
        //修改用户信息
        mapper.updateByExampleSelective(user, example);
        //修改用户角色信息
        //根据用户id与角色id修改，如果这次有该角色，则添加，否则修改为del
        int userid = user.getId();
        //暂时先删掉，然后添加
        AuthUserRoleCriteria example2 = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andUserIdEqualTo(userid);
        authUserRoleMapper.deleteByExample(example2);

        //添加用户角色信息
        if (null != roleids) {
            if (roleids.length > 0) {
                for (int temp : roleids) {
                    AuthUserRole authUserRole = new AuthUserRole();
                    authUserRole.setUserId(userid);
                    authUserRole.setRoleId(temp);
                    authUserRoleMapper.insertSelective(authUserRole);
                }
            }
        }

        return 0;
    }

    @Override
    public List<AuthUser> query(AuthUser user) {
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        if (null != user.getUsername() && !"".equals(user.getUsername())) {
            criteria.andUsernameEqualTo(user.getUsername());
        }
        if (null != user.getProjectId() && !"".equals(user.getProjectId())) {
            criteria.andProjectIdEqualTo(user.getProjectId());
        }
        return mapper.selectByExample(example);
    }

    /**
     * 获取用户信息列表
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    //@DataFilter(tableAlias = "u", user = false)
    public List<AuthUserVO> getListByPage(int pageNum, int pageSize, HashMap map, AuthUserSearchVo authUserSearchVo,cn.yq.common.vo.AuthUser authUser) {
//        AuthUserCriteria example = new AuthUserCriteria();
//        AuthUserCriteria.Criteria criteria = example.createCriteria();
//        criteria.andIsDelEqualTo(false);
//        String username = (String) map.get("username");
//        String userName = "";
//        //获取用户所关联角色所在部门的id
//        //and (u.department_id in(5))
//        String deptids = (String) map.get("deptids");
//        ArrayList<Integer> integers = new ArrayList<>();
//        if (!"".equals(deptids) && !"10001".equals(deptids)) {
//            String[] ids = deptids.split(",");
//
//            for (String id : ids) {
//                integers.add(Integer.parseInt(id));
//            }
//            criteria.andDepartmentIdIn(integers);
//        }
//        if (!"".equals(deptids) && "10001".equals(deptids)) {
//            criteria.andUsernameEqualTo(username);
//            userName = username;
//        }
        PageHelper.startPage(pageNum, pageSize);

        List<AuthUserVO> list = authUserCusMapper.queryUserList(authUserSearchVo);
        return list;
    }

    /**
     * 设置用户账号锁定状态
     *
     * @param userId
     * @param isLocked
     * @return
     */
    @Override
    public boolean setIsLocked(int userId, boolean isLocked) {
        AuthUser authUser = new AuthUser();
        authUser.setId(userId);
        authUser.setIsLocked(isLocked);
        mapper.updateByPrimaryKeySelective(authUser);

        return true;
    }

    @Override
    public List<AuthRole> getRolesByUsername(String username) {

        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andUsernameEqualTo(username);
        criteria.andIsDelEqualTo(false);
        List<AuthUser> list = mapper.selectByExample(example);
        int userid = 0;
        if (list.size() > 0) {
            AuthUser user = list.get(0);
            userid = user.getId();
        }
        //根据用户id找到此用户有的权限
        AuthUserRoleCriteria example2 = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andUserIdEqualTo(userid);
        criteria2.andIsDelEqualTo(false);
        List<AuthUserRole> list2 = authUserRoleMapper.selectByExample(example2);
        List idlist = new ArrayList();
        for (AuthUserRole temp : list2) {
            idlist.add(temp.getRoleId());
        }
        //根据权限id，找到权限实体
        AuthRoleCriteria example3 = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria3 = example3.createCriteria();
        criteria3.andIdIn(idlist);
        criteria3.andIsDelEqualTo(false);
        List<AuthRole> resultList = authRoleMapper.selectByExample(example3);

        return resultList;
    }

    @Override
    public List<AuthRole> getRolesByUserid2(Integer userid) {

        //根据用户id找到此用户有的权限
        AuthUserRoleCriteria example2 = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andUserIdEqualTo(userid);
        criteria2.andIsDelEqualTo(false);
        List<AuthUserRole> list2 = authUserRoleMapper.selectByExample(example2);
        List idlist = new ArrayList();
        for (AuthUserRole temp : list2) {
            idlist.add(temp.getRoleId());
        }
        //根据权限id，找到权限实体
        AuthRoleCriteria example3 = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria3 = example3.createCriteria();
        criteria3.andIdIn(idlist);
        criteria3.andIsDelEqualTo(false);
        List<AuthRole> resultList = authRoleMapper.selectByExample(example3);

        return resultList;
    }

    @Override
    public List<AuthRole> getRoles(Integer orgid) {
        AuthRoleCriteria example3 = new AuthRoleCriteria();
        AuthRoleCriteria.Criteria criteria3 = example3.createCriteria();
        criteria3.andIsDelEqualTo(false);
        criteria3.andOrganizationIdEqualTo(orgid);
        List<AuthRole> resultList = authRoleMapper.selectByExample(example3);
        return resultList;
    }

    @Override
    public List<AuthUser> getUserByDept(Integer id) {
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andDepartmentIdEqualTo(id);
        criteria.andIsDelEqualTo(false);
        List<AuthUser> users = mapper.selectByExample(example);
        return users;
    }

    @Override
    public List getRolesByUserid(int userid) {
        List<AuthUserVO> voResultList = new ArrayList<>();
//        //根据用户id，查询该用户的权限集合

        AuthUserRoleCriteria example2 = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andUserIdEqualTo(userid);
        List<AuthUserRole> list2 = authUserRoleMapper.selectByExample(example2);
        List idlist = new ArrayList();
        for (AuthUserRole temp : list2) {
            idlist.add(temp.getRoleId());
        }

        List<AuthRole> resultList = new ArrayList<>();
        if (idlist.size() > 0) {
            //根据权限id，找到权限实体
            AuthRoleCriteria example3 = new AuthRoleCriteria();
            AuthRoleCriteria.Criteria criteria3 = example3.createCriteria();
            criteria3.andIdIn(idlist);
            criteria3.andIsDelEqualTo(false);
            resultList = authRoleMapper.selectByExample(example3);
        }
        List idlist2 = new ArrayList();
        for (AuthRole temp : resultList) {
            idlist2.add(temp.getId());
        }
        return idlist2;
    }

    @Override
    public String getUserRoleDeptIdsByUserName(String username) {
        return authUserRoleDeptMapper.getUserRoleDeptIdsByUserName(username);
    }

    @Override
    public UserDepartment getDeptByUsername(String username) {
        return authUserCusMapper.getDeptByUsername(username);
    }

    @Override
    public int getUserByDeptid(int id) {
        AuthUserCriteria example = new AuthUserCriteria();
        AuthUserCriteria.Criteria criteria = example.createCriteria();
        criteria.andIsDelEqualTo(false);
        criteria.andDepartmentIdEqualTo(id);
        List<AuthUser> list = mapper.selectByExample(example);
        return list.size();
    }


    @Override
    public List<AuthUserVO> getUserListByDeptid(Integer id) {
        return authUserCusMapper.getUserListByDeptId(id);
    }

    @Override
    public Result updatePassword(UpdatePasswordDto updPwd) {
        if (ObjectUtils.isEmpty(updPwd.getUserId())) {
            return new Result(ResultEnum.FAIL.getCode(), "用户id不能为空!");
        }
        // 校验原密码正确性
        AuthUser authUser = mapper.selectByPrimaryKey(updPwd.getUserId());
        if (ObjectUtils.isEmpty(authUser)) {
            return new Result(ResultEnum.FAIL.getCode(), "根据用户id查询用户为空!");
        }

        if (ObjectUtils.isEmpty(authUser.getMobile())) {
            return new Result(ResultEnum.FAIL.getCode(), "该用户无手机号，无法重置密码为手机号后六位!");
        }

        AuthUser updUser = new AuthUser();
        updUser.setId(updPwd.getUserId());
        String password = authUser.getMobile().substring(authUser.getMobile().length() - 6, authUser.getMobile().length());
        updUser.setPassword(BCryptUtil.encode(password));
        int i = mapper.updateByPrimaryKeySelective(updUser);
        if (i > 0) {
            return Result.returnOk();
        }
        return Result.returnFail();
    }

    @Override
    public Result forbiddenUser(Integer userId) {
        if (ObjectUtils.isEmpty(userId)) {
            return new Result(ResultEnum.FAIL.getCode(), "用户id不能为空!");
        }
        AuthUser user = new AuthUser();
        user.setId(userId);
        user.setIsLocked(true);
        int i = mapper.updateByPrimaryKeySelective(user);
        if (i > 0) {
            return Result.returnOk("禁用用户成功!");
        }
        return new Result(ResultEnum.FAIL.getCode(), "禁用用户不成功!");
    }

    @Override
    public Result deleteUser(Integer userId) {
        if (ObjectUtils.isEmpty(userId)) {
            return new Result(ResultEnum.FAIL.getCode(), "用户id不能为空!");
        }
        AuthUser user = new AuthUser();
        user.setId(userId);
        user.setIsDel(true);
        int i = mapper.updateByPrimaryKeySelective(user);
        if (i > 0) {
            return Result.returnOk("删除用户成功!");
        }
        return new Result(ResultEnum.FAIL.getCode(), "删除用户不成功!");
    }

    @Override
    public Result auditedUser(Integer userId, boolean isAudited) {
        if (ObjectUtils.isEmpty(userId)) {
            return new Result(ResultEnum.FAIL.getCode(), "用户di不能为空!");
        }
        AuthUser authUser = mapper.selectByPrimaryKey(userId);
        if (ObjectUtils.isEmpty(authUser)) {
            return new Result(ResultEnum.FAIL.getCode(), "用户查询为空!");
        }
        AuthUser user = new AuthUser();
        user.setId(userId);
        user.setAuditedStatus(isAudited ? GlobalConstant.USER_PASS_AUDITED : GlobalConstant.USER_AUDITED_FAILED);
        int i = mapper.updateByPrimaryKeySelective(user);
        if (i > 0) {
            return Result.returnOk("审核成功!");
        }
        return new Result(ResultEnum.FAIL.getCode(), "没有查询到需要审核的数据!");
    }

    @Override
    public Result nameCertification(AuthUserDTO dto, cn.yq.common.vo.AuthUser authUser1) {
        AuthUser authUser = new AuthUser();
        CopyUtils.copyProperties(dto,authUser);
        authUser.setId(authUser1.getId());
        mapper.updateByPrimaryKeySelective(authUser);
        return Result.returnOk("操作成功!");
    }

    @Override
    public Result isNameExist(Integer userId) {
        boolean flag = false;
        AuthUser authUser = mapper.selectByPrimaryKey(userId);
        Map map = new HashMap();
        if(null != authUser){
            if(StringUtils.isNotBlank(authUser.getName()) && StringUtils.isNotBlank(authUser.getCertifyNum())){
                flag = true;
            }
        }
        map.put("flag",flag);
        map.put("authUser",authUser);
        return Result.returnOk(map);
    }

    @Override
    public List getRoleByUserid(int userid) {
        List<AuthUserVO> voResultList = new ArrayList<>();
        //根据用户id，查询该用户的权限集合
        AuthUserRoleCriteria example2 = new AuthUserRoleCriteria();
        AuthUserRoleCriteria.Criteria criteria2 = example2.createCriteria();
        criteria2.andUserIdEqualTo(userid);
        criteria2.andIsDelEqualTo(false);
        List<AuthUserRole> list2 = authUserRoleMapper.selectByExample(example2);
        List idlist = new ArrayList();
        for (AuthUserRole temp : list2) {
            idlist.add(temp.getRoleId());
        }
        List<AuthRole> resultList = new ArrayList<>();
        if (idlist.size() > 0) {
            //根据权限id，找到权限实体
            AuthRoleCriteria example3 = new AuthRoleCriteria();
            AuthRoleCriteria.Criteria criteria3 = example3.createCriteria();
            criteria3.andIdIn(idlist);
            criteria3.andIsDelEqualTo(false);
            resultList = authRoleMapper.selectByExample(example3);
        }
        List idlist2 = new ArrayList();
        for (AuthRole temp : resultList) {
            idlist2.add(temp.getId());
        }
        return idlist2;
    }
}
