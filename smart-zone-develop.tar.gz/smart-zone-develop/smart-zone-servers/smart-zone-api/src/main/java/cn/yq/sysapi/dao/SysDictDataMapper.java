package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.SysDictData;
import cn.yq.sysapi.model.SysDictDataCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SysDictDataMapper {
    long countByExample(SysDictDataCriteria example);

    int deleteByExample(SysDictDataCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysDictData record);

    int insertSelective(SysDictData record);

    List<SysDictData> selectByExample(SysDictDataCriteria example);

    SysDictData selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysDictData record, @Param("example") SysDictDataCriteria example);

    int updateByExample(@Param("record") SysDictData record, @Param("example") SysDictDataCriteria example);

    int updateByPrimaryKeySelective(SysDictData record);

    int updateByPrimaryKey(SysDictData record);
}