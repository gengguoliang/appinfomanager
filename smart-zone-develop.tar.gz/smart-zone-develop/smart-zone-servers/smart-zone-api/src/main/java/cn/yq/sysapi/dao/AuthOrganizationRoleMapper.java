package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthOrganizationRole;
import cn.yq.sysapi.model.AuthOrganizationRoleCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthOrganizationRoleMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(AuthOrganizationRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(AuthOrganizationRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(AuthOrganizationRole record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(AuthOrganizationRole record);

    /**
     *
     * @mbg.generated
     */
    List<AuthOrganizationRole> selectByExample(AuthOrganizationRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    AuthOrganizationRole selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") AuthOrganizationRole record, @Param("example") AuthOrganizationRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") AuthOrganizationRole record, @Param("example") AuthOrganizationRoleCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(AuthOrganizationRole record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(AuthOrganizationRole record);
}