package cn.yq.sysapi.service;

import java.util.List;

public interface AuthRoleDeptService {

    //根据角色id获取该角色下的部门ids
    List<Integer> getDeptIdsByRoleId(int roleId);

    //携带角色id和部门ids将配置的部门保存到角色中
    Integer updateRoleDept(int roleId, int[] deptids);
}
