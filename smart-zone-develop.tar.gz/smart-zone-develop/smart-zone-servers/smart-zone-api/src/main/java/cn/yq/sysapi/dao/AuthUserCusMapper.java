package cn.yq.sysapi.dao;

import cn.yq.sysapi.dto.organization.AddRolesForUserDto;
import cn.yq.sysapi.dto.organization.UserShowDTO;
import cn.yq.sysapi.model.AuthRole;
import cn.yq.sysapi.model.AuthUser;
import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.vo.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthUserCusMapper {
      
      /**
      *@Description 入库生活圈个人资料表
      *@Param 
      *@Return 
      *@Author zhengjianhui
      */
      void insertProfileVO(TimelineProfileVO profileVO);
      
      /**
      *@Description 根据组织ID查询所有角色名
      *@Param 
      *@Return 
      *@Author zhengjianhui
      */
      List<String> queryRoleName(Integer orgId);

//      List<AuthUserVO> queryUserList(@Param("list") List list, @Param("username")String username,@Param("param") AuthUserSearchVo authUserSearchVo);

      List<AuthUserVO> queryUserList(@Param("param") AuthUserSearchVo authUserSearchVo);

      UserDepartment getDeptByUsername(String username);


      //根据部门id获取用户列表
      List<AuthUserVO> getUserListByDeptId(Integer id);
      cn.yq.common.vo.AuthUser getUserByUserName(String name);

      void forbiddenOrgUser(@Param("id") Integer id);

      void delOrgUserByOrgId(@Param("orgId") Integer orgId);

      void addRolesForUser(@Param("rolesList") AddRolesForUserDto addRolesDto);

      int insert(AuthUser authUser);

      /**
      *@Description 当前用户组织的所有角色
      *@Param
      *@Return
      *@Author zhengjianhui
      */
      List<AuthRole> getRolesByUser(Integer userId);
      /**
      *@Description PC端园区用户管理列表展示
      *@Param 
      *@Return 
      *@Author zhengjianhui
      */
      List<UserShowVO> showUserShowVOs(@Param("orgId")Integer orgId,@Param("userId")Integer userId,@Param("dto")UserShowDTO userShowDTO);
      
      /**
      *@Description PC端详情
      *@Param 
      *@Return 
      *@Author zhengjianhui
      */
      UserDetailVO detail(Integer id);
      
      /**
      *@Description PC端添加用户时的信息展示
      *@Param 
      *@Return 
      *@Author zhengjianhui
      */
      AddUserShowVO getAddUserShowVO(Integer userId);

      /**
      *@Description 获取AuthRoleVO
      *@Param
      *@Return
      *@Author zhengjianhui
      */
      List<Integer> getRoleIds(Integer userId);
      
      /**
      *@Description 查询所有部门
      *@Param 
      *@Return 
      *@Author zhengjianhui
      */
      List<UserDepartment> getDept(Integer userId);

      /**
       *@Description 部门回显需要的List<Integer>  2
       *@Param
       *@Return
       *@Author zhengjianhui
       */
      String getDeptIds2(Integer deptId);

      Integer getAppRole();
}
