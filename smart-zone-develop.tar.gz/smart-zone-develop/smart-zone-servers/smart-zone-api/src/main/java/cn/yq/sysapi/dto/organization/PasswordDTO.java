package cn.yq.sysapi.dto.organization;

import lombok.Data;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class PasswordDTO {

    private String originalPwd;//原密码
    private String newPwd;//新密码
}
