package cn.yq.sysapi.utils;

/**
 * @Author: ggl
 * @Date: 2019/6/14 11:44
 * @Description:
 */
public class RedisKeyUtil {
    /**
     * 数据权限前缀
     */
    public static final String TYPE_PREFIX = "data_auth";

    public static String getKey(Integer id){
        StringBuffer sb = new StringBuffer();
        sb.append(TYPE_PREFIX).append(":");
        sb.append(id);
        return sb.toString();
    }
}
