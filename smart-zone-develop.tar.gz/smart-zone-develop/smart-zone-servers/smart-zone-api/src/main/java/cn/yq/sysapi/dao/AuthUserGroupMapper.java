package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthUserGroup;
import cn.yq.sysapi.model.AuthUserGroupCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthUserGroupMapper {
    long countByExample(AuthUserGroupCriteria example);

    int deleteByExample(AuthUserGroupCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthUserGroup record);

    int insertSelective(AuthUserGroup record);

    List<AuthUserGroup> selectByExample(AuthUserGroupCriteria example);

    AuthUserGroup selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthUserGroup record, @Param("example") AuthUserGroupCriteria example);

    int updateByExample(@Param("record") AuthUserGroup record, @Param("example") AuthUserGroupCriteria example);

    int updateByPrimaryKeySelective(AuthUserGroup record);

    int updateByPrimaryKey(AuthUserGroup record);
}