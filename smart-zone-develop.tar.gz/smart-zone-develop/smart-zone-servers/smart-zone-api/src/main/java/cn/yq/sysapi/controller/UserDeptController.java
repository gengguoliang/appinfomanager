package cn.yq.sysapi.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.model.UserDepartment;
import cn.yq.sysapi.service.AuthUserService;
import cn.yq.sysapi.service.UserDeptService;
import cn.yq.sysapi.vo.AuthUserVO;
import cn.yq.sysapi.vo.TreeNode;
import cn.yq.sysapi.vo.UserDepartVo;
import cn.yq.sysapi.utils.TreeRecursion;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Api(value = "部门信息管理", description = "部门信息管理 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/userdept")
public class UserDeptController {

    @Autowired
    UserDeptService userDeptService;

    @Autowired
    AuthUserService userService;

    //获取组织机构树
    @ApiOperation(value = "获取组织机构树数据", notes = "获取组织机构树数据")
    @GetMapping("/getDeptTreeData")
    @LoginUser
    @SystemLog(description = "获取组织机构树数据")
    public BaseResult getDeptTreeData(AuthUser authuser){
        log.debug("organization_id===>{}",authuser.getOrganizationId());
        //根据部门过滤数据
        UserDepartment userDepartment = new UserDepartment();
        userDepartment.setOrganizationId(authuser.getOrganizationId());
        //获取数据
        List<UserDepartment> list = userDeptService.getDeptTreeData(userDepartment);
        log.debug("deptlist===>{}",list);
        //存储树结构
        Map<String, TreeNode> TreeNodes = new HashMap();
        for (UserDepartment temp: list) {
            TreeNode node = new TreeNode();
            node.setId(temp.getId().toString());
            node.setName(temp.getName());
            node.setParentId(temp.getParentId().toString());
            TreeNodes.put(temp.getId().toString(),node);
        }
        log.debug("treedata==>{}", TreeRecursion.getTreeNodeJson("0",TreeNodes));
        return BaseResult.successWithData(TreeRecursion.getTreeNodeJson("0",TreeNodes));
    }

    //获取组织机构树测试方法
//    @ApiOperation(value = "获取组织机构树数据", notes = "获取组织机构树数据")
//    @GetMapping("/getDeptTreeData2")
//    public BaseResult getDeptTreeData2(){
//        UserDepartment userDepartment = new UserDepartment();
//        //获取数据
//        List<UserDepartment> list = userDeptService.getDeptTreeData(userDepartment);
//        //存储树结构
//        Map<String,TreeNode> TreeNodes = new HashMap();
//        for (UserDepartment temp: list) {
//            TreeNode node = new TreeNode();
//            node.setId(temp.getId().toString());
//            node.setName(temp.getName());
//            node.setParentId(temp.getParentId().toString());
//            TreeNodes.put(temp.getId().toString(),node);
//        }
//        List resultlist = new ArrayList();
//        resultlist.add(4);
//        DeptRecursion.getTreeNodeJson("4",TreeNodes,resultlist);
//        for(int i=0;i<resultlist.size();i++){
//            System.out.println(resultlist.get(i)+"--------");
//        }
//        return BaseResult.successWithData(DeptRecursion.getTreeNodeJson("4",TreeNodes,resultlist));
//    }


    @ApiOperation(value = "添加部门信息", notes = "添加部门信息")
    @PostMapping(value = "/", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加部门信息")
    public BaseResult addUserDept(AuthUser authUser,@RequestBody UserDepartVo userDepartVo) {

          UserDepartment userDepartment = new UserDepartment();
          userDepartment.setOrganizationId(authUser.getOrganizationId());
          BeanUtils.copyProperties(userDepartVo,userDepartment);
          List<UserDepartment> list = userDeptService.getDeptTreeData(userDepartment);
        if (list.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "部门名称不能重复");
        }
        //判断新增之前删除的部门
        List<UserDepartment> list2 = userDeptService.getDeptTreeData2(userDepartment);
        if(list2.size()>0){
            //修改此前的数据状态
            userDeptService.updateUserDept(((UserDepartment)list2.get(0)).getId());
            return  BaseResult.successWithData("添加成功");
        }
        userDeptService.addDept(userDepartment);
      return BaseResult.successWithData("添加成功");
    }

    @ApiOperation(value = "删除部门", notes = "删除部门")
    @ApiImplicitParam(name = "id", value = "部门ID", dataType = "int", paramType = "path")
    @PutMapping(value = "/deleteUserDept/{id}")
    @SystemLog(description = "删除部门")
    public Result deleteUserDept(@PathVariable("id") int id) {
        //在删除部门之前判断该部门是否有人员
        int userCount = userService.getUserByDeptid(id);
        if(userCount>0){
           // return BaseResult.successWithData("删除失败，该部门有所属人员");
            return new Result(ResultEnum.FAIL.getCode(), "删除失败");
        }
         userDeptService.deleteUserDept(id);
         return Result.returnOk("删除成功");
    }

    @ApiOperation(value = "获取部门", notes = "获取部门")
    @ApiImplicitParam(name = "id", value = "部门ID", dataType = "int", paramType = "path")
    @GetMapping(value = "/getDeptById/{id}")
    @SystemLog(description = "获取部门")
    public Result getDeptById(@PathVariable("id") int id) {
        UserDepartment userDepartment = userDeptService.getDeptById(id);
        return Result.returnOk(userDepartment);
    }

    @ApiOperation(value = "获取部门下人员", notes = "获取部门下人员")
    @ApiImplicitParam(name = "id", value = "部门ID", dataType = "int", paramType = "path")
    @GetMapping(value = "/getUserByDept/{id}")
    @SystemLog(description = "获取部门下人员")
    public Result getUserByDept(@PathVariable("id") int id) {
        List<cn.yq.sysapi.model.AuthUser> users = userService.getUserByDept(id);
        return Result.returnOk(users);
    }


    @ApiOperation(value = "编辑部门名称信息", notes = "编辑部门名称信息")
    @PutMapping(value = "/updateUserDeptName", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "编辑部门名称信息")
    public BaseResult updateUserDeptName(AuthUser authUser,@RequestBody UserDepartVo userDepartVo) {

        UserDepartment userDepartment = new UserDepartment();
        userDepartment.setOrganizationId(authUser.getOrganizationId());
        BeanUtils.copyProperties(userDepartVo,userDepartment);
        List<UserDepartment> list = userDeptService.getDeptTreeData(userDepartment);
        if (list.size() > 0) {
            return BaseResult.failWithCodeAndMsg(1, "部门名称不能重复");
        }
        userDeptService.updateDept(userDepartment);
        return BaseResult.successWithData("修改成功");
    }



    @PostMapping(value = "/depts")
    @LoginUser
    public Result getDeptList(AuthUser authUser){
        int organizationId = authUser.getOrganizationId();
        List<UserDepartment> departments = userDeptService.getDeptList(organizationId);
        return Result.returnOk(departments);
    }










}
