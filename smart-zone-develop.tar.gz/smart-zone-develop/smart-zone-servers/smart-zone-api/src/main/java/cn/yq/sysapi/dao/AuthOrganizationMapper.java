package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthOrganization;
import cn.yq.sysapi.model.AuthOrganizationCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthOrganizationMapper {
    /**
     *
     * @mbg.generated
     */
    long countByExample(AuthOrganizationCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByExample(AuthOrganizationCriteria example);

    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int insert(AuthOrganization record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(AuthOrganization record);

    /**
     *
     * @mbg.generated
     */
    List<AuthOrganization> selectByExample(AuthOrganizationCriteria example);

    /**
     *
     * @mbg.generated
     */
    AuthOrganization selectByPrimaryKey(Integer id);

    /**
     *
     * @mbg.generated
     */
    int updateByExampleSelective(@Param("record") AuthOrganization record, @Param("example") AuthOrganizationCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByExample(@Param("record") AuthOrganization record, @Param("example") AuthOrganizationCriteria example);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(AuthOrganization record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(AuthOrganization record);
}