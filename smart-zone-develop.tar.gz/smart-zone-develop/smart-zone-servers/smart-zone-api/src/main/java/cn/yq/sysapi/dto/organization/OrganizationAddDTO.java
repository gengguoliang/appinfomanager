package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;


@ApiModel(value = "新增组织信息DTO")
@Data
public class OrganizationAddDTO implements Serializable {
    @ApiModelProperty(value = "用户ID")
    private Integer id;
    @ApiModelProperty(value = "所属分类")
    private Integer type;
    @ApiModelProperty(value = "管理员账号")
    private String username;
    @ApiModelProperty(value = "管理员密码")
    private String password;
    @ApiModelProperty(value = "企业名称")
    private String name;
    @ApiModelProperty(value = "承租单元ids")
    private List<Integer> unitIds;
    @ApiModelProperty(value = "企业地址")
    private String address;
    @ApiModelProperty(value = "统一社会信用代码")
    private String certifyNum;
    @ApiModelProperty(value = "身份证")
    private String identityCard;
    @ApiModelProperty(value = "状态")
    private Integer status;
    @ApiModelProperty(value = "联系电话")
    private String mobile;
    @ApiModelProperty(value = "角色ids")
    private List<Integer> roleIds;
    @ApiModelProperty(value = "单元文本")
    private String unit;

}
