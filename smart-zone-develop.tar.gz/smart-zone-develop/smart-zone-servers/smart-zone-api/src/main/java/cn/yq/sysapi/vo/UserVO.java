package cn.yq.sysapi.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

@ApiModel(description = "用户信息")
public class UserVO implements Serializable {
    private static final long serialVersionUID = 4083556596640978039L;

    @ApiModelProperty(value = "ID", name = "id", required = true, position = 0, example = "1")
    private int id;

    @ApiModelProperty(value = "所属项目ID", name = "projectId", required = true, position = 1, example = "1")
    private int projectId;

    @ApiModelProperty(value = "账号", name = "username", required = true, position = 2, example = "liubei")
    private String username;

    @ApiModelProperty(value = "密码", name = "password", required = true, position = 3)
    private String password;

    @ApiModelProperty(value = "姓名", name = "name", required = true, position = 4, example = "刘备")
    private String name;

    @ApiModelProperty(value = "手机号", name = "mobile", required = true, position = 5, example = "15876567857")
    private String mobile;

    @ApiModelProperty(value = "邮箱", name = "email", position = 6, example = "liubei@mail.com")
    private String email;

    @ApiModelProperty(value = "是否停用", name = "isLocked", position = 7)
    private Boolean isLocked;

    @ApiModelProperty(value = "角色ids", name = "roleids", position = 8)
    private int[] roleids;

    @ApiModelProperty(value = "部门id", name = "departmentId", position = 9, example = "1")
    private Integer departmentId;

    private Integer isLock;

    public Integer getIsLock() {
        return isLock;
    }

    public void setIsLock(Integer isLock) {
        this.isLock = isLock;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getLocked() {
        return isLocked;
    }

    public void setLocked(Boolean locked) {
        isLocked = locked;
    }

    public int[] getRoleids() {
        return roleids;
    }

    public void setRoleids(int[] roleids) {
        this.roleids = roleids;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    @Override
    public String toString() {
        return "UserVO{" +
                "id=" + id +
                "projectId=" + projectId +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", mobile='" + mobile + '\'' +
                ", email='" + email + '\'' +
                ", isLocked='" + isLocked + '\'' +
                '}';
    }
}
