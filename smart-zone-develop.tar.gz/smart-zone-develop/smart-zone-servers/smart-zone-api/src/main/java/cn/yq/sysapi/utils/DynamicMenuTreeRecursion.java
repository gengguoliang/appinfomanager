package cn.yq.sysapi.utils;

import cn.yq.sysapi.vo.DynamicMenuTreeNode;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DynamicMenuTreeRecursion {

    /**
     * 递归处理   数据库树结构数据->树形json
     * @param TreeNodeId
     * @param TreeNodes
     * @return
     */
    public static JSONArray getTreeNodeJson(String TreeNodeId, Map<String, DynamicMenuTreeNode> TreeNodes){

        //当前层级当前TreeNode对象
        DynamicMenuTreeNode cur = TreeNodes.get(TreeNodeId);
        //当前层级当前点下的所有子节点
        List<DynamicMenuTreeNode> childList = getChildTreeNodes(TreeNodeId,TreeNodes);

        JSONArray childTree = new JSONArray();
        for (DynamicMenuTreeNode TreeNode : childList) {
            JSONObject o = new JSONObject();
            o.put("id", TreeNode.getId());
            o.put("path",TreeNode.getPath());
            o.put("component",TreeNode.getComponent());
            o.put("name", TreeNode.getName());
            o.put("iconCls",TreeNode.getIconCls());
            o.put("type", TreeNode.getType());
            o.put("value",TreeNode.getValue());
            JSONArray childs = getTreeNodeJson(TreeNode.getId(),TreeNodes);  //递归调用该方法
            if(!childs.isEmpty()) {
                //判断树结构数据,同一级childs中，只会有一种类型的数据
                String type = childs.getJSONObject(0).get("type").toString();
                //如果type=1 则是菜单
                //如果type!=1 则是模块
                if(type.equals("1")){
                    o.put("children",childs);
                }else if(!type.equals("1")){
                    o.put("auth",childs);
                }
                o.put("leaf",false);
            }else{
                o.put("leaf",true);
            }
            childTree.fluentAdd(o);
        }
        return childTree;
    }

    /**
     * 获取当前节点的所有子节点
     * @param TreeNodeId
     * @param TreeNodes
     * @return
     */
    public static List<DynamicMenuTreeNode> getChildTreeNodes(String TreeNodeId, Map<String,DynamicMenuTreeNode> TreeNodes){
        List<DynamicMenuTreeNode> list = new ArrayList<>();
        for (String key : TreeNodes.keySet() ) {
            if(TreeNodes.get(key).getParentId().equals(TreeNodeId)){
                list.add(TreeNodes.get(key));
            }
        }
        return list;
    }

}




