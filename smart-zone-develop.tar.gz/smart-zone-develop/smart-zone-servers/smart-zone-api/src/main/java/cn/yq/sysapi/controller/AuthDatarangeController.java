package cn.yq.sysapi.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.config.BaseResult;
import cn.yq.sysapi.service.AuthDatarangeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "数据范围接口", description = "数据范围接口 API")
@RestController
public class AuthDatarangeController {

    @Autowired
    AuthDatarangeService authDatarangeService;


    @ApiOperation(value = "根据角色id获取数据范围", notes = "根据角色id获取数据范围")
    @ApiImplicitParam(name = "roleid", value = "角色id", dataType = "int", paramType = "path")
    @GetMapping("/getRangeDataByRoleid/{roleid}")
    @SystemLog(description = "根据角色id获取数据范围")
    public BaseResult getRangeDataByRoleid(@PathVariable("roleid") int roleid){
        return BaseResult.successWithData(authDatarangeService.getRangeDataByRoleid(roleid));
    }


    @ApiOperation(value = "保存角色与范围关系", notes = "保存角色与范围关系接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleid", value = "角色ID", dataType = "int", paramType = "path"),
            @ApiImplicitParam(name = "rangeid", value = "范围Id", dataType = "int", paramType = "path")
    })
    @PostMapping("/addRangeByRoleId/{roleid}/{rangeid}")
    @LoginUser
    @SystemLog(description = "保存角色与范围关系")
    public BaseResult addRangeByRoleId(@ApiIgnore AuthUser authUser,@PathVariable("roleid" ) int roleid, @PathVariable("rangeid") int rangeid){
        return BaseResult.successWithData(authDatarangeService.addRangeByRoleId(authUser,roleid, rangeid));
    }











}
