package cn.yq.sysapi.vo;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class UserDepartVo implements Serializable {
    private static final long serialVersionUID = -1637220864296212555L;

    @ApiModelProperty(value = "ID", name = "id", required = false, position = 0)
    private Integer id;

    @ApiModelProperty(value = "所属项目ID", name = "projectId", required = true, position = 1)
    private Integer projectId;

    @ApiModelProperty(value = "父Id", name = "parentId", required = true, position = 2)
    private Integer parentId;

    @ApiModelProperty(value = "level", name = "level", required = false, position = 3)
    private String level;

    @ApiModelProperty(value = "部门名称", name = "name", required = true, position = 4)
    private String name;

    @ApiModelProperty(value = "描述", name = "description", required = false, position = 5)
    private String description;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
