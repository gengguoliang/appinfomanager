package cn.yq.sysapi.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.sysapi.dto.organization.*;
import cn.yq.sysapi.model.AuthOrganization;
import cn.yq.sysapi.service.IAuthOrganizationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

@Slf4j
@Api(value = "组织信息(企业信息)管理", description = "组织信息(企业信息)管理 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/authOrg")
public class AuthOrganizationController {

    @Autowired
    private IAuthOrganizationService authOrganizationService;
    
    /**
    *@Description 根据用户ID获取组织的认证号
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @GetMapping("/getCertifyNum/{userId}")
    public Result<String> getCertifyNum(@PathVariable("userId")Integer userId){
        AuthOrganization authOrganization = authOrganizationService.getCertifyNum(userId);
        return Result.returnOk(authOrganization.getCertifyNum());
    }

    /**
     * 添加组织信息(企业信息)
     *
     * @author banzhiguo
     */
    @ApiOperation(value = "添加组织信息(企业信息)", notes = "添加组织信息(企业信息)")
    @PostMapping("/addAuthOrg")
    @SystemLog(description = "添加组织信息")
    public Result addAuthOrg(@RequestBody AddAuthOrganizationDto authOrganizationDto) {
        try {
            return Result.returnOk(authOrganizationService.addAuthOrg(authOrganizationDto));
        } catch (Exception e) {
            log.error("添加组织信息(企业信息)错误,原因{}", e.getMessage());
            e.printStackTrace();
            return new Result(ResultEnum.FAIL.getCode(), "添加组织信息(企业信息)错误,原因:" + e.getMessage());
        }
    }

    /**
     * 更新组织信息(企业信息)
     *
     * @author banzhiguo
     */
    @ApiOperation(value = "更新组织信息(企业信息)", notes = "更新组织信息(企业信息)")
    @PostMapping("/updateAuthOrg")
    @SystemLog(description = "更新组织信息")
    public Result updateAuthOrg(@RequestBody UpdateAuthOrganizationDto authOrganizationDto) {
        try {
            return Result.returnOk(authOrganizationService.updateAuthOrg(authOrganizationDto));
        } catch (Exception e) {
            log.error("更新组织信息(企业信息)错误,原因{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "更新组织信息(企业信息)错误,原因:" + e.getMessage());
        }
    }

    /**
     * 禁用企业账户的功能，禁用该企业账户时，该企业账户不能登录，该企业下其他员工可正常使用
     *
     * @param id
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "禁用组织信息(企业信息)", notes = "禁用组织信息(企业信息)")
    @GetMapping("/forbidden/{id}")
    @SystemLog(description = "禁用组织信息")
    public Result forbidden(@PathVariable("id") Integer id) {
        try {
            return authOrganizationService.forbidden(id);
        } catch (Exception e) {
            log.error("禁用组织异常,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "禁用组织异常,原因:" + e.getMessage());
        }
    }

    /**
     * 删除企业账号的功能，删除该企业账户时，该企业下的其它账户自动删除
     *
     * @param id
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "删除组织信息(企业信息)", notes = "删除组织信息(企业信息)")
    @DeleteMapping("/delAuthOrg/{id}")
    @SystemLog(description = "删除组织信息")
    public Result delAuthOrg(@PathVariable("id") Integer id) {
        try {
            return authOrganizationService.delAuthOrg(id);
        } catch (Exception e) {
            log.error("删除组织异常,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "删除组织异常,原因:" + e.getMessage());
        }
    }

    /**
     * @return Result
     * @Description 根据条件查询组织
     * @author banzhiguo
     * @date 2019/2/28 11:30:55
     */
    @ApiOperation(value = "根据条件查询组织", notes = "查询组织信息(企业信息)")
    @PostMapping("/query")
    @ResponseBody
    @SystemLog(description = "根据条件查询组织")
    public Result query(@RequestBody GetInfoAuthOrgDto query) {
        try {
            return authOrganizationService.query(query);
        } catch (Exception e) {
            log.error("根据条件查询组织异常,原因:{}", e.getMessage());
            e.printStackTrace();
            return new Result(ResultEnum.FAIL.getCode(), "根据条件查询组织异常,原因:" + e.getMessage());
        }
    }

    /**
     * 冻结企业账户的功能，冻结企业账户时，该企业下的其它账户同时自动冻结
     *
     * @param orgId
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "冻结组织信息(企业信息)", notes = "冻结组织信息(企业信息)")
    @GetMapping("/frozen/{id}")
    @SystemLog(description = "冻结组织信息")
    public Result frozen(@PathVariable("id") Integer orgId) {
        try {
            return authOrganizationService.frozen(orgId);
        } catch (Exception e) {
            log.error("冻结组织异常,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "冻结组织异常,原因:" + e.getMessage());
        }
    }

    /**
     * 给组织(企业)添加角色
     *
     * @param addRole
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "给组织(企业)添加角色", notes = "给组织(企业)添加角色")
    @PostMapping("/addRoleForOrg")
    @SystemLog(description = "给组织添加角色")
    public Result addRoleForOrg(@RequestBody AddRoleForOrgDto addRole) {
        try {
            return authOrganizationService.addRoleForOrg(addRole);
        } catch (Exception e) {
            log.error("给组织(企业)添加角色异常,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "给组织(企业)添加角色异常,原因:" + e.getMessage());
        }
    }

    /**
     * 查询组织超管拥有的角色
     *
     * @return 组织对应的角色列表
     * @date 2019/3/2 10:33:13
     * @author banzhiguo
     */
    @ApiOperation(value = "查询组织超管拥有的角色", notes = "查询组织超管拥有的角色")
    @GetMapping("/getOrgRoles")
    @SystemLog(description = "查询组织超管拥有的角色")
    public Result getOrgRoles(@RequestParam("orgId") Integer orgId) {
        try {
            return authOrganizationService.getOrgRoles(orgId);
        } catch (Exception e) {
            log.error("查询组织超管拥有的角色异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "查询组织超管拥有的角色异常,原因：" + e.getMessage());
        }
    }

    // TODO 后续优化

    /**
     * 查询自己组织下的员工
     *
     * @param orgId
     * @return
     * @author banzhiguo
     */
    @ApiOperation(value = "查询自己组织下的员工", notes = "查询自己组织下的员工")
    @GetMapping("/getUsersByOrg")
    @SystemLog(description = "查询自己组织下的员工")
    public Result getUsersByOrg(@RequestParam("orgId") Integer orgId) {
        try {
            return authOrganizationService.getUsersByOrg(orgId);
        } catch (Exception e) {
            log.error("查询自己组织下的员工异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "查询自己组织下的员工异常,原因：" + e.getMessage());
        }
    }

    /**
     * 根据审核状态查询（组织）企业信息
     *
     * @param auditedType
     * @return Result
     * @author banzhiguo
     */
    @ApiOperation(value = "根据审核状态查询（组织）企业信息", notes = "根据审核状态查询（组织）企业信息")
    @GetMapping("/getOrgByAudited")
    @ApiImplicitParam(name = "auditedType", value = "查询类型1全部2待审核3已通过4未通过", dataType = "int")
    @SystemLog(description = "根据审核状态查询企业信息")
    public Result getOrgByAudited(@RequestParam("auditedType") int auditedType) {
        try {
            return authOrganizationService.getOrgByAudited(auditedType);
        } catch (Exception e) {
            log.error("根据审核状态查询（组织）企业信息,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "根据审核状态查询（组织）企业信息异常,原因:" + e.getMessage());
        }
    }

    /**
     * 审核app申请
     *
     * @author banzhiguo
     * @param auditedOrgDto
     * @return
     */
    @ApiOperation(value = "审核app申请的组织", notes = "审核app申请的组织")
    @PostMapping("/audited")
    @SystemLog(description = "审核app申请的组织")
    public Result audited(@RequestBody AuditedOrgDto auditedOrgDto) {
        try {
            return authOrganizationService.audited(auditedOrgDto);
        } catch (Exception e) {
            log.error("审核app申请的组织异常,原因:{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "审核app申请的组织异常,原因:" + e.getMessage());
        }
    }

    /**
     * 根据组织id查询组织
     * @param orgId
     * @return
     */
    @ApiOperation(value = "根据组织id查询组织", notes = "根据组织id查询组织")
    @GetMapping("/getOrgById")
    @SystemLog(description = "根据组织id查询组织")
    public Result getOrgById(@RequestParam("orgId") Integer orgId) {
        try {
            return authOrganizationService.getOrgById(orgId);
        } catch (Exception e) {
            log.error("根据组织id查询组织异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "根据组织id查询组织异常,原因：" + e.getMessage());
        }
    }

    /**
     * 模糊查询单元
     * @author banzhiguo
     * @param unitName
     * @return
     */
    @ApiOperation(value = "模糊查询单元", notes = "模糊查询单元")
    @GetMapping("/queryUnit")
    @SystemLog(description = "模糊查询单元")
    public Result queryUnit(@RequestParam("orgId") String unitName) {
        try {
            return authOrganizationService.queryUnit(unitName);
        } catch (Exception e) {
            log.error("模糊查询单元异常,原因：{}", e.getMessage());
            return new Result(ResultEnum.FAIL.getCode(), "模糊查询单元异常,原因：" + e.getMessage());
        }
    }

    /**
     * 验证企业编码
     * @author ggl
     * @param
     * @return
     */
    @ApiOperation(value = "验证企业编码", notes = "验证企业编码")
    @GetMapping("/isExistCode")
    @LoginUser
    @SystemLog(description = "验证企业编码")
    public Result isExistCode(@ApiIgnore AuthUser authUser,@RequestParam("code")String code){
        return authOrganizationService.isExistCode(authUser.getId(),code);
    }
}
