package cn.yq.sysapi.dto.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@ApiModel(value = "审核组织(企业)dto")
@Setter
@Getter
public class AuditedOrgDto {
    @ApiModelProperty(value = "组织id")
    private Integer orgId;
    @ApiModelProperty(value = "审核是否通过")
    private boolean isAudited;
    @ApiModelProperty(value = "单元id集合")
    private List<Integer> unitIds;
}
