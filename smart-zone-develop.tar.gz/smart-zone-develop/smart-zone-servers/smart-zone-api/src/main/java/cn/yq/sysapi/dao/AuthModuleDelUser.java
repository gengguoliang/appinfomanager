package cn.yq.sysapi.dao;

import org.apache.ibatis.annotations.Param;

public interface AuthModuleDelUser {

    int removeUserByRoleIdAndUserid(@Param("roleId") int roleId, @Param("userId")int userId);
}
