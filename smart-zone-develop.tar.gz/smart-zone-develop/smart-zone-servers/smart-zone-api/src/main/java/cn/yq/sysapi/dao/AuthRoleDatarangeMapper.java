package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthRoleDatarange;
import cn.yq.sysapi.model.AuthRoleDatarangeCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthRoleDatarangeMapper {
    long countByExample(AuthRoleDatarangeCriteria example);

    int deleteByExample(AuthRoleDatarangeCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthRoleDatarange record);

    int insertSelective(AuthRoleDatarange record);

    List<AuthRoleDatarange> selectByExample(AuthRoleDatarangeCriteria example);

    AuthRoleDatarange selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthRoleDatarange record, @Param("example") AuthRoleDatarangeCriteria example);

    int updateByExample(@Param("record") AuthRoleDatarange record, @Param("example") AuthRoleDatarangeCriteria example);

    int updateByPrimaryKeySelective(AuthRoleDatarange record);

    int updateByPrimaryKey(AuthRoleDatarange record);
}