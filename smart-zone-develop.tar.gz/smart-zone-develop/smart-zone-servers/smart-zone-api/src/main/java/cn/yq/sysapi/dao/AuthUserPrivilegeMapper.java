package cn.yq.sysapi.dao;

import org.apache.ibatis.annotations.Param;
import cn.yq.sysapi.model.AuthPrivilege;
import java.util.List;

public interface AuthUserPrivilegeMapper {


    /**
     * 根据用户ID查找权限列表
     * @param userId
     * @return
     */
    List<AuthPrivilege> selectPrivilegesByUserId(@Param("userId") int userId);
}
