package cn.yq.sysapi.vo;

import lombok.Data;

import java.util.Date;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
@Data
public class UserShowVO {

    private Integer id;
    private String userName;
    private String mobile;
    private String name;
    private String departmentName;
    private String roles;
    private Date createTime;
    private Integer isLocked;//是否锁定  0：未锁定 1：锁定
    private Integer auditedStatus;//审核状态，0：待审核，1：审核通过，2：审核不通过
    private Integer isAdmin;
    private Integer isSystem;
    private Integer isEdit;//是否可编辑 0：不可以  1：可以
}
