package cn.yq.sysapi.vo;

public class DynamicMenuTreeNode {

    public String id ;
    public String name;
    public Integer type;
    public String parentId;
    public String path;
    public String component;
    public String iconCls;
    public boolean leaf;
    public Boolean value;


    public DynamicMenuTreeNode(String id, String name, Integer type, String parentId,
                               String path,String component,String iconCls,boolean leaf,Boolean value) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.parentId = parentId;
        this.path = path;
        this.component = component;
        this.iconCls = iconCls;
        this.leaf = leaf;
        this.value = value;
    }

    public DynamicMenuTreeNode() {
    }

    public Boolean getValue() {
        return value;
    }

    public void setValue(Boolean value) {
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public String getIconCls() {
        return iconCls;
    }

    public void setIconCls(String iconCls) {
        this.iconCls = iconCls;
    }

    public boolean isLeaf() {
        return leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }
}
