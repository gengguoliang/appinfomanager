package cn.yq.sysapi.dao;

import cn.yq.sysapi.model.AuthModule;
import cn.yq.sysapi.model.AuthModuleCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuthModuleMapper {
    long countByExample(AuthModuleCriteria example);

    int deleteByExample(AuthModuleCriteria example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthModule record);

    int insertSelective(AuthModule record);

    List<AuthModule> selectByExample(AuthModuleCriteria example);

    AuthModule selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthModule record, @Param("example") AuthModuleCriteria example);

    int updateByExample(@Param("record") AuthModule record, @Param("example") AuthModuleCriteria example);

    int updateByPrimaryKeySelective(AuthModule record);

    int updateByPrimaryKey(AuthModule record);

}