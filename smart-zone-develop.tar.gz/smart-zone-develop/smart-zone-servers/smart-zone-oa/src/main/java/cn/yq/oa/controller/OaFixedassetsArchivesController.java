package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.OaFixedassetsParam;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.OaFixedassetsReceptionVo;
import cn.yq.oa.vo.OaFixedassetsTransferVo;
import cn.yq.oa.vo.OaFixedassetsVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 * 固定资产档案 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-03
 */
@RestController
@RequestMapping("/oa-fixedassets-archives")
@AllArgsConstructor
public class OaFixedassetsArchivesController {
    IOaFixedassetsService oaFixedassetsService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsReceptionService oaFixedassetsReceptionService;

    IOaFixedassetsBorrowService oaFixedassetsBorrowService;

    IOaFixedassetsRefundService oaFixedassetsRefundService;

    IOaFixedassetsTransferService oaFixedassetsTransferService;

    IOaFixedassetsMaintenanceService oaFixedassetsMaintenanceService;

    IOaFixedassetsCleanupService oaFixedassetsCleanupService;

    IOaFixedassetsCategoryService oaFixedassetsCategoryService;

    IUserDepartmentService userDepartmentService;

    @PostMapping("/getAllAssets/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产档案信息")
    public Result getAllAssets(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody OaFixedassetsParam oaFixedassetsParam){
        Page<OaFixedassetsVo> page= new Page<OaFixedassetsVo>(pageNum,pageSize);
        IPage<OaFixedassetsVo> assetsPage = oaFixedassetsService.selectAssetsVoPage(page,oaFixedassetsParam);
        return Result.returnOk(assetsPage);
    }

    /**
     * 查看功能
     */
    @GetMapping("/getDetailById/{id}")
    @SystemLog(description = "查看功能")
    public Result getDetailById(@PathVariable("id") int id){

        Map map = new HashMap<>();
        ///////////////////
        //基本信息
        OaFixedassets oaFixedassets = oaFixedassetsService.getById(id);
        OaFixedassetsVo oaFixedassetsVo = new OaFixedassetsVo();
        BeanUtils.copyProperties(oaFixedassets,oaFixedassetsVo);
        //查询资产类别
        OaFixedassetsCategory category = oaFixedassetsCategoryService.getById(oaFixedassets.getCategoryId());
        oaFixedassetsVo.setCategoryName(category.getCategoryName());
        map.put("oaFixedassetsInfo",oaFixedassetsVo);

        //根据资产id查询业务单id与业务类型
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("asset_id",id);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        //业务类型，0：领用，1：退库，2：借用，3：转移，4：维修，5：清理
        List lylist = new ArrayList();
        List tklist = new ArrayList();
        List jhlist = new ArrayList();
        List zylist = new ArrayList();
        List wxlist = new ArrayList();
        List qllist = new ArrayList();
        for(OaFixedassetsBizDetail temp:list){
            //根据业务类型与业务单号查询不同的表
            if(temp.getBizType()==0){
                int bizid = temp.getBizId();
                OaFixedassetsReception oaFixedassetsReception = oaFixedassetsReceptionService.getById(bizid);
                OaFixedassetsReceptionVo oaFixedassetsReceptionVo = new OaFixedassetsReceptionVo();
                BeanUtils.copyProperties(oaFixedassetsReception,oaFixedassetsReceptionVo);

                UserDepartment userDepartment = userDepartmentService.getById(oaFixedassetsReception.getDepartmentId());
                String departmentName = userDepartment==null?"":userDepartment.getName();
                oaFixedassetsReceptionVo.setDepartmentName(departmentName);
                lylist.add(oaFixedassetsReceptionVo);
            }
            if(temp.getBizType()==1){
                int bizid = temp.getBizId();
                OaFixedassetsRefund oaFixedassetsRefund = oaFixedassetsRefundService.getById(bizid);
                tklist.add(oaFixedassetsRefund);
            }
            if(temp.getBizType()==2){
                int bizid = temp.getBizId();
                OaFixedassetsBorrow oaFixedassetsBorrow = oaFixedassetsBorrowService.getById(bizid);
                jhlist.add(oaFixedassetsBorrow);
            }
            if(temp.getBizType()==3){
                int bizid = temp.getBizId();
                OaFixedassetsTransfer oaFixedassetsTransfer = oaFixedassetsTransferService.getById(bizid);
                OaFixedassetsTransferVo oaFixedassetsTransferVo = new OaFixedassetsTransferVo();
                BeanUtils.copyProperties(oaFixedassetsTransfer,oaFixedassetsTransferVo);
                UserDepartment userDepartment = userDepartmentService.getById(oaFixedassetsTransfer.getDepartmentId());
                String departmentName = userDepartment==null?"":userDepartment.getName();
                oaFixedassetsTransferVo.setDepartmentName(departmentName);
                //返回转出部门信息
                oaFixedassetsTransferVo.setOutdeptId(temp.getOutdeptId());
                UserDepartment userDepartment1 = userDepartmentService.getById(temp.getOutdeptId());
                String departmentName1 = userDepartment1==null?"":userDepartment1.getName();
                oaFixedassetsTransferVo.setOutdeptName(departmentName1);
                zylist.add(oaFixedassetsTransferVo);
            }
            if(temp.getBizType()==4){
                int bizid = temp.getBizId();
                OaFixedassetsMaintenance oaFixedassetsMaintenance = oaFixedassetsMaintenanceService.getById(bizid);
                wxlist.add(oaFixedassetsMaintenance);
            }
            if(temp.getBizType()==5){
                int bizid = temp.getBizId();
                OaFixedassetsCleanup oaFixedassetsCleanup = oaFixedassetsCleanupService.getById(bizid);
                qllist.add(oaFixedassetsCleanup);
            }

            map.put("lylist",lylist);
            map.put("tklist",tklist);
            map.put("jhlist",jhlist);
            map.put("zylist",zylist);
            map.put("wxlist",wxlist);
            map.put("qllist",qllist);
        }

        return Result.returnOk(map);
    }

}
