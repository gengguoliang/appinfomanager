package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.enumeration.PropertyNoEnum;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.RelationInfoVO;
import cn.yq.push.annotations.Notification;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mysql.jdbc.util.ResultSetUtil;
import com.qiniu.util.Auth;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * <p>
 * 车位申请表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-12
 */
@RestController
@RequestMapping("/oa-parking-application")
@Api(value = "车位申请管理", description = "车位申请管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaParkingApplicationController {

    ICommonFilesService commonFilesService;

    IOaParkingApplicationService oaParkingApplicationService;

    OrderNumberService orderNumberService;

    IAuthOrganizationService authOrganizationService;

    IAuthOrganizationUnitService authOrganizationUnitService;
    IOaPropertyElevatorApplyService oaPropertyElevatorApplyService;

    @ApiOperation(value = "获取当前登录用户信息", notes = "获取当前登录用户信息")
    @LoginUser
    @GetMapping(value = "/getUserInfo")
    @SystemLog(description = "获取当前登录用户信息")
    public Result getUserInfo(AuthUser authUser){
        Map map = new HashMap();
       //获取公司名称
       int orgid = authUser.getOrganizationId();
        AuthOrganization authOrganization = authOrganizationService.getById(orgid);
        String orgname = authOrganization.getName();
        int userid = authUser.getId();
        String username = authUser.getName();
        map.put("username",username);
        map.put("userid",userid);
        map.put("orgname",orgname);
        map.put("orgid",orgid);
        List<RelationInfoVO> vos = oaPropertyElevatorApplyService.selectRelationInfo(authUser);
        map.put("vos",vos);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "添加车位申请", notes = "添加车位申请")
    @PostMapping(value = "/addParkingApply", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加车位申请")
    public Result addParkingApply(AuthUser authUser, @RequestBody ParkingApplyParam parkingApplyParam) {
        OaParkingApplication oaParkingApplication = new OaParkingApplication();
        BeanUtils.copyProperties(parkingApplyParam,oaParkingApplication);
        //申请编号
        String num = orderNumberService.getOneOrderNumber(PropertyNoEnum.CW_APPLICATION_NO.getPrefix());
        oaParkingApplication.setApplicationno(num);
        oaParkingApplication.setProposerId(authUser.getId());
        oaParkingApplication.setProposer(authUser.getName());
        oaParkingApplication.setStatus(1);
        oaParkingApplicationService.saveOrUpdate(oaParkingApplication);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除车位申请记录", notes = "删除车位申请记录")
    @GetMapping("/deleteParkingApplyById/{id}")
    @SystemLog(description = "删除车位申请记录")
    public Result deleteParkingApplyById(@PathVariable("id") int id) {
        oaParkingApplicationService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "查看车位申请记录", notes = "查看车位申请记录")
    @GetMapping("/viewParkingApplyById/{id}")
    @SystemLog(description = "查看车位申请记录")
    public Result viewParkingApplyById(@PathVariable("id") int id) {
        OaParkingApplication oaParkingApplication = oaParkingApplicationService.getById(id);
        Map map = new HashMap<>();
        map.put("info",oaParkingApplication);
        QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<CommonFiles>();
        queryWrapper.eq("relation_type",PropertyNoEnum.CW_APPLICATION_NO.getPrefix());
        queryWrapper.eq("relation_id",id);
        queryWrapper.eq("is_del",0);
        List<CommonFiles> list = commonFilesService.list(queryWrapper);
        map.put("attachment",list);
        return Result.returnOk(map);
    }
    @ApiOperation(value = "删除附件", notes = "删除附件")
    @GetMapping("/removettachment/{id}")
    @SystemLog(description = "删除车位申请附件")
    public Result removettachment(@PathVariable("id") Integer id){
        commonFilesService.removeById(id);
        return Result.returnOk("操作成功");
    }



    @ApiOperation(value = "分页获取车位申请列表", notes = "分页获取车位申请列表")
    @PostMapping("/listParkingApply/{pageNum}/{pageSize}")
    @SystemLog(description = "分页获取车位申请列表")
    public Result listAdvertisingPositionApply(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody ParkingApplySearchParam param) {

        Page<OaParkingApplication> page = new Page<OaParkingApplication>(pageNum, pageSize);
        IPage<OaParkingApplication> iPage = oaParkingApplicationService.selectParkingApplicationPage(page,param);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "App获取车位申请列表", notes = "App获取车位申请列表")
    @GetMapping("/listParkingApplyApp")
    @LoginUser
    @SystemLog(description = "app获取车位申请列表")
    public Result listParkingApplyApp(AuthUser authUser) {
        int unitid = authUser.getOrganizationId();
        QueryWrapper<OaParkingApplication> queryWrapper = new QueryWrapper<OaParkingApplication>();
        queryWrapper.eq("application_company_id",unitid);
        queryWrapper.eq("is_del",0);
        queryWrapper.orderByDesc("application_time");
        return Result.returnOk(oaParkingApplicationService.list(queryWrapper));
    }


    @ApiOperation(value = "业务办理", notes = "业务办理")
    @PostMapping("/changeStatus")
    @SystemLog(description = "车位申请业务办理")
    public Result changeStatusById(@RequestBody BusManageParam busManageParam) {
        OaParkingApplication oaParkingApplication = new OaParkingApplication();
        oaParkingApplication.setId(busManageParam.getId());
        oaParkingApplication.setStatus(busManageParam.getStatus());
//        oaParkingApplication.setRemark(busManageParam.getRemark());
        oaParkingApplication.setTransactRemark(busManageParam.getRemark());
        oaParkingApplicationService.updateById(oaParkingApplication);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "受理", notes = "受理")
    @PostMapping("/acceptance")
    @LoginUser
    @Notification("车位申请")
    @SystemLog(description = "车位申请受理")
    public Result acceptance(AuthUser authUser, @RequestBody BusManageParam busManageParam) {
        String userName = oaParkingApplicationService.selectParkingName(busManageParam.getId());
        PushUtil.setTargetUsername(userName);
        OaParkingApplication oaParkingApplication = new OaParkingApplication();
        oaParkingApplication.setId(busManageParam.getId());
        oaParkingApplication.setStatus(busManageParam.getStatus());
        oaParkingApplication.setResponseRemark(busManageParam.getRemark());
        oaParkingApplication.setResponofficer(authUser.getName());
        oaParkingApplication.setResponseTime(new Date());
        oaParkingApplicationService.updateById(oaParkingApplication);
        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "撤回申请", notes = "撤回申请")
    @PostMapping("/withdrawById")
    @SystemLog(description = "车位申请撤回")
    public Result withdrawById(@RequestBody BusManageParam busManageParam) {
        OaParkingApplication oaParkingApplication = new OaParkingApplication();
        oaParkingApplication.setId(busManageParam.getId());
        oaParkingApplication.setWithdrawReason(busManageParam.getRemark());
        oaParkingApplication.setStatus(busManageParam.getStatus());
        oaParkingApplication.setWithdrawTime(new Date());
        oaParkingApplicationService.updateById(oaParkingApplication);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "车位登记", notes = "车位登记")
    @PostMapping("/parkingRegister")
    @SystemLog(description = "车位登记")
    public Result parkingRegister(@RequestBody parkingRegisterParam parkingRegisterParam) {
        OaParkingApplication oaParkingApplication = new OaParkingApplication();
        oaParkingApplication.setId(parkingRegisterParam.getId());
        oaParkingApplication.setParkingNumber(parkingRegisterParam.getParkingNumber());
        oaParkingApplication.setParkingBegintime(parkingRegisterParam.getParkingBegintime());
        oaParkingApplication.setParkingEndtime(parkingRegisterParam.getParkingBegintime());
        oaParkingApplicationService.updateById(oaParkingApplication);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "资料登记", notes = "资料登记")
    @PostMapping("/dataRegister")
    @SystemLog(description = "车位申请资料登记")
    public Result dataRegistration(@RequestBody DataRegistrationParam dataRegistrationParam) {

        List<CommonFiles> datalist = dataRegistrationParam.getDatalist();
        for (CommonFiles temp:datalist) {
            temp.setRelationType(PropertyNoEnum.CW_APPLICATION_NO.getPrefix());
            temp.setRelationId(dataRegistrationParam.getId());
            commonFilesService.save(temp);
        }
        return Result.returnOk("操作成功");
    }




}
