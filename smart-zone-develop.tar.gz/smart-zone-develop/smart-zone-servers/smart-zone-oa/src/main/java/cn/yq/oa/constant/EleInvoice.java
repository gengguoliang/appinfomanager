package cn.yq.oa.constant;

/**
 * @program: smart-zone
 * @description:
 * @author: zhengjianhui
 **/
public class EleInvoice {

    /**
     * 根据订单号查询发票
     */
    public static final String FIND_INVOICE="chinaeinv.api.invoice.v3.cx";
    /**
     * 生成电子发票
     */
    public static final String CREATE_INVOICE="chinaeinv.api.invoice.v3.kp_async";

}
