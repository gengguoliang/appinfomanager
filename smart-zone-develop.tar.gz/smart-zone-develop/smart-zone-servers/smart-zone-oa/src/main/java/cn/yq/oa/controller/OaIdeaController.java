package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 创意信息表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-21
 */
@RestController
@RequestMapping("/oa-idea")
@Api(value = "创意空间管理", description = "ggl创意空间管理 API", position = 100, protocols = "http")
@AllArgsConstructor
@Slf4j
public class OaIdeaController {
    @Autowired
    private ISysDictDataService sysDictDataService;
    @Autowired
    private IOaIdeaService oaIdeaService;
    @Autowired
    private IOaIdeaConversionService oaIdeaConversionService;
    @Autowired
    private IOaIdeaOffloadService oaIdeaOffloadService;
    @Autowired
    private IOaIdeaExamineService oaIdeaExamineService;
    @Autowired
    private IOaIdeaCommentService oaIdeaCommentService;
    @Autowired
    private ICommonFilesService commonFilesService;

    @ApiOperation(value = "关联组织信息", notes = "关联组织信息")
    @GetMapping(value = "/getOrganizationInfo")
    @LoginUser
    public Result<OrganizationInfoVO> getOrganizationInfo(@ApiIgnore AuthUser authUser) {
        OrganizationInfoVO organizationInfoVO = oaIdeaService.selectOrganizationInfoVO(authUser.getId());
        return Result.returnOk(organizationInfoVO);
    }

    @ApiOperation(value = "创建/编辑 创意", notes = "创建/编辑 创意")
    @PostMapping(value = "/addorUpdateIdea", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加创意信息")
    public Result addorUpdateIdea(@ApiIgnore AuthUser authUser, @RequestBody IdeaParam ideaParam) {
        if(null != ideaParam){
            OaIdea oaIdea = new OaIdea();
            CopyUtils.copyProperties(ideaParam,oaIdea);
            if(ideaParam.getId() != 0){
                oaIdeaService.updateById(oaIdea);
                //获取当前创意下的所有附件信息
                QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<>();
                queryWrapper1.eq("is_del",0);
                queryWrapper1.eq("relation_type","idea_attachment");
                queryWrapper1.eq("relation_id",oaIdea.getId());
                List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper1);
                for (CommonFiles commonFiles : commonFilesList){
                    commonFilesService.removeById(commonFiles.getId());
                }
                for (CommFileVO commFileVO : ideaParam.getAttachmentUrl()){
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(commFileVO,commonFiles);
                    //创意附件名称
                    commonFiles.setRelationType("idea_attachment");
                    commonFiles.setRelationId(oaIdea.getId());
                    commonFilesService.save(commonFiles);
                }

            }else{
                oaIdea.setStatus(1);
                oaIdea.setOrgid(authUser.getOrganizationId());
                oaIdeaService.save(oaIdea);
                //上传附件
                for (CommFileVO commFileVO : ideaParam.getAttachmentUrl()){
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(commFileVO,commonFiles);
                    //创意附件名称
                    commonFiles.setRelationType("idea_attachment");
                    commonFiles.setRelationId(oaIdea.getId());
                    commonFilesService.save(commonFiles);
                }
            }
        }
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取创意类型与创意阶段", notes = "获取创意类型与创意阶段")
    @GetMapping(value = "/getDicInfo")
    @SystemLog(description = "获取创意类型与创意阶段")
    public Result getDicInfo(){
        Map map = new HashMap();
        //获取创意类型集合
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<SysDictData>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("dict_type","creative_type");
        List<SysDictData> listType= sysDictDataService.list(queryWrapper);
        //获取创意阶段集合
        QueryWrapper<SysDictData> queryWrapper1 = new QueryWrapper<SysDictData>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("dict_type","creative_stage");
        List<SysDictData> listStage= sysDictDataService.list(queryWrapper1);
        map.put("listType",listType);
        map.put("listStage",listStage);
        return Result.returnOk(map);
    }

    /**
     *
     * @param authUser
     * @param pageNum
     * @param pageSize
     * @param type 信息分类（0创意信息管理列表1创意审核列表）
     * @param param
     * @return
     */
    @ApiOperation(value = "分页获取创意信息", notes = "分页获取创意信息")
    @PostMapping("/listIdea/{pageNum}/{pageSize}/{type}")
    @LoginUser
    @SystemLog(description = "分页获取创意信息")
    public Result<IPage<IdeaPageInfoVO>> listIdea(@ApiIgnore AuthUser authUser,
                                          @PathVariable("pageNum") int pageNum,
                                          @PathVariable("pageSize") int pageSize,
                                          @PathVariable("type") int type,
                                          @RequestBody IdeaSearchParam param){
        Page<IdeaPageInfoVO> page = new Page<IdeaPageInfoVO>(pageNum, pageSize);
        IPage<IdeaPageInfoVO> iPage = null;
        if(type == 0){
             iPage = page.setRecords(oaIdeaService.selectIdeaPageInfo(authUser.getOrganizationId(),page,param));
        }else if(type == 1){
            iPage = page.setRecords(oaIdeaService.selectIdeaPageInfo(0,page,param));
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "查看创意信息", notes = "查看创意信息")
    @GetMapping("/viewIdea/{id}")
    @SystemLog(description = "查看创意信息")
    public Result<OaIdeaInfoVO> viewIdea(@PathVariable("id") Integer id){
        //获取创意详情
        OaIdeaInfoVO oaIdeaInfoVO = oaIdeaService.selectIdeaAllInfoVOById(id);
        //获取当前创意下的转化列表
        QueryWrapper<OaIdeaConversion> queryWrapper = new QueryWrapper<OaIdeaConversion>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("ideaid",id);
        List<OaIdeaConversion>list = oaIdeaConversionService.list(queryWrapper);
        List<OaIdeaConversionVO> list1 = new ArrayList<>();
        for (OaIdeaConversion oaIdeaConversion : list){
            OaIdeaConversionVO oaIdeaConversionVO = new OaIdeaConversionVO();
            CopyUtils.copyProperties(oaIdeaConversion,oaIdeaConversionVO);
            list1.add(oaIdeaConversionVO);
        }
        if(list1 != null && list1.size() > 0){
            oaIdeaInfoVO.setList(list1);
        }
        QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("relation_type","idea_attachment");
        queryWrapper1.eq("relation_id",id);
        List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper1);
        if(commonFilesList != null && commonFilesList.size()>0){
            oaIdeaInfoVO.setCommonFilesList(commonFilesList);
        }
        return Result.returnOk(oaIdeaInfoVO);
    }


    @ApiOperation(value = "提交(流转待审核)/撤回提交(流转待处理)", notes = "提交(流转待审核)/撤回提交(流转待处理)")
    @GetMapping("/submitOrReturnAudit/{id}/{status}")
    @SystemLog(description = "状态变更")
    public Result submitOrReturnAudit(@PathVariable("id") Integer id,@PathVariable("status") Integer status){
        OaIdea oaIdea = new OaIdea();
        oaIdea.setId(id);
        oaIdea.setStatus(status);
        oaIdeaService.updateById(oaIdea);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除创意信息", notes = "删除创意信息")
    @GetMapping("/removeIdea/{id}")
    @SystemLog(description = "删除创意信息")
    public Result removeIdea(@PathVariable("id") Integer id){
        if(null != id){
            oaIdeaService.removeById(id);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "下架创意信息", notes = "下架创意信息")
    @PostMapping ("/offloadIdea")
    @LoginUser
    @SystemLog(description = "下架创意信息")
    public Result offloadIdea(@ApiIgnore AuthUser authUser,@RequestBody OffloadDemandParam param){
        if(null != param){
            //改为已下架状态
            OaIdea oaIdea = new OaIdea();
            oaIdea.setId(param.getId());
            oaIdea.setStatus(4);
            oaIdeaService.updateById(oaIdea);
            //维护下架表
            OaIdeaOffload oaIdeaOffload = new OaIdeaOffload();
            oaIdeaOffload.setIdeaid(param.getId());
            oaIdeaOffload.setResult(param.getReason());
            oaIdeaOffload.setUsername(authUser.getName());
            oaIdeaOffload.setOffloadTime(new Date());
            oaIdeaOffloadService.save(oaIdeaOffload);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "审核(通过流转到已发布3/拒绝流转到待处理1)", notes = "审核(通过流转到已发布3/拒绝流转到待处理1)")
    @PostMapping("/audit/{id}/{status}")
    @LoginUser
    @SystemLog(description = "创意信息审核")
    public Result audit(@ApiIgnore AuthUser authUser,@PathVariable("id") Integer id,@PathVariable("status") Integer status,@RequestBody String reason){
        //获取当前创意下的所有审核信息删除
        QueryWrapper<OaIdeaExamine> queryWrapper = new QueryWrapper<OaIdeaExamine>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("ideaid",id);
        List<OaIdeaExamine> list = oaIdeaExamineService.list(queryWrapper);
        for(OaIdeaExamine oaIdeaExamine : list){
            oaIdeaExamineService.removeById(oaIdeaExamine.getId());
        }
        OaIdea oaIdea = new OaIdea();
        oaIdea.setId(id);
        //审核通过
        if(status == 3){
            oaIdea.setPublishtime(new Date());
            oaIdea.setPublisher(authUser.getName());
            oaIdea.setStatus(3);
            oaIdeaService.updateById(oaIdea);
            OaIdeaExamine oaIdeaExamine = new OaIdeaExamine();
            oaIdeaExamine.setIdeaid(id);
            oaIdeaExamine.setResult("通过");
            oaIdeaExamine.setUsername(authUser.getName());
            oaIdeaExamine.setExamineTime(new Date());
            oaIdeaExamineService.save(oaIdeaExamine);
        }else if(status == 1){ //审核拒绝
            oaIdea.setStatus(1);
            oaIdeaService.updateById(oaIdea);
            OaIdeaExamine oaIdeaExamine = new OaIdeaExamine();
            oaIdeaExamine.setIdeaid(id);
            oaIdeaExamine.setResult("拒绝");
            oaIdeaExamine.setReason(reason);
            oaIdeaExamine.setUsername(authUser.getName());
            oaIdeaExamine.setExamineTime(new Date());
            oaIdeaExamineService.save(oaIdeaExamine);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取评论信息必须要传ideaid即创意id", notes = "分页获取评论信息")
    @PostMapping("/listComment/{pageNum}/{pageSize}")
    @SystemLog(description = "创意下的评论信息")
    public Result<IPage<OaIdeaComment>> listComment(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody CommentSearchParam param){
        Page<OaIdeaComment> page = new Page<OaIdeaComment>(pageNum, pageSize);
        QueryWrapper<OaIdeaComment> queryWrapper = new QueryWrapper<OaIdeaComment>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        if(null != param){
            if(null != param.getIdeaId()){
                queryWrapper.eq("ideaid",param.getIdeaId());
            }
            if(StringUtils.isNotEmpty(param.getName())){
                queryWrapper.like("username",param.getName());
            }
            if(StringUtils.isNotEmpty(param.getContent())){
                queryWrapper.like("content",param.getContent());
            }
            if(null != param.getBegintime()){
                queryWrapper.ge("Date(comment_time)",sdf.format(param.getBegintime()));
            }
            if(null != param.getEndtime()){
                queryWrapper.le("Date(comment_time)",sdf.format(param.getEndtime()));
            }
        }
        queryWrapper.eq("is_del",0);
        IPage<OaIdeaComment> iPage = oaIdeaCommentService.page(page,queryWrapper);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "新增/编辑 创意转化", notes = "新增/编辑 创意转化")
    @PostMapping(value = "/addorUpdateIdeaConversion", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加创意转化")
    public Result addorUpdateIdeaConversion(@ApiIgnore AuthUser authUser, @RequestBody IdeaConvresionParam param) {
        if(null != param){
            OaIdeaConversion oaIdeaConversion = new OaIdeaConversion();
            CopyUtils.copyProperties(param,oaIdeaConversion);
            if(param.getId() != 0){ //修改
                oaIdeaConversionService.updateById(oaIdeaConversion);
            }else{ //添加
                oaIdeaConversionService.save(oaIdeaConversion);
            }
        }
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取转化信息", notes = "分页获取转化信息")
    @PostMapping("/listConversion/{pageNum}/{pageSize}/{ideaid}")
    @SystemLog(description = "分页获取转化信息")
    public Result<IPage<IdeaConversionVO>> listConversion(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize,@PathVariable("ideaid") Integer ideaid){
        Page<IdeaConversionVO> page = new Page<IdeaConversionVO>(pageNum, pageSize);
        IPage<IdeaConversionVO> iPage = page.setRecords(oaIdeaConversionService.listConversion(page,ideaid));
        return Result.returnOk(iPage);
    }


    @ApiOperation(value = "删除创意转化信息", notes = "删除创意转化信息")
    @GetMapping("/removeIdeaConversion/{id}")
    @SystemLog(description = "删除创意转化信息")
    public Result removeIdeaConversion(@PathVariable("id") Integer id){
        oaIdeaConversionService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "app评论", notes = "app评论")
    @PostMapping("/addOaIdeaComment/{id}")
    @LoginUser
    @SystemLog(description = "app评论")
    public Result addOaIdeaComment(@ApiIgnore AuthUser authUser,@PathVariable("id")Integer id,@RequestBody String content){
        OaIdeaComment oaIdeaComment = new OaIdeaComment();
        oaIdeaComment.setIdeaid(id);
        oaIdeaComment.setContent(content);
        oaIdeaComment.setUserid(authUser.getId());
        oaIdeaComment.setUsername(authUser.getName());
        oaIdeaComment.setCommentTime(new Date());
        oaIdeaCommentService.save(oaIdeaComment);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "app创意列表", notes = "app创意列表")
    @PostMapping("/getIdeaListAPP")
    @SystemLog(description = "app评论")
    public Result<List<IdeaAPPInfoVO>> getIdeaListAPP(@RequestBody IdeaAPPSearchParam param){
        List<IdeaAPPInfoVO> list = oaIdeaService.selectIdeaAPPInfo(param);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "创意下的评论信息", notes = "创意下的评论信息")
    @GetMapping("/listCommentById/{id}")
    @SystemLog(description = "查看创意下的评论信息")
    public Result<List<OaIdeaComment>> listCommentById(@PathVariable("id") Integer id){
        QueryWrapper<OaIdeaComment> queryWrapper = new QueryWrapper<OaIdeaComment>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("ideaid",id);
        List<OaIdeaComment> list = oaIdeaCommentService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "评论删除", notes = "评论删除")
    @GetMapping("/removeComment/{id}")
    @SystemLog(description = "删除创意下的评论信息")
    public Result removeComment(@PathVariable("id")Integer id){
        oaIdeaCommentService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "app创意名称模糊筛选", notes = "app创意名称模糊筛选")
    @PostMapping("/getAPPIdeaInfo")
    public Result<List<IdeaTitleInfoVO>> getAPPIdeaInfo(@RequestBody String name){
        QueryWrapper<OaIdea> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.like("idea_name",name);
        List<OaIdea> list = oaIdeaService.list(queryWrapper);
        List<IdeaTitleInfoVO> listVO = new ArrayList<>();
        for (OaIdea OaIdea : list){
            IdeaTitleInfoVO ideaTitleInfoVO = new IdeaTitleInfoVO();
            CopyUtils.copyProperties(OaIdea,ideaTitleInfoVO);
            listVO.add(ideaTitleInfoVO);
        }
        return Result.returnOk(listVO);
    }
}
