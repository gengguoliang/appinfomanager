package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 会议表决表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-02-26
 */
@RestController
@RequestMapping("/oa-conference-vote")
public class OaConferenceVoteController {
    @Autowired
    private IOaConferenceVoteService oaConferenceVoteService;
    @Autowired
    private IOaConferenceParticipantsService oaConferenceParticipantsService;
    @Autowired
    private IOaConferenceReservationService oaConferenceReservationService;
    @Autowired
    private ICommonFilesService commonFilesService;


    @ApiOperation(value = "会议纪要展示列表", notes = "会议纪要展示列表")
    @GetMapping("getMeetingSummary")
    @LoginUser
    @SystemLog(description = "app会议纪要列表")
    public Result<List<MeetingSummaryVO>> getMeetingSummary(@ApiIgnore AuthUser authUser){
        List<MeetingSummaryVO> list = oaConferenceVoteService.selectMeetingSummary(authUser);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "会议纪要已读", notes = "会议纪要已读")
    @GetMapping("/updateMeetingSummary/{id}/{isRead}")
    @LoginUser
    @SystemLog(description = "app会议纪要已读")
    public Result updateMeetingSummary(@ApiIgnore AuthUser authUser, @PathVariable("id") Integer id,@PathVariable("isRead") Integer isRead){
        //更新为阅读状态
        if(isRead == 0){
            QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
            queryWrapper.eq("conference_id",id);
            queryWrapper.eq("user_id",authUser.getId());
            OaConferenceParticipants oaConferenceParticipants = new OaConferenceParticipants();
            oaConferenceParticipants.setIsRead(1);
            oaConferenceParticipants.setUpdateBy(authUser.getName());
            oaConferenceParticipantsService.update(oaConferenceParticipants,queryWrapper);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "纪要详情", notes = "纪要详情")
    @GetMapping("getMeetingDetails/{id}")
    @LoginUser
    @SystemLog(description = "app会议纪要详情")
    public Result getMeetingDetails(@ApiIgnore AuthUser authUser,@PathVariable("id") Integer id){
        Map map = new HashMap();
        QueryWrapper<OaConferenceReservation> queryWrapper2 = new QueryWrapper<OaConferenceReservation>();
        queryWrapper2.eq("id",id);
        OaConferenceReservation oaConferenceReservation = oaConferenceReservationService.getOne(queryWrapper2);
        map.put("meetingName",oaConferenceReservation.getConferencetheme());
        map.put("createBy",oaConferenceReservation.getCreateBy());
        map.put("beginTime",oaConferenceReservation.getBeginTime());

        //获取当前会议下的文档信息
        QueryWrapper<CommonFiles>queryWrapper1 = new QueryWrapper<CommonFiles>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("relation_id",id);
        queryWrapper1.eq("relation_type","meetingsummary");
        List<CommonFiles> list = commonFilesService.list(queryWrapper1);
        map.put("list",list);
        return Result.returnOk(map);
    }
}
