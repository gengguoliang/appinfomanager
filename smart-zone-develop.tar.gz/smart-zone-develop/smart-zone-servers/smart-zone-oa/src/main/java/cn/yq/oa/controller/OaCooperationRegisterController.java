package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.AdvertisingPositionApplyParam;
import cn.yq.oa.param.AdvertisingPositionParam;
import cn.yq.oa.param.CleanUpAttachmentParam;
import cn.yq.oa.param.CooperationRegisterParam;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.CooperationRegisterVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 合作登记表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-03-12
 */
@RestController
@RequestMapping("/oa-cooperation-register")
@Api(value = "合作登记", description = "合作登记 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaCooperationRegisterController {

    @Autowired
    private IOaCooperationRegisterService oaCooperationRegisterService;
    @Autowired
    private IOaRegisterAdvertisingPositionService oaRegisterAdvertisingPositionService;
    @Autowired
    private IOaAdvertisingPositionService oaAdvertisingPositionService;
    @Autowired
    private IOaAdvertisingPositionApplyService oaAdvertisingPositionApplyService;
    @Autowired
    private ICommonFilesService commonFilesService;


    @ApiOperation(value = "添加/编辑合作登记信息", notes = "添加/编辑合作登记信息")
    @PostMapping(value = "/addCooperationRegisterInfo", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加合作登记信息")
    public Result addCooperationRegisterInfo(@ApiIgnore AuthUser authUser, @RequestBody CooperationRegisterParam cooperationRegisterParam) {
        if (null != cooperationRegisterParam) {
            //编辑
            if (null != cooperationRegisterParam.getId() && cooperationRegisterParam.getId() > 0) {
                //编辑合作登记表
                OaCooperationRegister oaCooperationRegister = new OaCooperationRegister();
                CopyUtils.copyProperties(cooperationRegisterParam, oaCooperationRegister);
                oaCooperationRegister.setCreateBy(authUser.getName());
                oaCooperationRegister.setCreateTime(new Date());
                oaCooperationRegisterService.updateById(oaCooperationRegister);
                //获取当前登记id下的所有广告登记关系表id集合
                QueryWrapper<OaRegisterAdvertisingPosition> queryWrapper = new QueryWrapper<OaRegisterAdvertisingPosition>();
                queryWrapper.eq("register_id", oaCooperationRegister.getId());
                queryWrapper.eq("is_del", 0);
                List<OaRegisterAdvertisingPosition> list = oaRegisterAdvertisingPositionService.list(queryWrapper);
                //循环删除关系表
                for (OaRegisterAdvertisingPosition oaRegisterAdvertisingPosition1 : list) {
                    oaRegisterAdvertisingPositionService.removeById(oaRegisterAdvertisingPosition1.getId());
                }
                //关系表维护
                for (Integer id : cooperationRegisterParam.getAdvertisingPositionIds()) {
                    OaRegisterAdvertisingPosition oaRegisterAdvertisingPosition = new OaRegisterAdvertisingPosition();
                    //广告位id
                    oaRegisterAdvertisingPosition.setAdvertisingPositionId(id);
                    //登记表id
                    oaRegisterAdvertisingPosition.setRegisterId(oaCooperationRegister.getId());
                    oaRegisterAdvertisingPositionService.save(oaRegisterAdvertisingPosition);
                }
                //删除当前合作下的合同信息
                QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<CommonFiles>();
                queryWrapper1.eq("is_del",0);
                queryWrapper1.eq("relation_type","cooperation");
                queryWrapper1.eq("relation_id",cooperationRegisterParam.getId());
                List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper1);
                for (CommonFiles commonFiles : commonFilesList){
                    commonFilesService.removeById(commonFiles.getId());
                }
                //上传合同附件
                List<CleanUpAttachmentParam> list1 = cooperationRegisterParam.getList();
                for (CleanUpAttachmentParam cleanUpAttachmentParam : list1) {
                    CommonFiles commonFiles = new CommonFiles();
                    commonFiles.setFileName(cleanUpAttachmentParam.getFileName());
                    commonFiles.setRelationId(oaCooperationRegister.getId());
                    commonFiles.setRelationType("cooperation");
                    commonFiles.setFileUrl(cleanUpAttachmentParam.getFileUrl());
                    commonFilesService.save(commonFiles);
                }
            } else { //添加
                //添加合作登记表
                OaCooperationRegister oaCooperationRegister = new OaCooperationRegister();
                CopyUtils.copyProperties(cooperationRegisterParam, oaCooperationRegister);
                oaCooperationRegisterService.save(oaCooperationRegister);
                //保存关联表数据
                for (Integer id : cooperationRegisterParam.getAdvertisingPositionIds()) {
                    OaRegisterAdvertisingPosition oaRegisterAdvertisingPosition = new OaRegisterAdvertisingPosition();
                    //广告位id
                    oaRegisterAdvertisingPosition.setAdvertisingPositionId(id);
                    //登记表id
                    oaRegisterAdvertisingPosition.setRegisterId(oaCooperationRegister.getId());
                    oaRegisterAdvertisingPositionService.save(oaRegisterAdvertisingPosition);
                    //修改当前合作登记下的广告位为已停用状态
                    OaAdvertisingPosition oaAdvertisingPosition = new OaAdvertisingPosition();
                    oaAdvertisingPosition.setId(id);
                    oaAdvertisingPosition.setStatus(1);
                    oaAdvertisingPositionService.updateById(oaAdvertisingPosition);
                }
                //修改该申请为已完成状态
                OaAdvertisingPositionApply oaAdvertisingPositionApply = new OaAdvertisingPositionApply();
                oaAdvertisingPositionApply.setId(cooperationRegisterParam.getApplicationId());
                oaAdvertisingPositionApply.setStopPerson(authUser.getName());
                oaAdvertisingPositionApply.setStopTime(new Date());
                oaAdvertisingPositionApply.setStatus(3);
                oaAdvertisingPositionApplyService.updateById(oaAdvertisingPositionApply);

                //上传合同附件
                List<CleanUpAttachmentParam> list = cooperationRegisterParam.getList();
                for (CleanUpAttachmentParam cleanUpAttachmentParam : list) {
                    CommonFiles commonFiles = new CommonFiles();
                    commonFiles.setFileName(cleanUpAttachmentParam.getFileName());
                    commonFiles.setRelationId(oaCooperationRegister.getId());
                    commonFiles.setRelationType("cooperation");
                    commonFiles.setFileUrl(cleanUpAttachmentParam.getFileUrl());
                    commonFilesService.save(commonFiles);
                }

            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "查看合作登记信息", notes = "查看合作登记信息")
    @GetMapping("/viewInfoByApplicationid/{id}")
    @SystemLog(description = "查看合作登记信息")
    public Result<CooperationRegisterVO> viewInfoByApplicationid(@PathVariable("id") int id){
        CooperationRegisterVO cooperationRegisterVO = new CooperationRegisterVO();
        //根据id获取登记信息
        QueryWrapper<OaCooperationRegister> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("application_id",id);
        OaCooperationRegister oaCooperationRegister = oaCooperationRegisterService.getOne(queryWrapper);
        if(null != oaCooperationRegister){
            CopyUtils.copyProperties(oaCooperationRegister,cooperationRegisterVO);
            //获取当前合作下的合同集合
            QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<CommonFiles>();
            queryWrapper1.eq("is_del",0);
            queryWrapper1.eq("relation_type","cooperation");
            queryWrapper1.eq("relation_id",oaCooperationRegister.getId());
            List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper1);
            List<CleanUpAttachmentParam> comlist = new ArrayList<>();
            for(CommonFiles commonFiles :commonFilesList){
                CleanUpAttachmentParam cleanUpAttachmentParam = new CleanUpAttachmentParam();
                CopyUtils.copyProperties(commonFiles,cleanUpAttachmentParam);
                comlist.add(cleanUpAttachmentParam);
            }
            cooperationRegisterVO.setCommfilelist(comlist);
            //获取该登记下的所有广告信息
            List<AdvertisingPositionParam> list = oaRegisterAdvertisingPositionService.selectAdvertisingPosition(oaCooperationRegister.getId());
            cooperationRegisterVO.setList(list);
        }
        return Result.returnOk(cooperationRegisterVO);
    }







	
}
