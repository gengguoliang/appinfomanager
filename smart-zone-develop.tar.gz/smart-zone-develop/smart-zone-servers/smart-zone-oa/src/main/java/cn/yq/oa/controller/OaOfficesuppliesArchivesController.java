package cn.yq.oa.controller;

import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.oa.dto.InOrOutQueryDTO;
import cn.yq.oa.dto.OutItemDTO;
import cn.yq.oa.entity.OaOfficesuppliesItem;
import cn.yq.oa.mapper.IOaOfficesuppliesStockOutMapper;
import cn.yq.oa.service.IOaOfficesuppliesItemService;
import cn.yq.oa.service.IOaOfficesuppliesStockOutDetailService;
import cn.yq.oa.service.IOaOfficesuppliesStockOutService;
import cn.yq.oa.service.IOaOfficesuppliesStockService;
import cn.yq.oa.vo.OaOfficesuppliesItemVO;
import cn.yq.oa.vo.OutItemVO;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @program: smart-zone
 * @description: 办公用品档案controller
 * @author: zhengjianhui
 **/
@Api(value = "办公用品档案", description = "办公用品档案")
@RestController
@RequestMapping("/oaOfficesuppliesArchives")
public class OaOfficesuppliesArchivesController {

    @Autowired
    private IOaOfficesuppliesItemService oaOfficesuppliesItemService;
    @Autowired
    private IOaOfficesuppliesStockOutDetailService oaOfficesuppliesStockOutDetailService;
    @Autowired
    private IOaOfficesuppliesStockOutDetailService oaOfficesuppliesStockOutDetaiService;
    @Autowired
    private IOaOfficesuppliesStockService oaOfficesuppliesStockService;
    
    /**
    *@Description 首页物品展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "首页物品展示", notes = "首页物品展示")
    @PostMapping(value = "/showItemPage/{pageNum}/{pageSize}")
    @SystemLog(description = "办公用品档案首页物品展示")
    public Result showItemPage(@PathVariable("pageNum")Integer pageNum,@PathVariable("pageSize")Integer pageSize,@RequestBody OutItemDTO outItemDTO){
        Page<OaOfficesuppliesItemVO> page=new Page<>(pageNum,pageSize);
        IPage<OaOfficesuppliesItemVO> oaOfficesuppliesItemVOIPage = oaOfficesuppliesItemService.showPageItem(page, outItemDTO.getName());
        return Result.returnOk(oaOfficesuppliesItemVOIPage);
    }
    
    /**
    *@Description 0:入库记录 1：领用记录 2：退库记录
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "记录", notes = "记录")
    @PostMapping(value = "/record/{flag}/{pageNum}/{pageSize}")
    @SystemLog(description = "办公用品档案记录信息")
    public Result pageRecord(@PathVariable("flag")Integer flag, @PathVariable("pageNum")int pageNum,@PathVariable("pageSize")int pageSize,
                         @RequestBody InOrOutQueryDTO inOrOutQueryDTO){
        Page page=new Page(pageNum,pageSize);
        IPage Page = oaOfficesuppliesStockOutDetaiService.pageRecord(page, inOrOutQueryDTO, flag);
        return Result.returnOk(page);
    }
    
    /**
    *@Description 物品详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "物品详情", notes = "物品详情")
    @GetMapping(value = "/itemDetail/{id}")
    @SystemLog(description = "办公用品档案物品详情")
    public Result itemDetail(@PathVariable("id")Integer id){
        OutItemVO outItemVO=new OutItemVO();
        OaOfficesuppliesItem oaOfficesuppliesItem = oaOfficesuppliesItemService.getById(id);
        BeanUtils.copyProperties(oaOfficesuppliesItem,outItemVO);
        //根据用品ID查库存和
        int sum = oaOfficesuppliesStockService.getSumByItemId(id);
        outItemVO.setQuantity(sum);
        return Result.returnOk(outItemVO);
    }
}
