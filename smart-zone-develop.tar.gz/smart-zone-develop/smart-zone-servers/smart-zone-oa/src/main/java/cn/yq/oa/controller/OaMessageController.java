package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaMessage;
import cn.yq.oa.param.OaMessageParam;
import cn.yq.oa.service.IOaMessageService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.ApiOperation;
import jodd.util.StringUtil;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 消息提醒 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-09-05
 */
@RestController
@RequestMapping("/oa-message")
@AllArgsConstructor
public class OaMessageController {

     IOaMessageService oaMessageService;

    @ApiOperation(value = "获取待办事项列表", notes = "获取待办事项列表")
    @GetMapping(value = "/getList")
    @LoginUser
    public Result getList(@ApiIgnore AuthUser authUser){
        QueryWrapper<OaMessage> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("username",authUser.getUsername());
        queryWrapper.eq("is_del",0);
        queryWrapper.orderByDesc("update_time");
        List<OaMessage> list = oaMessageService.list(queryWrapper);
        return Result.returnOk(list);
    }


    @ApiOperation(value = "获取待办事项总数", notes = "获取待办事项总数")
    @GetMapping(value = "/getTotalCount")
    @LoginUser
    public Result getTotalCount(@ApiIgnore AuthUser authUser){
        Integer totalCount = oaMessageService.getTotalCount(authUser.getUsername());
        return Result.returnOk(totalCount);
    }

    @ApiOperation(value = "清除待办事项", notes = "清除待办事项")
    @PostMapping(value = "/removeItem")
    @LoginUser
    public Result removeItem(@ApiIgnore AuthUser authUser,  @RequestBody OaMessageParam oaMessageParam){
        QueryWrapper<OaMessage> queryWrapper = new QueryWrapper<>();

        queryWrapper.eq("username",authUser.getUsername());
        if(StringUtil.isNotBlank(oaMessageParam.getItem())){
            queryWrapper.eq("item",oaMessageParam.getItem());
        }
        if(StringUtils.isNotBlank(oaMessageParam.getModule())){
            queryWrapper.eq("module",oaMessageParam.getModule());
        }
        queryWrapper.eq("module_name",oaMessageParam.getModuleName());
        oaMessageService.remove(queryWrapper);
        return Result.returnOk("操作成功");
    }








	
}
