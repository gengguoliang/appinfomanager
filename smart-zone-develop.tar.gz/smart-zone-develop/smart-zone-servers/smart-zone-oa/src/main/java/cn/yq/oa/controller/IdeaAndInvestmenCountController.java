package cn.yq.oa.controller;

import cn.yq.common.result.Result;
import cn.yq.oa.entity.OaIdea;
import cn.yq.oa.service.IOaIdeaService;
import cn.yq.oa.service.IOaServiceDemandService;
import cn.yq.oa.service.IdeaAndInvestmenCountService;
import cn.yq.oa.vo.DemandPushVO;
import cn.yq.oa.vo.bigscreen.CommonPieVO;
import cn.yq.oa.vo.oaservicedemand.DemandVO;
import cn.yq.oa.vo.oaservicedemand.ServiceDemandVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * @Author: ggl
 * @Date: 2019/5/13 15:27
 * @Description: 投融资、技术咨询系统
 */
@RestController
@Api(value = "投融资、技术咨询系统", description = "投融资、技术咨询系统 API", position = 100, protocols = "http")
@RequestMapping("/idea-investmen-count")
@Slf4j
public class IdeaAndInvestmenCountController {

    @Autowired
    private IdeaAndInvestmenCountService ideaAndInvestmenCountService;
    @Autowired
    private IOaIdeaService oaIdeaService;
    @Autowired
    private IOaServiceDemandService oaServiceDemandService;


    @ApiOperation(value = "投融资数据统计", notes = "投融资数据统计")
    @GetMapping("/getInvestmenCount")
    public Result getInvestmenCount(){
        Map map = new HashMap();
        //获取投资领域饼状图统计信息
        List<CommonPieVO> list = ideaAndInvestmenCountService.selectPieCount();
        //获取投资阶段饼状图信息
        List<CommonPieVO> list1 = ideaAndInvestmenCountService.selectStagePieCount();
        map.put("list",list);
        map.put("list1",list1);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "技术咨询", notes = "技术咨询")
    @GetMapping("/getTechnology")
    public Result getTechnology(){
        Map map = new HashMap();
        //获取创意空间饼状图统计
        List<CommonPieVO> list = ideaAndInvestmenCountService.getIdeaPio();
        //获取创意信息
        QueryWrapper<OaIdea> wrapper = new QueryWrapper();
        wrapper.eq("is_del",0);
        wrapper.eq("status",3);
        wrapper.orderByDesc("publishtime");
        List<OaIdea> list1 = oaIdeaService.list(wrapper);
        map.put("list",list);
        map.put("list1",list1);
        map.put("count",list1.size());
        return Result.returnOk(map);
    }

    @ApiOperation(value = "发布统计", notes = "发布统计")
    @GetMapping("/getpublishCount")
    public Result getpublishCount(){
        return ideaAndInvestmenCountService.getpublishCount();
    }

    /**
    *@Description 服务纵包圆环图
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "服务纵包圆环图", notes = "服务纵包圆环图")
    @GetMapping("/serviceStatistics")
    public Result<Map<String, Object>> serviceStatistics(){
        Map<String, Object> map = oaServiceDemandService.serviceStatistics();
        return Result.returnOk(map);
    }

    /**
    *@Description 服务纵包需求名称表格
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "服务纵包需求名称表格", notes = "服务纵包需求名称表格")
    @GetMapping("/serviceDemand")
    public Result<List<ServiceDemandVO>> serviceDemand(){
        List<ServiceDemandVO> serviceDemandVOS = oaServiceDemandService.serviceDemand();
        return Result.returnOk(serviceDemandVOS);
    }
    
    /**
    *@Description 发布统计的服务纵包
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "发布统计的服务纵包", notes = "发布统计的服务纵包")
    @GetMapping("/demandPush")
    public Result<List<DemandPushVO>> demandPush(){
        List<DemandPushVO> demandPushVOS = oaServiceDemandService.demandPush();
        return Result.returnOk(demandPushVOS);
    }



}
