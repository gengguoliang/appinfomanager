package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.oa.entity.MyContactUs;
import cn.yq.oa.param.MyContactUsParam;
import cn.yq.oa.service.IMyContactUsService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import java.util.List;

/**
 * <p>
 * 联系我们信息表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-04-28
 */
@RestController
@RequestMapping("/my-contact-us")
@Api(value = "联系我们", description = "ggl联系我们 API", position = 100, protocols = "http")
@AllArgsConstructor
public class MyContactUsController {

	private IMyContactUsService myContactUsService;

    @ApiOperation(value = "添加（id传0）或编辑（id传实际值）", notes = "添加或编辑")
    @PostMapping(value = "/addMyContactUs", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加联系我们",table = LogTableConstant.MY_CONTACT_US)
    public Result addMyContactUs(@RequestBody MyContactUsParam param){
        if(null != param){
            MyContactUs myContactUs = new MyContactUs();
            CopyUtils.copyProperties(param,myContactUs);
            if(param.getId() != 0){//编辑
                myContactUsService.updateById(myContactUs);
            }else{//新增
                myContactUsService.save(myContactUs);
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取联系我们", notes = "分页获取联系我们")
    @GetMapping("/listMyContactUs/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询联系我们",table = LogTableConstant.MY_CONTACT_US)
    public Result<IPage<MyContactUs>> listMyContactUs(@PathVariable("pageNum") int pageNum,
                                  @PathVariable("pageSize") int pageSize){
        Page<MyContactUs> page = new Page<>(pageNum,pageSize);
        QueryWrapper<MyContactUs> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del",0);
        IPage<MyContactUs> iPage = myContactUsService.page(page,wrapper);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/removeMyContactUs/{id}")
    @SystemLog(description = "删除联系我们信息",table = LogTableConstant.MY_CONTACT_US)
    public Result removeMyContactUs(@PathVariable("id") Integer id){
        myContactUsService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "app联系我们", notes = "app联系我们")
    @GetMapping("/listAPPMyContactUs")
    @SystemLog(description = "app端查询联系我们信息",table = LogTableConstant.MY_CONTACT_US)
    public Result<List<MyContactUs>> listAPPMyContactUs(){
        QueryWrapper<MyContactUs> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del",0);
        List<MyContactUs> list = myContactUsService.list(wrapper);
        return Result.returnOk(list);
    }
}
