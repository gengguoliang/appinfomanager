package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.push.annotations.Notification;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.common.enumeration.PropertyNoEnum;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.AuditingParam;
import cn.yq.oa.param.ElevatorApplyParam;
import cn.yq.oa.param.OaPropertyElevatorApplyParam;
import cn.yq.oa.param.TimesDetailParam;
import cn.yq.oa.service.*;
import cn.yq.oa.util.DateUtils;
import cn.yq.oa.vo.*;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.*;

/**
 * <p>
 * 货梯申请表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-06
 */
@Api(value = "货梯申请", description = "货梯申请")
@RestController
@RequestMapping("/oa-property-elevator-apply")
public class OaPropertyElevatorApplyController {
    @Autowired
    private IOaPropertyElevatorApplyService oaPropertyElevatorApplyService;
    @Autowired
    private OrderNumberService orderNumberService;
    @Autowired
    private IOaPropertyElevatorReserveTimeDetailService oaPropertyElevatorReserveTimeDetailService;
    @Autowired
    private IOaPropertyElevatorInformationService oaPropertyElevatorInformationService;
    @Autowired
    private IOaPropertyElevatorTimeSlotService oaPropertyElevatorTimeSlotService;
    @Autowired
    private IAuthOrganizationService authOrganizationService;
    @Autowired
    private IOaRecruitService oaRecruitService;

    /**
     * @param pageNum
     * @param pageSize
     * @param elevatorApplyParam
     * @return
     */
    @ApiOperation(value = "分页信息展示", notes = "分页信息展示")
    @PostMapping("/getElevatorApplyInfo/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查看货梯信息")
    public Result<IPage<OaPropertyElevatorApplyInfoVO>> getElevatorApplyInfo(@PathVariable("pageNum") Integer pageNum,
                                       @PathVariable("pageSize") Integer pageSize,
                                       @RequestBody ElevatorApplyParam elevatorApplyParam) {
        Page<OaPropertyElevatorApplyInfoVO> page = new Page<OaPropertyElevatorApplyInfoVO>(pageNum, pageSize);
        IPage<OaPropertyElevatorApplyInfoVO> iPage = oaPropertyElevatorApplyService.selectElevatorApplyInfo(page, elevatorApplyParam);
        for (OaPropertyElevatorApplyInfoVO oaPropertyElevatorApplyInfoVO : iPage.getRecords()){
            List<ElevatorTimeSlotVO> list1 = oaPropertyElevatorReserveTimeDetailService.selectElevatorApplyDetail(oaPropertyElevatorApplyInfoVO.getId());
            oaPropertyElevatorApplyInfoVO.setList(list1);
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "添加货梯申请", notes = "添加货梯申请")
    @PostMapping("/addElevatorApply")
    @LoginUser
    @SystemLog(description = "添加货梯申请")
    public Result addElevatorApply(@ApiIgnore AuthUser authUser,@RequestBody OaPropertyElevatorApplyParam oaPropertyElevatorApplyParam) {
        //添加货梯申请表并返回当前id
        OaPropertyElevatorApply oaPropertyElevatorApply = new OaPropertyElevatorApply();
        CopyUtils.copyProperties(oaPropertyElevatorApplyParam, oaPropertyElevatorApply);

        //生成申请编号
        String num = orderNumberService.getOneOrderNumber(PropertyNoEnum.CART_APPLICATION_NO.getPrefix());
        oaPropertyElevatorApply.setApplyNumber(num);
        if(oaPropertyElevatorApplyParam.getFlag() ==1){ //PC
            oaPropertyElevatorApply.setStatus(1);
            oaPropertyElevatorApply.setApplicantId(0);
            oaPropertyElevatorApply.setAuditorId(authUser.getId());
            oaPropertyElevatorApply.setAuditTime(new Date());
        }else{ //APP
            oaPropertyElevatorApply.setApplicantId(authUser.getId());
        }
        oaPropertyElevatorApplyService.save(oaPropertyElevatorApply);
        for (TimesDetailParam param : oaPropertyElevatorApplyParam.getList()){
            //添加预约时间明细表
            OaPropertyElevatorReserveTimeDetail oaPropertyElevatorReserveTimeDetail = new OaPropertyElevatorReserveTimeDetail();
            oaPropertyElevatorReserveTimeDetail.setApplyId(oaPropertyElevatorApply.getId());
            oaPropertyElevatorReserveTimeDetail.setReservationDate(param.getOrderTime());
            oaPropertyElevatorReserveTimeDetail.setTimesId(param.getTimeId());
            oaPropertyElevatorReserveTimeDetailService.save(oaPropertyElevatorReserveTimeDetail);
        }
        return Result.returnOk("操作成功");
    }

    /**
     * @param id 预约id
     * @return
     */
    @ApiOperation(value = "查看货梯预约详情", notes = "查看货梯预约详情")
    @GetMapping("/getElevatorApplyInfoById/{id}")
    @SystemLog(description = "查看货梯预约详情")
    public Result getElevatorApplyInfoById(@PathVariable("id") Integer id) {
        OaPropertyElevatorApplyInfoVO oaPropertyElevatorApplyInfoVO = oaPropertyElevatorApplyService.selectElevatorApplyInfoById(id);
        //获取当前申请下的货梯名称
        OaPropertyElevatorInformation oaPropertyElevatorInformation = oaPropertyElevatorInformationService.getById(oaPropertyElevatorApplyInfoVO.getElevatorId());
        oaPropertyElevatorApplyInfoVO.setElevatorName(oaPropertyElevatorInformation.getElevatorName());
        //获取当前申请表的下的预约日期
        List<ElevatorTimeSlotVO> list = oaPropertyElevatorReserveTimeDetailService.selectElevatorApplyDetail(oaPropertyElevatorApplyInfoVO.getId());
        oaPropertyElevatorApplyInfoVO.setList(list);
        return Result.returnOk(oaPropertyElevatorApplyInfoVO);
    }

    /**
     * @param authUser
     * @param id            预约id
     * @param auditingParam
     * @return
     */
    @ApiOperation(value = "审核", notes = "审核")
    @PostMapping("/updateAuditing/{id}")
    @LoginUser
    @StatusChangedNotification("货梯")
    @SystemLog(description = "货梯申请审核")
    public Result updateAuditing(@ApiIgnore AuthUser authUser, @PathVariable("id") Integer id, @RequestBody AuditingParam auditingParam) {

        PushUtil.setTargetUsername(oaPropertyElevatorApplyService.selectApplyByUserName(id));
        OaPropertyElevatorApply oaPropertyElevatorApply = new OaPropertyElevatorApply();
        oaPropertyElevatorApply.setId(id);
        oaPropertyElevatorApply.setAuditorId(authUser.getId());
        oaPropertyElevatorApply.setStatus(auditingParam.getStatus());
        oaPropertyElevatorApply.setAuditNotes(auditingParam.getAuditNotes());
        oaPropertyElevatorApply.setAuditTime(new Date());
        oaPropertyElevatorApplyService.updateById(oaPropertyElevatorApply);
        return Result.returnOk("操作成功");
    }

    /**
     * @param id           预约id
     * @param revokeReason 撤销理由
     * @return
     */
    @ApiOperation(value = "撤销申请", notes = "撤销申请")
    @PostMapping("/updateRevokeApply/{id}")
    @SystemLog(description = "货梯申请撤销")
    public Result updateRevokeApply(@PathVariable("id") Integer id, @RequestBody  String revokeReason) {
        //修改该申请为撤销状态
        OaPropertyElevatorApply oaPropertyElevatorApply = new OaPropertyElevatorApply();
        oaPropertyElevatorApply.setId(id);
        oaPropertyElevatorApply.setStatus(3);
        oaPropertyElevatorApply.setWithdrawTime(new Date());
        oaPropertyElevatorApply.setWithdrawReason(revokeReason);
        oaPropertyElevatorApplyService.updateById(oaPropertyElevatorApply);
        //删除当前申请下得预约时间明细
        oaPropertyElevatorReserveTimeDetailService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * @param id
     * @return
     */
    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/removeApplyById/{id}")
    @SystemLog(description = "删除货梯申请")
    public Result removeApplyById(@PathVariable("id") Integer id) {
        oaPropertyElevatorApplyService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "app列表展示", notes = "app列表展示")
    @GetMapping("/getElevatorApplyByUserId/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "app货梯申请列表")
    public Result<IPage<ElevatorApplyAppVO>> getElevatorApplyByUserId(@ApiIgnore AuthUser authUser,
                                           @PathVariable("pageNum") Integer pageNum,
                                           @PathVariable("pageSize") Integer pageSize) {
        Page<ElevatorApplyAppVO> page = new Page<>(pageNum,pageSize);

        IPage<ElevatorApplyAppVO> list = page.setRecords(oaPropertyElevatorApplyService.selectElevatorApplyByUserId(authUser.getOrganizationId(),page));
        for(ElevatorApplyAppVO elevatorApplyAppVO : list.getRecords()){
            List<ElevatorTimeSlotVO> list1 = oaPropertyElevatorReserveTimeDetailService.selectElevatorApplyDetail(elevatorApplyAppVO.getId());
            elevatorApplyAppVO.setList(list1);
        }
        return Result.returnOk(list);
    }

    @ApiOperation(value = "app添加关联信息", notes = "app添加关联信息")
    @GetMapping("/getUserInfo")
    @LoginUser
    public Result getUserInfo(@ApiIgnore AuthUser authUser) {
        Map map = new HashMap();
        boolean flag = false;
        map.put("name",authUser.getName());
        map.put("mobile",authUser.getMobile());
        String organizationName = oaPropertyElevatorApplyService.selectOrganizationName(authUser.getOrganizationId());
        map.put("organizationName",organizationName);
        map.put("orgId",authUser.getOrganizationId());
        //判断当前用户是否是物业公司
        QueryWrapper<AuthOrganization> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("type",2);
        queryWrapper.eq("id",authUser.getOrganizationId());
        AuthOrganization authOrganization = authOrganizationService.getOne(queryWrapper);
        if(null != authOrganization){
            List<RelationAllInfoVO> list =  oaPropertyElevatorApplyService.selectRelationAllInfo();
            map.put("list",list);
            flag = true;
        }else{
            List<RelationInfoVO> list = oaPropertyElevatorApplyService.selectRelationInfo(authUser);
            map.put("list",list);
        }
        map.put("flag",flag);
        /**
         * 人才招聘管理的最新logo获取  zjh
         */
        QueryWrapper<OaRecruit> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("orgid", authUser.getOrganizationId())
                .orderByDesc("create_time");
        List<OaRecruit> list = oaRecruitService.list(queryWrapper1);
        String logo = "";
        if (!ObjectUtils.isEmpty(list) && list.get(0).getLogo() != null) {
            logo = list.get(0).getLogo();
        }
        map.put("logo", logo);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "单元下的货梯信息和单位信息", notes = "单元下的货梯信息和单位信息")
    @GetMapping("/getElevator/{unitId}")
    public Result getElevator(@PathVariable("unitId") Integer unitId) {
        Map map = new HashMap();
        List<OaPropertyElevatorInformation> list = new ArrayList<OaPropertyElevatorInformation>();
        if (null == unitId || unitId == 0) {
            QueryWrapper<OaPropertyElevatorInformation> queryWrapper = new QueryWrapper<OaPropertyElevatorInformation>();
            queryWrapper.eq("is_del",0);
            queryWrapper.eq("status",0);
            list = oaPropertyElevatorInformationService.list(queryWrapper);
        } else {
            list = oaPropertyElevatorInformationService.selectElevatorByUnitId(unitId);
        }
        map.put("list",list);
        List<String> orglist = oaPropertyElevatorInformationService.selectOrganizationName(unitId);
        map.put("orglist",orglist);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "app预约时间筛选", notes = "app预约时间筛选")
    @GetMapping("/getOrderTimes/{elevatorId}")
    @SystemLog(description = "货梯申请预约时间筛选")
    public Result getOrderTimes(@PathVariable("elevatorId") Integer elevatorId) {
        //获取货梯的使用时间段集合
        QueryWrapper<OaPropertyElevatorTimeSlot> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        List<OaPropertyElevatorTimeSlot> list = oaPropertyElevatorTimeSlotService.list(queryWrapper);
        List<APPElevatorTimeVO> list1 = new ArrayList<APPElevatorTimeVO>();
        //获取当前货梯下未来三天的所有使用明细
        for (int i = 0; i < 3; i++) {
            Date date = DateUtils.getdate(i);
            APPElevatorTimeVO appElevatorTimeVO = new APPElevatorTimeVO();
            appElevatorTimeVO.setReservationDate(date);
            //获取这个货梯某一天的使用情况
            List<ElevatorTimeDetailVO> listTimeDetail = oaPropertyElevatorReserveTimeDetailService.selectAllElevatorReserveTimeDetail(elevatorId, date);
            List<ElevatorTimeSlotVO> list3 = new ArrayList<ElevatorTimeSlotVO>();
            //所有货梯时间段列表
            for (int j = 0; j < list.size(); j++) {
                OaPropertyElevatorTimeSlot oaPropertyElevatorTimeSlot = list.get(j);
                ElevatorTimeSlotVO elevatorTimeSlotVO = new ElevatorTimeSlotVO();
                int  num = 0;
                //所有这天被使用的时间段列表
                for (int k = 0; k < listTimeDetail.size(); k++) {
                    ElevatorTimeDetailVO elevatorTimeDetailVO = listTimeDetail.get(k);
                    if(oaPropertyElevatorTimeSlot.getId() == elevatorTimeDetailVO.getTimesId()){
                        num++;
                        break;
                    }
                }
                if(num == 0){
                    CopyUtils.copyProperties(oaPropertyElevatorTimeSlot,elevatorTimeSlotVO);
                    list3.add(elevatorTimeSlotVO);
                }
            }

            appElevatorTimeVO.setElevatorTimeSlotVO(list3);
            list1.add(appElevatorTimeVO);
        }
        return Result.returnOk(list1);
    }

    @ApiOperation(value = "楼层楼宇单元信息", notes = "楼层楼宇单元信息")
    @GetMapping("/getRelationAllInfo")
    public Result getRelationAllInfo(){
      List<RelationAllInfoVO> list =  oaPropertyElevatorApplyService.selectRelationAllInfo();
      return  Result.returnOk(list);
    }

}
