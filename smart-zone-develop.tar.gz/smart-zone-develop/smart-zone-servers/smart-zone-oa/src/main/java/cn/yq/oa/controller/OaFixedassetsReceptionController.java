package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.PrimaryGenerater;
import cn.yq.oa.entity.OaFixedassets;
import cn.yq.oa.entity.OaFixedassetsBizDetail;
import cn.yq.oa.entity.OaFixedassetsReception;
import cn.yq.oa.param.OaFixedassetsReceptionParam;
import cn.yq.oa.param.ReceptionSearchParam;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsReceptionService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.impl.OrderNumberServiceImpl;
import cn.yq.oa.vo.OaFixedassetsReceptionVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 固定资产领用表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-01
 */
@RestController
@RequestMapping("/oa-fixedassets-reception")
@AllArgsConstructor
public class OaFixedassetsReceptionController {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    IOaFixedassetsReceptionService oaFixedassetsReceptionService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsService oaFixedassetsService;

    @Resource(name = "orderNumberServiceImpl")
    OrderNumberServiceImpl orderNumberService;

    @PostMapping("/addReception")
    @SystemLog(description = "添加固定资产领用信息")
    public Result addReception(@RequestBody OaFixedassetsReceptionParam oaFixedassetsReceptionParam){

        OaFixedassetsReception oaFixedassetsReception = new OaFixedassetsReception();
        BeanUtils.copyProperties(oaFixedassetsReceptionParam,oaFixedassetsReception);
        //领用单号
//        String dh = "LYD" + PrimaryGenerater.geneterNextNumber(sdf.format(new Date()));
        String dh = orderNumberService.getOneOrderNumber("LYD");
        oaFixedassetsReception.setNo(dh);

        //保存领用表数据
        oaFixedassetsReceptionService.saveOrUpdate(oaFixedassetsReception);
        //获取领用单id
        int id = oaFixedassetsReception.getId();
        //保存业务明细表数据
        List<Integer> list = oaFixedassetsReceptionParam.getIds();

        for (Integer temp:list){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //领用
            oaFixedassetsBizDetail.setBizType(0);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp);
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
        //修改资产状态(根据资产id)
        for (Integer temp:list){
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(temp);
            //领用中
            oaFixedassets.setStatus(1);
            //修改固定资产主表（当前所在部门）
            oaFixedassets.setDeptid(oaFixedassetsReceptionParam.getDepartmentId());
            oaFixedassetsService.updateById(oaFixedassets);
        }
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllReceptions/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产领用信息")
    public Result getAllReceptions(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody ReceptionSearchParam receptionSearchParam){

        Page<OaFixedassetsReceptionVo> page= new Page<OaFixedassetsReceptionVo>(pageNum,pageSize);
//        IPage<OaFixedassetsReception> list = oaFixedassetsReceptionService.selectReceptionsPage(page,receptionSearchParam);
        IPage<OaFixedassetsReceptionVo> iPage = oaFixedassetsReceptionService.selectReceptionsVoPage(page, receptionSearchParam);
        return Result.returnOk(iPage);
    }



    /**
     * 导出功能
     */
    @PostMapping("/getReceptions")
    @SystemLog(description = "固定资产领用信息导出")
    public Result getReceptions( @RequestBody ReceptionSearchParam receptionSearchParam){
        List<OaFixedassetsReception> receptions = oaFixedassetsReceptionService.selectReceptions(receptionSearchParam);
        return Result.returnOk(receptions);
    }

    /**
     * 导出Excel
     */
    @PostMapping("/exportExcel")
    @SystemLog(description = "固定资产领用信息导出为Exel")
    public Result exportExcel( @RequestBody ReceptionSearchParam receptionSearchParam){
        List list = oaFixedassetsReceptionService.exportExcel(receptionSearchParam);
        return Result.returnOk(list);
    }

    /**
     * 删除功能
     */
    @GetMapping("/deleteReception/{id}")
    @SystemLog(description = "删除固定资产领用信息")
    public Result deleteReception(@PathVariable("id") int id){
        oaFixedassetsReceptionService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 查看详情
     */
    @GetMapping("/getReceptionById/{id}")
    @SystemLog(description = "固定资产领用信息详情")
    public Result getReceptionById(@PathVariable("id") int id){
        Map map = new HashMap<>();
        OaFixedassetsReception oaFixedassetsReception = oaFixedassetsReceptionService.getById(id);
        map.put("receptionInfo",oaFixedassetsReception);
        //固定资产列表
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",0);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        //查询固定资产表
        Collection list1=null;
        if (ids.size()>0){
            list1 = oaFixedassetsService.listByIds(ids);
        }
        map.put("list",list1);
        return Result.returnOk(map);
    }





}
