package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.oa.entity.OaAdvertisingPosition;
import cn.yq.oa.entity.OaParkingLot;
import cn.yq.oa.param.AdvertisingPositionParam;
import cn.yq.oa.param.ParkingLotParam;
import cn.yq.oa.param.ParkingLotSearchParam;
import cn.yq.oa.param.PositionSearchParam;
import cn.yq.oa.service.IOaParkingLotService;
import cn.yq.oa.vo.OaAdvertisingPositionVO;
import cn.yq.oa.vo.OaParkingLotVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 停车场信息管理表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-12
 */
@RestController
@RequestMapping("/oa-parking-lot")
@Api(value = "停车场信息管理", description = "停车场信息管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaParkingLotController {
    @Autowired
    private IOaParkingLotService oaParkingLotService;

    @ApiOperation(value = "添加或修改停车场信息", notes = "添加或修改停车场信息")
    @PostMapping(value = "/addOrSaveParkingLot", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加或修改停车场信息")
    public Result addOrSaveParkingLot(@RequestBody ParkingLotParam parkingLotParam) {
        OaParkingLot oaParkingLot = new OaParkingLot();
        if(null != parkingLotParam){
            CopyUtils.copyProperties(parkingLotParam,oaParkingLot);
            if(null != parkingLotParam.getId() && parkingLotParam.getId()>0){
                oaParkingLotService.updateById(oaParkingLot);
            }else{
                oaParkingLotService.save(oaParkingLot);
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "根据id获取停车位信息", notes = "根据id获取停车位信息")
    @GetMapping("/getParkingLotInfo/{id}")
    @SystemLog(description = "停车场信息详情")
    public Result getParkingLotInfo(@PathVariable("id")Integer id){
        OaParkingLot oaParkingLot = oaParkingLotService.getById(id);
        return  Result.returnOk(oaParkingLot);
    }

    @ApiOperation(value = "分页获取停车场列表", notes = "分页获取停车场列表")
    @PostMapping("/listParkingLot/{pageNum}/{pageSize}")
    @SystemLog(description = "分页获取停车场列表")
    public Result listParkingLot(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize,@RequestBody ParkingLotSearchParam param){
        Page<OaParkingLotVO> page= new Page<OaParkingLotVO>(pageNum,pageSize);
        IPage<OaParkingLotVO> iPage = oaParkingLotService.selectOaParkingLot(page,param);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "停用、启用停车场", notes = "停用、启用停车场")
    @GetMapping("/changeStatusById/{id}/{status}")
    @SystemLog(description = "停用、启用停车场")
    public Result changeStatusById(@PathVariable("id") int id,@PathVariable("status") int status){
        OaParkingLot oaParkingLot = new OaParkingLot();
        oaParkingLot.setId(id);
        oaParkingLot.setStatus(status);
        oaParkingLotService.updateById(oaParkingLot);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除停车场", notes = "删除停车场")
    @GetMapping("/deleteParkingLotById/{id}")
    @SystemLog(description = "删除停车场信息")
    public Result deleteParkingLotById(@PathVariable("id") int id){
        oaParkingLotService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "根据区域获取停车场信息", notes = "根据区域获取停车场信息")
    @GetMapping("/getParkingLotInfoByRegionid/{id}")
    @SystemLog(description = "根据区域获取停车场信息")
    public Result getParkingLotInfoByRegionid(@PathVariable("id") int id){
        QueryWrapper<OaParkingLot> queryWrapper = new QueryWrapper<OaParkingLot>();
        queryWrapper.eq("region",id);
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("status",0);
        List<OaParkingLot> list = oaParkingLotService.list(queryWrapper);
        return Result.returnOk(list);
    }



	
}
