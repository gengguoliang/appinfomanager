package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oabill.BillDTO;
import cn.yq.oa.dto.oabill.OaBillAddDTO;
import cn.yq.oa.dto.oabill.OabillShowDTO;
import cn.yq.oa.entity.OaBill;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.mapper.IOaBillMapper;
import cn.yq.oa.service.IOaBillService;
import cn.yq.oa.service.ISysDictDataService;
import cn.yq.oa.vo.oabill.AppDetailVO;
import cn.yq.oa.vo.oabill.AppShowVO;
import cn.yq.oa.vo.oabill.BillShowVO;
import cn.yq.oa.vo.oabill.UnitOrganizationVO;
import cn.yq.push.annotations.Notification;
import cn.yq.push.enumeration.PushRange;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 账单表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-20
 */
@Api(value = "zjh账单管理", description = "zjh账单管理")
@RestController
@RequestMapping("/oa-bill")
public class OaBillController {

    @Autowired
    private IOaBillService oaBillService;
    @Autowired
    private ISysDictDataService sysDictDataService;
    @Autowired
    private IOaBillMapper oaBillMapper;
    
    
    /**
    *@Description PC账单分类下拉框
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC账单分类下拉框", notes = "PC账单分类下拉框")
    @GetMapping(value = "/billCatogery")
    @SystemLog(description = "删除通知",table = LogTableConstant.SYS_DICT_DATA)
    public Result<List<SysDictData>> billCatogery(){
        List<SysDictData> sysDictDataList = sysDictDataService.billCatogery();
        return Result.returnOk(sysDictDataList);
    }

    /**
     *@Description PC添加账单时的单元与客户级联
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    @ApiOperation(value = "PC添加账单时的单元与客户级联", notes = "PC添加账单时的单元与客户级联")
    @GetMapping(value = "/unitOrganization")
    public Result<List<UnitOrganizationVO>> unitOrganization(){
        List<UnitOrganizationVO> unitOrganizationVOS = oaBillService.unitOrganization();
        return Result.returnOk(unitOrganizationVOS);
    }

    /**
    *@Description PC添加账单(编辑也调用此接口)
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC添加账单(编辑也调用此接口)", notes = "PC添加账单(编辑也调用此接口)")
    @PostMapping(value = "/addBill")
    @LoginUser
    @SystemLog(description = "添加账单")
    public Result addBill(@ApiIgnore AuthUser authUser,@RequestBody OaBillAddDTO oaBillAddDTO){
        oaBillService.addBill(authUser,oaBillAddDTO);
        return Result.returnOk();
    }
    
    /**
    *@Description PC列表展示(3个模块公用此接口，包括详情直接从里面获取)
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC列表展示(3个模块公用此接口，包括详情直接从里面获取)", notes = "PC列表展示(3个模块公用此接口，包括详情直接从里面获取)")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询账单信息")
    public Result<IPage<BillShowVO>> showPage(@PathVariable("pageNum")Integer pageNum,
                                       @PathVariable("pageSize")Integer pageSize,
                                       @RequestBody OabillShowDTO oabillShowDTO){
        Page<BillShowVO> page=new Page<>(pageNum,pageSize);
        IPage<BillShowVO> iPage=page.setRecords(oaBillService.showPage(page,oabillShowDTO));
        return Result.returnOk(iPage);
    }
    
    /**
    *@Description PC改变状态都调用此接口
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC改变状态都调用此接口", notes = "PC改变状态都调用此接口")
    @PostMapping(value = "/changeStatus")
    @LoginUser
    @Notification(name = "在线缴费",range = PushRange.USER)
    @SystemLog(description = "账单信息状态变更")
    public Result changeStatus(@ApiIgnore AuthUser authUser, @RequestBody BillDTO billDTO){
        oaBillService.changeStatus(authUser,billDTO);
        //消息推送
        OaBill oaBill = oaBillService.getById(billDTO.getId());
        if(billDTO.getStatus()==2){
            String[] adminNames = oaBillMapper.queryAaminName(oaBill.getOrganizationId());
            PushUtil.setTargetUsername(adminNames);
        }
        return Result.returnOk();
    }
    
    /**
    *@Description PC删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC删除", notes = "PC删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "账单信息删除",table = LogTableConstant.OA_BILL)
    public Result remove(@PathVariable("id")Integer id){
        oaBillService.remove(id);
        return Result.returnOk();
    }
    
    /**
    *@Description PC批量提交
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC批量提交", notes = "PC批量提交")
    @PostMapping(value = "/commit")
    @SystemLog(description = "账单信息批量提交",table = LogTableConstant.OA_BILL)
    public Result commit(@RequestBody List<Integer> ids){
        oaBillService.commit(ids);
        return Result.returnOk();
    }
    /**
     *@Description APP端的列表展示，flag 0:在线缴费  1：本月缴费记录  2：其它缴费记录
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    @ApiOperation(value = "APP端的列表展示，flag 0:在线缴费  1：本月缴费记录  2：其它缴费记录", notes = "APP端的列表展示，flag 0:在线缴费  1：本月缴费记录  2：其它缴费记录")
    @GetMapping(value = "/appShow/{flag}")
    @LoginUser
    @SystemLog(description = "app端查询账单信息")
    public Result<List<AppShowVO>> appShow(@ApiIgnore AuthUser authUser, @PathVariable("flag") Integer flag){
        List<AppShowVO> appShowVOS = oaBillService.appShow(authUser, flag);
        return Result.returnOk(appShowVOS);
    }
    
    
    /**
    *@Description APP端详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "APP端详情", notes = "APP端详情")
    @GetMapping(value = "/appDetail/{id}")
    @SystemLog(description = "APP端账单详情")
    public Result<AppDetailVO> appDetail(@PathVariable("id")Integer id){
        AppDetailVO appDetailVO = oaBillService.appDetail(id);
        return Result.returnOk(appDetailVO);
    }

}
