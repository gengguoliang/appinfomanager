package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.oa.entity.OaBusinessCategory;
import cn.yq.oa.entity.OaFixedassetsCategory;
import cn.yq.oa.entity.OaParkingRegion;
import cn.yq.oa.param.OaBusinessCatParam;
import cn.yq.oa.param.OaRegionParam;
import cn.yq.oa.service.IOaBusinessCategoryService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 合作商家分类表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-31
 */
@RestController
@RequestMapping("/oa-business-category")
@Api(value = "zhengjh合作商家分类管理", description = "zhengjh合作商家分类管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaBusinessCategoryController {

    @Autowired
    private IOaBusinessCategoryService oaBusinessCategoryService;

    @ApiOperation(value = "添加或修改分类", notes = "添加或修改分类")
    @PostMapping(value = "/addOrUpdateCategory", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加或修改分类",table = LogTableConstant.OA_BUSINESS_CATEGORY)
    public Result addOrUpdateCategory(@RequestBody OaBusinessCatParam param) {
        Result result = oaBusinessCategoryService.addOrUpdateCategory(param);
        return result;
    }

    //分页获取分类列表
    @ApiOperation(value = "分页获取分类列表", notes = "分页获取分类列表")
    @GetMapping("/getAllCategory/{pageNum}/{pageSize}")
    @SystemLog(description = "分页获取分类列表",table = LogTableConstant.OA_BUSINESS_CATEGORY)
    public Result getAllCategory(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize){
        Page<OaBusinessCategory> page= new Page<OaBusinessCategory>(pageNum,pageSize);
        QueryWrapper<OaBusinessCategory> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        IPage<OaBusinessCategory> iPage =  oaBusinessCategoryService.page(page,queryWrapper);
        return Result.returnOk(iPage);
    }

    //获取分类列表
    @ApiOperation(value = "获取分类列表", notes = "获取分类列表")
    @GetMapping("/getCategorys")
    public Result getCategorys(){
        QueryWrapper<OaBusinessCategory> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        List<OaBusinessCategory> list = oaBusinessCategoryService.list(queryWrapper);
        return Result.returnOk(list);
    }


    //启用停用状态
    @ApiOperation(value = "启用停用状态", notes = "启用停用状态")
    @GetMapping("/changeStatus/{id}/{status}")
    @SystemLog(description = "启用停用状态",table = LogTableConstant.OA_BUSINESS_CATEGORY)
    public Result changeStatus(@PathVariable("id") Integer id, @PathVariable("status") Integer status){
        OaBusinessCategory oaBusinessCategory = new OaBusinessCategory();
        oaBusinessCategory.setId(id);
        oaBusinessCategory.setStatus(status);
        oaBusinessCategoryService.updateById(oaBusinessCategory);
        return Result.returnOk("操作成功");
    }

    //删除
    @ApiOperation(value = "删除分类", notes = "删除分类")
    @GetMapping("/deleteById/{id}")
    @SystemLog(description = "删除分类",table = LogTableConstant.OA_BUSINESS_CATEGORY)
    public Result deleteById(@PathVariable("id") Integer id){
        oaBusinessCategoryService.removeById(id);
        return Result.returnOk("操作成功");
    }






}
