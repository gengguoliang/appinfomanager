package cn.yq.oa.controller;


import cn.yq.common.result.Result;
import cn.yq.oa.param.LiveCommentSearchParam;
import cn.yq.oa.param.TimelineItemReviceInfoParam;
import cn.yq.oa.vo.LiveCommentVo;
import cn.yq.oa.vo.TimelineItemReviewInfoVo;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 评论表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-10
 */
@RestController
@RequestMapping("/oa-live-comment")
@AllArgsConstructor
@Api(value = "直播评论管理", description = "直播评论管理 API", position = 100, protocols = "http")
public class OaLiveCommentController {

    @ApiOperation(value = "获取评论列表数据", notes = "获取评论列表数据")
    @PostMapping("/listPage/{pageNum}/{pageSize}")
    public Result<IPage<LiveCommentVo>> listPage(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody LiveCommentSearchParam param){

        return Result.returnOk();
    }

    @ApiOperation(value = "删除直播评论信息", notes = "删除直播评论信息")
    @GetMapping("/deleteLiveComment/{id}")
    public Result deleteLiveComment(@PathVariable("id") Integer id){

        return Result.returnOk("操作成功");
    }


	
}
