package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.PrimaryGenerater;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaFixedassets;
import cn.yq.oa.entity.OaFixedassetsBizDetail;
import cn.yq.oa.entity.OaFixedassetsBorrow;
import cn.yq.oa.entity.OaFixedassetsRefund;
import cn.yq.oa.param.*;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsBorrowService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.impl.OrderNumberServiceImpl;
import cn.yq.oa.vo.OaFixedassetsBorrowExportVo;
import cn.yq.oa.vo.OaFixedassetsBorrowVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 固定资产借用表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-02
 */
@RestController
@RequestMapping("/oa-fixedassets-borrow")
@AllArgsConstructor
public class OaFixedassetsBorrowController {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    private IOaFixedassetsBorrowService oaFixedassetsBorrowService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsService oaFixedassetsService;

    @Resource(name = "orderNumberServiceImpl")
    OrderNumberServiceImpl orderNumberService;


    @PostMapping("/addBorrow")
    @LoginUser
    @SystemLog(description = "添加固定资产借用")
    public Result addBorrow(AuthUser authUser, @RequestBody OaFixedassetsBorrowParam oaFixedassetsBorrowParam){
        OaFixedassetsBorrow oaFixedassetsBorrow = new OaFixedassetsBorrow();
        BeanUtils.copyProperties(oaFixedassetsBorrowParam,oaFixedassetsBorrow);
        oaFixedassetsBorrow.setBorrowHandlerName(authUser.getName());
        //借用单号
//        String dh = "JYD" + PrimaryGenerater.geneterNextNumber(sdf.format(new Date()));
        String dh = orderNumberService.getOneOrderNumber("JYD");
        oaFixedassetsBorrow.setNo(dh);
        //状态
        oaFixedassetsBorrow.setStatus(1);
        //保存借用表数据
        oaFixedassetsBorrowService.saveOrUpdate(oaFixedassetsBorrow);
        //获取借用单id
        int id = oaFixedassetsBorrow.getId();
        //保存业务明细表数据
        List<Integer> list = oaFixedassetsBorrowParam.getIds();

        for (Integer temp:list){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //借用中
            oaFixedassetsBizDetail.setBizType(2);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp);
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
        //修改资产状态(根据资产id)
        for (Integer temp:list){
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(temp);
            //借用中
            oaFixedassets.setStatus(2);
            oaFixedassetsService.updateById(oaFixedassets);
        }
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllBorrows/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产借用信息")
    public Result getAllBorrows(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody BorrowSearchParam borrowSearchParam) {

        Page<OaFixedassetsBorrowVo> page = new Page<OaFixedassetsBorrowVo>(pageNum,pageSize);
//        IPage<OaFixedassetsBorrow> iPage = oaFixedassetsBorrowService.selectRefundsPage(page, borrowSearchParam);
        IPage<OaFixedassetsBorrowVo> iPage = oaFixedassetsBorrowService.selectRefundsVoPage(page, borrowSearchParam);
        return Result.returnOk(iPage);
    }

    @PostMapping("/exportExcel")
    public Result exportExcel(@RequestBody BorrowSearchParam borrowSearchParam){
        List<OaFixedassetsBorrowExportVo> vos = oaFixedassetsBorrowService.exportExcel(borrowSearchParam);
        return Result.returnOk(vos);
    }

    /**getAllBorrows
     * 删除功能
     */
    @GetMapping("/deleteBorrow/{id}")
    @SystemLog(description = "删除固定资产借用信息")
    public Result deleteBorrow(@PathVariable("id") int id){
        oaFixedassetsBorrowService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 查看详情
     */
    @GetMapping("/getBorrowById/{id}")
    @SystemLog(description = "固定资产借用详情")
    public Result getBorrowById(@PathVariable("id") int id){
        Map map = new HashMap<>();
        OaFixedassetsBorrow borrow = oaFixedassetsBorrowService.getById(id);
        map.put("borrowInfo",borrow);
        //固定资产列表
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",2);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        //查询固定资产表
        Collection list1 = null;
        if (ids.size()>0){
            list1 = oaFixedassetsService.listByIds(ids);
        }

        map.put("list",list1);
        return Result.returnOk(map);
    }

    /**
     * 归还
     */
    @PostMapping("/ReturnBorrowById")
    @SystemLog(description = "归还")
    public Result ReturnBorrowById(@RequestBody BorrowReturnParam borrowReturnParam){
        //更新借还表状态
        OaFixedassetsBorrow oaFixedassetsBorrow = new OaFixedassetsBorrow();
        oaFixedassetsBorrow.setId(borrowReturnParam.getId());
        oaFixedassetsBorrow.setRealReturnDate(borrowReturnParam.getRealReturnDate());
        oaFixedassetsBorrow.setReturnHandlerName(borrowReturnParam.getReturnHandlerName());
        //已归还
        oaFixedassetsBorrow.setStatus(0);
        oaFixedassetsBorrowService.updateById(oaFixedassetsBorrow);
        //根据借用单id归还资产，更新资产状态

        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",2);
        queryWrapper.eq("biz_id",borrowReturnParam.getId());
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for(OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        QueryWrapper<OaFixedassets> queryWrapper1 = new QueryWrapper<OaFixedassets>();
        queryWrapper1.in("id",ids);
        //更新资产表状态
//        oaFixedassetsService.update(queryWrapper1);
        OaFixedassets oaFixedassets = new OaFixedassets();
        oaFixedassets.setStatus(0);
        oaFixedassetsService.update(oaFixedassets,queryWrapper1);
        return Result.returnOk("操作成功!");
    }








}
