package cn.yq.oa.config;

import com.alipay.api.AlipayConstants;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author: yinqk
 * @date: 2019-03-31 11:29
 * @description: TODO
 */
@Configuration
@ConfigurationProperties(prefix = "payment.alipay")
public class AlipayConfig {
    /**
     * 请求网关地址
     */
    private String gatewayUrl;

    /**
     * 商户appid
     */
    private String appId;

    /**
     * 卖家支付宝用户号
     */
    private String sellerId;

    /**
     * 私钥 pkcs8格式的
     */
    private String merchantPrivateKey;

    /**
     * 返回格式
     */
    private String format = AlipayConstants.FORMAT_JSON;

    /**
     * 编码
     */
    private String charset = AlipayConstants.CHARSET_UTF8;

    /**
     * 支付宝公钥
     */
    private String alipayPublicKey;

    /**
     * 商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2
     */
    private String signType = AlipayConstants.SIGN_TYPE_RSA2;

    /**
     * 支付宝服务器主动通知商户服务器里指定的页面http/https路径。建议商户使用https
     */
    private String notifyUrl;

    public String getGatewayUrl() {
        return gatewayUrl;
    }

    public void setGatewayUrl(String gatewayUrl) {
        this.gatewayUrl = gatewayUrl;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public String getMerchantPrivateKey() {
        return merchantPrivateKey;
    }

    public void setMerchantPrivateKey(String merchantPrivateKey) {
        this.merchantPrivateKey = merchantPrivateKey;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getAlipayPublicKey() {
        return alipayPublicKey;
    }

    public void setAlipayPublicKey(String alipayPublicKey) {
        this.alipayPublicKey = alipayPublicKey;
    }

    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }
}
