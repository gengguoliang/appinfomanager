package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.CommonFiles;
import cn.yq.oa.entity.OaRecruitInterview;
import cn.yq.oa.entity.OaRecruitMessage;
import cn.yq.oa.entity.OaRecruitResume;
import cn.yq.oa.param.PositionApplySearchParam;
import cn.yq.oa.param.RecruitChangeParam;
import cn.yq.oa.param.RecruitSerachParam;
import cn.yq.oa.service.ICommonFilesService;
import cn.yq.oa.service.IOaRecruitInterviewService;
import cn.yq.oa.service.IOaRecruitMessageService;
import cn.yq.oa.service.IOaRecruitResumeService;
import cn.yq.oa.vo.ResumeInfoVO;
import cn.yq.oa.vo.oarecruit.RecruitInfoVO;
import cn.yq.oa.vo.oarecruit.RecruitInterviewAPPInfo;
import cn.yq.oa.vo.oarecruit.RecruitInterviewVO;
import cn.yq.oa.vo.oarecruit.RecruitMessageVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 面试日程表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-18
 */
@RestController
@RequestMapping("/oa-recruit-interview")
@Api(value = "面试管理", description = "ggl面试管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaRecruitInterviewController {

    private IOaRecruitResumeService oaRecruitResumeService;

    private IOaRecruitInterviewService oaRecruitInterviewService;

    private ICommonFilesService commonFilesService;

    @ApiOperation(value = "分页获取面试信息", notes = "分页获取面试信息")
    @PostMapping("/listRecruitInfo/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "面试管理信息展示")
    public Result<IPage<RecruitInfoVO>> listRecruitInfo(@ApiIgnore AuthUser authUser,
                                  @PathVariable("pageNum") int pageNum,
                                  @PathVariable("pageSize") int pageSize,
                                  @RequestBody RecruitSerachParam param) {
        param.setOrgid(authUser.getOrganizationId());
        Page<RecruitInfoVO>page = new Page<RecruitInfoVO>(pageNum,pageSize);
        IPage<RecruitInfoVO>iPage = page.setRecords(oaRecruitInterviewService.listRecruitInfo(param,page));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "面试详情", notes = "面试详情")
    @GetMapping("/viewRecruitInfo/{id}/{resumeid}")
    @SystemLog(description = "面试管理信息详情")
    public Result<RecruitInfoVO> viewRecruitInfo(@PathVariable("id")Integer id,@PathVariable("resumeid")Integer resumeid){
        ResumeInfoVO oaRecruitResume = oaRecruitResumeService.viewResumeInfo(resumeid);
        RecruitInfoVO recruitInfoVO = new RecruitInfoVO();
        if(null != oaRecruitResume){
            CopyUtils.copyProperties(oaRecruitResume,recruitInfoVO);
            //获取当前简历下的面试日报
            List<RecruitInterviewVO> recruitInterviewVO = oaRecruitInterviewService.viewRecruitInfo(id,resumeid);
            if(null != recruitInterviewVO && recruitInterviewVO.size() > 0){
                recruitInfoVO.setRecruitInterviewVO(recruitInterviewVO.get(0));
            }
            //获取历史评语
            List<RecruitInterviewVO> listVO = oaRecruitInterviewService.viewRecruitInfo(0,resumeid);
            recruitInfoVO.setListInterview(listVO);
            //获取简历附件
            QueryWrapper<CommonFiles> queryWrapper3 = new QueryWrapper<>();
            queryWrapper3.eq("is_del",0);
            queryWrapper3.eq("relation_type","resume_attachment");
            queryWrapper3.eq("relation_id",resumeid);
            List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper3);
            if(null != commonFilesList && commonFilesList.size()>0){
                recruitInfoVO.setList(commonFilesList);
            }
        }
        return Result.returnOk(recruitInfoVO);
    }

    @ApiOperation(value = "APP面试管理列表", notes = "APP面试管理列表")
    @GetMapping("/listRecruitAPPInfo")
    @LoginUser
    @SystemLog(description = "App面试管理列表")
    public Result<List<RecruitInterviewAPPInfo>> listRecruitAPPInfo(@ApiIgnore AuthUser authUser){
        List<RecruitInterviewAPPInfo> list = oaRecruitInterviewService.listRecruitAPPInfo(authUser.getId());
        for(RecruitInterviewAPPInfo recruitInterviewAPPInfo : list){
            boolean flag = false;
            //待面试状态判断是否过期
            if(recruitInterviewAPPInfo.getStatus() == 1){
                //当前系统时间
                Date nowDate = new Date();
                //比较两个时间大小
                int num = recruitInterviewAPPInfo.getInterviewTime().compareTo(nowDate);
                flag = num >= 0 ? false : true;
            }
            recruitInterviewAPPInfo.setOrderTime(recruitInterviewAPPInfo.getInterviewTime());
            recruitInterviewAPPInfo.setFlag(flag);
        }
        return Result.returnOk(list);
    }

    @ApiOperation(value = "修改状态", notes = "修改状态")
    @PostMapping("/changeStatus")
    @LoginUser
    @SystemLog(description = "面试管理状态变更")
    public Result changeStatus(@RequestBody RecruitChangeParam param){
        if(null != param){
            if(param.getType() == 1){//通过
                OaRecruitInterview oaRecruitInterview = new OaRecruitInterview();
                oaRecruitInterview.setId(param.getId());
                oaRecruitInterview.setStatus(2);
                oaRecruitInterview.setConfirmTime(new Date());
                oaRecruitInterview.setComment(param.getComment());
                oaRecruitInterviewService.updateById(oaRecruitInterview);
                OaRecruitResume oaRecruitResume = new OaRecruitResume();
                oaRecruitResume.setId(param.getResumeid());
                oaRecruitResume.setStatus(6);
                oaRecruitResumeService.updateById(oaRecruitResume);
            }else if(param.getType() == 2){//不通过
                OaRecruitInterview oaRecruitInterview = new OaRecruitInterview();
                oaRecruitInterview.setId(param.getId());
                oaRecruitInterview.setStatus(2);
                oaRecruitInterview.setConfirmTime(new Date());
                oaRecruitInterview.setComment(param.getComment());
                oaRecruitInterviewService.updateById(oaRecruitInterview);
                OaRecruitResume oaRecruitResume = new OaRecruitResume();
                oaRecruitResume.setId(param.getResumeid());
                oaRecruitResume.setStatus(5);
                oaRecruitResumeService.updateById(oaRecruitResume);
            }
        }
        return Result.returnOk("操作成功");
    }
}
