package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.oa.entity.OaRegion;
import cn.yq.oa.param.OaRegionParam;
import cn.yq.oa.service.IOaRegionService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.pl.NIP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 区域维护表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-12
 */
@Api(value = "广告位区域维护", description = "广告位区域维护 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/oa-region")
@Slf4j
@AllArgsConstructor
public class OaRegionController {

    private final static Logger LOGGER = LoggerFactory.getLogger(OaRegionController.class);

    @Autowired
    private IOaRegionService oaRegionService;

    @ApiOperation(value = "添加区域信息", notes = "添加区域信息")
    @PostMapping(value = "/addRegion", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加广告位区域")
    public Result addRegion(@RequestBody OaRegionParam oaRegionParam) {
        OaRegion oaRegion = new OaRegion();
        CopyUtils.copyProperties(oaRegionParam,oaRegion);
        oaRegionService.save(oaRegion);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "区域信息列表", notes = "区域信息列表")
    @GetMapping(value = "/listRegion")
    @SystemLog(description = "广告位区域信息列表")
    public Result listRegion(){
        QueryWrapper<OaRegion> queryWrapper = new QueryWrapper<OaRegion>();
        queryWrapper.eq("is_del",0);
        List<OaRegion> list = oaRegionService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "删除区域信息", notes = "删除区域信息")
    @GetMapping(value = "/deleteRegions")
    @SystemLog(description = "删除广告位区域信息")
    public Result deleteRegions(String ids){
        String [] id = ids.split(",");
        for (int i = 0; i < id.length; i++) {
            oaRegionService.removeById(new Integer(id[i]));
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "区域名称校验 true已存在false不存在", notes = "区域名称校验")
    @GetMapping(value = "/isNameExist")
    @SystemLog(description = "广告位区域名称校验")
    public Result isNameExist(@RequestParam("name")String name){
        boolean flag = false;
        QueryWrapper<OaRegion> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del",0);
        wrapper.eq("region_name",name);
        OaRegion oaRegion = oaRegionService.getOne(wrapper);
        if(null != oaRegion){
            flag = true;
        }
        return Result.returnOk(flag);
    }








	
}
