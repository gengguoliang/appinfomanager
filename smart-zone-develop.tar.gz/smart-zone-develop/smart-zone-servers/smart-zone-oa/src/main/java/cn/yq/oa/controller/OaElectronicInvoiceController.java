package cn.yq.oa.controller;

/**
 * @author: YQ-DGZ
 * @date: 2019/5/23 17:09
 * @description: TODO
 */

import cn.hutool.core.collection.CollUtil;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.oa.entity.OaOnlineInvoice;
import cn.yq.oa.param.ElectronicInvoiceSearchParam;
import cn.yq.oa.service.IOaOnlineInvoiceService;
import cn.yq.oa.vo.oabill.BillShowVO;
import cn.yq.oa.vo.oainvoice.OaBillInfoVo;
import cn.yq.oa.vo.oainvoice.OaElectronicInvoiceVo;
import cn.yq.oa.vo.oainvoice.OaInvoiceDetailInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 电子发票管理
 * </p>
 *
 * @author lwl
 * @since 2019-05-23
 */
@RestController
@RequestMapping("/oa-electronic-invoice")
@Api(value = "电子发票管理", description = "电子发票管理（lwl） API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaElectronicInvoiceController {

    IOaOnlineInvoiceService oaOnlineInvoiceService;

    @ApiOperation(value = "获取电子发票管理列表", notes = "获取电子发票管理列表")
    @PostMapping("/listElectronicInvoice/{pageNum}/{pageSize}")
    @SystemLog(description = "获取电子发票管理列表")
    public Result<IPage<OaElectronicInvoiceVo>> listElectronicInvoice(@PathVariable("pageNum")Integer pageNum,
                                                                      @PathVariable("pageSize")Integer pageSize,
                                                                      @RequestBody ElectronicInvoiceSearchParam searchParam){
        Page<OaElectronicInvoiceVo> page=new Page<>(pageNum,pageSize);
        List<OaElectronicInvoiceVo> vos = oaOnlineInvoiceService.listElectronicInvoice(page,searchParam);
        IPage<OaElectronicInvoiceVo> iPage = page.setRecords(vos);
        return  Result.returnOk(iPage);
    }



    @ApiOperation(value = "查看电子发票详情", notes = "查看电子发票详情")
    @PostMapping("/getElectronicDetail/{id}")
    @SystemLog(description = "查看电子发票详情")
    public Result getElectronicDetail(@PathVariable("id")Integer id){
        Map map = new HashMap<>();
        OaOnlineInvoice oaOnlineInvoice = oaOnlineInvoiceService.getById(id);
        //账单id
        //账单信息
        Integer billId = 0;
        if (null !=oaOnlineInvoice ){
            billId = oaOnlineInvoice.getBillId();
        }
        OaBillInfoVo billInfo = oaOnlineInvoiceService.getBillInfo(billId);
        map.put("billInfo",billInfo);
        //开票信息
        OaInvoiceDetailInfo detailInfo = oaOnlineInvoiceService.getOaInvoiceDetailInfo(id);
        map.put("detailInfo",detailInfo);
        return Result.returnOk(map);
    }









}
