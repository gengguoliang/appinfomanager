package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.oa.dto.oarecruit.ShowStationDTO;
import cn.yq.oa.entity.OaRecruitStation;
import cn.yq.oa.service.IOaRecruitStationService;
import cn.yq.oa.vo.oarecruit.ShowStationVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 招聘需求岗位表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-06-28
 */
@RestController
@RequestMapping("/oa-recruit-station")
@Api(value = "zhengjh招聘需求岗位", description = "zhengjh招聘需求岗位")
public class OaRecruitStationController {

    @Autowired
    private IOaRecruitStationService oaRecruitStationService;


    /**
     * @Description 新增和编辑
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "新增和编辑", notes = "新增和编辑")
    @PostMapping(value = "/addStation")
    @SystemLog(description = "添加/编辑招聘需求管理")
    public Result addStation(@RequestBody OaRecruitStation oaRecruitStation) {
        QueryWrapper<OaRecruitStation> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dept_id", oaRecruitStation.getDeptId())
                .eq("name", oaRecruitStation.getName())
                .eq("is_del", 0);
        if (oaRecruitStation.getId() != null) {
            queryWrapper.ne("id", oaRecruitStation.getId());
        }
        Integer count = oaRecruitStationService.count(queryWrapper);
        if (count > 0) {
            return new Result(ResultEnum.FAIL.getCode(), "岗位名不能重复");
        }
        oaRecruitStationService.saveOrUpdate(oaRecruitStation);
        return Result.returnOk("成功");
    }

    /**
     * @Description 列表
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "列表", notes = "列表")
    @PostMapping(value = "/showStation/{pageNum}/{pageSize}")
    @SystemLog(description = "招聘需求管理列表展示")
    public Result<IPage<ShowStationVO>> showStation(@PathVariable("pageNum") Integer pageNum,
                                                    @PathVariable("pageSize") Integer pageSize) {
        Page<ShowStationVO> page = new Page<>(pageNum, pageSize);
        IPage<ShowStationVO> iPage = page.setRecords(oaRecruitStationService.showStation(page));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "详情", notes = "详情")
    @GetMapping(value = "/stationDetail/{id}")
    @SystemLog(description = "招聘需求管理详情")
    public Result<ShowStationVO> stationDetail(@PathVariable("id") Integer id) {
        ShowStationVO showStationVO = oaRecruitStationService.stationDetail(id);
        return Result.returnOk(showStationVO);
    }

    /**
     * @Description 改变状态
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "改变状态", notes = "改变状态")
    @GetMapping(value = "/statusStation/{id}/{status}")
    @SystemLog(description = "招聘需求管理状态变更")
    public Result statusStation(@PathVariable("id") Integer id, @PathVariable("status") Integer status) {
        OaRecruitStation oaRecruitStation = new OaRecruitStation();
        oaRecruitStation.setId(id);
        oaRecruitStation.setStatus(status);
        oaRecruitStationService.updateById(oaRecruitStation);
        return Result.returnOk("成功");
    }

    /**
     * @Description 删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping(value = "/removeStation/{id}")
    @SystemLog(description = "删除招聘需求管理")
    public Result addStation(@PathVariable("id") Integer id) {
        oaRecruitStationService.removeById(id);
        return Result.returnOk("成功");
    }

}
