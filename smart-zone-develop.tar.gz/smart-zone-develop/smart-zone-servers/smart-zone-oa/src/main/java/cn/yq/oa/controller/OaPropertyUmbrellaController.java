package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.CopyUtils;
import cn.yq.oa.entity.OaPropertyUmbrella;
import cn.yq.oa.entity.OaPropertyUmbrellaUser;
import cn.yq.oa.param.UmbrellaInfoParam;
import cn.yq.oa.service.IOaPropertyUmbrellaService;
import cn.yq.oa.service.IOaPropertyUmbrellaUserService;
import cn.yq.oa.vo.AddUmbrellaVO;
import cn.yq.oa.vo.UmbrellaInfoVO;
import cn.yq.oa.vo.oaproperty.UmbrellaOfficerVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 雨伞信息 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-06
 */
@Api(value = "雨伞信息管理", description = "雨伞信息管理")
@RestController
@RequestMapping("/oa-property-umbrella")
public class OaPropertyUmbrellaController {
    @Autowired
    private IOaPropertyUmbrellaService oaPropertyUmbrellaService;
    @Autowired
    private IOaPropertyUmbrellaUserService oaPropertyUmbrellaUserService;

    @ApiOperation(value = "添加", notes = "添加")
    @PostMapping("/addUmbrellaInfo")
    @SystemLog(description = "添加雨伞信息")
    public Result addUmbrellaInfo(@RequestBody AddUmbrellaVO addUmbrellaVO){
        if(null != addUmbrellaVO){
            QueryWrapper<OaPropertyUmbrella> wrapper = new QueryWrapper<>();
            wrapper.eq("building_id",addUmbrellaVO.getBuildingId());
            wrapper.eq("receive_place",addUmbrellaVO.getReceivePlace());
            wrapper.eq("is_del",0);
            List<OaPropertyUmbrella> list = oaPropertyUmbrellaService.list(wrapper);
            if(null != list && list.size() > 0){
                return new Result(ResultEnum.FAIL.getCode(),"重复信息，请重新填写领取地点");
            }
            //添加雨伞信息表
            OaPropertyUmbrella oaPropertyUmbrella = new OaPropertyUmbrella();
            CopyUtils.copyProperties(addUmbrellaVO,oaPropertyUmbrella);
            oaPropertyUmbrellaService.insertOaPropertyUmbrella(oaPropertyUmbrella);
            //添加雨伞负责人关系表
            for(Integer userId : addUmbrellaVO.getUserId()){
                OaPropertyUmbrellaUser oaPropertyUmbrellaUser = new OaPropertyUmbrellaUser();
                oaPropertyUmbrellaUser.setUserId(userId);
                oaPropertyUmbrellaUser.setUmbrellaId(oaPropertyUmbrella.getId());
                oaPropertyUmbrellaUserService.save(oaPropertyUmbrellaUser);
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "雨伞信息查看",notes = "雨伞信息查看")
    @GetMapping("/getAllUmbrellaInfo/{id}")
    @SystemLog(description = "雨伞信息查看")
    public Result getAllUmbrellaInfo(@PathVariable("id") Integer id){
        //根据id获取雨伞信息
        OaPropertyUmbrella oaPropertyUmbrella = oaPropertyUmbrellaService.getById(id);
        AddUmbrellaVO addUmbrellaVO = new AddUmbrellaVO();
        CopyUtils.copyProperties(oaPropertyUmbrella,addUmbrellaVO);
        //根据雨伞id获取负责人id集合
        List<Integer> list = oaPropertyUmbrellaUserService.selectUmbrellaUserById(id);
        addUmbrellaVO.setUserId(list);
        return Result.returnOk(addUmbrellaVO);
    }

    @ApiOperation(value = "修改雨伞信息",notes = "修改雨伞信息")
    @PostMapping("/getAllUmbrellaInfo")
    @SystemLog(description = "修改雨伞信息")
    public Result updateUmbrellaInfo(@RequestBody AddUmbrellaVO addUmbrellaVO ){
        QueryWrapper<OaPropertyUmbrella> wrapper1 = new QueryWrapper<>();
        wrapper1.eq("building_id",addUmbrellaVO.getBuildingId());
        wrapper1.eq("receive_place",addUmbrellaVO.getReceivePlace());
        wrapper1.ne("id",addUmbrellaVO.getId());
        wrapper1.eq("is_del",0);
        List<OaPropertyUmbrella> list1 = oaPropertyUmbrellaService.list(wrapper1);
        if(null != list1 && list1.size() > 0){
            return new Result(ResultEnum.FAIL.getCode(),"重复信息，请重新填写领取地点");
        }
        //修改雨伞信息表
        OaPropertyUmbrella oaPropertyUmbrella = new OaPropertyUmbrella();
        oaPropertyUmbrella.setId(addUmbrellaVO.getId());
        CopyUtils.copyProperties(addUmbrellaVO, oaPropertyUmbrella);
        oaPropertyUmbrellaService.updateById(oaPropertyUmbrella);
        //获取当前雨伞下的所有负责人
        QueryWrapper<OaPropertyUmbrellaUser> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del",0);
        wrapper.eq("umbrella_id",addUmbrellaVO.getId());
        List<OaPropertyUmbrellaUser> list = oaPropertyUmbrellaUserService.list(wrapper);
        //删除之前的负责人
        for(OaPropertyUmbrellaUser umbrellaUser : list){
            QueryWrapper<OaPropertyUmbrellaUser> queryWrapper = new QueryWrapper<OaPropertyUmbrellaUser>();
            queryWrapper.eq("id",umbrellaUser.getId());
            oaPropertyUmbrellaUserService.remove(queryWrapper);
        }
        //添加修改后的负责人
        for(Integer id : addUmbrellaVO.getUserId()){
            OaPropertyUmbrellaUser oaPropertyUmbrellaUser = new OaPropertyUmbrellaUser();
            oaPropertyUmbrellaUser.setUserId(id);
            oaPropertyUmbrellaUser.setUmbrellaId(addUmbrellaVO.getId());
            oaPropertyUmbrellaUserService.save(oaPropertyUmbrellaUser);
        }
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改状态",notes = "修改状态")
    @GetMapping("/updateStatus/{id}/{status}")
    @SystemLog(description = "雨伞信息状态修改")
    public Result updateStatus(@PathVariable("id") Integer id,@PathVariable("status") Integer status){
        OaPropertyUmbrella oaPropertyUmbrella = new OaPropertyUmbrella();
        oaPropertyUmbrella.setId(id);
        if(status == 0){
            oaPropertyUmbrella.setStatus(1);
        }else{
            oaPropertyUmbrella.setStatus(0);
        }
        oaPropertyUmbrellaService.updateById(oaPropertyUmbrella);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除",notes = "删除")
    @GetMapping("/removeUmbrellaInfo/{id}")
    @SystemLog(description = "删除雨伞信息")
    public Result removeUmbrellaInfo(@PathVariable("id") Integer id){
        oaPropertyUmbrellaService.removeById(id);
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页展示",notes = "分页展示")
    @PostMapping("/getAllUmbrellaInfo/{pageNum}/{pageSize}")
    @SystemLog(description = "分页展示雨伞信息")
    public Result getAllUmbrellaInfo(@PathVariable("pageNum") Integer pageNum,
                                     @PathVariable("pageSize") Integer pageSize,
                                     @RequestBody UmbrellaInfoParam umbrellaInfoParam){

        Page<UmbrellaInfoVO> page = new Page<UmbrellaInfoVO>(pageNum,pageSize);
        IPage<UmbrellaInfoVO> iPage = oaPropertyUmbrellaService.selectUmbrellaInfo(page,umbrellaInfoParam);
        for(UmbrellaInfoVO umbrellaInfoVO : iPage.getRecords()){
            //获取当前雨伞下的负责人集合
            List<Integer> userIds = oaPropertyUmbrellaUserService.selectUmbrellaUserById(umbrellaInfoVO.getId());
            //获取当前雨伞下的负责人名字集合
            List<String> userName = oaPropertyUmbrellaUserService.selectUmbrellaUserName(umbrellaInfoVO.getId());
            umbrellaInfoVO.setUserId(userIds);
            umbrellaInfoVO.setUserName(userName);
        }
        return Result.returnOk(iPage);

    }

    @ApiOperation(value = "雨伞负责人列表（物业公司）",notes = "雨伞负责人列表（物业公司）")
    @PostMapping("/listUserInfo")
    @SystemLog(description = "雨伞负责人列表")
    public Result<List<UmbrellaOfficerVO>> listUserInfo(){
       List<UmbrellaOfficerVO> list =  oaPropertyUmbrellaService.listUserInfo();
        return Result.returnOk(list);
    }
}
