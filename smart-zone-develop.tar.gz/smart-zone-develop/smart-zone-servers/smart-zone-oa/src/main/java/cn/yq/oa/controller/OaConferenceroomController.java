package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.OaConferenceroomParam;
import cn.yq.oa.param.OaFixedassetsParam;
import cn.yq.oa.param.OccupyParam;
import cn.yq.oa.service.IOaConferenceReservationService;
import cn.yq.oa.service.IOaConferenceroomService;
import cn.yq.oa.service.IUserDepartmentService;
import cn.yq.oa.vo.OaFixedassetsVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 会议室表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-25
 */
@RestController
@RequestMapping("/oa-conferenceroom")
@AllArgsConstructor
public class OaConferenceroomController {

    IOaConferenceroomService oaConferenceroomService;
    IUserDepartmentService userDepartmentService;
    IOaConferenceReservationService oaConferenceReservationService;


    @GetMapping("/getCurrentUserInfo")
    @LoginUser
    public Result getCurrentUserInfo(AuthUser authUser){
        Map map = new HashMap<>();
        map.put("name",authUser.getName());
        map.put("departmentid",authUser.getDepartmentId());
        map.put("userid",authUser.getId());
        map.put("mobile",authUser.getMobile());
        String name = userDepartmentService.getNameById(authUser.getDepartmentId());
        map.put("departmentName",name);
        return Result.returnOk(map);
    }


    @PostMapping("/addConferenceroom")
    @LoginUser
    @SystemLog(description = "添加会议室信息",table = LogTableConstant.CONFERENCEROOM)
    public Result addConferenceroom(AuthUser authUser, @RequestBody OaConferenceroom oaConferenceroom){
        oaConferenceroom.setCreateBy(authUser.getName());
        oaConferenceroomService.saveOrUpdate(oaConferenceroom);
        return Result.returnOk("操作成功");
    }

    @PostMapping("/getAllRooms/{pageNum}/{pageSize}")
    @SystemLog(description = "会议室信息")
    public Result getAllRooms(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody OaConferenceroomParam oaConferenceroomParam){
        Page<OaConferenceroom> page= new Page<OaConferenceroom>(pageNum,pageSize);
        IPage<OaConferenceroom> assetsPage = oaConferenceroomService.selectRoomsPage(page,oaConferenceroomParam);
        return Result.returnOk(assetsPage);
    }

    @GetMapping("/IsRepeat/{no}")
    public Result IsRepeat(@PathVariable("no") String no){
        QueryWrapper<OaConferenceroom> queryWrapper = new QueryWrapper<OaConferenceroom>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("ordernumber",no);
        List<OaConferenceroom> list = oaConferenceroomService.list(queryWrapper);
        boolean flag = false;
        if(list.size()>0){
            flag = true;
        }
        return Result.returnOk(flag);
    }




    @GetMapping("/viewConferenceroom/{id}")
    @SystemLog(description = "会议室详情")
    public Result viewConferenceroom(@PathVariable("id") int id){
        OaConferenceroom oaConferenceroom = oaConferenceroomService.getById(id);
        String depatmentnames = oaConferenceroom.getDepartments();
        String  name ="";
        if(null!=depatmentnames && !"".equals(depatmentnames)){
            String[] names = depatmentnames.split(",");
            for(String temp:names){
                name+= userDepartmentService.getNameById(Integer.valueOf(temp));
                name+=",";
            }
        }


        String undepatmentnames = oaConferenceroom.getUndepartments();
        String unname = "";
        if (null!=undepatmentnames&&!"".equals(undepatmentnames)){
            String[] unnames = undepatmentnames.split(",");
            for (String temp:unnames){
                unname+=userDepartmentService.getNameById(Integer.valueOf(temp));
                unname+=",";
            }
        }

        Map map = new HashMap();
        map.put("info",oaConferenceroom);
        map.put("name",name);
        map.put("unname",unname);
        return Result.returnOk(map);
    }

    @GetMapping("/deleteConferenceroom/{id}")
    @SystemLog(description = "删除会议室",table = LogTableConstant.CONFERENCEROOM)
    public Result deleteConferenceroom(@PathVariable("id") int id) {
        oaConferenceroomService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @GetMapping("/changeStatus/{id}/{status}")
    @SystemLog(description = "会议室状态变更",table = LogTableConstant.CONFERENCEROOM)
    public Result deleteConferenceroom(@PathVariable("id") int id,@PathVariable("status") int status) {
        OaConferenceroom oaConferenceroom = new OaConferenceroom();
        oaConferenceroom.setId(id);
        oaConferenceroom.setStatus(status);
        oaConferenceroomService.updateById(oaConferenceroom);
        return Result.returnOk("操作成功");
    }

    //通过所选部门判断权限显示该部门有权限的会议室
    @GetMapping("/getRoomsByDepartmentId/{departmentId}")
    @SystemLog(description = "部门下的会议室")
    public Result getRoomsByDepartmentId(@PathVariable("departmentId") int departmentId){
        //根据部门id查询该部门可预订的会议室
        QueryWrapper<OaConferenceroom> queryWrapper = new QueryWrapper<OaConferenceroom>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("status",1);
        queryWrapper.like("departments",departmentId);
        List<OaConferenceroom> list = oaConferenceroomService.list(queryWrapper);

        //通过不可预约部门查

        QueryWrapper<OaConferenceroom> wrapper = new QueryWrapper<OaConferenceroom>();
        wrapper.eq("is_del",0);
        wrapper.eq("status",1);
        wrapper.notLike("undepartments",departmentId);
        wrapper.eq("departments","").or().isNull("departments");
        List<OaConferenceroom> conferencerooms = oaConferenceroomService.list(wrapper);
        list.addAll(conferencerooms);

        return  Result.returnOk(list);
    }

    //获取参会人员信息
    @GetMapping("/getUserInfos")
    public Result getUserInfos(){
        //获取部门


        return Result.returnOk("");
    }

    //判断时间段内指定会议室是否被占用
    @PostMapping("/isOccupy")
    @SystemLog(description = "指定时间段会议室是否被占用")
    public Result isOccupy(@RequestBody OccupyParam param){
        Date begintime = param.getBegintime();
        Date endtime = param.getEndtime();
        //根据会议室ID找到该会议室预约信息
        QueryWrapper<OaConferenceReservation> queryWrapper = new QueryWrapper<OaConferenceReservation>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("room_id",param.getRoomId());
        queryWrapper.eq("status",1);
        //找到所有该会议室的预约信息
        List<OaConferenceReservation> conferences = oaConferenceReservationService.list(queryWrapper);
        //根据输入开始时间、结束时间判断会议室是否已被占用
        //判断会议室占用
        boolean flag = false;
        for(OaConferenceReservation temp:conferences){
              Date kssj = temp.getBeginTime();
              Date jssj = temp.getEndTime();
              if((begintime.before(kssj) && endtime.before(jssj))||(begintime.after(jssj)&&endtime.after(jssj))){

              }else{
                  flag = true;
                  break;
              }
        }
        return Result.returnOk(flag);
    }





























}
