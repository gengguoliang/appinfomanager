package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.CommonNotice;
import cn.yq.oa.service.ICommonNoticeService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 通知 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-29
 */
@RestController
@RequestMapping("/common-notice")
@AllArgsConstructor
public class CommonNoticeController {

    private ICommonNoticeService commonNoticeService;

    @ApiOperation(value = "新增通知", notes = "新增通知")
    @PostMapping(value = "/addNotice", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "新增通知",table = LogTableConstant.NOTICE)
    public Result addNotice(@ApiIgnore AuthUser authUser, CommonNotice commonNotice){
        commonNotice.setCreateBy(authUser.getName());
        commonNoticeService.saveOrUpdate(commonNotice);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取通知列表", notes = "获取通知列表")
    @GetMapping(value = "/getNotices")
    @LoginUser
    @SystemLog(description = "获取通知列表",table = LogTableConstant.NOTICE)
    public Result getNotices(@ApiIgnore AuthUser authUser){
        QueryWrapper<CommonNotice> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userid",authUser.getId());
        List<CommonNotice> list = commonNoticeService.list(queryWrapper);
        return Result.returnOk(list);
    }


    @ApiOperation(value = "删除通知", notes = "删除通知")
    @GetMapping(value = "/removeNotice/{id}")
    @SystemLog(description = "删除通知",table = LogTableConstant.NOTICE)
    public Result removeNotice(@PathVariable("id")Integer id){
        commonNoticeService.removeById(id);
        return Result.returnOk("操作成功");
    }








	
}
