package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oaproperty.PropertyCartDTO;
import cn.yq.oa.entity.OaPropertyCart;
import cn.yq.oa.service.IOaPropertyCartService;
import cn.yq.oa.vo.oaproperty.PropertyCartVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 推车信息表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-06
 */
@Api(value = "推车信息管理", description = "推车信息管理")
@RestController
@RequestMapping("/oa-property-cart")
public class OaPropertyCartController {

    @Autowired
    private IOaPropertyCartService oaPropertyCartService;


    /**
     * @Description 添加和编辑
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "添加和编辑", notes = "添加和编辑")
    @PostMapping(value = "/add")
    @SystemLog(description = "添加推车信息")
    public Result add(@RequestBody OaPropertyCart oaPropertyCart) {
        if(oaPropertyCart.getId()==null){
            QueryWrapper<OaPropertyCart> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("model", oaPropertyCart.getModel())
                    .eq("receive_place_id", oaPropertyCart.getReceivePlaceId())
                    .eq("is_del", 0);
            List<OaPropertyCart> list = oaPropertyCartService.list(queryWrapper);
            if (list != null && list.size() > 0) {
                return new Result(ResultEnum.FAIL.getCode(), "领取地点的推车型号已存在");
            }
        }
        if (oaPropertyCart.getId() == null) {
            oaPropertyCartService.save(oaPropertyCart);
        }else {
            oaPropertyCartService.updateById(oaPropertyCart);
        }
        return Result.returnOk();
    }

    /**
     * @Description 列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "列表展示", notes = "列表展示")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页查看推车信息")
    public Result showPage(@ApiIgnore AuthUser authUser, @PathVariable("pageNum") Integer pageNum, @PathVariable("pageSize") Integer pageSize, @RequestBody PropertyCartDTO propertyCartDTO) {
        Page<PropertyCartVO> page = new Page<>(pageNum, pageSize);
        List<PropertyCartVO> propertyCartVOS = oaPropertyCartService.showPage(page, propertyCartDTO,authUser);
        IPage<PropertyCartVO> propertyCartVOPage = page.setRecords(propertyCartVOS);
        return Result.returnOk(propertyCartVOPage);
    }
    
    /**
    *@Description 删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "删除推车信息")
    public Result remove(@PathVariable("id")Integer id){
        oaPropertyCartService.removeById(id);
        return Result.returnOk();
    }
    
    /**
    *@Description 修改状态
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "修改状态", notes = "修改状态")
    @GetMapping(value = "/change/{id}/{status}")
    @SystemLog(description = "推车信息状态变更")
    public Result change(@PathVariable("id")Integer id,@PathVariable("status")Integer status){
        OaPropertyCart oaPropertyCart = new OaPropertyCart();
        oaPropertyCart.setId(id);
        oaPropertyCart.setStatus(status);
        oaPropertyCartService.updateById(oaPropertyCart);
        return Result.returnOk();
    }

}
