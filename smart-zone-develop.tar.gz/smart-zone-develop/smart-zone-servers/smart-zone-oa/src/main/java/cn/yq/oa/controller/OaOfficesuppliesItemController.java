package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.oa.entity.OaOfficesuppliesDepot;
import cn.yq.oa.entity.OaOfficesuppliesItem;
import cn.yq.oa.entity.OaOfficesuppliesStock;
import cn.yq.oa.mapper.IOaOfficesuppliesItemMapper;
import cn.yq.oa.service.IOaOfficesuppliesDepotService;
import cn.yq.oa.service.IOaOfficesuppliesItemService;
import cn.yq.oa.service.IOaOfficesuppliesStockService;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 办公用品物品表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-01-31
 */
@Api(value = "办公用品和仓库维护", description = "办公用品和仓库维护")
@RestController
@RequestMapping("/oa-officesupplies-item")
public class OaOfficesuppliesItemController {

    @Autowired
    private IOaOfficesuppliesItemService oaOfficesuppliesItemService;
    @Autowired
    private IOaOfficesuppliesDepotService oaOfficesuppliesDepotService;
    @Autowired
    private IOaOfficesuppliesStockService oaOfficesuppliesStockService;
    
    
    /**
    *@Description 新增物品编码判重
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "新增物品编码判重", notes = "新增物品编码判重")
    @GetMapping(value = "/uniqueCode")
    @SystemLog(description = "新增物品编码判重")
    public Result uniqueCode(@RequestParam("itemCode")String itemCode){
        QueryWrapper<OaOfficesuppliesItem> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("item_code",itemCode)
                .eq("is_del",0);
        int count = oaOfficesuppliesItemService.count(queryWrapper);
        if(count>0){
            return Result.returnOk(false);
        }
        return Result.returnOk(true);
    }

    /**
     * @Description 新增物品
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "新增物品", notes = "新增物品")
    @PostMapping(value = "/add")
    @SystemLog(description = "新增物品")
    public Result add(@RequestBody OaOfficesuppliesItem oaOfficesuppliesItem) {
        oaOfficesuppliesItem.setStatus(0);
        oaOfficesuppliesItemService.save(oaOfficesuppliesItem);
        return Result.returnOk();
    }

    /**
     * @Description 物品详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "物品详情", notes = "物品详情")
    @GetMapping(value = "/itemDetail/{itemId}")
    @SystemLog(description = "物品详情")
    public Result itemDetail(@PathVariable("itemId") int itemId) {
        return Result.returnOk(oaOfficesuppliesItemService.getById(itemId));
    }

    /**
     * @Description 物品删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "物品删除", notes = "物品删除")
    @GetMapping(value = "/itemRemove/{itemId}")
    @SystemLog(description = "物品删除")
    public Result itemRemove(@PathVariable("itemId") int itemId) {
        QueryWrapper<OaOfficesuppliesStock> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("item_id", itemId)
                .gt("quantity",0)
                .eq("is_del", 0);
        if (oaOfficesuppliesStockService.count(queryWrapper) > 0) {
            return new Result(ResultEnum.FAIL,"此物品还有库存，无法删除");
        }
        oaOfficesuppliesItemService.removeById(itemId);
        return Result.returnOk();
    }

    /**
     * @Description 物品的禁用和启用
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "物品的禁用和启用", notes = "物品的禁用和启用")
    @GetMapping(value = "/changeItemStaus/{itemId}/{status}")
    @SystemLog(description = "物品的禁用和启用")
    public Result changeItemStaus(@PathVariable("itemId") Integer itemId, @PathVariable("status") Integer status) {
        OaOfficesuppliesItem oaOfficesuppliesItem = new OaOfficesuppliesItem();
        oaOfficesuppliesItem.setId(itemId);
        oaOfficesuppliesItem.setStatus(status);
        oaOfficesuppliesItemService.updateById(oaOfficesuppliesItem);
        return Result.returnOk();
    }


    /**
     * @Description 物品分页展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "物品分页展示", notes = "物品分页展示")
    @GetMapping(value = "/showPage/{pageNum}/{pageSize}/{categoryId}")
    @SystemLog(description = "物品分页展示")
    public Result showPage(@PathVariable("pageNum") Integer pageNum, @PathVariable("pageSize") Integer pageSize, @PathVariable("categoryId") int categoryId) {
        Page<OaOfficesuppliesItem> oaOfficesuppliesItemPage = new Page<>(pageNum, pageSize);
        QueryWrapper<OaOfficesuppliesItem> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("category_id", categoryId)
                .eq("is_del", 0).orderByDesc("create_time");
        IPage<OaOfficesuppliesItem> page = oaOfficesuppliesItemService.page(oaOfficesuppliesItemPage, queryWrapper);
        return Result.returnOk(page);
    }

    /**
     * @Description 新增和编辑仓库
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "新增和编辑仓库", notes = "新增和编辑仓库")
    @PostMapping(value = "/addDepot")
    @SystemLog(description = "新增和编辑仓库")
    public Result addDepot(@RequestBody OaOfficesuppliesDepot oaOfficesuppliesDepot) {
        if (oaOfficesuppliesDepot.getId() == null) {
            oaOfficesuppliesDepotService.save(oaOfficesuppliesDepot);
        } else {
            oaOfficesuppliesDepotService.updateById(oaOfficesuppliesDepot);
        }
        return Result.returnOk();
    }

    /**
     * @Description 仓库列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "仓库列表展示", notes = "仓库列表展示")
    @PostMapping(value = "/showDepotPage/{pageNum}/{pageSize}")
    @SystemLog(description = "仓库列表展示")
    public Result showDepotPage(@PathVariable("pageNum") Integer pageNum, @PathVariable("pageSize") Integer pageSize, @RequestBody OaOfficesuppliesDepot oaOfficesuppliesDepot) {
        QueryWrapper<OaOfficesuppliesDepot> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("create_time");
        if (StringUtils.isNotBlank(oaOfficesuppliesDepot.getDepotName())) {
            queryWrapper.like("depot_name", oaOfficesuppliesDepot.getDepotName());
        }
        if (null != oaOfficesuppliesDepot.getStatus()) {
            queryWrapper.eq("status", oaOfficesuppliesDepot.getStatus());
        }
        queryWrapper.eq("is_del", 0);
        Page<OaOfficesuppliesDepot> oaOfficesuppliesDepotPage = new Page<>(pageNum, pageSize);
        IPage<OaOfficesuppliesDepot> page = oaOfficesuppliesDepotService.page(oaOfficesuppliesDepotPage, queryWrapper);
        return Result.returnOk(page);
    }

    /**
     * @Description 仓库的停用启用
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "仓库的停用启用", notes = "仓库的停用启用")
    @GetMapping(value = "/changeStaus/{id}/{status}")
    @SystemLog(description = "仓库的停用启用")
    public Result changeStaus(@PathVariable("id") Integer id, @PathVariable("status") Integer status) {
        OaOfficesuppliesDepot oaOfficesuppliesDepot = new OaOfficesuppliesDepot();
        oaOfficesuppliesDepot.setId(id);
        oaOfficesuppliesDepot.setStatus(status);
        oaOfficesuppliesDepotService.updateById(oaOfficesuppliesDepot);
        return Result.returnOk();
    }

    /**
     * @Description 仓库删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "仓库删除", notes = "仓库删除")
    @GetMapping(value = "/removeDepot/{id}")
    @SystemLog(description = "仓库删除")
    public Result removeDepot(@PathVariable("id") Integer id) {
        QueryWrapper<OaOfficesuppliesStock> queryWrapper = new QueryWrapper<>();
        queryWrapper.gt("quantity", 0).eq("depot_id", id);
        int count = oaOfficesuppliesStockService.count(queryWrapper);
        if (count > 0) {
            return new Result(ResultEnum.FAIL.getCode(),"此仓库存在物品，无法删除");
        }
        oaOfficesuppliesDepotService.removeById(id);
        return Result.returnOk();
    }

    /**
     * @Description 查询所有入库仓库  flag: 0.只查询启用的 1.查所有
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "查询所有入库仓库", notes = "查询所有入库仓库")
    @GetMapping(value = "/getAllDepot/{flag}")
    @SystemLog(description = "查询所有入库仓库")
    public Result getAllDepot(@PathVariable("flag") Integer flag) {
        QueryWrapper<OaOfficesuppliesDepot> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("create_time");
        if (flag == 0) {
            queryWrapper.eq("status", 1);
        }
        queryWrapper.eq("is_del", 0);
        return Result.returnOk(oaOfficesuppliesDepotService.list(queryWrapper));
    }
}
