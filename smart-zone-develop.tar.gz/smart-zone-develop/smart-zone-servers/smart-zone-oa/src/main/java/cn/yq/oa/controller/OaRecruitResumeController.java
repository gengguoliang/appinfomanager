package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import cn.yq.push.annotations.Notification;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qiniu.util.Auth;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanInfoFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 简历表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-18
 */
@RestController
@RequestMapping("/oa-recruit-resume")
@Api(value = "人才档案管理", description = "人才档案管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaRecruitResumeController {

    IOaRecruitResumeService oaRecruitResumeService;

    ISysDictDataService sysDictDataService;

    ICommonFilesService commonFilesService;

    IOaRecruitInterviewService oaRecruitInterviewService;

    IOaRecruitMessageService oaRecruitMessageService;

    IAuthUserService authUserService;

    @ApiOperation(value = "创建/编辑 简历", notes = "创建/编辑 简历")
    @PostMapping(value = "/addorUpdateResume")
    @LoginUser
    @SystemLog(description = "添加/编辑简历")
    public Result addorUpdateResume(@ApiIgnore AuthUser authUser, @RequestBody ResumeParam resumeParam) {

        OaRecruitResume resume = new OaRecruitResume();
        BeanUtils.copyProperties(resumeParam,resume);
        resume.setStatus(0);
        resume.setOrganizationId(authUser.getOrganizationId());
        oaRecruitResumeService.saveOrUpdate(resume);
        //删除附件listResumeInfo
        if(null!=resume.getId()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","resume_attachment");
            queryWrapper.eq("relation_id",resume.getId());
            commonFilesService.remove(queryWrapper);
        }

       //上传附件信息
        for (CommFileVO commFileVO : resumeParam.getList()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //身份证名称
            commonFiles.setRelationType("resume_attachment");
            commonFiles.setRelationId(resume.getId());
            commonFilesService.save(commonFiles);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取应聘岗位、投递渠道、面试轮次", notes = "获取应聘岗位、投递渠道、面试轮次")
    @GetMapping(value = "/getDicInfo")
    public Result getDicInfo(){
        Map map = new HashMap();
        //获取应聘岗位
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<SysDictData>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("dict_type","post");
        List<SysDictData> listPost= sysDictDataService.list(queryWrapper);
        //获取投递渠道
        QueryWrapper<SysDictData> queryWrapper1 = new QueryWrapper<SysDictData>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("dict_type","recruit_channel");
        List<SysDictData> listChannel= sysDictDataService.list(queryWrapper1);
        //获取面试轮次
        QueryWrapper<SysDictData> queryWrapper2 = new QueryWrapper<SysDictData>();
        queryWrapper2.eq("is_del",0);
        queryWrapper2.eq("dict_type","rotation");
        List<SysDictData> listRotation= sysDictDataService.list(queryWrapper2);

        map.put("post",listPost);
        map.put("listStage",listChannel);
        map.put("listRotation",listRotation);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "获取网络招聘下拉框", notes = "获取网络招聘下拉框")
    @GetMapping(value = "/getOnlineRecruit")
    public Result getOnlineRecruit(){
        QueryWrapper<SysDictData> queryWrapper1 = new QueryWrapper<SysDictData>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("dict_type","online_recruit");
        List<SysDictData> listChannel= sysDictDataService.list(queryWrapper1);
        return Result.returnOk(listChannel);
    }

    @ApiOperation(value = "分页获取人才档案信息列表", notes = "分页获取人才档案信息列表")
    @PostMapping("/listResumeInfo/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "人才档案信息展示")
    public Result<IPage<ResumePageInfoVO>> listResumeInfo(@ApiIgnore AuthUser authUser,
                                                          @PathVariable("pageNum") int pageNum,
                                                          @PathVariable("pageSize") int pageSize,
                                                          @RequestBody ResumeSearchParam param){
        Page<ResumePageInfoVO> page = new Page<ResumePageInfoVO>(pageNum, pageSize);
        param.setOrganizationId(authUser.getOrganizationId());
        List<ResumePageInfoVO> vos = oaRecruitResumeService.selectResumePageInfo(page, param);
        IPage<ResumePageInfoVO> iPage = null;
        iPage=page.setRecords(vos);
        return Result.returnOk(iPage);
    }


    @ApiOperation(value = "查看简历", notes = "查看简历")
    @GetMapping("/viewResume/{id}")
    @SystemLog(description = "人才档案信息详情")
    public Result<ResumeInfoVO> viewResume(@PathVariable("id") Integer id){
        ResumeInfoVO infoVO = oaRecruitResumeService.viewResumeInfo(id);
        //处理附件信息
        QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("relation_type","resume_attachment");
        queryWrapper.eq("relation_id",infoVO.getId());
        List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper);
        infoVO.setList(commonFilesList);
        return Result.returnOk(infoVO);
    }

    @ApiOperation(value = "获取留言", notes = "获取留言")
    @GetMapping("/getMessage/{id}")
    @SystemLog(description = "人才档案面试留言")
    public Result<List<OaRecruitMessage>> getMessage(@PathVariable("id") Integer id){

        QueryWrapper<OaRecruitMessage> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("resumeid",id);
        queryWrapper.eq("is_del",0);
        queryWrapper.orderByDesc("message_time");
        List<OaRecruitMessage> list = oaRecruitMessageService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "获取面试日程", notes = "获取面试日程")
    @GetMapping("/getInterviews/{id}")
    @SystemLog(description = "人才档案面试日程信息")
    public Result<List<InterviewInfoVO>> getInterviews(@PathVariable("id") Integer id){
        List<InterviewInfoVO> interviews = oaRecruitResumeService.getInterviews(id);
        return Result.returnOk(interviews);
    }

    @ApiOperation(value = "删除面试日程", notes = "删除面试日程")
    @GetMapping("/removeInterview/{id}")
    @SystemLog(description = "删除人才档案面试日程")
    public Result removeInterview(@PathVariable("id") Integer id){
        return Result.returnOk(oaRecruitInterviewService.removeById(id));
    }

    @ApiOperation(value = "删除简历", notes = "删除简历")
    @GetMapping("/removeResume/{id}")
    @SystemLog(description = "删除人才档案信息")
    public Result removeResume(@PathVariable("id") Integer id){
        oaRecruitResumeService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "备选/放弃", notes = "备选/放弃")
    @GetMapping("/reserveResume/{id}/{status}")
    @SystemLog(description = "人才档案备选/放弃")
    public Result reserveResume(@PathVariable("id") Integer id,@PathVariable("status") Integer status) {
        OaRecruitResume resume = new OaRecruitResume();
        resume.setId(id);
        resume.setStatus(status);
        oaRecruitResumeService.updateById(resume);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "安排面试", notes = "安排面试")
    @PostMapping("/addInterview")
    @Notification("面试")
    public Result addInterview(@RequestBody InterviewParam param) {
        cn.yq.oa.entity.AuthUser authUser = authUserService.getById(param.getLeadingid());
        PushUtil.setTargetUsername(authUser.getUsername());
        OaRecruitInterview interview = new OaRecruitInterview();
        BeanUtils.copyProperties(param,interview);
        interview.setStatus(1);
        oaRecruitInterviewService.saveOrUpdate(interview);
        //更改状态
        OaRecruitResume resume = new OaRecruitResume();
        resume.setId(param.getResumeid());
        resume.setStatus(2);
        oaRecruitResumeService.updateById(resume);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "留言", notes = "留言")
    @PostMapping("/addMessage")
    @LoginUser
    public Result addMessage(@ApiIgnore AuthUser authUser, @RequestBody MessageParam param) {
        OaRecruitMessage message = new OaRecruitMessage();
        param.setName(authUser.getName());
        BeanUtils.copyProperties(param,message);
        message.setMessageTime(new Date());
        oaRecruitMessageService.saveOrUpdate(message);
        return Result.returnOk("操作成功");
    }





















	
}
