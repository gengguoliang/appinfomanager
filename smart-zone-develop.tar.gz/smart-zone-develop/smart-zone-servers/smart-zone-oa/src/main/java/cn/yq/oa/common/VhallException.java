package cn.yq.oa.common;

import cn.yq.oa.vo.vhall.BaseResponse;

/**
 * @author: yinqk
 * @date: 2019-04-13 16:23
 * @description: TODO
 */
public class VhallException extends RuntimeException {
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    private int code;

    public VhallException(int code, String message) {
        super(message);
        this.code = code;
    }

    public VhallException(BaseResponse response) {
        this(response.getCode(), response.getMsg());
    }
}
