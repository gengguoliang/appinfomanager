package cn.yq.oa.controller;

import cn.yq.common.result.Result;
import cn.yq.oa.entity.OaFixedassets;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.IOaOfficesuppliesStockOutService;
import cn.yq.oa.vo.FixedassetsAnalysis.FixedassetsAnaVo;
import cn.yq.oa.vo.FixedassetsAnalysis.FixedassetsCountVo;
import cn.yq.oa.vo.officesuppliesAnalysis.OfficeSuppliesAnaVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: YQ-DGZ
 * @date: 2019/5/13 19:36
 * @description: TODO
 */
@RestController
@RequestMapping("/oa-analysis")
@AllArgsConstructor
@Api(value = "行政办公大屏展示", description = "行政办公大屏展示")
public class OaAnalysisController {

    @Autowired
    IOaFixedassetsService oaFixedassetsService;
    @Autowired
    private IOaOfficesuppliesStockOutService oaOfficesuppliesStockOutService;

    @GetMapping("/fixedAssetsCategory")
    public Result fixedAssetsCategory() {
        List<FixedassetsAnaVo> vos = oaFixedassetsService.fixedAssetsCategory();
        return Result.returnOk(vos);
    }

    @GetMapping("/officesuppliesCategory")
    public Result officesuppliesCategory() {
        List<OfficeSuppliesAnaVo> vos = oaFixedassetsService.officesuppliesCategory();
        return Result.returnOk(vos);
    }


    @GetMapping("/fixedAssetsCount")
    public Result fixedAssetsCount() {
        ArrayList<Object> resultList = new ArrayList<>();
        QueryWrapper<OaFixedassets> queryWrapper = new QueryWrapper<OaFixedassets>();
        queryWrapper.eq("status", 0);
        List<OaFixedassets> list = oaFixedassetsService.list(queryWrapper);
        Map map = new HashMap();
        map.put("xz",list.size());

        QueryWrapper<OaFixedassets> queryWrapper1 = new QueryWrapper<OaFixedassets>();
        queryWrapper1.ne("status", 0);
        List<OaFixedassets> list1 = oaFixedassetsService.list(queryWrapper1);
        map.put("zy", list1.size());


        map.put("tj", list.size() + list1.size());
        resultList.add(map);

        return Result.returnOk(map);
    }

    @GetMapping("/fixedAssetsDistribute")
    public Result fixedAssetsDistribute() {
        List<FixedassetsCountVo> vos = oaFixedassetsService.fixedAssetsDistribute();
        return Result.returnOk(vos);
    }


    /**
     * @Description 办公用品使用情况柱状图
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "办公用品使用情况柱状图", notes = "办公用品使用情况柱状图")
    @GetMapping("/officesUse")
    public Result<Map<String, Object>> officesUse() {
        Map<String, Object> map = oaOfficesuppliesStockOutService.officesUse();
        return Result.returnOk(map);
    }

    /**
     *@Description 办公用品总数
     *@Param
     *@Return
     *@Author zhengjianhui
     */
    @ApiOperation(value = "办公用品总数", notes = "办公用品总数")
    @GetMapping("/officesStatistics")
    public Result<Map<String,Object>> officesStatistics(){
        Map<String, Object> map = oaOfficesuppliesStockOutService.officesStatistics();
        return Result.returnOk(map);
    }

}
