package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.ReimApproverDTO;
import cn.yq.oa.dto.ReimbursementApplicationDTO;
import cn.yq.oa.entity.OaOfficesuppliesReimbursementApplication;
import cn.yq.oa.service.IOaOfficesuppliesReimbursementApplicationService;
import cn.yq.oa.vo.ReimbursementApplicationVO;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 办公用品报销申请表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-01-31
 */
@Api(value = "报销申请", description = "报销申请")
@RestController
@RequestMapping("/reimbursement-application")
public class OaOfficesuppliesReimbursementApplicationController {

    @Autowired
    private IOaOfficesuppliesReimbursementApplicationService reimbursementApplicationService;
	
    
    /**
    *@Description 新增报销
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "新增报销", notes = "新增报销")
    @PostMapping(value = "/add")
    @LoginUser
    @SystemLog(description = "新增办公用品报销")
    public Result add(AuthUser authUser, @RequestBody ReimbursementApplicationDTO reimbursementApplicationDTO){
        reimbursementApplicationService.add(reimbursementApplicationDTO,authUser.getId());
        return Result.returnOk();
    }
    
    /**
    *@Description 报销分页列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "报销分页列表展示", notes = "报销分页列表展示")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询办公用品报销信息")
    public Result showPage(@PathVariable("pageNum")int pageNum,@PathVariable("pageSize")int pageSize,@RequestBody ReimbursementApplicationDTO reimbursementApplicationDTO){
        Page page=new Page(pageNum,pageSize);
        IPage iPage = reimbursementApplicationService.showPage(page, reimbursementApplicationDTO);
        return Result.returnOk(iPage);
    }
    
    /**
    *@Description 详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "详情", notes = "详情")
    @GetMapping(value = "/detail/{id}")
    @SystemLog(description = "办公用品报销详情")
    public Result detail(@PathVariable("id")Integer id){
        return Result.returnOk(reimbursementApplicationService.detail(id));
    }
    
    /**
    *@Description 审核
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "审核", notes = "审核")
    @PostMapping(value = "/approver")
    @LoginUser
    @SystemLog(description = "办公用品报销审核")
    public Result approver(AuthUser authUser,@RequestBody ReimApproverDTO reimApproverDTO){
        reimbursementApplicationService.approver(reimApproverDTO,authUser.getId());
        return Result.returnOk();
    }
    
    /**
    *@Description App端用品报销列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "App端用品报销列表展示", notes = "App端用品报销列表展示")
    @PostMapping(value = "/showList/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "App端用品报销列表展示")
    public Result showList(AuthUser authUser,@PathVariable("pageNum")Integer pageNum,
                           @PathVariable("pageSize")Integer pageSize){
        Page page=new Page(pageNum,pageSize);
        List<ReimbursementApplicationVO> applicationVOS = reimbursementApplicationService.showList(page,authUser.getId());
        IPage iPage=page.setRecords(applicationVOS);
        return Result.returnOk(iPage);
    }
}
