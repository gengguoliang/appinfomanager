package cn.yq.oa.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * @author: yinqk
 * @date: 2019-07-04 17:10
 * @description: 即时通信相关配置
 */
@Configuration
@ConfigurationProperties(prefix = "im.tencent")
@Data
@RefreshScope
public class IMProperties {
    private long sdkAppid;
    private String privateKey;
    private String avChatRoomId;
    private String hls;
}
