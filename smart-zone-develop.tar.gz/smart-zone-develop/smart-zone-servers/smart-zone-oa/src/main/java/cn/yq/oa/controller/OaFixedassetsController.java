package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaFixedassets;
import cn.yq.oa.entity.OaFixedassetsBizDetail;
import cn.yq.oa.entity.OaFixedassetsCategory;
import cn.yq.oa.param.CleanAssetsParam;
import cn.yq.oa.param.OaFixedassetsParam;
import cn.yq.oa.param.OaFixedassetsSearchParam;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsCategoryService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.vo.BarcodeVo;
import cn.yq.oa.vo.OaFixedassetsVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 固定资产表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-01-31
 */
@RestController
@RequestMapping("/oa-fixedassets")
@AllArgsConstructor
public class OaFixedassetsController {

    IOaFixedassetsService oaFixedassetsService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsCategoryService oaFixedassetsCategoryService;

    @PostMapping("/addAssets")
    @LoginUser
    public Result addAssets(AuthUser authUser, @RequestBody OaFixedassets oaFixedassets){
        oaFixedassets.setCreateBy(authUser.getName());
        oaFixedassetsService.saveOrUpdate(oaFixedassets);
        return Result.returnOk("操作成功");
    }

    @PostMapping("/uniqueBarcode")
    @LoginUser
    public Result uniqueBarcode(@RequestBody BarcodeVo barcodeVo){
        //资产条码唯一判断
        QueryWrapper<OaFixedassets> queryWrapper = new QueryWrapper<OaFixedassets>();
        queryWrapper.eq("barcode",barcodeVo.getBarcode());
        queryWrapper.eq("is_del",0);
        List<OaFixedassets> list = oaFixedassetsService.list(queryWrapper);
        //false 为数据库有重复的
        if (list.size()>0){
            return Result.returnOk(false);
        }
        return Result.returnOk(true);

    }


    @PostMapping("/updateAssets")
    public Result updateAssets(@RequestBody OaFixedassets oaFixedassets){
        //编辑之前判断，有处理记录的情况下不能编辑
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("asset_id",oaFixedassets.getId());
        queryWrapper.eq("is_del",0);
        queryWrapper.ne("biz_type",5);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        if (list.size()>0){
            return new Result(ResultEnum.FAIL.getCode(), "该资产已有处理记录，不可编辑");
        }
        oaFixedassetsService.updateById(oaFixedassets);
        return Result.returnOk("操作成功");
    }

    @GetMapping("/viewAssets/{id}")
    public Result viewAssets(@PathVariable("id") int id){
        OaFixedassets oaFixedassets = oaFixedassetsService.getById(id);
        return Result.returnOk(oaFixedassets);
    }

    @PostMapping("/cleanAssets")
    public Result cleanAssets(@RequestBody CleanAssetsParam param){
       List<Integer> idlist = param.getIdlist();
       List<OaFixedassets> list = new ArrayList();
        for (Integer id:idlist) {
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(id);
            oaFixedassets.setStatus(4);
            list.add(oaFixedassets);
        }
        oaFixedassetsService.updateBatchById(list);
        return Result.returnOk("操作成功");
    }

    @GetMapping("/deleteAssets/{id}")
    public Result deleteAssets(@PathVariable("id") int id) {
        //删除之前判断，有处理记录的情况下不能删除
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("asset_id",id);
        queryWrapper.eq("is_del",0);
        queryWrapper.ne("biz_type",5);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        if (list.size()>0){
            return new Result(ResultEnum.FAIL.getCode(), "该资产已有处理记录，不可编辑，请使用资产清理报废管理");
        }
        oaFixedassetsService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @PostMapping("/getAllAssets/{pageNum}/{pageSize}")
    public Result getAllAssets(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody OaFixedassetsParam oaFixedassetsParam){
        Page<OaFixedassetsVo> page= new Page<OaFixedassetsVo>(pageNum,pageSize);
        IPage<OaFixedassetsVo> assetsPage = oaFixedassetsService.selectAssetsVoPage(page,oaFixedassetsParam);
        return Result.returnOk(assetsPage);
    }


    @PostMapping("/getAllCleanAssets/{pageNum}/{pageSize}")
    public Result getAllCleanAssets(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody OaFixedassetsParam oaFixedassetsParam){
        Page<OaFixedassetsVo> page= new Page<OaFixedassetsVo>(pageNum,pageSize);
        IPage<OaFixedassetsVo> assetsPage = oaFixedassetsService.selectCleanAssetsVoPage(page,oaFixedassetsParam);
        return Result.returnOk(assetsPage);
    }

    /*
       根据状态查询固定资产列表
     */
    @PostMapping("/getAssetsByStatus")
    public Result getAssetsByStatus(@RequestBody OaFixedassetsSearchParam oaFixedassetsSearchParam){
        QueryWrapper<OaFixedassets> queryWrapper = new QueryWrapper<OaFixedassets>();
        if (null!=oaFixedassetsSearchParam.getStatus()){
            queryWrapper.eq("status",oaFixedassetsSearchParam.getStatus());
        }
        queryWrapper.eq("is_del",0);
        if(null!=oaFixedassetsSearchParam.getSearchInfo()){
            queryWrapper.and(wrapper -> wrapper.like("barcode", oaFixedassetsSearchParam.getSearchInfo()).or().like("name",  oaFixedassetsSearchParam.getSearchInfo()));
        }
        List<OaFixedassets> list = oaFixedassetsService.list(queryWrapper);
        List<OaFixedassetsVo> resultlist = new ArrayList<>();
        for(OaFixedassets temp:list){
            OaFixedassetsVo vo = new OaFixedassetsVo();
            BeanUtils.copyProperties(temp,vo);
            //查询资产类别
            OaFixedassetsCategory oaFixedassetsCategory = oaFixedassetsCategoryService.getById(temp.getCategoryId());
            vo.setCategoryName(oaFixedassetsCategory.getCategoryName());
            resultlist.add(vo);
        }
        return Result.returnOk(resultlist);
    }

    /*
       根据状态查询固定资产列表
     */
    @PostMapping("/getAssetsByAppointStatus")
    public Result getAssetsByAppointStatus(@RequestBody OaFixedassetsSearchParam oaFixedassetsSearchParam){
        QueryWrapper<OaFixedassets> queryWrapper = new QueryWrapper<OaFixedassets>();
//        if (null!=oaFixedassetsSearchParam.getStatus()){
//            queryWrapper.eq("status",oaFixedassetsSearchParam.getStatus());
//        }
        List list1 = new ArrayList();
        list1.add(0);
        list1.add(1);
        queryWrapper.in("status",list1);
        if(null!=oaFixedassetsSearchParam.getSearchInfo()){
            queryWrapper.and(wrapper -> wrapper.like("barcode", oaFixedassetsSearchParam.getSearchInfo()).or().like("name",  oaFixedassetsSearchParam.getSearchInfo()));
        }
        List<OaFixedassets> list = oaFixedassetsService.list(queryWrapper);
        List<OaFixedassetsVo> resultlist = new ArrayList<>();
        for(OaFixedassets temp:list){
            OaFixedassetsVo vo = new OaFixedassetsVo();
            BeanUtils.copyProperties(temp,vo);
            //查询资产类别
            OaFixedassetsCategory oaFixedassetsCategory = oaFixedassetsCategoryService.getById(temp.getCategoryId());
            vo.setCategoryName(oaFixedassetsCategory.getCategoryName());
            resultlist.add(vo);
        }
        return Result.returnOk(resultlist);
    }



















}
