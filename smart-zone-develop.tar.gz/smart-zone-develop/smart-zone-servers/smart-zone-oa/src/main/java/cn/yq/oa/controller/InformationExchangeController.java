package cn.yq.oa.controller;

import cn.yq.common.result.Result;
import cn.yq.oa.constant.CurrencyConstant;
import cn.yq.oa.entity.MyFeedback;
import cn.yq.oa.entity.OaLiveRoomInfo;
import cn.yq.oa.entity.OaRoadshowRoomInfo;
import cn.yq.oa.entity.TimelineItem;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.AirVO;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author: ggl
 * @Date: 2019/5/13 17:44
 * @Description: 信息交流系统展示
 */
@RestController
@Api(value = "信息交流系统展示", description = "信息交流系统展示 API", position = 100, protocols = "http")
@RequestMapping("/info-exchange")
@Slf4j
public class InformationExchangeController {

    @Autowired
    private IMyFeedbackService myFeedbackService;
    @Autowired
    private IOaLiveRoomInfoService oaLiveInfoService;
    @Autowired
    private ITimelineItemService timelineItemService;
    @Autowired
    private IOaBusinessCooperativeService oaBusinessCooperativeService;
    @Autowired
    private IOaPropertyCartUseDetailService oaPropertyCartUseDetailService;
    @Autowired
    private IOaRoadshowRoomInfoService oaRoadshowRoomInfoService;
    @Autowired
    private IOaParkingLotService oaParkingLotService;
    @Autowired
    private RedisTemplate redisTemplate;


    @ApiOperation(value = "基本信息(livecountd大咖秀发布数量、linecount时代生活圈数量、list意见反馈内容)", notes = "基本信息")
    @GetMapping("/getBaseInfo")
    public Result getBaseInfo() {
        Map map = new HashMap();
        //获取大咖秀信息发布数量
        QueryWrapper<OaLiveRoomInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del", 0);
        wrapper.eq("status", 2);
        int livecount = oaLiveInfoService.count(wrapper);
        //获取时代生活圈发布数量
        QueryWrapper<TimelineItem> wrapper1 = new QueryWrapper<>();
        wrapper1.eq("is_del", 0);
        int linecount = timelineItemService.count(wrapper1);
        map.put("livecount", livecount);
        map.put("linecount", linecount);
        //通过视图获取每日意见反馈
        List<MyFeedback> list = myFeedbackService.everydayFeedBack();
        map.put("list", list);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "预警中心（路演预告roadShow、意见反馈feedback、停车场车位parking）", notes = "预警中心")
    @GetMapping("/getWarningInfo")
    public Result getWarningInfo() {
        //路演预告
        QueryWrapper<OaRoadshowRoomInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del", 0);
        wrapper.eq("live_status", 1);
        List<OaRoadshowRoomInfo> list1 = oaRoadshowRoomInfoService.list(wrapper);
        //通过视图获取每日意见反馈
        List<MyFeedback> list2 = myFeedbackService.everydayFeedBack();
        //停车场车位
        List<String> parkingName = oaParkingLotService.getParkingName();

        Map map = new HashMap();
        map.put("roadShow", list1);
        map.put("feedback", list2);
        map.put("parking", parkingName);
        return Result.returnOk(map);
    }

    /**
     * @Description 合作商家圆环图，轮播活动，合作商家数量
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "合作商家圆环图，轮播活动，合作商家数量", notes = "合作商家圆环图，轮播活动，合作商家数量")
    @GetMapping("/cooperative")
    public Result<Map<String, Object>> cooperative() {
        Map<String, Object> map = oaBusinessCooperativeService.cooperative();
        return Result.returnOk(map);
    }

    /**
     * @Description 推车和雨伞的统计
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "推车和雨伞的统计", notes = "推车和雨伞的统计")
    @GetMapping("/cartAndUmbrella")
    public Result<Map<String, Object>> cartAndUmbrella() {
        Map<String, Object> map = oaPropertyCartUseDetailService.cartAndUmbrella();
        return Result.returnOk(map);
    }


    private final String url = "http://106.37.208.228:8082";//全国空气质量预报网址
    private final String airAction = "CityForecast";//获取数据的地址

    /**
     * @Description 未来空气质量报告
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "未来空气质量报告", notes = "未来空气质量报告")
    @GetMapping("/futureAir")
    public Result<List<AirVO>> futureAir() {
        List<AirVO> airVOS = null;
        try {
            //爬取数据
            airVOS = this.getAir(url + "/" + airAction);
            //如果爬取成功存入缓存
            if (!ObjectUtils.isEmpty(airVOS)) {
                redisTemplate.opsForValue().set(CurrencyConstant.FUTURE_AIR, JSON.toJSONString(airVOS));
            }
        } catch (Exception e) {
            //如果爬取失败则从缓存中拿数据
            String airString = (String) redisTemplate.opsForValue().get(CurrencyConstant.FUTURE_AIR);
            airVOS = JSON.parseArray(airString, AirVO.class);
        }
        return Result.returnOk(airVOS);
    }

    /**
     * 爬取数据
     *
     * @return
     */
    private List<AirVO> getAir(String dataUrl) throws ParseException {
        List<AirVO> airVOS = new ArrayList<>();
        Document doc = null;
        try {
            Connection con = Jsoup.connect(dataUrl).userAgent("Mozilla/5.0").timeout(3000);
            con.data("CityName", "北京市");
            doc = con.post();
        } catch (IOException e) {
            log.error("爬取未来空气质量错误：", e);
        }
        Elements aqiTitles = doc.getElementsByClass("aqi_title");
        Elements aqiValues = doc.getElementsByClass("aqi_value_level");
        DateFormat format1 = new SimpleDateFormat("yyyy年MM月dd日");
        DateFormat format2 = new SimpleDateFormat("MM/dd");
        AirVO airVO = null;
        for (int i = 0; i < aqiTitles.size(); i++) {
            airVO = new AirVO();
            String aqiTitleText = aqiTitles.get(i).getElementsByTag("p").get(0).text();
            Date date = format1.parse(aqiTitleText);
            String aqiTitle = format2.format(date);
            String aqiValue = aqiValues.get(i).text().split("~")[0];
            airVO.setAqiTitle(aqiTitle);
            airVO.setAqiValue(aqiValue);
            airVOS.add(airVO);
        }
        return airVOS;
    }


}
