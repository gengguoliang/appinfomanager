package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaConferenceParticipants;
import cn.yq.oa.entity.OaConferenceProblem;
import cn.yq.oa.entity.OaConferenceReservation;
import cn.yq.oa.entity.OaConferenceVote;
import cn.yq.oa.param.OaConferenceProblemParam;
import cn.yq.oa.service.IOaConferenceParticipantsService;
import cn.yq.oa.service.IOaConferenceProblemService;
import cn.yq.oa.service.IOaConferenceReservationService;
import cn.yq.oa.service.IOaConferenceVoteService;
import cn.yq.oa.vo.ConferenceThemeVO;
import cn.yq.oa.vo.OaConferenceProblemVO;
import cn.yq.oa.vo.OnlineVoteVO;
import cn.yq.oa.vo.VotingResultVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.*;

/**
 * <p>
 * 会议问题表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-02-26
 */
@RestController
@RequestMapping("/oa-conference-problem")
public class OaConferenceProblemController {
    @Autowired
    private IOaConferenceProblemService oaConferenceProblemService;
    @Autowired
    private IOaConferenceReservationService oaConferenceReservationService;
    @Autowired
    private IOaConferenceVoteService oaConferenceVoteService;
    @Autowired
    private IOaConferenceParticipantsService oaConferenceParticipantsService;

    @ApiOperation(value = "在线表决展示列表", notes = "在线表决展示列表")
    @GetMapping("/getAllOnLineVote")
    @LoginUser
    @SystemLog(description = "在线表决展示列表")
    public Result<List<OnlineVoteVO>> getAllOnLineVote(@ApiIgnore AuthUser authUser) {
        List<OnlineVoteVO> list = oaConferenceVoteService.selectOnlineVote(authUser);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "用户所属会议", notes = "用户所属会议")
    @GetMapping("/getConferencesByUser")
    @LoginUser
    public Result<List<ConferenceThemeVO>> getConferencesByUser(AuthUser authUser) {
        List<ConferenceThemeVO> list = oaConferenceReservationService.selectConferenceTheme(authUser);
        return Result.returnOk(list);
    }
    @ApiOperation(value = "新增问题表决", notes = "新增问题表决")
    @PostMapping("/addVotingInfo/{id}")
    @LoginUser
    @SystemLog(description = "新增会议表决")
    public Result addVotingInfo(@ApiIgnore AuthUser authUser,@PathVariable("id") Integer id,@RequestBody List<OaConferenceVote> list){
        if (null != list) {
            for(OaConferenceVote oaConferenceVote : list){
                oaConferenceVote.setUserId(authUser.getId());
                if(null == oaConferenceVote.getVotingResult()){
                    oaConferenceVote.setVotingResult(3);
                }
                oaConferenceVote.setReservationId(id);
                oaConferenceVote.setCreateBy(authUser.getName());
                oaConferenceVoteService.save(oaConferenceVote);
            }
        }
        //更新为已表决状态
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("user_id",authUser.getId());
        queryWrapper.eq("conference_id",id);
        OaConferenceParticipants oaConferenceParticipants = oaConferenceParticipantsService.getOne(queryWrapper);
        if(null != oaConferenceParticipants){
            OaConferenceParticipants oaConferenceParticipants1 = new OaConferenceParticipants();
            oaConferenceParticipants1.setId(oaConferenceParticipants.getId());
            oaConferenceParticipants1.setIsVoting(1);
            oaConferenceParticipants1.setVotingTime(new Date());
            oaConferenceParticipantsService.updateById(oaConferenceParticipants1);
        }
        return Result.returnOk("操作成功");
    }
    @ApiOperation(value = "查看表决结果", notes = "查看表决结果")
    @GetMapping("/getVotingResult/{id}")
    @LoginUser
    @SystemLog(description = "查看表决结果")
    public Result getVotingResult(@ApiIgnore AuthUser authUser,@PathVariable("id") Integer id){
        Map map = new HashMap();
        List<VotingResultVO> votingResultVOList = new ArrayList<VotingResultVO>();
        //获取当前会议信息
        QueryWrapper<OaConferenceReservation> queryWrapper1 = new QueryWrapper<OaConferenceReservation>();
        queryWrapper1.eq("id",id);
        OaConferenceReservation oaConferenceReservation = oaConferenceReservationService.getOne(queryWrapper1);
        map.put("meetingName",oaConferenceReservation.getConferencetheme());
        map.put("beginTime",oaConferenceReservation.getBeginTime());
        //获取当前会议下的所有问题
        QueryWrapper<OaConferenceProblem> queryWrapper = new QueryWrapper<OaConferenceProblem>();
        queryWrapper.eq("conference_id", id);
        queryWrapper.eq("is_del", 0);
        List<OaConferenceProblem> oaConferenceProblemList = oaConferenceProblemService.list(queryWrapper);
        for (OaConferenceProblem oaConferenceProblem : oaConferenceProblemList) {
            //当前问题的同意人信息
            List<String> agreeList = oaConferenceParticipantsService.selectVotingResultInfo(id, oaConferenceProblem.getId(), 1);
            //当前问题的不同意人信息
            List<String> disagreeList = oaConferenceParticipantsService.selectVotingResultInfo(id, oaConferenceProblem.getId(), 2);
            //List<String> waiverList = oaConferenceParticipantsService.selectVotingResultInfo(id, oaConferenceProblem.getId(), 3);
            //判断当前登录人是否是会议发起人
            QueryWrapper<OaConferenceReservation>queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.eq("is_del",0);
            queryWrapper2.eq("order_id",authUser.getId());
            queryWrapper2.eq("id",id);
            OaConferenceReservation oaConferenceReservation1 = oaConferenceReservationService.getOne(queryWrapper2);
            if(null != oaConferenceReservation1){
                VotingResultVO votingResultVO = new VotingResultVO(oaConferenceProblem.getProblem(), agreeList,agreeList.size(), disagreeList,disagreeList.size());
                votingResultVOList.add(votingResultVO);
            }else{
                VotingResultVO votingResultVO = new VotingResultVO();
                votingResultVO.setProblem(oaConferenceProblem.getProblem());
                votingResultVO.setAgreenum(agreeList.size());
                votingResultVO.setDisagreenum(disagreeList.size());
                votingResultVOList.add(votingResultVO);
            }
        }
        map.put("list",votingResultVOList);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "添加表决", notes = "添加表决")
    @PostMapping("/addProblem")
    @LoginUser
    @SystemLog(description = "添加表决")
    public Result addProblem(AuthUser authUser, @RequestBody OaConferenceProblemParam oaConferenceProblemParam) {
        oaConferenceProblemService.addProblemInfo(authUser, oaConferenceProblemParam);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "表决详情", notes = "表决详情")
    @GetMapping("getProblemInfo/{id}/{isVoting}")
    @LoginUser
    @SystemLog(description = "表决详情")
    public Result getProblemInfo(@ApiIgnore AuthUser authUser, @PathVariable("id") Integer id,@PathVariable("isVoting") Integer isVoting) {
        //根据会议ID获取当前会议信息
        OaConferenceReservation oaConferenceReservation = oaConferenceReservationService.getById(id);
        Map map = new HashMap();
        map.put("conferencetheme",oaConferenceReservation.getConferencetheme());
        map.put("beginTime",oaConferenceReservation.getBeginTime());
        //根据会议id获取所有问题列表
        QueryWrapper<OaConferenceProblem> queryWrapper = new QueryWrapper<OaConferenceProblem>();
        queryWrapper.eq("conference_id",id);
        queryWrapper.eq("is_del",0);
        List<OaConferenceProblem> oaConferenceProblemList = oaConferenceProblemService.list(queryWrapper);
        //未表决问题列表
        if(isVoting==0){
            map.put("list",oaConferenceProblemList);
        }else if(isVoting==1){//已表决
            List<OaConferenceProblemVO> oaConferenceProblemVOList = new ArrayList<OaConferenceProblemVO>();
            for (OaConferenceProblem oaConferenceProblem : oaConferenceProblemList){
                OaConferenceProblemVO oaConferenceProblemVO = new OaConferenceProblemVO();
                CopyUtils.copyProperties(oaConferenceProblem,oaConferenceProblemVO);
                QueryWrapper<OaConferenceVote> queryWrapper1 = new QueryWrapper<OaConferenceVote>();
                queryWrapper1.eq("problem_id",oaConferenceProblem.getId());
                queryWrapper1.eq("user_id",authUser.getId());
                queryWrapper1.eq("reservation_id",id);
                queryWrapper1.eq("is_del",0);
                OaConferenceVote oaConferenceVote = oaConferenceVoteService.getOne(queryWrapper1);
                oaConferenceProblemVO.setVotingResult(oaConferenceVote.getVotingResult());
                oaConferenceProblemVOList.add(oaConferenceProblemVO);
            }
            map.put("list",oaConferenceProblemVOList);
        }

        return Result.returnOk(map);
    }
}
