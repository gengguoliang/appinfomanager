package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oaproperty.UmbrellaApplicationAddDTO;
import cn.yq.oa.dto.oaproperty.UmbrellaApplicationDTO;
import cn.yq.oa.dto.oaproperty.UmbrellaApplicationShowDTO;
import cn.yq.oa.dto.oaproperty.UmbrellaUseDTO;
import cn.yq.oa.entity.OaPropertyPlace;
import cn.yq.oa.entity.OaPropertyUmbrella;
import cn.yq.oa.entity.OaPropertyUmbrellaApplication;
import cn.yq.oa.mapper.IOaPropertyUmbrellaApplicationMapper;
import cn.yq.oa.service.IOaPropertyPlaceService;
import cn.yq.oa.service.IOaPropertyUmbrellaApplicationService;
import cn.yq.oa.service.IOaPropertyUmbrellaService;
import cn.yq.oa.vo.oaproperty.BuildingAndUmbrellaVO;
import cn.yq.oa.vo.oaproperty.UmbrellaApplicationAddVO;
import cn.yq.oa.vo.oaproperty.UmbrellaApplicationVO;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 雨伞申请表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-11
 */
@Api(value = "雨伞申请办理", description = "雨伞申请办理")
@RestController
@RequestMapping("/oa-property-umbrella-application")
@Slf4j
public class OaPropertyUmbrellaApplicationController {

    @Autowired
    private IOaPropertyUmbrellaApplicationService oaPropertyUmbrellaApplicationService;
    @Autowired
    private IOaPropertyUmbrellaService oaPropertyUmbrellaService;
    @Autowired
    private IOaPropertyUmbrellaApplicationMapper umbrellaApplicationMapper;
    
    
    /**
    *@Description 根据楼宇ID获取当前登录人负责的雨伞领取地点
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "根据楼宇ID获取雨伞的地点", notes = "根据楼宇ID获取雨伞的地点")
    @GetMapping(value = "/getUmbrellaPlace/{buildingId}")
    @LoginUser
    public Result getUmbrellaPlace(@ApiIgnore AuthUser authUser ,@PathVariable("buildingId")Integer buildingId){
        List<OaPropertyUmbrella> oaPropertyUmbrellas = oaPropertyUmbrellaService.getUmbrellaPlace(authUser,buildingId);
        return Result.returnOk(oaPropertyUmbrellas);
    }
    
    /**
    *@Description PC端申请领用
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端申请领用", notes = "PC端申请领用")
    @PostMapping(value = "/add")
    @LoginUser
    @SystemLog(description = "添加雨伞申请")
    public Result add(AuthUser authUser, @RequestBody UmbrellaApplicationDTO umbrellaApplicationDTO){
        oaPropertyUmbrellaApplicationService.add(authUser,umbrellaApplicationDTO);
        return Result.returnOk();
    }
    
    /**
    *@Description PC端列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端列表展示", notes = "PC端列表展示")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "雨伞申请列表展示")
    public Result showPage(AuthUser authUser,@PathVariable("pageNum")Integer pageNum, @PathVariable("pageSize")Integer pageSize,
                           @RequestBody UmbrellaApplicationShowDTO umbrellaApplicationShowDTO){
        Page page=new Page(pageNum,pageSize);
        IPage<UmbrellaApplicationVO> iPage=
                page.setRecords(oaPropertyUmbrellaApplicationService.showPage(page,umbrellaApplicationShowDTO,authUser));
        return Result.returnOk(iPage);
    }
    
    /**
    *@Description 详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "详情", notes = "详情")
    @GetMapping(value = "/detail/{id}")
    @SystemLog(description = "雨伞申请详情")
    public Result detail(@PathVariable("id")Integer id){
        UmbrellaApplicationVO umbrellaApplicationVO = oaPropertyUmbrellaApplicationService.detail(id);
        return Result.returnOk(umbrellaApplicationVO);
    }
    
    /**
    *@Description 删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "删除雨伞申请记录")
    public Result remove(@PathVariable("id")Integer id){
        oaPropertyUmbrellaApplicationService.removeById(id);
        return Result.returnOk();
    }
    
    /**
    *@Description 领用和归还
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "领用和归还", notes = "领用和归还")
    @PostMapping(value = "/useOrRevert")
    @LoginUser
    @StatusChangedNotification("雨伞信息")
    @SystemLog(description = "雨伞申请领用和归还")
    public Result useOrRevert(AuthUser authUser,@RequestBody UmbrellaUseDTO umbrellaUseDTO){
        log.debug("umbrellaUseDTO=================>"+umbrellaUseDTO);
        OaPropertyUmbrellaApplication application = new OaPropertyUmbrellaApplication();
        OaPropertyUmbrellaApplication application1 = oaPropertyUmbrellaApplicationService.getById(umbrellaUseDTO.getId());
        //领用
        if(application1.getStatus()==0){
            BeanUtils.copyProperties(umbrellaUseDTO,application);
            application.setUseHandleId(authUser.getId());
            application.setUseTime(new Date());
            application.setStatus(1);
        }
        if(application1.getStatus()==1){
            application.setId(umbrellaUseDTO.getId());
            application.setRevertHandleId(authUser.getId());
            application.setRevertAmount(umbrellaUseDTO.getUseAmount());
            application.setRevertDeposit(umbrellaUseDTO.getUseDeposit());
            application.setRevertRemark(umbrellaUseDTO.getUseRemark());
            application.setRevertTime(new Date());
            application.setStatus(2);
        }
        log.debug("application================>"+application);
        oaPropertyUmbrellaApplicationService.updateById(application);
        //消息推送
        String username = umbrellaApplicationMapper.queryUsername(umbrellaUseDTO.getId());
        PushUtil.setTargetUsername(username);
        return Result.returnOk();
    }
    
    /**
    *@Description APP端添加申请信息展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "APP端添加申请信息展示", notes = "APP端添加申请信息展示")
    @GetMapping(value = "/addApplicationShow")
    @LoginUser
    @SystemLog(description = "添加雨伞申请信息展示")
    public Result addApplicationShow(AuthUser authUser){
        UmbrellaApplicationAddVO umbrellaApplicationAddVO = oaPropertyUmbrellaApplicationService.addApplicationShow(authUser);
        return Result.returnOk(umbrellaApplicationAddVO);
    }
    
    /**
    *@Description App端添加
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "App端添加", notes = "App端添加")
    @PostMapping(value = "/addApp")
    @LoginUser
    @SystemLog(description = "App端添加雨伞申请")
    public Result addApp(AuthUser authUser,@RequestBody UmbrellaApplicationAddDTO umbrellaApplicationAddDTO){
        oaPropertyUmbrellaApplicationService.addApp(authUser,umbrellaApplicationAddDTO);
        return Result.returnOk();
    }
    
    /**
    *@Description App端列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "App端列表展示", notes = "App端列表展示")
    @GetMapping(value = "/appShow/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "App端雨伞申请列表展示")
    public Result appShow(@ApiIgnore AuthUser authUser,@PathVariable("pageNum")Integer pageNum,@PathVariable("pageSize")Integer pageSize){
        Page page=new Page(pageNum,pageSize);
        List<UmbrellaApplicationVO> applications = oaPropertyUmbrellaApplicationService.appShow(page,authUser);
        return Result.returnOk(page.setRecords(applications));
    }
    
    /**
    *@Description PC端编辑
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC端编辑", notes = "PC端编辑")
    @PostMapping(value = "/edit")
    @SystemLog(description = "雨伞申请编辑")
    public Result edit(@RequestBody OaPropertyUmbrellaApplication oaPropertyUmbrellaApplication){
        oaPropertyUmbrellaApplicationService.updateById(oaPropertyUmbrellaApplication);
        return Result.returnOk();
    }

}
