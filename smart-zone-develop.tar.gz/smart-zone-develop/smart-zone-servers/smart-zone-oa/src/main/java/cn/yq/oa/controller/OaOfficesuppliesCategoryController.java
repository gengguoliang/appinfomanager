package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.oa.entity.OaOfficesuppliesCategory;
import cn.yq.oa.entity.OaOfficesuppliesItem;
import cn.yq.oa.service.IOaOfficesuppliesCategoryService;
import cn.yq.oa.service.IOaOfficesuppliesItemService;
import cn.yq.oa.vo.OaOfficesuppliesCategoryVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 办公用品分类表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-01-31
 */
@Api(value = "办公用品分类", description = "办公用品分类")
@RestController
@RequestMapping("/oa-officesupplies-category")
public class OaOfficesuppliesCategoryController {

    @Autowired
    private IOaOfficesuppliesCategoryService oaOfficesuppliesCategoryService;
    @Autowired
    private IOaOfficesuppliesItemService oaOfficesuppliesItemService;

    /**
    *@Description 添加分类（传parentId,添加父类子类都可以）
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "添加分类", notes = "添加分类")
    @PostMapping(value = "/add")
    @SystemLog(description = "办公用品分类添加")
    public Result add(@RequestBody OaOfficesuppliesCategory oaOfficesuppliesCategory){
        oaOfficesuppliesCategoryService.save(oaOfficesuppliesCategory);
        return Result.returnOk();
    }

    /**
    *@Description 删除分类
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "删除分类", notes = "删除分类")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "办公用品分类删除")
    public Result remove(@PathVariable("id") Integer id){
        QueryWrapper<OaOfficesuppliesItem> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("category_id",id)
                .eq("is_del",0);
        int count = oaOfficesuppliesItemService.count(queryWrapper);
        if(count>0){
            return new Result(ResultEnum.FAIL,"此分类还有物品，无法删除");
        }
        oaOfficesuppliesCategoryService.removeById(id);
        return Result.returnOk();
    }
    
    /**
    *@Description 修改分类
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "修改分类", notes = "修改分类")
    @PostMapping(value = "/change")
    @SystemLog(description = "办公用品分类编辑")
    public Result change(@RequestBody OaOfficesuppliesCategory oaOfficesuppliesCategory){
        oaOfficesuppliesCategoryService.updateById(oaOfficesuppliesCategory);
        return Result.returnOk();
    }
    
    /**
    *@Description 查询分类
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "查询分类", notes = "查询分类")
    @PostMapping(value = "/show")
    public Result show(){
        QueryWrapper queryWrapper=new QueryWrapper();
        queryWrapper.eq("is_del",0);
        List<OaOfficesuppliesCategory> rootList = oaOfficesuppliesCategoryService.list(queryWrapper);
        List<OaOfficesuppliesCategoryVO> list=new ArrayList<>();
        for (int i = 0; i < rootList.size(); i++) {
            OaOfficesuppliesCategory typeEntity = rootList.get(i);
            // 找出根级菜单
            if (0==typeEntity.getParentId()) {
                OaOfficesuppliesCategoryVO oaOfficesuppliesCategoryVO = new OaOfficesuppliesCategoryVO();
                BeanUtils.copyProperties(typeEntity,oaOfficesuppliesCategoryVO);
                list.add(oaOfficesuppliesCategoryVO);
            }
        }
        // 循环根级菜单，为每个根级菜单下的子菜单list赋值。
        for (OaOfficesuppliesCategoryVO entity : list) {
            entity.setChildren(getChildNodes(entity.getId(), rootList));
        }

        return Result.returnOk(list);
    }

    /**
    *@Description 递归查询
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    private List<OaOfficesuppliesCategoryVO> getChildNodes(Integer id, List<OaOfficesuppliesCategory> rootList) {
        List<OaOfficesuppliesCategoryVO> childList = new ArrayList<>();
        for (OaOfficesuppliesCategory typeEntity : rootList) {
            if (0 != typeEntity.getParentId()) {
                if (typeEntity.getParentId().equals(id)) {
                    OaOfficesuppliesCategoryVO oaOfficesuppliesCategoryVO = new OaOfficesuppliesCategoryVO();
                    BeanUtils.copyProperties(typeEntity,oaOfficesuppliesCategoryVO);
                    childList.add(oaOfficesuppliesCategoryVO);
                }
            }
        }
        if (childList.size() == 0) {
            return null;
        }
        for (OaOfficesuppliesCategoryVO entity : childList) {
            entity.setChildren(getChildNodes(entity.getId(), rootList));
        }
        return childList;
    }

}
