package cn.yq.oa.controller;

import cn.yq.client.userapi.UserClient;
import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 员工基本信息 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-15
 */
@RestController
@RequestMapping("/oa-employee-basicinfo")
@Api(value = "人事档案管理", description = "人事档案管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaEmployeeBasicinfoController {

    IOaEmployeeBasicinfoService oaEmployeeBasicinfoService;
    IOaEmployeeContactinfoService oaEmployeeContactinfoService;
    IOaEmployeeSocialsecinfoService oaEmployeeSocialsecinfoService;
    IOaEmployeeEducationinfoService oaEmployeeEducationinfoService;
    IOaEmployeeEmploymentinfoService oaEmployeeEmploymentinfoService;
    //岗位信息
    IOaEmployeePostinfoService oaEmployeePostinfoService;
    IOaEmployeeContractinfoService oaEmployeeContractinfoService;
    IOaEmployeeRecruitinfoService oaEmployeeRecruitinfoService;
    IOaEmployeeAdjustpostService oaEmployeeAdjustpostService;

    IOaEmployeeRegularinfoService oaEmployeeRegularinfoService;
    IOaEmployeeLeaveinfoService oaEmployeeLeaveinfoService;

    ISysDictDataService sysDictDataService;
    ICommonFilesService commonFilesService;

    private UserClient userClient;




    @ApiOperation(value = "添加员工/待入职员工", notes = "添加员工/待入职员工")
    @PostMapping(value = "/addEmployee", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加员工")
    public Result addEmployee(@ApiIgnore AuthUser authUser, @RequestBody EmployParam param) {
        OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
        BeanUtils.copyProperties(param,basicinfo);
        basicinfo.setOrganizationId(authUser.getOrganizationId());
        oaEmployeeBasicinfoService.saveOrUpdate(basicinfo);
        //保存岗位信息
        OaEmployeePostinfo postinfo = new OaEmployeePostinfo();
        postinfo.setEmployeeid(basicinfo.getId());
        postinfo.setEntrydate(basicinfo.getJoinedTime());
        postinfo.setMailbox(basicinfo.getMailbox());
        postinfo.setCorrectionDate(basicinfo.getRegularTime());
        postinfo.setDeptid(basicinfo.getDeptid());
        postinfo.setPost(basicinfo.getPost());
        postinfo.setEmployShape(basicinfo.getEmployShape());
        postinfo.setJobNumber(basicinfo.getJobNumber());
        postinfo.setCorrectionStatus(param.getCorrectionStatus());
        oaEmployeePostinfoService.save(postinfo);
        //保存教育信息
        OaEmployeeEducationinfo educationinfo = new OaEmployeeEducationinfo();
        educationinfo.setEmployeeid(basicinfo.getId());
        oaEmployeeEducationinfoService.save(educationinfo);

        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取人事档案信息", notes = "分页获取人事档案信息")
    @PostMapping("/listEmployeeInfo/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页获取人事档案信息")
    public Result<IPage<EmployeePageInfoVO>> listEmployeeInfo(@ApiIgnore AuthUser authUser,
                                                              @PathVariable("pageNum") int pageNum,
                                                              @PathVariable("pageSize") int pageSize,
                                                              @RequestBody EmployeeSearchParam param){
        Page<EmployeePageInfoVO> page = new Page<EmployeePageInfoVO>(pageNum, pageSize);
        param.setOrganizationId(authUser.getOrganizationId());
        List<EmployeePageInfoVO> vos = oaEmployeeBasicinfoService.selectEmployeePageInfo(page, param);
        IPage<EmployeePageInfoVO> iPage = null;
        iPage=page.setRecords(vos);
        return Result.returnOk(iPage);
    }
    @ApiOperation(value = "查询工号是否唯一", notes = "查询工号是否唯一")
    @PostMapping("/isUnique")
    @SystemLog(description = "查询工号是否唯一")
    public Result isUnique(@RequestBody JobNumberParam param){
        String jobNumber = param.getJobNumber();
        QueryWrapper<OaEmployeeBasicinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("job_number",jobNumber);
        queryWrapper.eq("is_del",false);
        List<OaEmployeeBasicinfo> list = oaEmployeeBasicinfoService.list(queryWrapper);
        Boolean isUnique=true;
        if(list.size()>0){
            isUnique=false;
        }
        return Result.returnOk(isUnique);

    }


    @ApiOperation(value = "查看人员个人信息", notes = "查看人员个人信息")
    @GetMapping("/viewEmployeeInfo/{id}")
    @LoginUser
    @SystemLog(description = "查看人员个人信息")
    public Result viewEmployeeInfo(@ApiIgnore AuthUser authUser,@PathVariable("id") Integer id){
        //获取基础信息
         Map map = new HashMap<>();
        OaEmployeeBasicinfo basicinfo = oaEmployeeBasicinfoService.getById(id);

        AuthUser authUser1 = new AuthUser();
        authUser1.setId(authUser.getId());
        authUser1.setDepartmentId(basicinfo.getDeptid());
        List<Integer> deptIds = userClient.getDeptIds2(authUser1);
        map.put("deptIds",deptIds);
        map.put("basicinfo",basicinfo);
        //获取身份证照片集合
        QueryWrapper<CommonFiles> queryWrapper6 = new QueryWrapper<>();
        queryWrapper6.eq("is_del",0);
        queryWrapper6.eq("relation_type","employee_idimg_attachment");
        queryWrapper6.eq("relation_id",basicinfo.getId());
        List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper6);
        map.put("idimglist",commonFilesList);
        //获取员工照片集合
        QueryWrapper<CommonFiles> queryWrapper7 = new QueryWrapper<>();
        queryWrapper7.eq("is_del",0);
        queryWrapper7.eq("relation_type","employee_img_attachment");
        queryWrapper7.eq("relation_id",basicinfo.getId());
        List<CommonFiles> imglist = commonFilesService.list(queryWrapper7);
        map.put("imglist",imglist);

        QueryWrapper<OaEmployeeContactinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("employeeid",id);
        OaEmployeeContactinfo contactinfo = oaEmployeeContactinfoService.getOne(queryWrapper);
        if(null == contactinfo){
            contactinfo = new OaEmployeeContactinfo();
        }
        map.put("contactinfo",contactinfo);
        QueryWrapper<OaEmployeeSocialsecinfo> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("employeeid",id);
        OaEmployeeSocialsecinfo socialsecinfo = oaEmployeeSocialsecinfoService.getOne(queryWrapper1);
        if(null == socialsecinfo){
            socialsecinfo = new OaEmployeeSocialsecinfo();
        }
        map.put("socialsecinfo",socialsecinfo);
        QueryWrapper<OaEmployeeEducationinfo> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("employeeid",id);
        OaEmployeeEducationinfo educationinfo = oaEmployeeEducationinfoService.getOne(queryWrapper2);
        if(null == educationinfo){
            educationinfo = new OaEmployeeEducationinfo();
        }
        map.put("educationinfo",educationinfo);

        //获取毕业证书集合
        QueryWrapper<CommonFiles> queryWrapper8 = new QueryWrapper<>();
        queryWrapper8.eq("is_del",0);
        queryWrapper8.eq("relation_type","employee_zsimg_attachment");
        queryWrapper8.eq("relation_id",educationinfo.getId());
        List<CommonFiles> zsimglist = commonFilesService.list(queryWrapper8);
        map.put("zsimglist",zsimglist);

        //获取学位证书集合
        QueryWrapper<CommonFiles> queryWrapper9 = new QueryWrapper<>();
        queryWrapper9.eq("is_del",0);
        queryWrapper9.eq("relation_type","employee_xwimg_attachment");
        queryWrapper9.eq("relation_id",educationinfo.getId());
        List<CommonFiles> xwimglist = commonFilesService.list(queryWrapper9);
        map.put("xwimglist",xwimglist);

        QueryWrapper<OaEmployeeEmploymentinfo> queryWrapper3 = new QueryWrapper<>();
        queryWrapper3.eq("employeeid",id);
        OaEmployeeEmploymentinfo employmentinfo = oaEmployeeEmploymentinfoService.getOne(queryWrapper3);
        if(null == employmentinfo){
            employmentinfo = new OaEmployeeEmploymentinfo();
        }
        map.put("employmentinfo",employmentinfo);

        //获取简历集合
        QueryWrapper<CommonFiles> queryWrapper10 = new QueryWrapper<>();
        queryWrapper10.eq("is_del",0);
        queryWrapper10.eq("relation_type","employee_resume_attachment");
        queryWrapper10.eq("relation_id",employmentinfo.getId());
        List<CommonFiles> resumelist = commonFilesService.list(queryWrapper10);
        map.put("resumelist",resumelist);

        //获取离职证明集合
        QueryWrapper<CommonFiles> queryWrapper11 = new QueryWrapper<>();
        queryWrapper11.eq("is_del",0);
        queryWrapper11.eq("relation_type","employee_lzzm_attachment");
        queryWrapper11.eq("relation_id",employmentinfo.getId());
        List<CommonFiles> lzzmlist = commonFilesService.list(queryWrapper11);
        map.put("lzzmlist",lzzmlist);

        return Result.returnOk(map);
    }

    @ApiOperation(value = "获取字典表数据", notes = "获取字典表数据")
    @GetMapping(value = "/getDicInfo")
    public Result getDicInfo(){

        Map map = new HashMap();
        //获取非正式类型集合
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<SysDictData>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("dict_type","informal_category");
        List<SysDictData> listType= sysDictDataService.list(queryWrapper);
        map.put("fzslx",listType);

        QueryWrapper<SysDictData> queryWrapper1 = new QueryWrapper<SysDictData>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("dict_type","recruit_channel");
        List<SysDictData> listChannel= sysDictDataService.list(queryWrapper1);
        map.put("zpqd",listChannel);


        QueryWrapper<SysDictData> queryWrapper2 = new QueryWrapper<SysDictData>();
        queryWrapper2.eq("is_del",0);
        queryWrapper2.eq("dict_type","post");
        List<SysDictData> listPost= sysDictDataService.list(queryWrapper2);
        map.put("gw",listPost);

        QueryWrapper<SysDictData> queryWrapper3 = new QueryWrapper<SysDictData>();
        queryWrapper3.eq("is_del",0);
        queryWrapper3.eq("dict_type","gryy");
        List<SysDictData> listGryy= sysDictDataService.list(queryWrapper3);
        map.put("gryy",listGryy);

        QueryWrapper<SysDictData> queryWrapper4 = new QueryWrapper<SysDictData>();
        queryWrapper4.eq("is_del",0);
        queryWrapper4.eq("dict_type","gsyy");
        List<SysDictData> listGsyy= sysDictDataService.list(queryWrapper4);
        map.put("gsyy",listGsyy);


        return Result.returnOk(map);
    }

    @ApiOperation(value = "删除人员信息", notes = "删除人员信息")
    @PostMapping("/deleteEmployeeInfo/{id}")
    @SystemLog(description = "删除人员信息")
    public Result deleteEmployeeInfo(@PathVariable("id") Integer id){
        if(null != id){
            oaEmployeeBasicinfoService.removeById(id);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改个人基本信息", notes = "修改个人基本信息")
    @PostMapping("/updateEmployeeBasicInfo")
    @SystemLog(description = "修改个人基本信息")
    public Result updateEmployeeBasicInfo(@RequestBody OaEmployeeBasicinfoParam basicinfoParam){
        OaEmployeeBasicinfo oaEmployeeBasic = new OaEmployeeBasicinfo();
        BeanUtils.copyProperties(basicinfoParam,oaEmployeeBasic);
        oaEmployeeBasicinfoService.saveOrUpdate(oaEmployeeBasic);
        //上传前删掉文件信息
        if(null!=basicinfoParam.getIdimglist()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_idimg_attachment");
            queryWrapper.eq("relation_id",basicinfoParam.getId());
            commonFilesService.remove(queryWrapper);
        }
        if(null!=basicinfoParam.getImglist()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_img_attachment");
            queryWrapper.eq("relation_id",basicinfoParam.getId());
            commonFilesService.remove(queryWrapper);
        }
        //处理身份证照片与员工照片
        for (CommFileVO commFileVO : basicinfoParam.getIdimglist()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //身份证名称
            commonFiles.setRelationType("employee_idimg_attachment");
            commonFiles.setRelationId(basicinfoParam.getId());
            commonFilesService.save(commonFiles);
        }
        //处理员工照片
        for (CommFileVO commFileVO : basicinfoParam.getImglist()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //身份证名称
            commonFiles.setRelationType("employee_img_attachment");
            commonFiles.setRelationId(basicinfoParam.getId());
            commonFilesService.save(commonFiles);
        }
        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "修改个人通讯信息", notes = "修改个人通讯信息")
    @PostMapping("/updateEmployeeContactInfo")
    @SystemLog(description = "修改个人通讯信息")
    public Result updateEmployeeContactInfo(@RequestBody OaEmployeeContactinfo contactinfo){
        oaEmployeeContactinfoService.saveOrUpdate(contactinfo);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改个人工资/社保信息", notes = "修改个人工资/社保信息")
    @PostMapping("/updateEmployeeSocialSecinfo")
    @SystemLog(description = "修改个人工资/社保信息")
    public Result updateEmployeeSocialSecinfo(@RequestBody OaEmployeeSocialsecinfo socialsecinfo){
        oaEmployeeSocialsecinfoService.saveOrUpdate(socialsecinfo);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改个人教育信息", notes = "修改个人教育信息")
    @PostMapping("/updateEmployeeEducationinfo")
    @SystemLog(description = "修改个人教育信息")
    public Result updateEmployeeEducationinfo(@RequestBody OaEmployeeEducationinfoParam educationinfoParam){
        OaEmployeeEducationinfo educationinfo = new OaEmployeeEducationinfo();
        BeanUtils.copyProperties(educationinfoParam,educationinfo);
        oaEmployeeEducationinfoService.saveOrUpdate(educationinfo);

        //上传前删掉文件信息
        if(null!=educationinfoParam.getZsimglist()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_zsimg_attachment");
            queryWrapper.eq("relation_id",educationinfo.getId());
            commonFilesService.remove(queryWrapper);
        }
        if(null!=educationinfoParam.getXwimglist()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_xwimg_attachment");
            queryWrapper.eq("relation_id",educationinfo.getId());
            commonFilesService.remove(queryWrapper);
        }
        //毕业证书
        for (CommFileVO commFileVO : educationinfoParam.getZsimglist()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //身份证名称
            commonFiles.setRelationType("employee_zsimg_attachment");
            commonFiles.setRelationId(educationinfo.getId());
            commonFilesService.save(commonFiles);
        }
        //学位证书
        for (CommFileVO commFileVO : educationinfoParam.getXwimglist()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //身份证名称
            commonFiles.setRelationType("employee_xwimg_attachment");
            commonFiles.setRelationId(educationinfo.getId());
            commonFilesService.save(commonFiles);
        }


        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改个人从业信息", notes = "修改个人从业信息")
    @PostMapping("/updateEmployeeEmploymentinfo")
    @SystemLog(description = "修改个人从业信息")
    public Result updateEmployeeEmploymentinfo(@RequestBody OaEmployeeEmploymentinfoParam employmentinfoparam){
        OaEmployeeEmploymentinfo employmentinfo = new OaEmployeeEmploymentinfo();
        BeanUtils.copyProperties(employmentinfoparam,employmentinfo);
        oaEmployeeEmploymentinfoService.saveOrUpdate(employmentinfo);

        //上传前删掉文件信息
        if(null!=employmentinfoparam.getResumeList()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_resume_attachment");
            queryWrapper.eq("relation_id",employmentinfo.getId());
            commonFilesService.remove(queryWrapper);
        }
        if(null!=employmentinfoparam.getLzzmList()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_lzzm_attachment");
            queryWrapper.eq("relation_id",employmentinfo.getId());
            commonFilesService.remove(queryWrapper);
        }
        //简历
        for (CommFileVO commFileVO : employmentinfoparam.getResumeList()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            commonFiles.setRelationType("employee_resume_attachment");
            commonFiles.setRelationId(employmentinfo.getId());
            commonFilesService.save(commonFiles);
        }
        //离职证明
        for (CommFileVO commFileVO : employmentinfoparam.getLzzmList()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //身份证名称
            commonFiles.setRelationType("employee_lzzm_attachment");
            commonFiles.setRelationId(employmentinfo.getId());
            commonFilesService.save(commonFiles);
        }

        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "查看人员岗位信息", notes = "查看人员岗位信息")
    @GetMapping("/viewEmployeePostInfo/{id}")
    @SystemLog(description = "查看人员岗位信息")
    public Result viewEmployeePostInfo(@PathVariable("id") Integer id){
        Map map = new HashMap();
        QueryWrapper<OaEmployeePostinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("employeeid",id);
//        OaEmployeePostinfo postinfo = oaEmployeePostinfoService.getOne(queryWrapper);
        OaEmployeePostinfoVo postinfo = oaEmployeePostinfoService.getPostinfoByEmployeeid(id);
        map.put("postinfo",postinfo);
        QueryWrapper<OaEmployeeContractinfo> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("employeeid",id);
        queryWrapper1.eq("is_del",false);
        queryWrapper1.orderByDesc("create_time");
        List<OaEmployeeContractinfo> list = oaEmployeeContractinfoService.list(queryWrapper1);
        map.put("contractList",list);
        OaEmployeeContractinfo contractinfo = new OaEmployeeContractinfo();
        if(list.size()>0){
            contractinfo = list.get(0);
        }
//        map.put("contractinfo",contractinfo);
        //获取合同附件信息
        QueryWrapper<CommonFiles> queryWrapper10 = new QueryWrapper<>();
        queryWrapper10.eq("is_del",0);
        queryWrapper10.eq("relation_type","employee_contract_attachment");
        queryWrapper10.eq("relation_id",contractinfo.getId());
        List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper10);
        map.put("contract_attachment",commonFilesList);

//        QueryWrapper<OaEmployeeRecruitinfo> queryWrapper2 = new QueryWrapper<>();
//        queryWrapper2.eq("employeeid",id);
//        OaEmployeeRecruitinfo recruitinfo = oaEmployeeRecruitinfoService.getOne(queryWrapper2);
        OaEmployeeRecruitinfoVo recruitinfo = oaEmployeeBasicinfoService.getRecruitinfo(id);
        map.put("recruitinfo",recruitinfo);

        //调岗信息列表
//        QueryWrapper<OaEmployeeAdjustpost> queryWrapper3 = new QueryWrapper<>();
//        queryWrapper3.eq("employeeid",id);
//        queryWrapper3.eq("is_del",false);
//        queryWrapper3.orderByDesc("create_time");
//        List<OaEmployeeAdjustpost> adjustpostList = oaEmployeeAdjustpostService.list(queryWrapper3);
        List<OaEmployeeAdjustpostVo> adjustpostList = oaEmployeeBasicinfoService.listAdjustPosts(id);
        for (OaEmployeeAdjustpostVo temp:adjustpostList){
            QueryWrapper<CommonFiles> queryWrapper11 = new QueryWrapper<>();
            queryWrapper11.eq("is_del",0);
            queryWrapper11.eq("relation_type","employee_adjustpost_attachment");
            queryWrapper11.eq("relation_id",temp.getId());
            List<CommonFiles> adcommonFilesList = commonFilesService.list(queryWrapper11);
            temp.setAttachmentlist(adcommonFilesList);
        }
        map.put("adjustpostList",adjustpostList);

        return Result.returnOk(map);
    }


    @ApiOperation(value = "删除调岗信息", notes = "删除调岗信息")
    @GetMapping("/deleteAdjustPost/{id}")
    @SystemLog(description = "删除调岗信息")
    public Result deleteAdjustPost(@PathVariable("id") Integer id){
        if(null != id){
            oaEmployeeAdjustpostService.removeById(id);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除合同续签信息", notes = "删除合同续签信息")
    @GetMapping("/deleteContract/{id}")
    @SystemLog(description = "删除合同续签信息")
    public Result deleteContract(@PathVariable("id") Integer id){
        if(null != id){
            oaEmployeeContractinfoService.removeById(id);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改个人岗位基本信息", notes = "修改个人岗位基本信息")
    @PostMapping("/updateEmployeePostinfo")
    @SystemLog(description = "修改个人岗位基本信息")
    public Result updateEmployeePostinfo(@RequestBody OaEmployeePostinfo postinfo){
        oaEmployeePostinfoService.saveOrUpdate(postinfo);
        //修改主表岗位
        if (null!=postinfo.getPost()){
            OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
            basicinfo.setId(postinfo.getEmployeeid());
            basicinfo.setPost(postinfo.getPost());
            oaEmployeeBasicinfoService.updateById(basicinfo);
        }
        if (null!=postinfo.getJobNumber()){
            OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
            basicinfo.setId(postinfo.getEmployeeid());
            basicinfo.setJobNumber(postinfo.getJobNumber());
            oaEmployeeBasicinfoService.updateById(basicinfo);
        }

        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "修改个人合同基本信息", notes = "修改个人合同基本信息")
    @PostMapping("/updateEmployeeContractinfo")
    @SystemLog(description = "修改个人合同基本信息")
    public Result updateEmployeeContractinfo(@RequestBody EmployeeContractinfoParam contactinfo){
        OaEmployeeContractinfo oaEmployeeContractinfo = new OaEmployeeContractinfo();
        BeanUtils.copyProperties(contactinfo,oaEmployeeContractinfo);
        oaEmployeeContractinfoService.saveOrUpdate(oaEmployeeContractinfo);
        //上传前删除
        if(null!=contactinfo.getFiles()){
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("relation_type","employee_contract_attachment");
            queryWrapper.eq("relation_id",oaEmployeeContractinfo.getId());
            commonFilesService.remove(queryWrapper);
        }
        //上传附件
        for (CommFileVO commFileVO : contactinfo.getFiles()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //人事档案合同附件名称
            commonFiles.setRelationType("employee_contract_attachment");
            commonFiles.setRelationId(oaEmployeeContractinfo.getId());
            commonFilesService.save(commonFiles);
        }
        //修改员工基本信息合同到期时间
        if (null != contactinfo.getCcontractEndtime()){
            OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
            basicinfo.setId(contactinfo.getEmployeeid());
            basicinfo.setContractExpiretime(contactinfo.getCcontractEndtime());
            oaEmployeeBasicinfoService.updateById(basicinfo);
        }

        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "修改个人招聘基本信息", notes = "修改个人招聘基本信息")
    @PostMapping("/updateEmployeeRecruitinfo")
    @SystemLog(description = "修改个人招聘基本信息")
    public Result updateEmployeeRecruitinfo(@RequestBody OaEmployeeRecruitinfo recruitinfo){
        oaEmployeeRecruitinfoService.saveOrUpdate(recruitinfo);
        return Result.returnOk("操作成功");
    }

    //转正
    @ApiOperation(value = "转正", notes = "转正")
    @PostMapping(value = "/regular", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "转正")
    public Result regular(@ApiIgnore AuthUser authUser, @RequestBody OaEmployeeRecruitinfoParam param) {
        OaEmployeeRegularinfo regularinfo = new OaEmployeeRegularinfo();
        BeanUtils.copyProperties(param,regularinfo);
        oaEmployeeRegularinfoService.saveOrUpdate(regularinfo);

        //上传附件
        for (CommFileVO commFileVO : param.getFiles()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //人事档案合同附件名称
            commonFiles.setRelationType("employee_regular_attachment");
            commonFiles.setRelationId(regularinfo.getId());
            commonFilesService.save(commonFiles);
        }
        //更改岗位表字段
        OaEmployeePostinfo postinfo = new OaEmployeePostinfo();
        postinfo.setCorrectionStatus("已转正");
        postinfo.setCorrectionDate(param.getTime());
        QueryWrapper<OaEmployeePostinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("employeeid",param.getEmployeeid());
        oaEmployeePostinfoService.update(postinfo,queryWrapper);

        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "调岗", notes = "调岗")
    @PostMapping(value = "/adjustpost", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "调岗")
    public Result adjustpost(@ApiIgnore AuthUser authUser, @RequestBody OaEmployeeAdjustpostParam param) {
        OaEmployeeAdjustpost adjustpost = new OaEmployeeAdjustpost();
        BeanUtils.copyProperties(param,adjustpost);
        oaEmployeeAdjustpostService.saveOrUpdate(adjustpost);

        //上传附件
        for (CommFileVO commFileVO : param.getFiles()){
            CommonFiles commonFiles = new CommonFiles();
            CopyUtils.copyProperties(commFileVO,commonFiles);
            //人事档案合同附件名称
            commonFiles.setRelationType("employee_adjustpost_attachment");
            commonFiles.setRelationId(adjustpost.getId());
            commonFilesService.save(commonFiles);
        }

        //修改岗位
        OaEmployeePostinfo postinfo = new OaEmployeePostinfo();
        postinfo.setDeptid(param.getTzbm());
        postinfo.setPost(param.getTzgw());
        QueryWrapper<OaEmployeePostinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("employeeid",param.getEmployeeid());
        oaEmployeePostinfoService.update(postinfo,queryWrapper);
        //修改主表岗位
        OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
        basicinfo.setId(param.getEmployeeid());
        basicinfo.setPost(param.getTzgw());
        basicinfo.setDeptid(param.getTzbm());
        oaEmployeeBasicinfoService.updateById(basicinfo);


        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "离职", notes = "离职")
    @PostMapping(value = "/leave", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "离职")
    public Result leave(@ApiIgnore AuthUser authUser, @RequestBody OaEmployeeLeaveinfo param) {
        oaEmployeeLeaveinfoService.saveOrUpdate(param);
        //更改人员状态
        OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
        basicinfo.setId(param.getEmployeeid());
        basicinfo.setStatus(3);
        oaEmployeeBasicinfoService.saveOrUpdate(basicinfo);

        return Result.returnOk("操作成功");
    }




    @ApiOperation(value = "获取离职信息", notes = "获取离职信息")
    @GetMapping("/getLeaveInfo/{employeeid}")
    @SystemLog(description = "获取离职信息")
    public Result<OaEmployeeLeaveinfoVo> getLeaveInfo(@PathVariable("employeeid") Integer employeeid){
        OaEmployeeLeaveinfoVo leaveInfo = oaEmployeeBasicinfoService.getLeaveInfo(employeeid);
        return Result.returnOk(leaveInfo);
    }

    @ApiOperation(value = "入职", notes = "入职")
    @PostMapping("/join")
    @SystemLog(description = "入职")
    public Result join(@RequestBody JoinParam joinParam){
        //修改基本信息
         OaEmployeeBasicinfo basicinfo = new OaEmployeeBasicinfo();
         BeanUtils.copyProperties(joinParam,basicinfo);
         oaEmployeeBasicinfoService.updateById(basicinfo);
        //修改岗位信息
        OaEmployeePostinfo postinfo = new OaEmployeePostinfo();
        postinfo.setDeptid(joinParam.getDeptId());
        postinfo.setPost(joinParam.getPostId());
        postinfo.setEntrydate(joinParam.getJoinedTime());
        QueryWrapper<OaEmployeePostinfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("employeeid",joinParam.getId());
        oaEmployeePostinfoService.update(postinfo,queryWrapper);
        //修改教育信息
        OaEmployeeEducationinfo educationinfo = new OaEmployeeEducationinfo();
        educationinfo.setEducation(joinParam.getEducation());
        educationinfo.setEducationName(joinParam.getEducationName());
        QueryWrapper<OaEmployeeEducationinfo> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("employeeid",joinParam.getId());
        oaEmployeeEducationinfoService.update(educationinfo,queryWrapper1);

        return Result.returnOk("操作成功");
    }

































































}
