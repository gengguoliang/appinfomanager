package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.oa.entity.OaFixedassetsCategory;
import cn.yq.oa.service.IOaFixedassetsCategoryService;
import cn.yq.oa.service.IOaFixedassetsCategoryService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 固定资产分类表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-01-31
 */
@RestController
@RequestMapping("/oa-fixedassets-category")
@AllArgsConstructor
public class OaFixedassetsCategoryController {

    private IOaFixedassetsCategoryService oaFixedassetsCategoryService;

    //分页获取分类列表
    @GetMapping("/getAllCategory/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产分类信息")
    public Result getAllCategory(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize){
        Page<OaFixedassetsCategory> page= new Page<OaFixedassetsCategory>(pageNum,pageSize);
        IPage<OaFixedassetsCategory> assetsCategoryIPage = oaFixedassetsCategoryService.selectCategoryPage(page);
        return Result.returnOk(assetsCategoryIPage);
    }
    //获取分类列表
    @ApiOperation(value = "获取分类列表", notes = "获取分类列表")
    @GetMapping("/getCategorys")
    @SystemLog(description = "获取分类列表")
    public Result getCategorys(){
        QueryWrapper<OaFixedassetsCategory> queryWrapper = new QueryWrapper<OaFixedassetsCategory>();
        queryWrapper.eq("category_status",1);
        List<OaFixedassetsCategory> list = oaFixedassetsCategoryService.list(queryWrapper);
        return Result.returnOk(list);
    }
    //添加分类
    @PostMapping("/addCategory")
    @SystemLog(description = "添加固定资产分类")
    public Result addCategory(@RequestBody OaFixedassetsCategory assetsCategory){
        String name = assetsCategory.getCategoryName();
        QueryWrapper<OaFixedassetsCategory> queryWrapper = new QueryWrapper<OaFixedassetsCategory>();

        //判断分类名称重复
        //新增
        if(null == assetsCategory.getId()){
            queryWrapper.eq("category_name",name);
            List<OaFixedassetsCategory> list = oaFixedassetsCategoryService.list(queryWrapper);
            if (list.size()>0){
                return new Result(ResultEnum.FAIL.getCode(),"分类名称重复，请重新输入!");
            }
        }
        //修改
        if(null != assetsCategory.getId()){

            OaFixedassetsCategory category = oaFixedassetsCategoryService.getById(assetsCategory.getId());
            //分类名称不改，备注修改（id为当前id）
            if(category.getCategoryName().equals(assetsCategory.getCategoryName())){
                //oaFixedassetsCategoryService.saveOrUpdate(assetsCategory);
            }
            else{
                //分类名称修改
                queryWrapper.eq("category_name",name);
                List<OaFixedassetsCategory> list = oaFixedassetsCategoryService.list(queryWrapper);
                if (list.size()>0){
                    return new Result(ResultEnum.FAIL.getCode(),"分类名称重复，请重新输入!");
                }
            }
        }

        oaFixedassetsCategoryService.saveOrUpdate(assetsCategory);
        return Result.returnOk("操作成功");
    }

    //启用停用状态
    @GetMapping("/changeStatus/{id}/{status}")
    @SystemLog(description = "固定资产分类状态变更")
    public Result changeStatus(@PathVariable("id") Integer id, @PathVariable("status") Integer status){
        OaFixedassetsCategory assetsCategory = new OaFixedassetsCategory();
        assetsCategory.setId(id);
        assetsCategory.setCategoryStatus(status);
        oaFixedassetsCategoryService.updateById(assetsCategory);
        return Result.returnOk("操作成功");
    }


	
}
