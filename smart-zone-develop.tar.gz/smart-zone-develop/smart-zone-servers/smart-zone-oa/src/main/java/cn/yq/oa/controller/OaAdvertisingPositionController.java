package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.oa.entity.OaAdvertisingPosition;
import cn.yq.oa.entity.OaFixedassetsCategory;
import cn.yq.oa.param.AdvertisingPositionParam;
import cn.yq.oa.param.OaRegionParam;
import cn.yq.oa.param.PositionSearchParam;
import cn.yq.oa.service.IOaAdvertisingPositionService;
import cn.yq.oa.vo.OaAdvertisingPositionVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import sun.awt.geom.AreaOp;

import java.util.List;

/**
 * <p>
 * 广告位信息管理表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-12
 */
@RestController
@Api(value = "广告位信息管理", description = "广告位信息管理 API", position = 100, protocols = "http")
@RequestMapping("/oa-advertising-position")
@Slf4j
@AllArgsConstructor
public class OaAdvertisingPositionController {

    @Autowired
    private IOaAdvertisingPositionService oaAdvertisingPositionService;

    @ApiOperation(value = "添加或修改广告位", notes = "添加或修改广告位")
    @PostMapping(value = "/addOrSaveAdvertisingPosition", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加广告位信息")
    public Result addOrSaveAdvertisingPosition(@RequestBody AdvertisingPositionParam advertisingPositionParam) {
        if(null != advertisingPositionParam.getId() && advertisingPositionParam.getId() != 0){
            OaAdvertisingPosition oaAdvertisingPosition = new OaAdvertisingPosition();
            CopyUtils.copyProperties(advertisingPositionParam,oaAdvertisingPosition);
            oaAdvertisingPositionService.updateById(oaAdvertisingPosition);
        }else{
            OaAdvertisingPosition oaAdvertisingPosition = new OaAdvertisingPosition();
            CopyUtils.copyProperties(advertisingPositionParam,oaAdvertisingPosition);
            oaAdvertisingPositionService.save(oaAdvertisingPosition);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "根据id获取广告信息", notes = "根据id获取广告信息")
    @GetMapping("/getAdvertisingPositionInfo/{id}")
    @SystemLog(description = "广告位信息详情")
    public Result getAdvertisingPositionInfo(@PathVariable("id")Integer id){
        OaAdvertisingPosition oaAdvertisingPosition = oaAdvertisingPositionService.getById(id);
        return  Result.returnOk(oaAdvertisingPosition);
    }

    @ApiOperation(value = "分页获取广告位", notes = "分页获取广告位")
    @PostMapping("/listAdvertisingPosition/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询广告位信息")
    public Result listAdvertisingPosition(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize,@RequestBody PositionSearchParam param){

        Page<OaAdvertisingPositionVO> page= new Page<OaAdvertisingPositionVO>(pageNum,pageSize);
        IPage<OaAdvertisingPositionVO> iPage = oaAdvertisingPositionService.selectOaAdvertisingPosition(page,param);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "停用、启用广告位", notes = "停用、启用广告位")
    @GetMapping("/changeStatusById/{id}/{status}")
    @SystemLog(description = "广告位信息状态变更")
    public Result changeStatusById(@PathVariable("id") int id,@PathVariable("status") int status){
        OaAdvertisingPosition oaAdvertisingPosition = new OaAdvertisingPosition();
        oaAdvertisingPosition.setId(id);
        if(status == 0){
            oaAdvertisingPosition.setStatus(1);
        }else if(status == 1){
            oaAdvertisingPosition.setStatus(0);
        }
        oaAdvertisingPositionService.updateById(oaAdvertisingPosition);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除广告位", notes = "删除广告位")
    @GetMapping("/deletePositionById/{id}")
    @SystemLog(description = "删除广告位信息")
    public Result deletePositionById(@PathVariable("id") int id){
        oaAdvertisingPositionService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "广告位名称判重", notes = "广告位名称判重")
    @GetMapping("/isNameExist")
    @SystemLog(description = "广告位名称判重")
    public Result<Boolean> isNameExist(@RequestParam("name") String name){
        boolean flag = false;
        //根据当前名称查询
        QueryWrapper<OaAdvertisingPosition>queryWrapper = new QueryWrapper<OaAdvertisingPosition>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("name",name);
        List<OaAdvertisingPosition> list = oaAdvertisingPositionService.list(queryWrapper);
        if(null != list && list.size() > 0){
            flag = false;
        }else{
            flag = true;
        }
        return Result.returnOk(flag);
    }















	
}
