package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.PrimaryGenerater;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.MaintenanceSearchParam;
import cn.yq.oa.param.OaFixedassetsMaintenanceParam;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsMaintenanceService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.impl.OrderNumberServiceImpl;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 固定资产维修信息表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-03
 */
@RestController
@RequestMapping("/oa-fixedassets-maintenance")
@AllArgsConstructor
public class OaFixedassetsMaintenanceController {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    IOaFixedassetsMaintenanceService oaFixedassetsMaintenanceService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsService oaFixedassetsService;

    @Resource(name = "orderNumberServiceImpl")
    OrderNumberServiceImpl orderNumberService;

    @PostMapping("/addMaintenance")
    @LoginUser
    @SystemLog(description = "添加固定资产维修信息")
    public Result addMaintenance(AuthUser authUser,@RequestBody OaFixedassetsMaintenanceParam oaFixedassetsMaintenanceParam){

        OaFixedassetsMaintenance oaFixedassetsMaintenance = new OaFixedassetsMaintenance();
        BeanUtils.copyProperties(oaFixedassetsMaintenanceParam,oaFixedassetsMaintenance);
        //维修单号
//        String dh = "WXD" + PrimaryGenerater.geneterNextNumber(sdf.format(new Date()));
        String dh = orderNumberService.getOneOrderNumber("WXD");
        oaFixedassetsMaintenance.setNo(dh);
        oaFixedassetsMaintenance.setCreateBy(authUser.getName());
        //保存维修表数据
        oaFixedassetsMaintenanceService.saveOrUpdate(oaFixedassetsMaintenance);
        //获取维修单id
        int id = oaFixedassetsMaintenance.getId();
        //保存业务明细表数据
        List<Integer> list = oaFixedassetsMaintenanceParam.getIds();

        for (Integer temp:list){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //
            oaFixedassetsBizDetail.setBizType(4);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp);
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
        //修改资产状态(根据资产id)

        for (Integer temp:list){
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(temp);
            //领用中
            oaFixedassets.setStatus(3);
            oaFixedassetsService.updateById(oaFixedassets);
        }
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllMaintenance/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产维修信息")
    public Result getAllMaintenance(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody MaintenanceSearchParam maintenanceSearchParam) {
        Page<OaFixedassetsMaintenance> page = new Page<OaFixedassetsMaintenance>(pageNum,pageSize);
        IPage<OaFixedassetsMaintenance> iPage = oaFixedassetsMaintenanceService.selectMaintenancePage(page, maintenanceSearchParam);
        return Result.returnOk(iPage);
    }

    /**
     * 删除功能
     */
    @GetMapping("/deleteMaintenance/{id}")
    @SystemLog(description = "删除固定资产维修信息")
    public Result deleteMaintenance(@PathVariable("id") int id){
        oaFixedassetsMaintenanceService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 查看详情
     */
    @GetMapping("/getMaintenanceById/{id}")
    @SystemLog(description = "固定资产维修信息详情")
    public Result getMaintenanceById(@PathVariable("id") int id){
        Map map = new HashMap<>();
        OaFixedassetsMaintenance oaFixedassetsMaintenance = oaFixedassetsMaintenanceService.getById(id);
        map.put("maintenanceInfo",oaFixedassetsMaintenance);
        //固定资产列表
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",4);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        //查询固定资产表
        Collection list1 = null;
        if (ids.size()>0){
            list1 = oaFixedassetsService.listByIds(ids);
        }
        map.put("list",list1);
        return Result.returnOk(map);
    }

    /**
     * 查看中编辑
     */
    @PostMapping("/updateMaintenanceView")
    @SystemLog(description = "编辑固定资产维修信息")
    public Result updateMaintenanceView(@RequestBody OaFixedassetsMaintenanceParam oaFixedassetsMaintenanceParam){
        OaFixedassetsMaintenance oaFixedassetsMaintenance = new OaFixedassetsMaintenance();
        BeanUtils.copyProperties(oaFixedassetsMaintenanceParam,oaFixedassetsMaintenance);
        oaFixedassetsMaintenanceService.updateById(oaFixedassetsMaintenance);

        //如果修改维修状态为已完成，修改固定资产为闲置
        if(oaFixedassetsMaintenanceParam.getStatus()==1){
            QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
            queryWrapper.eq("biz_type",4);
            queryWrapper.eq("biz_id",oaFixedassetsMaintenanceParam.getId());
            queryWrapper.eq("is_del",0);
            List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
            for (OaFixedassetsBizDetail temp:list){
                OaFixedassets oaFixedassets = new OaFixedassets();
                oaFixedassets.setId(temp.getAssetId());
                oaFixedassets.setStatus(0);
                oaFixedassetsService.updateById(oaFixedassets);
            }
        }
        return Result.returnOk("操作成功");
    }

    /**
     * 编辑
     */
    @PostMapping("/updateMaintenance")
    public Result updateMaintenance(@RequestBody OaFixedassetsMaintenanceParam oaFixedassetsMaintenanceParam){
        OaFixedassetsMaintenance oaFixedassetsMaintenance = new OaFixedassetsMaintenance();
        BeanUtils.copyProperties(oaFixedassetsMaintenanceParam,oaFixedassetsMaintenance);
        oaFixedassetsMaintenanceService.updateById(oaFixedassetsMaintenance);
        int id = oaFixedassetsMaintenanceParam.getId();
        //资产处理
        //查到原有资产，删除
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",4);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper2 = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper2.in("asset_id",ids);
        oaFixedassetsBizDetailService.remove(queryWrapper2);
        //新增资产
        //保存业务明细表数据
        List<Integer> listp = oaFixedassetsMaintenanceParam.getIds();

        for (Integer temp:listp){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //
            oaFixedassetsBizDetail.setBizType(4);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp);
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
        //修改资产状态(根据资产id)
        for (Integer temp:listp){
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(temp);
            //领用中
            oaFixedassets.setStatus(3);
            oaFixedassetsService.updateById(oaFixedassets);
        }
        return Result.returnOk("操作成功");
    }


}
