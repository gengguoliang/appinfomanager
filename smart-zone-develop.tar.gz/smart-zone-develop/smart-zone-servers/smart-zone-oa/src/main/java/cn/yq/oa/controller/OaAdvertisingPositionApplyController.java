package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.common.enumeration.PropertyNoEnum;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 广告位申请表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-12
 */
@RestController
@RequestMapping("/oa-advertising-position-apply")
@Api(value = "广告位申请管理", description = "广告位申请管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaAdvertisingPositionApplyController {

    @Autowired
    private IOaAdvertisingPositionApplyService oaAdvertisingPositionApplyService;
    @Autowired
    private IOaAdvertisingPositionService oaAdvertisingPositionService;
    @Autowired
    private IOaApplicationAdvertisingPositionService oaApplicationAdvertisingPositionService;
    @Autowired
    private OrderNumberService orderNumberService;
    @Autowired
    private IOaCooperationRegisterService oaCooperationRegisterService;
    @Autowired
    private IOaRegisterAdvertisingPositionService oaRegisterAdvertisingPositionService;
    @Autowired
    private ICommonFilesService commonFilesService;

    @ApiOperation(value = "添加广告位申请", notes = "添加广告位申请")
    @PostMapping(value = "/addAdvertisingPositionApply", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加广告位申请")
    public Result addAdvertisingPositionApply(@ApiIgnore AuthUser authUser, @RequestBody AdvertisingPositionApplyParam advertisingPositionApplyParam) {
        //添加广告申请表
        OaAdvertisingPositionApply oaAdvertisingPositionApply = new OaAdvertisingPositionApply();
        if(null != advertisingPositionApplyParam){
            CopyUtils.copyProperties(advertisingPositionApplyParam,oaAdvertisingPositionApply);
        }
        oaAdvertisingPositionApply.setProposerId(authUser.getId());
        //生成申请编号
        String num = orderNumberService.getOneOrderNumber(PropertyNoEnum.AD_APPLICATION_NO.getPrefix());
        oaAdvertisingPositionApply.setApplicationno(num);
        oaAdvertisingPositionApply.setApplicationTime(new Date());
        //oaAdvertisingPositionApply.setApplicationCompanyId(authUser.getOrganizationId());
        oaAdvertisingPositionApplyService.save(oaAdvertisingPositionApply);
        //保存关联表数据
        for(Integer id : advertisingPositionApplyParam.getAdvertisingPositionIds()){
            OaApplicationAdvertisingPosition oaApplicationAdvertisingPosition = new OaApplicationAdvertisingPosition();
            oaApplicationAdvertisingPosition.setAdvertisingPositionId(id);
            oaApplicationAdvertisingPosition.setApplicationId(oaAdvertisingPositionApply.getId());
            oaApplicationAdvertisingPositionService.save(oaApplicationAdvertisingPosition);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除广告位申请记录", notes = "删除广告位申请记录")
    @GetMapping("/deletePositionApplyById/{id}")
    @SystemLog(description = "删除广告位申请记录",table = LogTableConstant.ADVERTISING)
    public Result deletePositionApplyById(@PathVariable("id") int id){
        oaAdvertisingPositionApplyService.removeById(id);
        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "查看广告位申请详情", notes = "查看广告位申请详情")
    @GetMapping("/viewPositionApplyById/{id}")
    @SystemLog(description = "添加广告位申请")
    public Result<AdvertisementApplicationDetailVO> viewPositionApplyById(@PathVariable("id") int id){
        AdvertisementApplicationDetailVO advertisementApplicationDetailVO = new AdvertisementApplicationDetailVO();
        //获取当前申请表信息
        OaAdvertisingPositionApply oaAdvertisingPositionApply = oaAdvertisingPositionApplyService.getById(id);
        if(null != oaAdvertisingPositionApply){
            CopyUtils.copyProperties(oaAdvertisingPositionApply,advertisementApplicationDetailVO);
            //获取申请表下的广告信息
            QueryWrapper<OaApplicationAdvertisingPosition> queryWrapper = new QueryWrapper<OaApplicationAdvertisingPosition>();
            queryWrapper.eq("application_id",oaAdvertisingPositionApply.getId());
            queryWrapper.eq("is_del",0);
            List<OaApplicationAdvertisingPosition> list = oaApplicationAdvertisingPositionService.list(queryWrapper);
            List<AdvertisingPositionParam> listPosition = new ArrayList<AdvertisingPositionParam>();
            for (OaApplicationAdvertisingPosition oaApplicationAdvertisingPosition : list){
                OaAdvertisingPosition oaAdvertisingPosition = oaAdvertisingPositionService.getById(oaApplicationAdvertisingPosition.getAdvertisingPositionId());
                AdvertisingPositionParam advertisingPositionParam = new AdvertisingPositionParam();
                CopyUtils.copyProperties(oaAdvertisingPosition,advertisingPositionParam);
                listPosition.add(advertisingPositionParam);
            }
            advertisementApplicationDetailVO.setList(listPosition);
            //获取合作登记表
            QueryWrapper<OaCooperationRegister> queryWrapper1 = new QueryWrapper<OaCooperationRegister>();
            queryWrapper1.eq("application_id",id);
            queryWrapper1.eq("is_del",0);
            OaCooperationRegister oaCooperationRegister = oaCooperationRegisterService.getOne(queryWrapper1);
            if(null != oaCooperationRegister){
                //获取当前合作下的合同集合
                QueryWrapper<CommonFiles> queryWrapper3 = new QueryWrapper<CommonFiles>();
                queryWrapper3.eq("is_del",0);
                queryWrapper3.eq("relation_type","cooperation");
                queryWrapper3.eq("relation_id",oaCooperationRegister.getId());
                List<CommonFiles> commonFilesList = commonFilesService.list(queryWrapper3);
                List<CleanUpAttachmentParam> comlist = new ArrayList<>();
                for(CommonFiles commonFiles :commonFilesList){
                    CleanUpAttachmentParam cleanUpAttachmentParam = new CleanUpAttachmentParam();
                    CopyUtils.copyProperties(commonFiles,cleanUpAttachmentParam);
                    comlist.add(cleanUpAttachmentParam);
                }
                advertisementApplicationDetailVO.setCommfilelist(comlist);
                CopyUtils.copyProperties(oaCooperationRegister,advertisementApplicationDetailVO);
                //获取合作登记表下的广告信息
                QueryWrapper<OaRegisterAdvertisingPosition> queryWrapper2 = new QueryWrapper<OaRegisterAdvertisingPosition>();
                queryWrapper2.eq("register_id",oaCooperationRegister.getId());
                queryWrapper2.eq("is_del",0);
                List<OaRegisterAdvertisingPosition> list1 = oaRegisterAdvertisingPositionService.list(queryWrapper2);
                List<AdvertisingPositionParam> listPositions = new ArrayList<AdvertisingPositionParam>();
                for (OaRegisterAdvertisingPosition oaRegisterAdvertisingPosition : list1){
                    OaAdvertisingPosition oaAdvertisingPosition = oaAdvertisingPositionService.getById(oaRegisterAdvertisingPosition.getAdvertisingPositionId());
                    AdvertisingPositionParam advertisingPositionParam = new AdvertisingPositionParam();
                    CopyUtils.copyProperties(oaAdvertisingPosition,advertisingPositionParam);
                    listPositions.add(advertisingPositionParam);
                }
                advertisementApplicationDetailVO.setList1(listPositions);
            }
        }

        return Result.returnOk(advertisementApplicationDetailVO);
    }


    @ApiOperation(value = "分页获取广告位申请列表", notes = "分页获取广告位申请列表")
    @PostMapping("/listAdvertisingPositionApply/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询广告位申请列表")
    public Result<IPage<AdvertisingPositionApplyVO>> listAdvertisingPositionApply(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize,@RequestBody PositionApplySearchParam param){

        Page<AdvertisingPositionApplyVO> page= new Page<AdvertisingPositionApplyVO>(pageNum,pageSize);
        IPage<AdvertisingPositionApplyVO> iPage = oaAdvertisingPositionApplyService.selectAdvertisingPositionApplyInfo(page,param);
        for(AdvertisingPositionApplyVO advertisingPositionApplyVO : iPage.getRecords()){
            //根据广告申请id获取所有广告名称
            List<AdvertisingPositionParam> list = oaAdvertisingPositionService.selectAllAdvertisingPositionName(advertisingPositionApplyVO.getId());
            advertisingPositionApplyVO.setParams(list);
            List<String> list1 = new ArrayList<>();
            for(AdvertisingPositionParam advertisingPositionParam : list){
                list1.add(advertisingPositionParam.getName());
            }
            advertisingPositionApplyVO.setAdvertisingPositionName(list1);
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "App获取广告位申请列表", notes = "App获取广告位申请列表")
    @GetMapping("/listPositionApplyApp/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "App端查询广告位申请列表")
    public Result<IPage<PositionApplyAppVO>> listPositionApplyApp(@ApiIgnore AuthUser authUser,
                                                                 @PathVariable("pageNum") int pageNum,
                                                                 @PathVariable("pageSize") int pageSize){
        IPage<PositionApplyAppVO> list = null;
        if(authUser.getOrganizationId() != 0 && null != authUser.getOrganizationId()) {
            Page<PositionApplyAppVO> page = new Page<>(pageNum,pageSize);
            list = page.setRecords(oaAdvertisingPositionApplyService.selectPositionApplyAPP(authUser,page));
            for (PositionApplyAppVO positionApplyAppVO : list.getRecords()) {
                //根据广告申请id获取所有广告名称
                List<AdvertisingPositionParam> list1 = oaAdvertisingPositionService.selectAllAdvertisingPositionName(positionApplyAppVO.getId());
                List<String> list2 = new ArrayList<>();
                for (AdvertisingPositionParam advertisingPositionParam : list1) {
                    list2.add(advertisingPositionParam.getName());
                }
                positionApplyAppVO.setAdvertisingPositionName(list2);
            }
        }
        return Result.returnOk(list);
    }



    @ApiOperation(value = "根据区域获取广告位信息", notes = "根据区域获取广告位信息")
    @GetMapping("/getPositionInfoByRegionid/{id}")
    public Result getPositionInfoByRegionid(@PathVariable("id") int id){
        QueryWrapper<OaAdvertisingPosition> queryWrapper = new QueryWrapper<OaAdvertisingPosition>();
        queryWrapper.eq("region",id);
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("status", 0);
        List<OaAdvertisingPosition> list = oaAdvertisingPositionService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "受理/受理终止/业务终止/撤回 广告位申请", notes = "受理/受理终止/业务终止/撤回 广告位申请")
    @PostMapping("/changeStatusById")
    @LoginUser
    @StatusChangedNotification("广告位")
    @SystemLog(description = "广告位申请状态变更")
    public Result changeStatusById(@ApiIgnore  AuthUser authUser, @RequestBody AdvertisingChangeStatus param){
        String userName = oaAdvertisingPositionApplyService.selectApplyByUserName(param.getId());
        OaAdvertisingPositionApply oaAdvertisingPositionApply = new OaAdvertisingPositionApply();
        oaAdvertisingPositionApply.setId(param.getId());
        oaAdvertisingPositionApply.setStatus(param.getStatus());
        if(param.getStatus() == 2){//已受理
            PushUtil.setTargetUsername(userName);
            oaAdvertisingPositionApply.setResponofficer(authUser.getName());
            oaAdvertisingPositionApply.setResponseRemark(param.getRemark());
            oaAdvertisingPositionApply.setResponseTime(new Date());
        }else if(param.getStatus() == 4){//业务终止
            oaAdvertisingPositionApply.setStopPerson(authUser.getName());
            oaAdvertisingPositionApply.setStopReason(param.getRemark());
            oaAdvertisingPositionApply.setStopTime(new Date());
        }else if(param.getStatus() == 5){//已撤回
            oaAdvertisingPositionApply.setWithdrawReason(param.getRemark());
            oaAdvertisingPositionApply.setWithdrawTime(new Date());
        }else if(param.getStatus() == 6){//受理终止
            oaAdvertisingPositionApply.setResponofficer(authUser.getName());
            oaAdvertisingPositionApply.setResponseRemark(param.getRemark());
            oaAdvertisingPositionApply.setResponseTime(new Date());
        }
        oaAdvertisingPositionApplyService.updateById(oaAdvertisingPositionApply);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "单元下的单位信息", notes = "单元下的单位信息")
    @GetMapping("/getOrganizationByUnitId/{unitId}")
    public Result<List<OrganizationInfoVO>> getOrganizationByUnitId(@PathVariable("unitId") Integer unitId){
        List<OrganizationInfoVO> orglist = oaAdvertisingPositionApplyService.selectOrganizationName(unitId);
        return  Result.returnOk(orglist);
    }
}
