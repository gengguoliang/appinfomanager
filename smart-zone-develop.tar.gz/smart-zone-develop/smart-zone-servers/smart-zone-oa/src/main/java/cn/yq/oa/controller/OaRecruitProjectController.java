package cn.yq.oa.controller;


import cn.yq.client.userapi.UserClient;
import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oarecruit.ProjectDTO;
import cn.yq.oa.dto.oarecruit.ProjectShowDTO;
import cn.yq.oa.entity.OaRecruitPost;
import cn.yq.oa.mapper.IOaRecruitProjectMapper;
import cn.yq.oa.service.IOaRecruitPostService;
import cn.yq.oa.service.IOaRecruitProjectService;
import cn.yq.oa.vo.oarecruit.PorjectShowVO;
import cn.yq.oa.vo.oarecruit.RecruitDemandVO;
import cn.yq.oa.vo.oarecruit.RecruitPostVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 招聘计划表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-04-17
 */
@RestController
@RequestMapping("/oa-recruit-project")
@Api(value = "zhengjh招聘计划", description = "zhengjh招聘计划")
@Slf4j
public class OaRecruitProjectController {

    @Autowired
    private IOaRecruitProjectService oaRecruitProjectService;
    @Autowired
    private IOaRecruitPostService oaRecruitPostService;
    @Autowired
    private IOaRecruitProjectMapper oaRecruitProjectMapper;
    @Autowired
    private UserClient userClient;

    
    /**
    *@Description PC新增与编辑
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC新增与编辑", notes = "PC新增与编辑")
    @PostMapping(value = "/addRecruitProject")
    @LoginUser
    @SystemLog(description = "添加或编辑招聘计划")
    public Result addRecruitProject(@ApiIgnore AuthUser authUser, @RequestBody ProjectDTO projectDTO){
        oaRecruitProjectService.addRecruitProject(authUser,projectDTO);
        return Result.returnOk();
    }

    
    /**
    *@Description PC删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC删除", notes = "PC删除")
    @GetMapping(value = "/removeRecruitProject/{id}")
    @SystemLog(description = "删除招聘计划")
    public Result removeRecruitProject(@PathVariable("id")Integer id){
        //删除计划表
        oaRecruitProjectService.removeById(id);
        //删除职位表
        QueryWrapper<OaRecruitPost> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("project_id",id).eq("is_del",0);
        oaRecruitPostService.remove(queryWrapper);
        return Result.returnOk();
    }
    
    
    /**
    *@Description PC列表+详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC列表+详情", notes = "PC列表+详情")
    @PostMapping(value = "/showRecruitProject/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "招聘计划信息展示")
    public Result<IPage<PorjectShowVO>> showRecruitProject(@ApiIgnore AuthUser authUser,
                                     @PathVariable("pageNum")Integer pageNum,
                                     @PathVariable("pageSize")Integer pageSize,
                                     @RequestBody ProjectShowDTO projectShowDTO){
        Page<PorjectShowVO> page=new Page<>(pageNum,pageSize);
        IPage<PorjectShowVO> iPage=
                page.setRecords(oaRecruitProjectService.showRecruitProject(page,authUser,projectShowDTO));
        return Result.returnOk(iPage);
    }

    /**
    *@Description PC详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC详情", notes = "PC详情")
    @GetMapping(value = "/recruitProject/{id}")
    @LoginUser
    @SystemLog(description = "招聘计划详情")
    public Result recruitProject(@ApiIgnore AuthUser authUser,@PathVariable("id")Integer id){
        List<RecruitPostVO> postVOs = oaRecruitProjectMapper.getRecruitPostVOs(id);
        postVOs.forEach(postVO->{
            authUser.setDepartmentId(postVO.getDeptId());
            List<Integer> deptIds = userClient.getDeptIds2(authUser);
            postVO.setDeptIds(deptIds);
        });
        return Result.returnOk(postVOs);
    }

    /**
    *@Description PC需求下拉
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC需求下拉", notes = "PC需求下拉")
    @GetMapping(value = "/getDemand")
    @LoginUser
    public Result<List<RecruitDemandVO>> getDemand(@ApiIgnore AuthUser authUser){
        List<RecruitDemandVO> demands = oaRecruitProjectService.getDemand(authUser);
        return Result.returnOk(demands);
    }

	
}
