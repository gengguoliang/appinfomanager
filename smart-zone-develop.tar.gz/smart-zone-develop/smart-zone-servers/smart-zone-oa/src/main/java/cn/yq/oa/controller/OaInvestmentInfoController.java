package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaBusinessCooperative;
import cn.yq.oa.entity.OaInvestmentFocus;
import cn.yq.oa.entity.OaInvestmentInfo;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.param.*;
import cn.yq.oa.service.IOaInvestmentFocusService;
import cn.yq.oa.service.IOaInvestmentInfoService;
import cn.yq.oa.service.ISysDictDataService;
import cn.yq.oa.vo.OaInvestmentInfoVo;
import cn.yq.oa.vo.OaInvestmentVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qiniu.util.Auth;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.awt.image.ConvolveOp;
import java.util.*;

/**
 * <p>
 * 投资方信息管理 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-01
 */
@AllArgsConstructor
@RestController
@RequestMapping("/oa-investment-info")
@Api(value = "投资方管理", description = "ggl投资方管理 API", position = 100, protocols = "http")
public class OaInvestmentInfoController {

    private IOaInvestmentInfoService oaInvestmentInfoService;

    private ISysDictDataService sysDictDataService;

    private IOaInvestmentFocusService oaInvestmentFocusService;


    @ApiOperation(value = "获取所有分类(list1关注领域/list2关注阶段/list3融资方式)取dictLabel和dictValue字段", notes = "获取所有分类")
    @GetMapping("/getALLClassify")
    public Result getALLClassify(){
        Map map = new HashMap();
        //获取关注领域
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("dict_type","follow_field");
        List<SysDictData> list1 = sysDictDataService.list(queryWrapper);
        //获取关注阶段
        QueryWrapper<SysDictData> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("dict_type","follow_stage");
        List<SysDictData> list2 = sysDictDataService.list(queryWrapper1);
        //获取融资方式
        QueryWrapper<SysDictData> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("is_del",0);
        queryWrapper2.eq("dict_type","financing_mode");
        List<SysDictData> list3 = sysDictDataService.list(queryWrapper2);
        map.put("list1",list1);
        map.put("list2",list2);
        map.put("list3",list3);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "添加(id传0)/编辑(id传实际的值)投资方信息", notes = "添加/编辑投资方信息")
    @PostMapping(value = "/addInvestment", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加投资方信息")
    public Result addInvestment(@ApiIgnore AuthUser authUser, @RequestBody OaInvestmentParam param) {
        if(null != param){
            OaInvestmentInfo oaInvestmentInfo = new OaInvestmentInfo();
            CopyUtils.copyProperties(param,oaInvestmentInfo);
            if(param.getId() != 0){ //编辑
                oaInvestmentInfoService.updateById(oaInvestmentInfo);
                //获取当前投资方下的所有分类信息
                QueryWrapper<OaInvestmentFocus>queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("is_del",0);
                queryWrapper.eq("invest_id",param.getId());
                List<OaInvestmentFocus> list = oaInvestmentFocusService.list(queryWrapper);
                //删除所有分类信息
                for (OaInvestmentFocus oaInvestmentFocus : list){
                    oaInvestmentFocusService.removeById(oaInvestmentFocus.getId());
                }
                //维护关注领域关系表
                for(SysDictDataParam sysDictDataParam : param.getFocusAreas()){
                    OaInvestmentFocus oaInvestmentFocus = new OaInvestmentFocus();
                    CopyUtils.copyProperties(sysDictDataParam,oaInvestmentFocus);
                    oaInvestmentFocus.setDictType("follow_field");
                    oaInvestmentFocus.setInvestId(oaInvestmentInfo.getId());
                    oaInvestmentFocusService.save(oaInvestmentFocus);
                }
                //维护关注阶段关系表
                for(SysDictDataParam sysDictDataParam : param.getFocusStage()){
                    OaInvestmentFocus oaInvestmentFocus = new OaInvestmentFocus();
                    CopyUtils.copyProperties(sysDictDataParam,oaInvestmentFocus);
                    oaInvestmentFocus.setDictType("follow_stage");
                    oaInvestmentFocus.setInvestId(oaInvestmentInfo.getId());
                    oaInvestmentFocusService.save(oaInvestmentFocus);
                }
            }else{//新增
                oaInvestmentInfo.setCreateBy(authUser.getName());
                oaInvestmentInfoService.save(oaInvestmentInfo);
                //维护关注领域关系表
                for(SysDictDataParam sysDictDataParam : param.getFocusAreas()){
                    OaInvestmentFocus oaInvestmentFocus = new OaInvestmentFocus();
                    CopyUtils.copyProperties(sysDictDataParam,oaInvestmentFocus);
                    oaInvestmentFocus.setDictType("follow_field");
                    oaInvestmentFocus.setInvestId(oaInvestmentInfo.getId());
                    oaInvestmentFocusService.save(oaInvestmentFocus);
                }
                //维护关注阶段关系表
                for(SysDictDataParam sysDictDataParam : param.getFocusStage()){
                    OaInvestmentFocus oaInvestmentFocus = new OaInvestmentFocus();
                    CopyUtils.copyProperties(sysDictDataParam,oaInvestmentFocus);
                    oaInvestmentFocus.setDictType("follow_stage");
                    oaInvestmentFocus.setInvestId(oaInvestmentInfo.getId());
                    oaInvestmentFocusService.save(oaInvestmentFocus);
                }
            }
        }
        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "分页投资方信息", notes = "分页投资方信息")
    @PostMapping("/listInvestment/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页查询投资方信息")
    public Result<IPage<OaInvestmentVo>> listInvestment(@ApiIgnore AuthUser authUser,
                                                        @PathVariable("pageNum") int pageNum,
                                                        @PathVariable("pageSize") int pageSize,
                                                        @RequestBody InvestmentSearchParam param){
        Page<OaInvestmentVo> page = new Page<OaInvestmentVo>(pageNum, pageSize);
        IPage<OaInvestmentVo> iPage = page.setRecords(oaInvestmentInfoService.selectInvestmentList(page,param));
        for(OaInvestmentVo oaInvestmentVo : iPage.getRecords()){
            //获取当前投资方的关注领域
            QueryWrapper<OaInvestmentFocus>queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("is_del",0);
            queryWrapper.eq("invest_id",oaInvestmentVo.getId());
            queryWrapper.eq("dict_type","follow_field");
            List<OaInvestmentFocus> list1 = oaInvestmentFocusService.list(queryWrapper);
            List<SysDictDataParam> list2 = new ArrayList<>();
            for (OaInvestmentFocus oaInvestmentFocus : list1){
                SysDictDataParam sysDictDataParam = new SysDictDataParam();
                CopyUtils.copyProperties(oaInvestmentFocus,sysDictDataParam);
                list2.add(sysDictDataParam);
            }
            oaInvestmentVo.setFocusAreas(list2);
            //获取当前投资方下的关于阶段
            QueryWrapper<OaInvestmentFocus>queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("is_del",0);
            queryWrapper1.eq("invest_id",oaInvestmentVo.getId());
            queryWrapper1.eq("dict_type","follow_stage");
            List<OaInvestmentFocus> list3 = oaInvestmentFocusService.list(queryWrapper1);
            List<SysDictDataParam> list4 = new ArrayList<>();
            for (OaInvestmentFocus oaInvestmentFocus : list3){
                SysDictDataParam sysDictDataParam = new SysDictDataParam();
                CopyUtils.copyProperties(oaInvestmentFocus,sysDictDataParam);
                list4.add(sysDictDataParam);
            }
            oaInvestmentVo.setFocusStage(list4);
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "查看投资方信息", notes = "查看投资方信息")
    @GetMapping("/viewInvestment/{id}")
    @SystemLog(description = "查看投资方信息详情")
    public Result<OaInvestmentVo> viewInvestment(@PathVariable("id") Integer id){
        OaInvestmentInfo oaInvestmentInfo = oaInvestmentInfoService.getById(id);
        OaInvestmentVo oaInvestmentVo = new OaInvestmentVo();
        if(null != oaInvestmentInfo){
            CopyUtils.copyProperties(oaInvestmentInfo,oaInvestmentVo);
            //获取当前投资方的关注领域
            QueryWrapper<OaInvestmentFocus>queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("is_del",0);
            queryWrapper.eq("invest_id",oaInvestmentVo.getId());
            queryWrapper.eq("dict_type","follow_field");
            List<OaInvestmentFocus> list1 = oaInvestmentFocusService.list(queryWrapper);
            List<SysDictDataParam> list2 = new ArrayList<>();
            for (OaInvestmentFocus oaInvestmentFocus : list1){
                SysDictDataParam sysDictDataParam = new SysDictDataParam();
                CopyUtils.copyProperties(oaInvestmentFocus,sysDictDataParam);
                list2.add(sysDictDataParam);
            }
            oaInvestmentVo.setFocusAreas(list2);
            //获取当前投资方下的关于阶段
            QueryWrapper<OaInvestmentFocus>queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("is_del",0);
            queryWrapper1.eq("invest_id",oaInvestmentVo.getId());
            queryWrapper1.eq("dict_type","follow_stage");
            List<OaInvestmentFocus> list3 = oaInvestmentFocusService.list(queryWrapper1);
            List<SysDictDataParam> list4 = new ArrayList<>();
            for (OaInvestmentFocus oaInvestmentFocus : list3){
                SysDictDataParam sysDictDataParam = new SysDictDataParam();
                CopyUtils.copyProperties(oaInvestmentFocus,sysDictDataParam);
                list4.add(sysDictDataParam);
            }
            oaInvestmentVo.setFocusStage(list4);
        }
        return Result.returnOk(oaInvestmentVo);
    }

    @ApiOperation(value = "删除投资方信息", notes = "删除投资方信息")
    @GetMapping("/deleteInvestment/{id}")
    @SystemLog(description = "删除投资方信息")
    public Result deleteInvestment(@PathVariable("id") Integer id){
        oaInvestmentInfoService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "修改状态(传更改之后的状态0:未发布 1：已发布 2：已下架 )", notes = "修改状态")
    @GetMapping("/changeStatus/{id}/{status}")
    @LoginUser
    @SystemLog(description = "投资方信息状态变更")
    public Result changeStatus(@ApiIgnore AuthUser authUser,@PathVariable("id") Integer id,@PathVariable("status") Integer status){
        OaInvestmentInfo oaInvestmentInfo = new OaInvestmentInfo();
        oaInvestmentInfo.setId(id);
        oaInvestmentInfo.setStatus(status);
        if(status == 1){//发布
            oaInvestmentInfo.setPublishTime(new Date());
            oaInvestmentInfo.setPublishName(authUser.getName());
        }
        oaInvestmentInfoService.updateById(oaInvestmentInfo);
        return Result.returnOk("操作成功");
    }
















































}
