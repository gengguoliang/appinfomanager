package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.RecruitStatusDTO;
import cn.yq.oa.dto.oarecruit.OffloadSomeDTO;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.param.RecruitParam;
import cn.yq.oa.param.RecruitSearchParam;
import cn.yq.oa.service.IOaRecruitAuditingService;
import cn.yq.oa.service.impl.SysDictDataServiceImpl;
import cn.yq.oa.vo.oarecruit.RecruitVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 招聘审核信息表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-26
 */
@RestController
@RequestMapping("/oa-recruit-auditing")
@Api(value = "zhengjh人才招聘PC端", description = "zhengjh人才招聘PC端")
public class OaRecruitAuditingController {

    @Autowired
    private IOaRecruitAuditingService oaRecruitAuditingService;
    @Autowired
    private SysDictDataServiceImpl sysDictDataService;

    /**
     * @Description PC新增和编辑
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC新增和编辑", notes = "PC新增和编辑")
    @PostMapping(value = "/addOrEdit")
    @LoginUser
    @SystemLog(description = "添加人才招聘信息")
    public Result addOrEdit(@ApiIgnore AuthUser authUser, @RequestBody RecruitParam recruitParam) {
        oaRecruitAuditingService.addOrEdit(authUser, recruitParam);
        return Result.returnOk();
    }


    /**
     * @Description PC列表展示, flag 1:管理模块 2：审核模块
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC列表展示,flag 1:管理模块 2：审核模块", notes = "PC列表展示,flag 1:管理模块 2：审核模块")
    @PostMapping(value = "/listRecruit/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "人才招聘列表展示")
    public Result<IPage<RecruitVO>> listRecruit(@ApiIgnore AuthUser authUser,
                                                @PathVariable("pageNum") Integer pageNum,
                                                @PathVariable("pageSize") Integer pageSize,
                                                @RequestBody RecruitSearchParam searchParam) {
        Page<RecruitVO> page = new Page<>(pageNum, pageSize);
        IPage<RecruitVO> iPage = page.setRecords(oaRecruitAuditingService.listRecruit(page, authUser, searchParam));
        return Result.returnOk(iPage);
    }


    /**
     * @Description PC删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC删除", notes = "PC删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "删除人才招聘信息")
    public Result remove(@PathVariable("id") Integer id) {
        oaRecruitAuditingService.remove(id);
        return Result.returnOk();
    }

    /**
     * @Description PC批量删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC批量删除", notes = "PC批量删除")
    @PostMapping(value = "/removeSome")
    @SystemLog(description = "人才招聘批量删除")
    public Result removeSome(@RequestBody List<Integer> ids) {
        for (Integer id : ids) {
            oaRecruitAuditingService.remove(id);
        }
        return Result.returnOk();
    }


    /**
     * @Description PC改变状态
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC改变状态", notes = "PC改变状态")
    @PostMapping(value = "/changeStatus")
    @LoginUser
    @SystemLog(description = "人才招聘信息状态变更")
    public Result changeStatus(@ApiIgnore AuthUser authUser, @RequestBody RecruitStatusDTO recruitStatusDTO) {
        oaRecruitAuditingService.changeStatus(authUser, recruitStatusDTO);
        return Result.returnOk();
    }
    
    
    /**
    *@Description PC批量下架
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "PC批量下架", notes = "PC批量下架")
    @PostMapping(value = "/offloadSome")
    @LoginUser
    @SystemLog(description = "人才招聘信息批量下架")
    public Result offloadSome(@ApiIgnore AuthUser authUser, @RequestBody OffloadSomeDTO dto){
        for (Integer id : dto.getIds()) {
            RecruitStatusDTO recruitStatusDTO = new RecruitStatusDTO();
            recruitStatusDTO.setId(id);
            recruitStatusDTO.setOffReason(dto.getOffReason());
            recruitStatusDTO.setStatus(3);
            oaRecruitAuditingService.changeStatus(authUser, recruitStatusDTO);
        }
        return Result.returnOk();
    }


    /**
     * @Description PC新增时的几个下拉框
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC新增时的几个下拉框，取dictValue和dictLabel", notes = "PC新增时的几个下拉框，取dictValue和dictLabel")
    @GetMapping(value = "/getVal")
    public Result getVal() {
        Map<String, Object> map = new HashMap<>();
        //所属行业
        List<SysDictData> hangYe = this.getSys("oa_recruit_industry");
        map.put("hangYe", hangYe);
        //岗位
        List<SysDictData> gangWei = this.getSys("oa_recruit_post");
        map.put("gangWei", gangWei);
        //薪资
        List<SysDictData> xinZi = this.getSys("oa_recruit_salary");
        map.put("xinZi", xinZi);
        //教育
        List<SysDictData> jiaoYu = this.getSys("oa_recruit_education");
        map.put("jiaoYu", jiaoYu);
        //经验
        List<SysDictData> jingYan = this.getSys("oa_recruit_experience");
        map.put("jingYan", jingYan);
        //APP端页面中的发布时间段按钮
        List<SysDictData> publishTime = this.getSys("oa_recruit_publish_time");
        map.put("publishTime", publishTime);
        return Result.returnOk(map);
    }

    private List<SysDictData> getSys(String dictType) {
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dict_type", dictType)
                .eq("is_del", 0);
        List<SysDictData> list = sysDictDataService.list(queryWrapper);
        return list;
    }

}
