package cn.yq.oa.common;

/**
 * @Author: houqijun
 * @Date: 2019/1/30 18:01
 * @Description:
 */
public class Constant {
}
