package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.CommonFiles;
import cn.yq.oa.entity.CommonNotice;
import cn.yq.oa.entity.MyFeedback;
import cn.yq.oa.param.CleanUpAttachmentParam;
import cn.yq.oa.param.MyFeedbackParam;
import cn.yq.oa.param.MyFeedbackSearchParam;
import cn.yq.oa.service.ICommonFilesService;
import cn.yq.oa.service.ICommonNoticeService;
import cn.yq.oa.service.IMyFeedbackService;
import cn.yq.oa.vo.CommonNoticeVO;
import cn.yq.oa.vo.MyFeedbackVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 意见反馈信息表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-04-28
 */
@RestController
@RequestMapping("/my-feedback")
@Api(value = "意见反馈", description = "ggl意见反馈 API", position = 100, protocols = "http")
@AllArgsConstructor
public class MyFeedbackController {

	private IMyFeedbackService myFeedbackService;

	private ICommonFilesService commonFilesService;

	private ICommonNoticeService commonNoticeService;

    @ApiOperation(value = "添加", notes = "添加")
    @PostMapping(value = "/addMyFeedback", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加意见反馈信息",table = LogTableConstant.MY_FEEDBACK)
    public Result addMyFeedback(@ApiIgnore AuthUser authUser,@RequestBody MyFeedbackParam param){
        if(null != param){
            MyFeedback myFeedback = new MyFeedback();
            CopyUtils.copyProperties(param,myFeedback);
            myFeedback.setUserId(authUser.getId());
            myFeedbackService.save(myFeedback);
            //添加意见图片
            for (CleanUpAttachmentParam cleanParam : param.getList()){
                CommonFiles commonFiles = new CommonFiles();
                CopyUtils.copyProperties(cleanParam,commonFiles);
                commonFiles.setRelationId(myFeedback.getId());
                commonFiles.setRelationType("feedback");
                commonFilesService.save(commonFiles);
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取反馈信息", notes = "分页获取反馈信息")
    @PostMapping("/listMyFeedback/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询意见反馈信息",table = LogTableConstant.MY_FEEDBACK)
    public Result<IPage<MyFeedbackVO>> listMyFeedback(@PathVariable("pageNum") int pageNum,
                                 @PathVariable("pageSize") int pageSize,
                                 @RequestBody MyFeedbackSearchParam param){
        Page<MyFeedbackVO> page = new Page<MyFeedbackVO>(pageNum,pageSize);
        IPage<MyFeedbackVO> iPage = page.setRecords(myFeedbackService.listMyFeedback(param,page));
        for(MyFeedbackVO myFeedbackVO : iPage.getRecords()){
            //获取当前反馈下的意见图片
            QueryWrapper<CommonFiles> wrapper = new QueryWrapper<>();
            wrapper.eq("is_del",0);
            wrapper.eq("relation_type","feedback");
            wrapper.eq("relation_id",myFeedbackVO.getId());
            List<CommonFiles> list = commonFilesService.list(wrapper);
            myFeedbackVO.setList(list);
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/removeMyFeedback/{id}")
    @SystemLog(description = "删除意见反馈信息",table = LogTableConstant.MY_FEEDBACK)
    public Result removeMyFeedback(@PathVariable("id") Integer id){
        myFeedbackService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "回复", notes = "回复")
    @PostMapping("/getReply")
    @SystemLog(description = "意见反馈信息回复",table = LogTableConstant.NOTICE)
    public Result getReply(@RequestBody CommonNoticeVO param){
        if(null != param) {
            CommonNotice commonNotice = new CommonNotice();
            CopyUtils.copyProperties(param,commonNotice);
            commonNotice.setIsRead(0);
            commonNoticeService.save(commonNotice);
        }
        return Result.returnOk("操作成功");
    }
}
