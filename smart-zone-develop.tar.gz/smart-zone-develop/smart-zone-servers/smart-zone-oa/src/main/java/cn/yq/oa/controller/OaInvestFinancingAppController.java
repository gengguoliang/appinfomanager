package cn.yq.oa.controller;

import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.CommonFiles;
import cn.yq.oa.entity.OaFinancingSuccessCase;
import cn.yq.oa.entity.OaInvestmentFocus;
import cn.yq.oa.entity.OaInvestmentInfo;
import cn.yq.oa.param.CleanUpAttachmentParam;
import cn.yq.oa.param.FinancingSearchParam;
import cn.yq.oa.param.InvestmentSearchParam;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: YQ-DGZ
 * @date: 2019/4/2 14:32
 * @description: TODO
 */
@RestController
@RequestMapping("/oa-investment-financing-app")
@Api(value = "投融资app管理", description = "投融资app API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaInvestFinancingAppController {

    IOaInvestmentInfoService  oaInvestmentInfoService;

    IOaInvestmentFocusService oaInvestmentFocusService;

    IOaFinancingInfoService oaFinancingInfoService;

    IOaFinancingSuccessCaseService oaFinancingSuccessCaseService;

    private ICommonFilesService commonFilesService;


    @ApiOperation(value = "app查询投资方信息", notes = "app查询投资方信息")
    @PostMapping("/listInvestmentApp")
    @SystemLog(description = "app查询投资方信息")
    public Result<List<InvestmentAppVo>> listInvestmentApp(@RequestBody InvestmentSearchParam param){
        List<InvestmentAppVo> vos = oaInvestmentInfoService.listInvestmentApp(param);
        return Result.returnOk(vos);
    }

    @ApiOperation(value = "查看投资方信息", notes = "查看投资方信息")
    @GetMapping("/viewInvestment/{id}")
    @SystemLog(description = "查看投资方信息")
    public Result<OaInvestmentInfoVo> viewInvestment(@PathVariable("id") Integer id){
        //获取投资方信息
        OaInvestmentInfo investmentInfo = oaInvestmentInfoService.getById(id);
        OaInvestmentInfoVo infoVo = new OaInvestmentInfoVo();
        BeanUtils.copyProperties(investmentInfo,infoVo);
        //获取关注领域
        StringBuffer areabuffer = new StringBuffer();
        QueryWrapper<OaInvestmentFocus> queryWrapper = new QueryWrapper<>();
         queryWrapper.eq("invest_id",id);
         queryWrapper.eq("dict_type","follow_field");
         queryWrapper.eq("is_del",0);
        List<OaInvestmentFocus> areaList = oaInvestmentFocusService.list(queryWrapper);
        for (OaInvestmentFocus temp:areaList) {
            areabuffer.append(temp.getDictLabel()).append(" ");
        }
        infoVo.setFocusAreasName(areabuffer.toString());

        //获取关注阶段
        StringBuffer stagebuffer = new StringBuffer();
        QueryWrapper<OaInvestmentFocus> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("invest_id",id);
        queryWrapper1.eq("dict_type","follow_stage");
        queryWrapper1.eq("is_del",0);
        List<OaInvestmentFocus> stageList = oaInvestmentFocusService.list(queryWrapper1);
        for (OaInvestmentFocus temp:stageList) {
            stagebuffer.append(temp.getDictLabel()).append(" ");
        }
        infoVo.setFocusStageName(stagebuffer.toString());
        return Result.returnOk(infoVo);
    }

    @ApiOperation(value = "app获取融资项目信息", notes = "app获取融资项目信息")
    @PostMapping("/listFinancingApp")
    @SystemLog(description = "app获取融资项目信息")
    public Result<List<FinancingAppVo>> listFinancingApp(@RequestBody FinancingSearchParam param){
        List<FinancingAppVo> vos = oaFinancingInfoService.listFinancingApp(param);
        return Result.returnOk(vos);
    }

    @ApiOperation(value = "查看融资项目信息", notes = "查看融资项目信息")
    @GetMapping("/viewFinancing/{id}")
    @SystemLog(description = "查看融资项目信息详情")
    public Result<OaFinancingInfoVo> viewFinancing(@PathVariable("id") Integer id){
        OaFinancingInfoVo vo = oaFinancingInfoService.viewFinancing(id);
        //计划书
        //获取当前融资项目下的计划书
        QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("relation_id",id);
        queryWrapper.eq("relation_type","financing_plan");
        List<CommonFiles> list = commonFilesService.list(queryWrapper);
        List<CleanUpAttachmentParam> list1 = new ArrayList<CleanUpAttachmentParam>();
        for(CommonFiles commonFiles : list){
            CleanUpAttachmentParam cleanUpAttachmentParam = new CleanUpAttachmentParam();
            CopyUtils.copyProperties(commonFiles,cleanUpAttachmentParam);
            list1.add(cleanUpAttachmentParam);
        }
        if(null != list1 && list1.size()>0){
            vo.setPlanbook(list1);
        }
        return Result.returnOk(vo);
    }

    @ApiOperation(value = "app获取成功案例", notes = "app获取成功案例")
    @PostMapping("/listFinancingCaseApp")
    @SystemLog(description = "app获取成功案例列表信息")
    public Result<List<FinancingSuccessAppVo>> listFinancingCaseApp(){
        List<FinancingSuccessAppVo> vos = oaFinancingSuccessCaseService.listFinancingCaseApp();
        return Result.returnOk(vos);
    }


    @ApiOperation(value = "查看成功案例信息", notes = "查看成功案例信息")
    @GetMapping("/viewFinancingCase/{id}")
    @SystemLog(description = "app查看成功案例信息详情")
    public Result<OaFinancingSuccessCaseVo> viewFinancingCase(@PathVariable("id") Integer id){
        OaFinancingSuccessCaseVo vo = oaFinancingSuccessCaseService.viewFinancingCase(id);
        return Result.returnOk(vo);
    }
















}
