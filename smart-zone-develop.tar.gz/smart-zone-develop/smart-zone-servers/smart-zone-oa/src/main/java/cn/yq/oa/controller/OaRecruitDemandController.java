package cn.yq.oa.controller;


import cn.yq.client.userapi.UserClient;
import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oarecruit.DemandDTO;
import cn.yq.oa.dto.oarecruit.ShowDemandDTO;
import cn.yq.oa.dto.oarecruit.StatusDemandDTO;
import cn.yq.oa.entity.OaRecruitDemand;
import cn.yq.oa.entity.OaRecruitPost;
import cn.yq.oa.entity.OaRecruitStation;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.service.IOaRecruitDemandService;
import cn.yq.oa.service.IOaRecruitStationService;
import cn.yq.oa.service.ISysDictDataService;
import cn.yq.oa.vo.oarecruit.DemandVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 招聘需求表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-04-17
 */
@RestController
@Api(value = "zhengjh招聘需求", description = "zhengjh招聘需求")
@RequestMapping("/oa-recruit-demand")
public class OaRecruitDemandController {

    @Autowired
    private IOaRecruitDemandService oaRecruitDemandService;
    @Autowired
    private ISysDictDataService sysDictDataService;
    @Autowired
    private UserClient userClient;
    @Autowired
    private IOaRecruitStationService oaRecruitStationService;


    /**
     * @Description PC新增与编辑
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC新增与编辑", notes = "PC新增与编辑")
    @PostMapping(value = "/addOrEdit")
    @LoginUser
    @SystemLog(description = "添加或编辑招聘需求")
    public Result addOrEdit(@ApiIgnore AuthUser authUser, @RequestBody DemandDTO demandDTO) {
        OaRecruitDemand oaRecruitDemand = new OaRecruitDemand();
        BeanUtils.copyProperties(demandDTO, oaRecruitDemand);
        oaRecruitDemand.setOrganizationId(authUser.getOrganizationId());
        if (ObjectUtils.isEmpty(demandDTO.getId())) {
            //添加
            oaRecruitDemand.setCreateUserid(authUser.getId());
            oaRecruitDemandService.save(oaRecruitDemand);
        } else {
            //编辑
            oaRecruitDemandService.updateById(oaRecruitDemand);
        }

        return Result.returnOk("操作成功");
    }

    /**
     * @Description PC根据部门ID获取岗位  flag: 1,只查启用的岗位  2。查所有
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC根据部门ID获取岗位", notes = "PC根据部门ID获取岗位")
    @GetMapping(value = "/getPost/{deptId}/{flag}")
    @SystemLog(description = "根据部门获取岗位")
    public Result getPost(@PathVariable("deptId") Integer deptId, @PathVariable("flag") Integer flag) {
        QueryWrapper<OaRecruitStation> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dept_id", deptId)
                .eq("is_del", 0);
        if (flag == 1) {
            queryWrapper.eq("status", 1);
        }
        List<OaRecruitStation> list = oaRecruitStationService.list(queryWrapper);
        return Result.returnOk(list);
    }

    /**
     * @Description 查询所有岗位
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "查询所有岗位", notes = "查询所有岗位")
    @GetMapping(value = "/getAllPost")
    @SystemLog(description = "查询所有岗位")
    public Result getAllPost() {
        QueryWrapper<OaRecruitStation> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del", 0);
        List<OaRecruitStation> list = oaRecruitStationService.list(queryWrapper);
        return Result.returnOk(list);
    }


    /**
     * @Description 查询当前用户所在组织下的所有用户
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "查询当前用户所在组织下的所有用户", notes = "查询当前用户所在组织下的所有用户")
    @GetMapping(value = "/getUser")
    @LoginUser
    public Result<List<AuthUser>> getUser(@ApiIgnore AuthUser authUser) {
        List<AuthUser> users = oaRecruitDemandService.getUser(authUser);
        return Result.returnOk(users);
    }


    /**
     * @Description PC删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC删除", notes = "PC删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "招聘需求信息删除")
    public Result remove(@PathVariable("id") Integer id) {
        oaRecruitDemandService.removeById(id);
        return Result.returnOk("操作成功");
    }


    /**
     * @Description PC列表+详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC列表+详情", notes = "PC列表+详情")
    @PostMapping(value = "/showRecruitDemand/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "招聘需求信息展示")
    public Result<IPage<DemandVO>> showRecruitDemand(@ApiIgnore AuthUser authUser,
                                                     @PathVariable("pageNum") Integer pageNum,
                                                     @PathVariable("pageSize") Integer pageSize,
                                                     @RequestBody ShowDemandDTO showDemandDTO) {
        Page<DemandVO> page = new Page<>(pageNum, pageSize);
        IPage<DemandVO> iPage =
                page.setRecords(oaRecruitDemandService.showRecruitDemand(authUser, page, showDemandDTO));
        return Result.returnOk(iPage);
    }

    /**
     * @Description PC改变状态
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC改变状态", notes = "PC改变状态")
    @PostMapping(value = "/statusDemand")
    @SystemLog(description = "招聘需求状态变更")
    public Result statusDemand(@RequestBody StatusDemandDTO dto) {
        OaRecruitDemand oaRecruitDemand = new OaRecruitDemand();
        BeanUtils.copyProperties(dto, oaRecruitDemand);
        oaRecruitDemand.setExamineTime(new Date());
        oaRecruitDemandService.updateById(oaRecruitDemand);
        return Result.returnOk();
    }


    /**
     * @Description PC招聘需求的部门回显
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC招聘需求的部门回显", notes = "PC招聘需求的部门回显")
    @GetMapping(value = "/revertRecruitDept/{deptId}")
    @LoginUser
    public Result revertRecruitDept(@ApiIgnore AuthUser authUser, @PathVariable("deptId") Integer deptId) {
        authUser.setDepartmentId(deptId);
        List<Integer> deptIds = userClient.getDeptIds2(authUser);
        return Result.returnOk(deptIds);
    }


}
