package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.utils.DateUtil;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 会议预约表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-26
 */
@RestController
@RequestMapping("/oa-conference-reservation")
@AllArgsConstructor
public class OaConferenceReservationController {

    IOaConferenceReservationService oaConferenceReservationService;

    IOaConferenceParticipantsService oaConferenceParticipantsService;

    IOaConferenceroomService oaConferenceroomService;

    @Autowired
    private ICommonFilesService commonFilesService;
    @Autowired
    private IUserDepartmentService userDepartmentService;
    @Autowired
    private IOaConferenceVoteService oaConferenceVoteService;
    @Autowired
    private IOaConferenceProblemService oaConferenceProblemService;

    /**
     * 新增预约
     * @param authUser
     * @return
     */
    @PostMapping("/addConference")
    @LoginUser
    @SystemLog(description = "新增会议预约")
    public Result addConference(AuthUser authUser, @RequestBody OaConferenceReservationParam oaConferenceReservationParam){
        OaConferenceReservation oaConferenceReservation = new OaConferenceReservation();
        BeanUtils.copyProperties(oaConferenceReservationParam,oaConferenceReservation);
        oaConferenceReservation.setCreateBy(authUser.getName());
        oaConferenceReservationService.saveOrUpdate(oaConferenceReservation);
        int id = oaConferenceReservation.getId();
        //添加参会人员表数据
        int conferenceId = oaConferenceReservation.getId();
        List<PeopleParam> peopleList = oaConferenceReservationParam.getList();
        for (PeopleParam temp:peopleList){
            OaConferenceParticipants participants = new OaConferenceParticipants();
            participants.setUserId(temp.getUserid());
            participants.setUsername(temp.getUsername());
            participants.setConferenceId(conferenceId);
            oaConferenceParticipantsService.saveOrUpdate(participants);
        }
        return Result.returnOk(id);
    }

    /**
     * 获取预约列表
     * @param pageNum
     * @param pageSize
     * @param oaConferenceParam
     * @return
     */
    @PostMapping("/getAllConferences/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "会议预约列表")
    public Result getAllConferences(AuthUser authUser,@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody OaConferenceParam oaConferenceParam){
        Page<OaConferenceReservation> page= new Page<OaConferenceReservation>(pageNum,pageSize);
//        oaConferenceParam.setOrderId(authUser.getId());
        IPage<OaConferenceReservation> assetsPage = oaConferenceReservationService.selectConferencesPage(page,oaConferenceParam);
        return Result.returnOk(assetsPage);
    }

    /**
     * App获取预约列表
     * @return
     */
    @PostMapping("/getAllAppConferences")
    @LoginUser
    @SystemLog(description = "app会议预约列表")
    public Result getAllAppConferences(AuthUser authUser){
        QueryWrapper<OaConferenceReservation> queryWrapper = new QueryWrapper<OaConferenceReservation>();
        queryWrapper.eq("order_id", authUser.getId());
        queryWrapper.eq("is_del",false);
        queryWrapper.orderByDesc("create_time");
        List<OaConferenceReservation> list = oaConferenceReservationService.list(queryWrapper);
        return Result.returnOk(list);
    }

    /**
     * 修改预约状态
     */
    @PostMapping("/changeConferenceStatus")
    @LoginUser
    @SystemLog(description = "会议预约状态变更")
    public Result changeConferenceStatus(AuthUser authUser,@RequestBody ConferenceStatusParam param) {
        OaConferenceReservation oaConferenceReservation = new OaConferenceReservation();
        oaConferenceReservation.setId(param.getId());
        oaConferenceReservation.setStatus(param.getStatus());
        oaConferenceReservation.setRemark(param.getRemark());
        oaConferenceReservation.setOperationTime(new Date());
        oaConferenceReservation.setOperator(authUser.getName());
        oaConferenceReservation.setOperationDept(authUser.getDepartmentId());
        oaConferenceReservationService.saveOrUpdate(oaConferenceReservation);
        return Result.returnOk("操作成功");
    }

    /**
     * 删除预约
     */
    @GetMapping("/deleteConference/{id}")
    @SystemLog(description = "删除会议预约记录",table = LogTableConstant.CONFERENCE_RESERVATION)
    public Result deleteConference(@PathVariable("id") int id) {
        oaConferenceReservationService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 查看预约详情
     */
    @GetMapping("/getDetailById/{id}")
    @SystemLog(description = "会议预约详情")
    public Result getDetailById(@PathVariable("id") int id){
//        OaConferenceReservation conferenceReservation = oaConferenceReservationService.getById(id);
        OaConferenceReservationVO oaConferenceReservationVO = oaConferenceReservationService.selectConferenceInfoById(id);
        Map map = new HashMap<>();
        map.put("conferenceInfo",oaConferenceReservationVO);
        //查询会议参会人员
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper.eq("conference_id",id);
        queryWrapper.eq("is_del",0);
        List<OaConferenceParticipants> list = oaConferenceParticipantsService.list(queryWrapper);
        map.put("userInfo",list);
        //确认人员
        QueryWrapper<OaConferenceParticipants> queryWrapper2 = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper2.eq("conference_id",id);
        queryWrapper2.eq("is_del",0);
        queryWrapper2.eq("is_confirm",1);
        List<OaConferenceParticipants> qrlist = oaConferenceParticipantsService.list(queryWrapper2);
        map.put("confirmInfo",qrlist);
        //签到人员
        QueryWrapper<OaConferenceParticipants> queryWrapper3 = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper3.eq("conference_id",id);
        queryWrapper3.eq("is_del",0);
        queryWrapper3.eq("is_signin",1);
        List<OaConferenceParticipants> qdlist = oaConferenceParticipantsService.list(queryWrapper3);
        map.put("signinInfo",qdlist);
        return Result.returnOk(map);
    }

    //会议信息接口（登录人参加的已结束的会议）
    @GetMapping("/getConferenceList")
    @LoginUser
    @SystemLog(description = "删除会议预约记录",table = LogTableConstant.CONFERENCE_RESERVATION)
    public Result getConferenceList(AuthUser authUser){
        int userId = authUser.getId();
        //根据人员id找到参加的会议集合
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper.eq("user_id",userId);
        queryWrapper.eq("is_del",0);
        List<OaConferenceParticipants> list = oaConferenceParticipantsService.list(queryWrapper);
        //根据会议ID集合，找到已结束的会议
        List idlist = new ArrayList();
        for (OaConferenceParticipants temp:list){
            idlist.add(temp.getConferenceId());
        }
        QueryWrapper<OaConferenceReservation> queryWrapper2 = new QueryWrapper<OaConferenceReservation>();
        //获取系统当前时间
        Date date = new Date();
        queryWrapper2.lt("end_time",date);
        queryWrapper2.in("id",idlist);
        queryWrapper2.ne("status",3);
        List<OaConferenceReservation> listresult = oaConferenceReservationService.list(queryWrapper2);
        return Result.returnOk(listresult);
    }
    //会议确认列表（登录人参加的未结束的会议）
    @GetMapping("/getConferenceConfirmList")
    @LoginUser
    @SystemLog(description = "会议确认列表")
    public Result getConferenceConfirmList(AuthUser authUser){
        int userId = authUser.getId();
        //根据人员id找到参加的会议集合
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper.eq("user_id",userId);
        queryWrapper.eq("is_del",0);
        List<OaConferenceParticipants> list = oaConferenceParticipantsService.list(queryWrapper);
        //根据会议ID集合，找到未结束的会议
        List idlist = new ArrayList();
        for (OaConferenceParticipants temp:list){
            idlist.add(temp.getConferenceId());
        }
        QueryWrapper<OaConferenceReservation> queryWrapper2 = new QueryWrapper<OaConferenceReservation>();
        //获取系统当前时间
        Date date = new Date();
//        queryWrapper2.le("begin_time",date);
        if (idlist.size()==0){
            queryWrapper2.eq("status",80);
        }else{
            queryWrapper2.in("id",idlist);
            queryWrapper2.eq("status",1);
        }


        List<OaConferenceReservation> listresult = oaConferenceReservationService.list(queryWrapper2);
        //添加人员签到或确认信息
       List resultlist = new ArrayList();
        for(OaConferenceReservation temp:listresult){
            QueryWrapper<OaConferenceParticipants> queryWrapper3 = new QueryWrapper<OaConferenceParticipants>();
            queryWrapper3.eq("user_id",userId);
            queryWrapper3.eq("conference_id",temp.getId());
            queryWrapper3.eq("is_del",0);
            OaConferenceParticipants one = oaConferenceParticipantsService.getOne(queryWrapper3);
            Map map = new HashMap();
            map.put("conferenceInfo",temp);
            map.put("sifnconfirminfo",one);
            resultlist.add(map);
        }
        return Result.returnOk(resultlist);
    }

    //登录人签到接口
    @GetMapping("/signin/{conferenceId}")
    @LoginUser
    @SystemLog(description = "会议签到")
    public Result signin(AuthUser authUser,@PathVariable("conferenceId") int conferenceId){
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper.eq("conference_id",conferenceId);
        queryWrapper.eq("user_id",authUser.getId());
        queryWrapper.eq("is_del",0);
        OaConferenceParticipants participants = new OaConferenceParticipants();
        participants.setIsSignin(1);
        participants.setSigninTime(new Date());
        oaConferenceParticipantsService.update(participants,queryWrapper);
        return Result.returnOk("操作成功");
    }

    //登录人确认接口
    @GetMapping("/confirm/{conferenceId}/{value}")
    @LoginUser
    @SystemLog(description = "会议确认")
    public Result confirm(AuthUser authUser,@PathVariable("conferenceId") int conferenceId,@PathVariable("value") int value){
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper.eq("conference_id",conferenceId);
        queryWrapper.eq("user_id",authUser.getId());
        queryWrapper.eq("is_del",0);
        OaConferenceParticipants participants = new OaConferenceParticipants();
        participants.setIsConfirm(value);
        participants.setConfirmTime(new Date());
        oaConferenceParticipantsService.update(participants,queryWrapper);
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @ApiOperation(value = "会议信息管理展示", notes = "会议信息管理展示")
    @PostMapping("/getAllReservation/{pageNum}/{pageSize}")
    @SystemLog(description = "会议信息管理列表")
    public Result<IPage<OaConferenceReservationVO>> getAllReservation(@ApiIgnore AuthUser authUser, @PathVariable("pageNum") Integer pageNum, @PathVariable("pageSize") Integer pageSize, @RequestBody ReservationSearchParam param) {
        Page<OaConferenceReservationVO> page = new Page<OaConferenceReservationVO>(pageNum,pageSize);
        IPage<OaConferenceReservationVO> iPage = oaConferenceReservationService.selectConferenceInfoManager(page,param);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "会议详情接口PC", notes = "会议详情接口PC")
    @GetMapping("/getConferenceReservationInfo/{id}")
    @SystemLog(description = "会议信息管理详情")
    public Result<OaConferenceReservationVO> getConferenceReservationInfo(@PathVariable("id") Integer id){
        OaConferenceReservationVO oaConferenceReservationVO = oaConferenceReservationService.selectConferenceInfoById(id);
        return Result.returnOk(oaConferenceReservationVO);
    }

    @ApiOperation(value = "会议信息删除", notes = "会议信息删除")
    @GetMapping("/removeReservation/{id}")
    @SystemLog(description = "会议信息管理删除")
    public Result removeReservation(@PathVariable("id") Integer id){
        oaConferenceReservationService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "确认签到记录PC", notes = "确认签到记录PC")
    @GetMapping("/getParticipantsById/{id}")
    @SystemLog(description = "确认签到记录")
    public Result<List<OaParticipantsVO>> getParticipantsById(@PathVariable("id")Integer id) {
        //获取签到人员信息详情
        List<OaConferenceParticipants> oaConferenceParticipantsList = oaConferenceParticipantsService.selectParticipantsSignOk(id);
        List<OaParticipantsVO> OaParticipantsVOlist = new ArrayList<OaParticipantsVO>();
        for (OaConferenceParticipants oaConferenceParticipants : oaConferenceParticipantsList) {
            //根据当前用户id获取用户所属部门
            String department = userDepartmentService.selectDepartmentByUserId(oaConferenceParticipants.getUserId());
            OaParticipantsVO oaParticipantsVO = new OaParticipantsVO();
            CopyUtils.copyProperties(oaConferenceParticipants, oaParticipantsVO);
            oaParticipantsVO.setDepartmentName(department);
            OaParticipantsVOlist.add(oaParticipantsVO);
        }

        return Result.returnOk(OaParticipantsVOlist);
    }

    @ApiOperation(value = "新增会议纪要文件上传记录", notes = "新增会议纪要文件上传记录")
    @PostMapping("/addMeetingfiles")
    @SystemLog(description = "会议纪要文件上传")
    public Result addMeetingfiles(@RequestBody MeetingSummaryParam meetingSummaryParam){
        CommonFiles commonFiles = new CommonFiles();
        if(null != meetingSummaryParam){
            CopyUtils.copyProperties(meetingSummaryParam,commonFiles);
            commonFiles.setRelationType("meetingsummary");
            commonFilesService.save(commonFiles);
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "查看会议纪要文件列表", notes = "查看会议纪要文件列表")
    @GetMapping("/getMeetingRecord/{relationId}")
    @SystemLog(description = "会议纪要文件列表")
    public Result<List<MeetingSummaryInfoVO>> getMeetingRecord(@PathVariable("relationId")Integer relationId){
        //获取当前会议预约下的会议纪要信息
        QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<CommonFiles>();
        queryWrapper.eq("relation_id",relationId);
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("relation_type","meetingsummary");
        List<CommonFiles> list = commonFilesService.list(queryWrapper);
        List<MeetingSummaryInfoVO> list1 = new ArrayList<MeetingSummaryInfoVO>();
        for(CommonFiles commonFiles : list){
            MeetingSummaryInfoVO meetingSummaryInfoVO = new MeetingSummaryInfoVO();
            CopyUtils.copyProperties(commonFiles,meetingSummaryInfoVO);
            list1.add(meetingSummaryInfoVO);
        }
        return Result.returnOk(list1);
    }

    @ApiOperation(value = "会议纪要文件删除", notes = "会议纪要文件删除")
    @GetMapping("/removeMeetingRecord/{id}")
    @SystemLog(description = "会议纪要文件删除")
    public Result removeMeetingRecord(@PathVariable("id")Integer id){
        commonFilesService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取图表数据", notes = "获取图表数据")
    @PostMapping("/getChartData")
    @LoginUser
    @SystemLog(description = "获取图表数据")
    public Result<List<ConferenceChartVo>> getChartData(@ApiIgnore AuthUser authUser,@RequestBody ChartParam param){
        QueryWrapper<OaConferenceroom> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",false);
        List<OaConferenceroom> roomList = oaConferenceroomService.list(queryWrapper);
        List<ConferenceChartVo> list = new ArrayList<>();
        for (OaConferenceroom temp:roomList){
            ConferenceChartVo conferenceChartVo = new ConferenceChartVo();
            conferenceChartVo.setName(temp.getRoomName());
            //会议室所有预约情况
            QueryWrapper<OaConferenceReservation> wrapper = new QueryWrapper<OaConferenceReservation>();
            wrapper.eq("is_del",false);
            wrapper.eq("room_id",temp.getId());
            //时间转换
//            SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar c = Calendar.getInstance();
            c.setTime(param.getTime());
            c.add(Calendar.DAY_OF_MONTH, 1);
            Date endtime = c.getTime();
            wrapper.ge("begin_time",param.getTime());
            wrapper.le("end_time",endtime);
            List<OaConferenceReservation> ResList = oaConferenceReservationService.list(wrapper);
            ArrayList<ChartVo> chartVos = new ArrayList<>();
            for (OaConferenceReservation reservation:ResList){
                ChartVo chartVo = new ChartVo();
                chartVo.setBeginDate(reservation.getBeginTime());
                c.setTime(reservation.getBeginTime());
                chartVo.setEndDate(reservation.getEndTime());
                if(authUser.getId().equals(reservation.getOrderId())){
                    chartVo.setIsmine(true);
                }
                chartVos.add(chartVo);
            }
            conferenceChartVo.setAlReserve(chartVos);
            list.add(conferenceChartVo);
        }
        return Result.returnOk(list);
    }


    @ApiOperation(value = "表决记录展示", notes = "表决记录展示")
    @GetMapping("/getAllVoteInfoById/{id}")
    @SystemLog(description = "会议表决记录")
    public Result<List<VotingRecordsVO>> getAllVoteInfoById(@PathVariable("id") Integer id) {
        //获取当前会议所有问题
        List<OaConferenceProblem> oaConferenceProblemList = oaConferenceProblemService.getProblemInfoById(id);
        //获取当前会议的总人数
        int participantsNo = oaConferenceParticipantsService.selectParticipantsSignOkNo(id);
        List<VotingRecordsVO> votingRecordsVOList = new ArrayList<VotingRecordsVO>();
        for (OaConferenceProblem oaConferenceProblem : oaConferenceProblemList) {
            VotingRecordsVO votingRecordsVO = new VotingRecordsVO();
            CopyUtils.copyProperties(oaConferenceProblem, votingRecordsVO);
            //获取当前会议当前问题表决同意人数
            int agreeNumber = oaConferenceVoteService.selectConferenceVoteCountById(oaConferenceProblem.getConferenceId(), oaConferenceProblem.id, 1);
            //获取当前会议当前问题表决不同意人数
            int disagreeNumber = oaConferenceVoteService.selectConferenceVoteCountById(oaConferenceProblem.getConferenceId(), oaConferenceProblem.id, 2);
            //获取当前会议当前问题表决弃权人数
            int waiverNumber = oaConferenceVoteService.selectConferenceVoteCountById(oaConferenceProblem.getConferenceId(), oaConferenceProblem.id, 0);
            votingRecordsVO.setAgreeNumber(agreeNumber);
            votingRecordsVO.setDisagreeNumber(disagreeNumber);
            votingRecordsVO.setWaiverNumber(waiverNumber);
            votingRecordsVO.setSignNumber(participantsNo);
            votingRecordsVOList.add(votingRecordsVO);
        }

        return Result.returnOk(votingRecordsVOList);
    }




































































}
