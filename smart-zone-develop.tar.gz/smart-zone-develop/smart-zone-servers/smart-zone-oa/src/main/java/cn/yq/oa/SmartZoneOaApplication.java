package cn.yq.oa;

import cn.yq.common.config.FeignConfiguration;
import cn.yq.common.utils.SensitiveWordUtil;
import cn.yq.oa.service.ISysDictDataService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@EnableDiscoveryClient
@ComponentScan(basePackages = {"cn.yq.client.userapi", "cn.yq.oa","cn.yq.common"},excludeFilters={
        @ComponentScan.Filter(type= FilterType.ASSIGNABLE_TYPE, value= FeignConfiguration.class)})
@EnableFeignClients(basePackages = {"cn.yq.client.userapi","cn.yq.oa.service"})
@SpringBootApplication
@EnableScheduling
@EnableAsync
public class SmartZoneOaApplication {

    @Resource
    ISysDictDataService sysDictDataService;

    public static void main(String[] args) {
        System.out.println("... start SpringApplication.run()");
        SpringApplication.run(SmartZoneOaApplication.class, args);
        System.out.println("... end SpringApplication.run()");
    }

    @Component
    public class MyCommandLineRunner implements CommandLineRunner {

        @Override
        public void run(String... args) throws Exception {
            List<String> list = sysDictDataService.selectWords();
            Set<String> sensitiveWordSet = new HashSet<>(list);

            //初始化敏感词库
            SensitiveWordUtil.init(sensitiveWordSet);
        }

    }
}
