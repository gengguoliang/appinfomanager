package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaInvoiceInfo;
import cn.yq.oa.param.InvoiceInfoParam;
import cn.yq.oa.param.WordParam;
import cn.yq.oa.service.IOaInvoiceInfoService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 发票基本信息表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-05-23
 */
@RestController
@RequestMapping("/oa-invoice-info")
@Api(value = "发票基本信息 ", description = "发票基本信息（lwl） API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaInvoiceInfoController {

    IOaInvoiceInfoService oaInvoiceInfoService;

    @ApiOperation(value = "新增/编辑发票抬头信息", notes = "新增/编辑发票抬头信息")
    @PostMapping("/addInvoiceInfo")
    @LoginUser
    @SystemLog(description = "添加/编辑发票抬头信息")
    public Result addInvoiceInfo(@ApiIgnore AuthUser authUser, @RequestBody InvoiceInfoParam invoiceInfoParam){
        Integer organizationId = authUser.getOrganizationId();
        OaInvoiceInfo oaInvoiceInfo = new OaInvoiceInfo();
        BeanUtils.copyProperties(invoiceInfoParam,oaInvoiceInfo);
        oaInvoiceInfo.setOrgid(organizationId);
        oaInvoiceInfo.setCategory(2);
        oaInvoiceInfo.setOrgType(1);
        oaInvoiceInfo.setReceiveAddress(oaInvoiceInfo.getAddress());
        oaInvoiceInfoService.saveOrUpdate(oaInvoiceInfo);
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "查看发票抬头信息", notes = "查看发票抬头信息")
    @GetMapping("/viewInvoiceInfo")
    @LoginUser
    @SystemLog(description = "查看发票抬头信息")
    public Result<OaInvoiceInfo> viewInvoiceInfo(@ApiIgnore AuthUser authUser){
        Integer organizationId = authUser.getOrganizationId();
        QueryWrapper<OaInvoiceInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("orgid",organizationId);
        List<OaInvoiceInfo> list = oaInvoiceInfoService.list(queryWrapper);
        OaInvoiceInfo oaInvoiceInfo = new OaInvoiceInfo();
        if (list.size()>0){
            oaInvoiceInfo = list.get(0);
        }
        return Result.returnOk(oaInvoiceInfo);
    }

}
