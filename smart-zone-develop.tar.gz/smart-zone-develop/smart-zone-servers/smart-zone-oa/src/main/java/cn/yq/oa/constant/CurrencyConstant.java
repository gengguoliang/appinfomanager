package cn.yq.oa.constant;

/**
 * @program: smart-zone
 * @description: 公用常量类
 * @author: zhengjianhui
 **/
public class CurrencyConstant {

    /**
     * 未来空气质量redis Key值
     */
    public static final String FUTURE_AIR="future_air";

}
