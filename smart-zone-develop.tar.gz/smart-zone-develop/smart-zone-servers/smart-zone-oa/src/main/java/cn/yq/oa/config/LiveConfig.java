package cn.yq.oa.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * @author: yinqk
 * @date: 2019-07-11 17:44
 * @description: 直播相关配置信息
 */
@Configuration
@ConfigurationProperties(prefix = "live.tencent")
@Data
@RefreshScope
public class LiveConfig {
    /**
     * 推流域名
     */
    private String pushDomain;

    /**
     * 播放域名
     */
    private String playDomain;
    private String bizId;

    /**
     * 推流防盗链Key
     */
    private String pushUrlKey;

    /**
     * API鉴权key
     */
    private String apiKey;

    /**
     * 聊天室服务器地址
     */
    private String chatAddress;
}
