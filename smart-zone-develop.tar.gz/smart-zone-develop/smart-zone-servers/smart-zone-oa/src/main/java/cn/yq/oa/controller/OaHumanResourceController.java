package cn.yq.oa.controller;


import cn.yq.common.result.Result;
import cn.yq.oa.service.IOaChannelService;
import cn.yq.oa.service.IOaRecruitService;
import cn.yq.oa.service.IOaTrainService;
import cn.yq.oa.vo.CooperationCountVo;
import cn.yq.oa.vo.SourceChannelCountVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import net.bytebuddy.agent.builder.AgentBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 人力资源大屏展示
 * </p>
 *
 * @author LWL
 * @since 2019-03-26
 */
@RestController
@RequestMapping("/human-resource")
@Api(value = "人力资源大屏展示", description = "人力资源大屏展示 API")
public class OaHumanResourceController {

    @Autowired
    private IOaRecruitService oaRecruitService;
    @Autowired
    private IOaTrainService oaTrainService;
    @Resource
    private IOaChannelService oaChannelService;
    
    
    /**
    *@Description 人才招聘所有统计
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "人才招聘所有统计", notes = "人才招聘所有统计")
    @GetMapping("/recruitStatistics")
    public Result<Map<String,Object>> recruitStatistics(){
        Map<String, Object> map = oaRecruitService.recruitStatistics();
        return Result.returnOk(map);
    }

    /**
    *@Description 人才培训所有统计
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "人才培训所有统计", notes = "人才培训所有统计")
    @GetMapping("/trainStatistics")
    public Result<Map<String,Object>> trainStatistics(){
        Map<String, Object> map = oaTrainService.trainStatistics();
        return Result.returnOk(map);
    }

    @ApiOperation(value = "员工人数统计", notes = "员工人数统计")
    @GetMapping("/personCount")
    public Result<Map<String,Object>> personCount(){
         Map map = oaRecruitService.personCount();
         return Result.returnOk(map);
    }

    @ApiOperation(value = "合作高校数、合作企业数统计", notes = "合作高校数、合作企业数统计")
    @GetMapping("/cooperationCount")
    public Result<List> cooperationCount(){
        List<CooperationCountVo> vos = oaChannelService.cooperationCount();
        return  Result.returnOk(vos);
    }

    @ApiOperation(value = "来源渠道", notes = "来源渠道")
    @GetMapping("/sourceChannelCount")
    public Result<List> sourceChannelCount(){
        List<SourceChannelCountVo> vos  = oaChannelService.sourceChannelCount();
        return Result.returnOk(vos);
    }











}
