package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.AuthOrganization;
import cn.yq.oa.entity.MyEnterpriseCertification;
import cn.yq.oa.param.ChangeMyEnterpriseParam;
import cn.yq.oa.param.MyEnterpriseParam;
import cn.yq.oa.service.IAuthOrganizationService;
import cn.yq.oa.service.IAuthUserService;
import cn.yq.oa.service.IMyEnterpriseCertificationService;
import cn.yq.oa.vo.MyEnterpriseVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * 企业认证信息表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-04-30
 */
@RestController
@RequestMapping("/my-enterprise-certification")
@Api(value = "企业认证", description = "ggl企业认证 API", position = 100, protocols = "http")
@AllArgsConstructor
public class MyEnterpriseCertificationController {

	private IMyEnterpriseCertificationService myEnterpriseCertificationService;

	private IAuthUserService authUserService;

	private IAuthOrganizationService authOrganizationService;


    @ApiOperation(value = "添加", notes = "添加")
    @PostMapping(value = "/addMyEnterprise", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加企业认证信息",table = LogTableConstant.MY_ENTERPRISE_CERTIFICATION)
    public Result addMyEnterprise(@RequestBody MyEnterpriseParam param){
        if(null != param){
            MyEnterpriseCertification myEnterpriseCertification = new MyEnterpriseCertification();
            CopyUtils.copyProperties(param,myEnterpriseCertification);
            myEnterpriseCertification.setAuditedStatus(1);
            myEnterpriseCertificationService.save(myEnterpriseCertification);
        }
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/removeMyEnterprise/{id}")
    @SystemLog(description = "删除企业认证信息",table = LogTableConstant.MY_ENTERPRISE_CERTIFICATION)
    public Result removeMyEnterprise(@PathVariable("id") Integer id){
        myEnterpriseCertificationService.removeById(id);
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取审核信息", notes = "分页获取审核信息")
    @GetMapping("/listMyEnterprise/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页查询企业认证信息",table = LogTableConstant.MY_ENTERPRISE_CERTIFICATION)
    public Result<IPage<MyEnterpriseVO>> listMyEnterprise(@ApiIgnore AuthUser authUser,
                                                          @PathVariable("pageNum") int pageNum,
                                                          @PathVariable("pageSize") int pageSize){
        Page<MyEnterpriseVO> page = new Page<>(pageNum,pageSize);
        IPage<MyEnterpriseVO> iPage = page.setRecords(myEnterpriseCertificationService.listMyEnterprise(page,authUser.getOrganizationId()));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "审核通过传2/审核拒绝传3", notes = "删除")
    @PostMapping("/changAuditStatus")
    @LoginUser
    @SystemLog(description = "审核企业认证信息",table = LogTableConstant.MY_ENTERPRISE_CERTIFICATION)
    public Result changAuditStatus(@RequestBody ChangeMyEnterpriseParam param){

        if(null != param){
            MyEnterpriseCertification myEnterpriseCertification = new MyEnterpriseCertification();
            myEnterpriseCertification.setId(param.getId());
            myEnterpriseCertification.setAuditedStatus(param.getStatus());
            myEnterpriseCertification.setAuditTime(new Date());
            myEnterpriseCertificationService.updateById(myEnterpriseCertification);
            if(param.getStatus() == 2){
                //审核通过后入驻企业
                cn.yq.oa.entity.AuthUser authUser = new cn.yq.oa.entity.AuthUser();
                authUser.setId(param.getUserId());
                authUser.setOrganizationId(param.getOrgId());
                authUserService.updateById(authUser);
            }
        }
        return  Result.returnOk("操作成功");
    }

    @ApiOperation(value = "app企业认证校验", notes = "app企业认证校验")
    @GetMapping("/isMyEnterprise")
    @LoginUser
    @SystemLog(description = "app端企业认证校验")
    public Result isMyEnterprise(@ApiIgnore AuthUser authUser){
        cn.yq.oa.entity.AuthUser user = authUserService.getById(authUser.getId());
        Map map = new HashMap();
        int flag;
        //判断是否是管理员
        if (user.getIsAdmin() == 1) {
            flag = 1;
            //获取当前企业下的编码
            QueryWrapper<AuthOrganization> wrapper = new QueryWrapper<>();
            wrapper.eq("id",user.getOrganizationId());
            wrapper.eq("is_del",0);
            AuthOrganization authOrganization = authOrganizationService.getOne(wrapper);
            map.put("code",authOrganization.getCode());
        } else {
            //判断是否已认证企业
            if (null != user.getOrganizationId() && user.getOrganizationId() != 0) {
                flag = 2;
            }else{
                flag = 3;
            }
        }
        map.put("flag",flag);
        return Result.returnOk(map);
    }
}
