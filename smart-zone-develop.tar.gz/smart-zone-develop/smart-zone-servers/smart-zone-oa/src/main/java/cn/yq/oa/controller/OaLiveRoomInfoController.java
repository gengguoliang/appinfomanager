package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.config.LiveConfig;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.CleanUpAttachmentParam;
import cn.yq.oa.param.LiveRoomParam;
import cn.yq.oa.param.LiveRoomSearchParam;
import cn.yq.oa.param.LiveSearchParam;
import cn.yq.oa.service.*;
import cn.yq.oa.util.tencent.TencentUtils;
import cn.yq.oa.vo.TimelineProfileVO;
import cn.yq.oa.vo.liveRoom.ChatRoomVO;
import cn.yq.oa.vo.liveRoom.ListLiveRoomVO;
import cn.yq.oa.vo.liveRoom.PushUrlVO;
import cn.yq.oa.vo.liveRoom.ViewLiveRoomVO;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.websocket.server.PathParam;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 大咖秀直播间信息表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-07-12
 */
@RestController
@RequestMapping("/live")
@Slf4j
@AllArgsConstructor
@Api(value = "大咖秀信息管理", description = "大咖秀信息管理(tencent版) API", position = 100, protocols = "http")
public class OaLiveRoomInfoController {
    private ISysDictDataService sysDictDataService;

    private ICommonFilesService commonFilesService;

    private IOaLiveRoomInfoService oaLiveRoomInfoService;

    private ITimelineProfileService timelineProfileService;

    private LiveConfig liveConfig;

    private IOaRoadshowRoomInfoService oaRoadshowRoomInfoService;

    @ApiOperation(value = "创建(id传0)/编辑直播（id传实际的值）", notes = "创建/编辑直播")
    @PostMapping(value = "/addorUpdateLive", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加或编辑大咖秀信息")
    public Result addorUpdateLive(@ApiIgnore AuthUser authUser, @RequestBody LiveRoomParam param) {
        if (null != param) {
            OaLiveRoomInfo oaLiveInfo = new OaLiveRoomInfo();
            CopyUtils.copyProperties(param, oaLiveInfo);
            if (param.getId() != 0) {
                oaLiveRoomInfoService.updateById(oaLiveInfo);
                //获取当前直播下的海报文件集合
                QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("is_del", 0);
                queryWrapper.eq("relation_id", oaLiveInfo.getId());
                queryWrapper.eq("relation_type", "poster_type");
                List<CommonFiles> list = commonFilesService.list(queryWrapper);
                for (CommonFiles commonFiles : list) {
                    commonFilesService.removeById(commonFiles.getId());
                }
                //添加直播海报
                for (CleanUpAttachmentParam cleanUpAttachmentParam : param.getList()) {
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(cleanUpAttachmentParam, commonFiles);
                    commonFiles.setRelationId(oaLiveInfo.getId());
                    commonFiles.setRelationType("poster_type");
                    commonFilesService.save(commonFiles);
                }

            } else {
                //生成聊天室id
                String chatRoomId = TencentUtils.getChatRoomId();
                //生成流id
                String StreamId = liveConfig.getBizId()+"_"+chatRoomId;
                oaLiveInfo.setStatus(1);
                oaLiveInfo.setLiveStatus(1);
                oaLiveInfo.setChatroomId(chatRoomId);
                oaLiveInfo.setStreamId(StreamId);
                oaLiveInfo.setCreateBy(authUser.getName());
                oaLiveRoomInfoService.save(oaLiveInfo);
                //添加直播海报
                for (CleanUpAttachmentParam cleanUpAttachmentParam : param.getList()) {
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(cleanUpAttachmentParam, commonFiles);
                    commonFiles.setRelationId(oaLiveInfo.getId());
                    commonFiles.setRelationType("poster_type");
                    commonFilesService.save(commonFiles);
                }
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取直播类别(取dictValue和dictLabel)", notes = "获取直播类别")
    @GetMapping(value = "/getDicInfo")
    public Result getDicInfo() {
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del", 0);
        queryWrapper.eq("dict_type", "live_type");
        List<SysDictData> list = sysDictDataService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "分页获取直播信息", notes = "分页获取直播信息")
    @PostMapping("/listLive/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查看大咖秀信息")
    public Result<IPage<ListLiveRoomVO>> listLive(@PathVariable("pageNum") int pageNum,
                                                  @PathVariable("pageSize") int pageSize,
                                                  @RequestBody LiveSearchParam param) {
        Page<ListLiveRoomVO> page = new Page<ListLiveRoomVO>(pageNum, pageSize);
        IPage<ListLiveRoomVO> iPage = page.setRecords(oaLiveRoomInfoService.listPageLive(page, param));
        for (ListLiveRoomVO listLiveRoomVO : iPage.getRecords()){
            listLiveRoomVO.setChatroomUrl(liveConfig.getChatAddress());
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "查看直播信息", notes = "查看直播信息")
    @GetMapping("/viewLive/{id}")
    @SystemLog(description = "大咖秀信息详情")
    public Result<ViewLiveRoomVO> viewLive(@PathVariable("id") Integer id) {
        ViewLiveRoomVO viewLiveInfoVO = oaLiveRoomInfoService.selectViewInfo(id);
        List<CleanUpAttachmentParam> list1 = new ArrayList<>();
        if (null != viewLiveInfoVO) {
            //获取当前直播下得海报信息
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("is_del", 0);
            queryWrapper.eq("relation_id", id);
            queryWrapper.eq("relation_type", "poster_type");
            List<CommonFiles> list = commonFilesService.list(queryWrapper);
            for (CommonFiles commonFiles : list) {
                CleanUpAttachmentParam param = new CleanUpAttachmentParam();
                CopyUtils.copyProperties(commonFiles, param);
                list1.add(param);
            }
            viewLiveInfoVO.setList(list1);
            //生成播放地址
            Map map = new HashMap();
            String date = String.valueOf(System.currentTimeMillis()).substring(0,10);
            map.put("rtmp",TencentUtils.getPlayUrl(liveConfig.getPlayDomain(),liveConfig.getApiKey(),viewLiveInfoVO.getStreamId(),new Long(date),"rtmp"));
            map.put("flv",TencentUtils.getPlayUrl(liveConfig.getPlayDomain(),liveConfig.getApiKey(),viewLiveInfoVO.getStreamId(),new Long(date),"flv"));
            map.put("m3u8",TencentUtils.getPlayUrl(liveConfig.getPlayDomain(),liveConfig.getApiKey(),viewLiveInfoVO.getStreamId(),new Long(date),"m3u8"));
            viewLiveInfoVO.setPlayUrl(map);
        }
        return Result.returnOk(viewLiveInfoVO);
    }

    @ApiOperation(value = "删除直播信息", notes = "删除直播信息")
    @GetMapping("/deleteLive/{id}")
    @SystemLog(description = "删除大咖秀信息")
    public Result deleteLive(@PathVariable("id") Integer id) {
        oaLiveRoomInfoService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "更改直播信息状态(发布status传2下架传3)", notes = "更改直播信息状态")
    @GetMapping("/changeLiveStatus/{id}/{status}")
    @LoginUser
    @SystemLog(description = "大咖秀信息状态变更")
    public Result changeLiveStatus(@ApiIgnore AuthUser authUser, @PathVariable("id") Integer id, @PathVariable("status") Integer status) {
        OaLiveRoomInfo oaLiveInfo = new OaLiveRoomInfo();
        oaLiveInfo.setId(id);
        oaLiveInfo.setStatus(status);
        if (status == 2) {
            oaLiveInfo.setPublisher(authUser.getName());
            oaLiveInfo.setPublishtime(new Date());
        }
        oaLiveRoomInfoService.updateById(oaLiveInfo);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "开播", notes = "开播")
    @GetMapping("/getPushUrl/{id}")
    @SystemLog(description = "大咖秀开播")
    public Result<PushUrlVO> getPushUrl(@PathVariable("id")Integer id){
        //获取直播码
        OaLiveRoomInfo oaLiveRoomInfo = oaLiveRoomInfoService.getById(id);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(oaLiveRoomInfo.getLiveTime());
        calendar.add(Calendar.HOUR,24);
        Date expireTime = calendar.getTime();
        String unixTime = String.valueOf(expireTime.getTime()).substring(0,10);
        String pushUrl = TencentUtils.getPushUrl(liveConfig.getPushDomain(),liveConfig.getPushUrlKey(),oaLiveRoomInfo.getStreamId(),new Long(unixTime));
        int index = pushUrl.lastIndexOf("/");
        String serverUrl = pushUrl.substring(0,index+1);
        PushUrlVO pushUrlVO = new PushUrlVO(expireTime,serverUrl, pushUrl.substring(index+1));

        return Result.returnOk(pushUrlVO);
    }

    @ApiOperation(value = "直播回调", notes = "直播回调")
    @PostMapping("/live-notify")
    public Result liveNotify(@RequestBody Object obj){
        log.info("腾讯云直播回调参数=====================>",obj);
        String json = JSON.toJSONString(obj);
        Map map = JSON.parseObject(json, Map.class);
        //异常处理
        if(map.containsKey("errcode")){
            int errcode = (int)map.get("errcode");
            if( errcode != 0){
                log.error(String.valueOf(errcode),map.get("errmsg").toString());
                return Result.returnFail();
            }
        }
        if(map.containsKey("event_type")){
            String streamId = map.get("stream_id").toString();
            QueryWrapper<OaLiveRoomInfo> wrapper = new QueryWrapper<>();
            wrapper.eq("stream_id",streamId);
            wrapper.eq("is_del",0);
            OaLiveRoomInfo oaLiveRoomInfo1 = oaLiveRoomInfoService.getOne(wrapper);
            if(oaLiveRoomInfo1 != null){
                OaLiveRoomInfo oaLiveRoomInfo = new OaLiveRoomInfo();
                switch (Integer.parseInt(map.get("event_type").toString())) {
                    case 0:
                        //断流/直播已结束
                        oaLiveRoomInfo.setLiveStatus(4);
                        oaLiveRoomInfoService.update(oaLiveRoomInfo,wrapper);
                        break;
                    case 1:
                        //推流/开始直播
                        oaLiveRoomInfo.setLiveStatus(2);
                        oaLiveRoomInfoService.update(oaLiveRoomInfo,wrapper);
                        break;
                    case 100:
                        //新录制文件/存在回放
                        oaLiveRoomInfo.setLiveStatus(3);
                        oaLiveRoomInfo.setVideoUrl(map.get("video_url").toString());
                        oaLiveRoomInfoService.update(oaLiveRoomInfo,wrapper);
                        break;
                    default:
                        //TODO
                        break;
                }
            }else{
                QueryWrapper<OaRoadshowRoomInfo> wrapper1 = new QueryWrapper<>();
                wrapper1.eq("stream_id",streamId);
                wrapper1.eq("is_del",0);
                OaRoadshowRoomInfo oaRoadshowRoomInfo = new OaRoadshowRoomInfo();
                switch (Integer.parseInt(map.get("event_type").toString())) {
                    case 0:
                        //断流/直播已结束
                        oaRoadshowRoomInfo.setLiveStatus(4);
                        oaRoadshowRoomInfoService.update(oaRoadshowRoomInfo,wrapper1);
                        break;
                    case 1:
                        //推流/开始直播
                        oaRoadshowRoomInfo.setLiveStatus(2);
                        oaRoadshowRoomInfoService.update(oaRoadshowRoomInfo,wrapper1);
                        break;
                    case 100:
                        //新录制文件/存在回放
                        oaRoadshowRoomInfo.setLiveStatus(3);
                        oaRoadshowRoomInfo.setVideoUrl(map.get("video_url").toString());
                        oaRoadshowRoomInfoService.update(oaRoadshowRoomInfo,wrapper1);
                        break;
                    default:
                        //TODO
                        break;
                }
            }

        }
        return Result.returnOk();
    }

    @ApiOperation(value = "APP大咖秀列表", notes = "APP大咖秀列表")
    @PostMapping("/listAPPLiveInfo")
    public Result<List<ViewLiveRoomVO>> listAppLiveRoom(@RequestBody LiveRoomSearchParam params) {
        List<ViewLiveRoomVO> list = oaLiveRoomInfoService.listAppLiveRoom(params);
        for (ViewLiveRoomVO viewLiveInfoVO : list) {
            List<CleanUpAttachmentParam> listparam = new ArrayList<>();
            //获取当前直播下得海报信息
            QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("is_del", 0);
            queryWrapper1.eq("relation_id", viewLiveInfoVO.getId());
            queryWrapper1.eq("relation_type", "poster_type");
            List<CommonFiles> comlist = commonFilesService.list(queryWrapper1);
            for (CommonFiles commonFiles : comlist) {
                CleanUpAttachmentParam param = new CleanUpAttachmentParam();
                CopyUtils.copyProperties(commonFiles, param);
                listparam.add(param);
            }
            if (null != comlist && comlist.size() > 0) {
                viewLiveInfoVO.setList(listparam);
            }
        }
        List<ViewLiveRoomVO> list2 = new ArrayList<>();
        list2 = list.stream().filter(v -> {
            if(v.getLiveStatus() == 4){
                return  false;
            }else{
                return  true;
            }
        }).collect(Collectors.toList());
        return Result.returnOk(list2);
    }

    @ApiOperation(value = "聊天室个人资料", notes = "聊天室个人资料")
    @GetMapping("/getPersonalData")
    @LoginUser
    public Result<ChatRoomVO> getPersonalData(@ApiIgnore AuthUser authUser) {
        ChatRoomVO chatRoomVO = new ChatRoomVO();
        chatRoomVO.setName(authUser.getUsername());
        QueryWrapper<TimelineProfile> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id",authUser.getId());
        TimelineProfile timelineProfile = timelineProfileService.getOne(wrapper);
        if(null != timelineProfile){
            String [] urls = timelineProfile.getHeadImgUrl().split("\\?");
            String url = urls[0].replaceAll("http://kodo.smart-zone.51yuqian.net/","");
            chatRoomVO.setHeadUrl(new StringBuilder(url).toString());
        }else{
            chatRoomVO.setHeadUrl(new StringBuilder().append("FthSUgiphSsST3uMRv0I3rA-zny8").toString());
        }
        return Result.returnOk(chatRoomVO);
    }

}
