package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oachannel.OaChannelDTO;
import cn.yq.oa.dto.oarecruit.ProjectDTO;
import cn.yq.oa.entity.OaChannel;
import cn.yq.oa.entity.OaFixedassetsCleanup;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.param.ChannelParam;
import cn.yq.oa.param.CleanUpParam;
import cn.yq.oa.service.IOaChannelService;
import cn.yq.oa.service.impl.OaChannelServiceImpl;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 人才渠道管理 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-08-23
 */
@Api(value = "人才渠道管理", description = "人才渠道管理")
@RestController
@RequestMapping("/oa-channel")
public class OaChannelController {

    @Resource
    private IOaChannelService oaChannelService;

    @ApiOperation(value = "新增/编辑", notes = "新增/编辑")
    @PostMapping(value = "/addChannel")
    @SystemLog(description = "添加人才渠道",table = LogTableConstant.OA_CHANNEL)
    public Result addChannel(@RequestBody OaChannelDTO oaChannelDTO){
        OaChannel oaChannel = new OaChannel();
        BeanUtils.copyProperties(oaChannelDTO,oaChannel);
        oaChannelService.saveOrUpdate(oaChannel);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/deleteChannel/{id}")
    @SystemLog(description = "删除人才渠道信息",table = LogTableConstant.OA_CHANNEL)
    public Result deleteChannel(@PathVariable("id") int id) {
        oaChannelService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllChannel/{pageNum}/{pageSize}")
    @SystemLog(description = "人才渠道列表")
    public Result getAllChannel(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody ChannelParam channelParam) {
        Page<OaChannel> page = new Page<OaChannel>(pageNum,pageSize);
        IPage<OaChannel> iPage = oaChannelService.selectChannelPage(page, channelParam);
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "根据类型获取渠道（0：合作高校，1：合作企业）", notes = "根据类型获取渠道（0：合作高校，1：合作企业）")
    @GetMapping("/getChannelByType/{type}")
    @SystemLog(description = "根据类型获取渠道",table = LogTableConstant.OA_CHANNEL)
    public Result getChannelByType(@PathVariable("type") Integer type){
        QueryWrapper<OaChannel> queryWrapper = new QueryWrapper<OaChannel>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("type",type);
        queryWrapper.orderByDesc("create_time");
        List<OaChannel> list = oaChannelService.list(queryWrapper);
        return Result.returnOk(list);
    }











    }
