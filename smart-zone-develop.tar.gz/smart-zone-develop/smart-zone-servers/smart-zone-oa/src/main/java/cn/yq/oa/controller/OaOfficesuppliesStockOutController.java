package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.*;
import cn.yq.oa.entity.OaOfficesuppliesApplication;
import cn.yq.oa.entity.OaOfficesuppliesItem;
import cn.yq.oa.entity.OaOfficesuppliesStockOut;
import cn.yq.oa.service.IOaOfficesuppliesApplicationService;
import cn.yq.oa.service.IOaOfficesuppliesItemService;
import cn.yq.oa.service.IOaOfficesuppliesStockOutService;
import cn.yq.oa.vo.*;
import cn.yq.oa.vo.officesuppliesAnalysis.ExportStockInVO;
import cn.yq.oa.vo.officesuppliesAnalysis.ExportStockOutVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 办公用品出库信息表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-01-31
 */
@Api(value = "办公用品出库", description = "办公用品出库")
@RestController
@RequestMapping("/oa-officesupplies-stock-out")
public class OaOfficesuppliesStockOutController {

    @Autowired
    private IOaOfficesuppliesStockOutService oaOfficesuppliesStockOutService;
    @Autowired
    private IOaOfficesuppliesItemService oaOfficesuppliesItemService;
    @Autowired
    private IOaOfficesuppliesApplicationService oaOfficesuppliesApplicationService;


    /**
     * @Description 导出办公用品入库
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "导出办公用品入库", notes = "导出办公用品入库")
    @PostMapping("/exportStockIn")
    @SystemLog(description = "导出办公用品入库")
    public Result<List<ExportStockInVO>> exportStockIn(@RequestBody ExportStockInDTO dto) {
        List<ExportStockInVO> exportStockInVOS = oaOfficesuppliesStockOutService.exportStockIn(dto);
        return Result.returnOk(exportStockInVOS);
    }


    /**
     * @Description 导出办公用品领用
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "导出办公用品领用", notes = "导出办公用品领用")
    @PostMapping("/exportStockOut")
    @SystemLog(description = "导出办公用品领用")
    public Result<List<ExportStockOutVO>> exportStockOut(@RequestBody StockOutShowDTO dto) {
        List<ExportStockOutVO> exportStockOutVOS = oaOfficesuppliesStockOutService.exportStockOut(dto);
        return Result.returnOk(exportStockOutVOS);
    }


    /**
     * @Description 导出办公用品库存
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "导出办公用品库存", notes = "导出办公用品库存")
    @PostMapping("/exportItem")
    @SystemLog(description = "导出办公用品库存")
    public Result<List<OaOfficesuppliesItemVO>> exportItem(@RequestBody OutItemDTO dto) {
        List<OaOfficesuppliesItemVO> itemVOS = oaOfficesuppliesStockOutService.exportItem(dto);
        return Result.returnOk(itemVOS);
    }


    /**
     * @Description PC根据部门ID查询当前部门下的所有用户
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC根据部门ID查询当前部门下的所有用户", notes = "PC根据部门ID查询当前部门下的所有用户")
    @GetMapping("/getUserByDeptId/{deptId}")
    public Result getUserByDeptId(@PathVariable("deptId") Integer deptId) {
        List<AuthUser> userByDeptId = oaOfficesuppliesStockOutService.getUserByDeptId(deptId);
        return Result.returnOk(userByDeptId);
    }

    /**
     * @Description 新增领用记录
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "新增领用记录", notes = "新增领用记录")
    @PostMapping(value = "/add")
    @SystemLog(description = "办公用品新增领用记录")
    public Result add(@RequestBody OaOfficesuppliesStockOutDTO oaOfficesuppliesStockOutDTO) {
        if (StringUtils.isNotBlank(oaOfficesuppliesStockOutDTO.getNo())) {
            QueryWrapper<OaOfficesuppliesApplication> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("no", oaOfficesuppliesStockOutDTO.getNo())
                    .eq("is_del", 0);
            List<OaOfficesuppliesApplication> oaOfficesuppliesApplications = oaOfficesuppliesApplicationService.list(queryWrapper);
            if (ObjectUtils.isEmpty(oaOfficesuppliesApplications)) {
                return new Result(ResultEnum.FAIL.getCode(), "单号不存在");
            }
            //状态，0：待处理，1：已通过，2：已领用，3：未通过
            if (oaOfficesuppliesApplications.get(0).getStatus() == 0) {
                return new Result(ResultEnum.FAIL.getCode(), "此单号还未审核");
            }
            if (oaOfficesuppliesApplications.get(0).getStatus() == 3) {
                return new Result(ResultEnum.FAIL.getCode(), "此单号审核未通过");
            }
            if (oaOfficesuppliesApplications.get(0).getStatus() == 2) {
                return new Result(ResultEnum.FAIL.getCode(), "此单号已领用");
            }

        }
        oaOfficesuppliesStockOutService.add(oaOfficesuppliesStockOutDTO);
        return Result.returnOk();
    }

    /**
     * @Description 领用列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "领用列表展示", notes = "领用列表展示")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @SystemLog(description = "办公用品领用列表展示")
    public Result showPage(@PathVariable("pageNum") Integer pageNum, @PathVariable("pageSize") Integer pageSize, @RequestBody StockOutShowDTO stockOutShowDTO) {
        IPage<OaOfficesuppliesStockOutVO> oaOfficesuppliesStockOutVOIPage = oaOfficesuppliesStockOutService.showPage(pageNum, pageSize, stockOutShowDTO);
        return Result.returnOk(oaOfficesuppliesStockOutVOIPage);
    }

    /**
     * @Description 领用登记详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "领用登记详情", notes = "领用登记详情")
    @GetMapping(value = "/detail/{pageNum}/{pageSize}/{id}")
    @SystemLog(description = "办公用品领用登记详情")
    public Result detail(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @PathVariable("id") Integer id) {
        Page page = new Page(pageNum, pageSize);
        IPage<OutDetailVO> outDetailVOIPage = oaOfficesuppliesStockOutService.detail(page, id);
        return Result.returnOk(outDetailVOIPage);
    }

    /**
     * @Description 退库
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "退库", notes = "退库")
    @GetMapping(value = "/returnStock/{id}")
    @SystemLog(description = "办公用品领用退库")
    public Result returnStock(@PathVariable("id") Integer id) {
        oaOfficesuppliesStockOutService.returnStock(id);
        return Result.returnOk();
    }

    /**
     * @Description 领用商品的展示（只用于入库时了）
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "领用商品的展示（只用于入库时了）", notes = "领用商品的展示（只用于入库时了）")
    @PostMapping(value = "/showItemPage/{pageNum}/{pageSize}")
    @SystemLog(description = "办公用品领用商品的展示")
    public Result showItemPage(@RequestBody OaOfficesuppliesItem oaOfficesuppliesItem, @PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize) {
        Page<OaOfficesuppliesItem> page = new Page<>(pageNum, pageSize);
        QueryWrapper queryWrapper = new QueryWrapper();
        queryWrapper.orderByDesc("create_time");
        if (StringUtils.isNotBlank(oaOfficesuppliesItem.getName())) {
            queryWrapper.like("name", "%" + oaOfficesuppliesItem.getName() + "%");
        }
        if (StringUtils.isNotBlank(oaOfficesuppliesItem.getItemCode())) {
            queryWrapper.like("item_code", "%" + oaOfficesuppliesItem.getItemCode() + "%");
        }
        if (oaOfficesuppliesItem.getCategoryId() != null) {
            queryWrapper.eq("category_id", oaOfficesuppliesItem.getCategoryId());
        }
        queryWrapper.eq("status", 0);
        queryWrapper.eq("is_del", 0);
        IPage page1 = oaOfficesuppliesItemService.page(page, queryWrapper);
        return Result.returnOk(page1);
    }

    /**
     * @Description 领用商品的展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "领用商品的展示", notes = "领用商品的展示")
    @PostMapping(value = "/showOutItemPage")
    @SystemLog(description = "办公用品领用商品的展示")
    public Result showOutItemPage(@RequestBody OutItemDTO outItemDTO) {
        List<OutItemVO> outItemVOS = oaOfficesuppliesStockOutService.showOutItemPage(outItemDTO);
        return Result.returnOk(outItemVOS);
    }

    /**
     * @Description PC领用物品批次的展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC领用物品批次的展示", notes = "PC领用物品批次的展示")
    @PostMapping(value = "/detailNoShow")
    @SystemLog(description = "办公用品领用物品批次的展示")
    public Result<List<DetailNoVO>> detailNoShow(@RequestBody List<DetailNoDTO> detailNoDTOS) {
        List<DetailNoVO> detailNoVOS = oaOfficesuppliesStockOutService.detailNoShow(detailNoDTOS);
        return Result.returnOk(detailNoVOS);
    }

}
