package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaConferenceParticipants;
import cn.yq.oa.entity.OaConferenceReservation;
import cn.yq.oa.entity.OaConferenceroom;
import cn.yq.oa.service.IOaConferenceParticipantsService;
import cn.yq.oa.service.IOaConferenceReservationService;
import cn.yq.oa.service.IOaConferenceroomService;
import cn.yq.oa.service.IUserDepartmentService;
import cn.yq.oa.vo.OaMeetingReservationVO;
import cn.yq.oa.vo.OaParticipantsVO;
import cn.yq.oa.vo.SeatInfoVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 参会人员表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-28
 */
@Api(value = "智能排座", description = "智能排座 API", position = 100, protocols = "http")
@RestController
@RequestMapping("/oa-conference-participants")
public class OaConferenceParticipantsController {
    @Autowired
    private IOaConferenceParticipantsService oaConferenceParticipantsService;
    @Autowired
    private IOaConferenceroomService oaConferenceroomService;
    @Autowired
    private IOaConferenceReservationService oaConferenceReservationService;
    @Autowired
    private IUserDepartmentService userDepartmentService;


    @ApiOperation(value = "智能排座展/会议纪要列表", notes = "智能排座展/会议纪要列表")
    @GetMapping("/getAppointmentOk")
    @LoginUser
    @SystemLog(description = "智能排座列表")
    public Result<List<OaMeetingReservationVO>> getAppointmentOk(@ApiIgnore AuthUser authUser){
        List<OaMeetingReservationVO> list = oaConferenceParticipantsService.selectMeetingListByUserId(authUser);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "座位信息", notes = "座位信息")
    @GetMapping("/getSeatInfo/{meetingId}")
    @LoginUser
    @SystemLog(description = "座位信息")
    public Result<SeatInfoVO> getSeatInfo(@ApiIgnore AuthUser authUser,@PathVariable("meetingId") Integer meetingId){
        //座位信息整合
        SeatInfoVO seatInfoVO = new SeatInfoVO();
        //根据用户id和会议id获取当前人员信息
        QueryWrapper<OaConferenceParticipants> queryWrapper = new QueryWrapper<OaConferenceParticipants>();
        queryWrapper.eq("user_id",authUser.getId());
        queryWrapper.eq("conference_id",meetingId);
        queryWrapper.eq("is_del",0);
        OaConferenceParticipants oaConferenceParticipants = oaConferenceParticipantsService.getOne(queryWrapper);
        if(null != oaConferenceParticipants){
            seatInfoVO.setUsername(oaConferenceParticipants.getUsername());
            seatInfoVO.setSeat(oaConferenceParticipants.getSeat());
        }
        //根据会议id获取会议室id
        QueryWrapper<OaConferenceReservation> queryWrapper1 = new QueryWrapper<OaConferenceReservation>();
        queryWrapper1.eq("id",meetingId);
        queryWrapper1.eq("is_del",0);
        OaConferenceReservation oaConferenceReservation = oaConferenceReservationService.getOne(queryWrapper1);
        if(null != oaConferenceReservation){
            CopyUtils.copyProperties(oaConferenceReservation,seatInfoVO);
        }
        //根据会议室id获取会议室信息
        QueryWrapper<OaConferenceroom> queryWrapper2 = new QueryWrapper<OaConferenceroom>();
        queryWrapper2.eq("id",oaConferenceReservation.getRoomId());
        queryWrapper2.eq("is_del",0);
        OaConferenceroom oaConferenceroom = oaConferenceroomService.getOne(queryWrapper2);
        if(null != oaConferenceroom){
            seatInfoVO.setAddress(oaConferenceroom.getAddress());
            seatInfoVO.setEntrylocation(oaConferenceroom.getEntrylocation());
            seatInfoVO.setPeoplenumber(oaConferenceroom.getPeoplenumber());
        }
        //根据用户id获取所属部门
        String departmentName = userDepartmentService.selectDepartmentByUserId(authUser.getId());
        seatInfoVO.setDepartmentName(departmentName);
        return Result.returnOk(seatInfoVO);
    }

    @ApiOperation(value = "智能排座", notes = "智能排座")
    @GetMapping("/updateSeat/{id}")
    @LoginUser
    @SystemLog(description = "排座")
    public Result updateSeat(@ApiIgnore AuthUser authUser, @PathVariable("id") Integer id){
        //获取该会议所用会议室的容纳人数
        int peopleNumber = oaConferenceroomService.selectPeopleNumber(id);
        //获取当前会议下的所有人员id集合
        List<Integer> ids = oaConferenceParticipantsService.selectAllSeat(id);
        for(int i = 0; i < ids.size();i++){
            int num = ids.get(i);
            OaConferenceParticipants oaConferenceParticipants = new OaConferenceParticipants();
            oaConferenceParticipants.setId(num);
            oaConferenceParticipants.setSeat(i+1);
            oaConferenceParticipantsService.updateById(oaConferenceParticipants);
        }
/*        for (int i = 1; i <= peopleNumber; i++) {
            int k = 0;
            for (int j = 0; i < seatList.size(); i++) {
                int num = seatList.get(j);
                if(num == i){
                    k++;
                    break;
                }
            }

            if(k==0){
                //此处用作更新座位号
            }
        }*/
        return Result.returnOk("操作成功");
    }
}
