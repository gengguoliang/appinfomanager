package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.CommonFiles;
import cn.yq.oa.entity.OaBusinessActivity;
import cn.yq.oa.entity.OaBusinessCooperative;
import cn.yq.oa.param.*;
import cn.yq.oa.service.ICommonFilesService;
import cn.yq.oa.service.IOaBusinessActivityService;
import cn.yq.oa.service.IOaBusinessCategoryService;
import cn.yq.oa.service.IOaBusinessCooperativeService;
import cn.yq.oa.vo.oabusiness.ActivityAPPInfoVO;
import cn.yq.oa.vo.oabusiness.ActivityAPPVO;
import cn.yq.oa.vo.oabusiness.BusinessCooperativeVO;
import cn.yq.oa.vo.oabusiness.BusinessInfoAPPVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 合作商家信息表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-31
 */
@RestController
@RequestMapping("/oa-business-cooperative")
@Api(value = "合作商家管理", description = "ggl合作商家管理 API", position = 100, protocols = "http")
public class OaBusinessCooperativeController {
    @Autowired
    private IOaBusinessActivityService oaBusinessActivityService;
    @Autowired
    private IOaBusinessCooperativeService oaBusinessCooperativeService;
    @Autowired
    private ICommonFilesService commonFilesService;


    @ApiOperation(value = "APP查询活动信息", notes = "APP查询活动信息")
    @PostMapping("/listActivity")
    @SystemLog(description = "APP查询活动信息")
    public Result listActivity(@RequestBody ActivitySearchParam param){
        Map<String,List<ActivityAPPVO>> map = new HashMap<>();

        //所有活动信息
        List<ActivityAPPVO> list = oaBusinessActivityService.selectActivityAPPVO(param,0);
        for(ActivityAPPVO activityAPPVO : list){
            String [] imgs = activityAPPVO.getActivityImg().split(",");
            activityAPPVO.setImgs(imgs);
        }
        map.put("listAll",list);

        //最新活动信息TOP3
        List<ActivityAPPVO> listTop = oaBusinessActivityService.selectActivityAPPVO(param,3);
        for(ActivityAPPVO activityAPPVO : listTop){
            String [] imgs = activityAPPVO.getActivityImg().split(",");
            activityAPPVO.setImgs(imgs);
        }
        map.put("listTop3",listTop);
        return Result.returnOk(map);
    }

    @ApiOperation(value = "APP查询商家信息", notes = "APP查询商家信息")
    @PostMapping("/listBusiness")
    @SystemLog(description = "APP查询商家信息")
    public Result<List<BusinessCooperativeVO>> listBusiness(@RequestBody AppBusinessSearchParam param){

        List<BusinessCooperativeVO> list = oaBusinessActivityService.listAPPBusiness(param);
        for (BusinessCooperativeVO businessCooperativeVO : list){
            String [] imgs = businessCooperativeVO.getImg().split(",");
            businessCooperativeVO.setImgs(imgs);
        }
        return Result.returnOk(list);

    }

    @ApiOperation(value = "APP合作商家详情(shopId 商家id activityId 活动id 商家详情页面活动activityId传0)", notes = "APP合作商家详情")
    @PostMapping("/getBusinessInfo/{shopId}/{activityId}")
    @SystemLog(description = "app端合作商家详情")
    public Result<BusinessInfoAPPVO> getBusinessInfo(@PathVariable("shopId")Integer shopId,
                                                     @PathVariable("activityId") Integer activityId){

        BusinessInfoAPPVO businessInfoAPPVO = oaBusinessCooperativeService.getBusinessInfoAPPVO(shopId);
        if(null != businessInfoAPPVO){
            //获取附件
            QueryWrapper<CommonFiles> wrapper = new QueryWrapper<>();
            wrapper.eq("is_del",0);
            wrapper.eq("relation_type","cooperative_enclosure");
            wrapper.eq("relation_id",shopId);
            List<CommonFiles> attlist = commonFilesService.list(wrapper);
            businessInfoAPPVO.setAttlist(attlist);
            //获取附件图片
            QueryWrapper<CommonFiles> wrapper2 = new QueryWrapper<>();
            wrapper2.eq("is_del",0);
            wrapper2.eq("relation_type","cooperative_enclosure_image");
            wrapper2.eq("relation_id",shopId);
            List<CommonFiles> attImglist = commonFilesService.list(wrapper2);
            businessInfoAPPVO.setAttImgList(attImglist);
            //获取荣誉资质图片
            QueryWrapper<CommonFiles> wrapper1 = new QueryWrapper<>();
            wrapper1.eq("is_del",0);
            wrapper1.eq("relation_type","cooperative_honor");
            wrapper1.eq("relation_id",shopId);
            List<CommonFiles> imglist = commonFilesService.list(wrapper1);
            businessInfoAPPVO.setImglist(imglist);

            String [] imgs = businessInfoAPPVO.getImg().split(",");
            businessInfoAPPVO.setImgs(imgs);
            //获取当前商户下的活动信息集合
            QueryWrapper<OaBusinessActivity> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("shop_id",shopId);
            if(activityId != 0){
                queryWrapper1.eq("id",activityId);
            }
            queryWrapper1.eq("is_del",0);
            List<OaBusinessActivity> list = oaBusinessActivityService.list(queryWrapper1);
            List<ActivityAPPInfoVO> listVO = new ArrayList<>();
            for (OaBusinessActivity oaBusinessActivity : list){
                ActivityAPPInfoVO activityAPPInfoVO = new ActivityAPPInfoVO();
                CopyUtils.copyProperties(oaBusinessActivity,activityAPPInfoVO);
                String []activityImgs = oaBusinessActivity.getActivityImg().split(",");
                activityAPPInfoVO.setActivityImgs(activityImgs);
                listVO.add(activityAPPInfoVO);
            }
            businessInfoAPPVO.setList(listVO);
        }
        return Result.returnOk(businessInfoAPPVO);
    }


}
