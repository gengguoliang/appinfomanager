package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.oa.dto.oaproperty.PropertyPlaceDTO;
import cn.yq.oa.entity.OaPropertyPlace;
import cn.yq.oa.service.IOaPropertyPlaceService;
import cn.yq.oa.vo.oaproperty.PropertyPlaceVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 领取地点表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-06
 */
@Api(value = "推车领取地点维护", description = "推车领取地点维护")
@RestController
@RequestMapping("/oa-property-place")
public class OaPropertyPlaceController {

    @Autowired
    private IOaPropertyPlaceService oaPropertyPlaceService;

    /**
     * @Description 添加
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "添加", notes = "添加")
    @PostMapping(value = "/add")
    @SystemLog(description = "添加推车领取地点维护")
    public Result add(@RequestBody PropertyPlaceDTO propertyPlaceDTO) {
        QueryWrapper<OaPropertyPlace> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("building_id",propertyPlaceDTO.getBuildingId())
                .eq("place_name",propertyPlaceDTO.getPlaceName())
                .eq("is_del",0);
        int count = oaPropertyPlaceService.count(queryWrapper);
        if(count>0){
            return new Result(ResultEnum.FAIL.getCode(), "此楼宇的此地点已存在");
        }
        oaPropertyPlaceService.add(propertyPlaceDTO);
        return Result.returnOk();
    }

    /**
     * @Description 列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "列表展示", notes = "列表展示")
    @GetMapping(value = "/show/{pageNum}/{pageSize}")
    @SystemLog(description = "推车领取地点维护列表展示")
    public Result show(@PathVariable("pageNum")Integer pageNum,@PathVariable("pageSize")Integer pageSize) {
        Page<PropertyPlaceVO> page=new Page<>(pageNum,pageSize);
        IPage<PropertyPlaceVO> ipage=page.setRecords(oaPropertyPlaceService.show(page));
        return Result.returnOk(ipage);
    }

    /**
     * @Description 批量删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "批量删除", notes = "批量删除")
    @PostMapping(value = "/removeSome")
    @SystemLog(description = "推车领取地点维护批量删除")
    public Result removeSome(@RequestBody List<Integer> ids) {
        oaPropertyPlaceService.removeByIds(ids);
        return Result.returnOk();
    }


}
