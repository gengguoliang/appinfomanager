package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.PrimaryGenerater;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.ICommonFilesService;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsCleanupService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.impl.OrderNumberServiceImpl;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 固定资产清理信息表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-03
 */
@RestController
@RequestMapping("/oa-fixedassets-cleanup")
@AllArgsConstructor
public class
OaFixedassetsCleanupController {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsService oaFixedassetsService;

    IOaFixedassetsCleanupService oaFixedassetsCleanupService;

    @Resource(name = "orderNumberServiceImpl")
    OrderNumberServiceImpl orderNumberService;

    ICommonFilesService commonFilesService;

    @PostMapping("/addCleanup")
    @LoginUser
    @SystemLog(description = "添加固定资产清理信息")
    public Result addCleanup(AuthUser authUser, @RequestBody OaFixedassetsCleanupParam oaFixedassetsCleanupParam){
        OaFixedassetsCleanup oaFixedassetsCleanup = new OaFixedassetsCleanup();
        BeanUtils.copyProperties(oaFixedassetsCleanupParam,oaFixedassetsCleanup);
        //清理单号
//        String dh = "QLD" + PrimaryGenerater.geneterNextNumber(sdf.format(new Date()));
        String dh = orderNumberService.getOneOrderNumber("QLD");
        oaFixedassetsCleanup.setNo(dh);
        //保存清理表数据
        oaFixedassetsCleanupService.saveOrUpdate(oaFixedassetsCleanup);
        //获取维修单id
        int id = oaFixedassetsCleanup.getId();
        //保存业务明细表数据
        List<Integer> list = oaFixedassetsCleanupParam.getIds();

        for (Integer temp:list){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //
            oaFixedassetsBizDetail.setBizType(5);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp);
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
        //修改资产状态(根据资产id)
        for (Integer temp:list){
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(temp);
            //领用中
            oaFixedassets.setStatus(4);
            oaFixedassetsService.updateById(oaFixedassets);
        }
        //保存附件
       List<CleanUpAttachmentParam> paramList = oaFixedassetsCleanupParam.getList();
        for(CleanUpAttachmentParam temp :paramList){
            CommonFiles commonFiles = new CommonFiles();
            commonFiles.setFileName(temp.getFileName());
            commonFiles.setFileUrl(temp.getFileUrl());
            commonFiles.setRelationType("cleanupAttachment");
            commonFiles.setRelationId(id);
            commonFiles.setCreateBy(authUser.getName());
            commonFilesService.save(commonFiles);
        }

        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllCleanUp/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产清理信息")
    public Result getAllCleanUp(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody CleanUpParam cleanUpParam) {
        Page<OaFixedassetsCleanup> page = new Page<OaFixedassetsCleanup>(pageNum,pageSize);
        IPage<OaFixedassetsCleanup> iPage = oaFixedassetsCleanupService.selectCleanupPage(page, cleanUpParam);
        return Result.returnOk(iPage);
    }

    /**
     * 删除功能
     */
    @GetMapping("/deleteCleanup/{id}")
    @SystemLog(description = "删除固定资产清理信息")
    public Result deleteCleanup(@PathVariable("id") int id){
        oaFixedassetsCleanupService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 查看详情
     */
    @GetMapping("/getCleanupById/{id}")
    @SystemLog(description = "固定资产清理信息详情")
    public Result getCleanupById(@PathVariable("id") int id){
        Map map = new HashMap<>();
        OaFixedassetsCleanup oaFixedassetsCleanup = oaFixedassetsCleanupService.getById(id);
        map.put("cleanupInfo",oaFixedassetsCleanup);
        //固定资产列表
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",5);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        //查询固定资产表
        Collection list1 = null;
        if (ids.size()>0){
            list1 = oaFixedassetsService.listByIds(ids);
        }
        map.put("list",list1);
        //查看附件
        QueryWrapper<CommonFiles> queryWrapperp = new QueryWrapper<CommonFiles>();
        queryWrapperp.eq("relation_type","cleanupAttachment");
        queryWrapperp.eq("relation_id",id);
        List<CommonFiles> attachments = commonFilesService.list(queryWrapperp);
        map.put("attachments",attachments);

        return Result.returnOk(map);
    }

    /**
     * 还原功能
     */
    @GetMapping("/reductionCleanup/{id}")
    @SystemLog(description = "固定资产清理信息还原")
    public Result reductionCleanup(@PathVariable("id") int id){
        //处理该清理单的资产
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",5);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        QueryWrapper<OaFixedassets> queryWrapper1 = new QueryWrapper<OaFixedassets>();
        queryWrapper1.in("id",ids);
        oaFixedassetsBizDetailService.remove(queryWrapper);
        OaFixedassets oaFixedassets = new OaFixedassets();
        oaFixedassets.setStatus(0);
        oaFixedassetsService.update(oaFixedassets,queryWrapper1);
        //还原后，记录删除
        oaFixedassetsCleanupService.removeById(id);
        return Result.returnOk("操作成功");
    }








}
