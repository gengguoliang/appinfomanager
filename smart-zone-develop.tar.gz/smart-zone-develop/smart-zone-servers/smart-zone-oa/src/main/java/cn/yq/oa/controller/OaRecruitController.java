package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaRecruit;
import cn.yq.oa.entity.OaTrain;
import cn.yq.oa.param.*;
import cn.yq.oa.service.IOaRecruitService;
import cn.yq.oa.vo.RecruitDetailVo;
import cn.yq.oa.vo.RecruitVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 招聘信息表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-26
 */
@RestController
@Api(value = "招聘管理", description = "招聘管理 API", position = 100, protocols = "http")
@RequestMapping("/oa-recruit")
@AllArgsConstructor
public class OaRecruitController {

    IOaRecruitService oaRecruitService;


    @ApiOperation(value = "App获取招聘信息", notes = "App获取招聘信息")
    @PostMapping("/listRecruitApp")
    @SystemLog(description = "App人才招聘信息")
    public Result<List<RecruitVo>> listRecruitApp(@RequestBody RecruitSearchAppParam param) {
        List<RecruitVo> recruitVos = oaRecruitService.listRecruitApp(param);
        return Result.returnOk(recruitVos);
    }


    @ApiOperation(value = "查看招聘信息", notes = "查看招聘信息")
    @GetMapping("/viewRecruitApp/{id}")
    @SystemLog(description = "App人才招聘信息详情")
    public Result<RecruitDetailVo> viewRecruitApp(@PathVariable("id") Integer id) {
        RecruitDetailVo vo = oaRecruitService.viewRecruit(id);
        return Result.returnOk(vo);
    }


}
