package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.FinancingAuditingVO;
import cn.yq.oa.vo.FinancingtOffloadVO;
import cn.yq.oa.vo.OaFinancingInfoVo;
import cn.yq.oa.vo.OrganizationVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 融资项目信息管理 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-02
 */
@RestController
@RequestMapping("/oa-financing-info")
@Api(value = "融资项目管理", description = "ggl融资项目管理 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaFinancingInfoController {

    private IOaFinancingInfoService oaFinancingInfoService;

    private ICommonFilesService commonFilesService;

    private IAuthOrganizationService authOrganizationService;

    private IOaFinancingAuditingService oaFinancingAuditingService;

    private IOaFinancingtOffloadService oaFinancingtOffloadService;

    @ApiOperation(value = "创建项目/编辑项目（创建id传0编辑传实际的值）", notes = "创建项目/编辑项目")
    @PostMapping(value = "/addProject", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加项目信息")
    public Result addProject(@ApiIgnore AuthUser authUser,@RequestBody OaFinancingParam param) {
        if(null != param){
            OaFinancingInfo oaFinancingInfo = new OaFinancingInfo();
            CopyUtils.copyProperties(param,oaFinancingInfo);
            if(param.getId() != 0){//编辑
                oaFinancingInfoService.updateById(oaFinancingInfo);
                //获取当前融资项目下的计划书
                QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("is_del",0);
                queryWrapper.eq("relation_id",oaFinancingInfo.getId());
                queryWrapper.eq("relation_type","financing_plan");
                List<CommonFiles> list = commonFilesService.list(queryWrapper);
                //删除
                for (CommonFiles commonFiles : list){
                    commonFilesService.removeById(commonFiles.getId());
                }
                //添加计划书
                for(CleanUpAttachmentParam cleanParam : param.getPlanbook()){
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(cleanParam,commonFiles);
                    commonFiles.setRelationId(oaFinancingInfo.getId());
                    commonFiles.setRelationType("financing_plan");
                    commonFilesService.save(commonFiles);
                }
            }else{//新增
                oaFinancingInfo.setOrgid(authUser.getOrganizationId());
                oaFinancingInfo.setStatus(1);
                oaFinancingInfoService.save(oaFinancingInfo);
                //添加计划书
                for(CleanUpAttachmentParam cleanParam : param.getPlanbook()){
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(cleanParam,commonFiles);
                    commonFiles.setRelationId(oaFinancingInfo.getId());
                    commonFiles.setRelationType("financing_plan");
                    commonFilesService.save(commonFiles);
                }
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "关联当前用户的企业信息", notes = "关联当前用户的企业信息")
    @GetMapping("/getOrganization")
    @LoginUser
    public Result<OrganizationVO> getOrganization(@ApiIgnore AuthUser authUser){
        AuthOrganization authOrganization = authOrganizationService.getById(authUser.getOrganizationId());
        OrganizationVO organizationVO = new OrganizationVO();
        if(null != authOrganization){
            CopyUtils.copyProperties(authOrganization,organizationVO);
        }
        return Result.returnOk(organizationVO);
    }

    @ApiOperation(value = "分页获取融资项目管理列表", notes = "分页获取融资项目管理列表")
    @PostMapping("/listFinancing/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页获取融资项目管理列表")
    public Result<IPage<OaFinancingInfoVo>> listFinancing(@ApiIgnore AuthUser authUser,
                                                          @PathVariable("pageNum") int pageNum,
                                                          @PathVariable("pageSize") int pageSize,
                                                          @RequestBody FinancingSearchParam param){
        Page<OaFinancingInfoVo> page = new Page<OaFinancingInfoVo>(pageNum, pageSize);
        IPage<OaFinancingInfoVo> iPage = page.setRecords(oaFinancingInfoService.selectlistFinancing(page,param,authUser.getOrganizationId()));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "查看融资项目信息", notes = "查看融资项目信息")
    @GetMapping("/viewFinancing/{id}")
    @SystemLog(description = "查看融资项目信息")
    public Result<OaFinancingInfoVo> viewFinancing(@PathVariable("id") Integer id){
        OaFinancingInfoVo oaFinancingInfoVo = oaFinancingInfoService.viewFinancing(id);
        //获取当前融资项目下的计划书
        QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("relation_id",id);
        queryWrapper.eq("relation_type","financing_plan");
        List<CommonFiles> list = commonFilesService.list(queryWrapper);
        List<CleanUpAttachmentParam> list1 = new ArrayList<CleanUpAttachmentParam>();
        for(CommonFiles commonFiles : list){
            CleanUpAttachmentParam cleanUpAttachmentParam = new CleanUpAttachmentParam();
            CopyUtils.copyProperties(commonFiles,cleanUpAttachmentParam);
            list1.add(cleanUpAttachmentParam);
        }
        if(null != list1 && list1.size()>0){
            oaFinancingInfoVo.setPlanbook(list1);
        }
        //获取当前融资下的审核信息
        QueryWrapper<OaFinancingAuditing> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("is_del",0);
        queryWrapper1.eq("financingId",id);
        OaFinancingAuditing oaFinancingAuditing = oaFinancingAuditingService.getOne(queryWrapper1);
        if(null != oaFinancingAuditing){
            FinancingAuditingVO financingAuditingVO = new FinancingAuditingVO();
            CopyUtils.copyProperties(oaFinancingAuditing,financingAuditingVO);
            oaFinancingInfoVo.setFinancingAuditingVO(financingAuditingVO);
        }
        //获取当前融资下的下架信息
        QueryWrapper<OaFinancingtOffload> queryWrapper2 = new QueryWrapper<>();
        queryWrapper2.eq("is_del",0);
        queryWrapper2.eq("financingId",id);
        OaFinancingtOffload oaFinancingtOffload = oaFinancingtOffloadService.getOne(queryWrapper2);
        if(null != oaFinancingtOffload){
            FinancingtOffloadVO financingtOffloadVO = new FinancingtOffloadVO();
            CopyUtils.copyProperties(oaFinancingtOffload,financingtOffloadVO);
            oaFinancingInfoVo.setFinancingtOffloadVO(financingtOffloadVO);
        }
        return Result.returnOk(oaFinancingInfoVo);
    }

    @ApiOperation(value = "删除融资项目信息", notes = "删除融资项目信息")
    @GetMapping("/deleteFinancing/{id}")
    @SystemLog(description = "删除融资项目信息")
    public Result deleteFinancing(@PathVariable("id") Integer id){
        oaFinancingInfoService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "通用修改状态(传之后的状态，原因没有传空即可)", notes = "修改状态")
    @PostMapping("/changeStatus")
    @LoginUser
    @SystemLog(description = "融资项目信息状态变更")
    public Result changeStatus(@ApiIgnore AuthUser authUser,@RequestBody FinancingChangeParam financingChangeParam){
        if(null != financingChangeParam){
            OaFinancingInfo oaFinancingInfo = new OaFinancingInfo();
            CopyUtils.copyProperties(financingChangeParam,oaFinancingInfo);
            switch (financingChangeParam.getStatus()){
                //未审核
                case 1:
                    oaFinancingInfoService.updateById(oaFinancingInfo);
                    break;
                //待审核/审核中
                case 2:
                    oaFinancingInfoService.updateById(oaFinancingInfo);
                    break;
                //已发布
                case 3:
                    oaFinancingInfo.setPublishTime(new Date());
                    oaFinancingInfo.setPublisher(authUser.getName());
                    oaFinancingInfoService.updateById(oaFinancingInfo);
                    //审核通过之后维护审核信息表
                    OaFinancingAuditing oaFinancingAuditing = new OaFinancingAuditing();
                    oaFinancingAuditing.setFinancingId(financingChangeParam.getId());
                    oaFinancingAuditing.setAuditTime(new Date());
                    oaFinancingAuditing.setResult(1);
                    oaFinancingAuditing.setAuditUsername(authUser.getName());
                    oaFinancingAuditingService.save(oaFinancingAuditing);
                    break;
                //已下架
                case 4:
                    oaFinancingInfoService.updateById(oaFinancingInfo);
                    //删除下架信息
                    QueryWrapper<OaFinancingtOffload> wrapper = new QueryWrapper<OaFinancingtOffload>();
                    wrapper.eq("financingId",financingChangeParam.getId());
                    oaFinancingtOffloadService.remove(wrapper);
                    //维护下架信息表
                    OaFinancingtOffload oaFinancingtOffload = new OaFinancingtOffload();
                    oaFinancingtOffload.setFinancingId(financingChangeParam.getId());
                    oaFinancingtOffload.setOfflloadTime(new Date());
                    oaFinancingtOffload.setReason(financingChangeParam.getRemark());
                    oaFinancingtOffload.setOffloadUsername(authUser.getName());
                    oaFinancingtOffloadService.save(oaFinancingtOffload);
                    break;
                //已拒绝
                case 5:
                    oaFinancingInfoService.updateById(oaFinancingInfo);
                    //审核拒绝之后维护审核信息表
                    OaFinancingAuditing oaFinancingAuditing1 = new OaFinancingAuditing();
                    oaFinancingAuditing1.setFinancingId(financingChangeParam.getId());
                    oaFinancingAuditing1.setAuditTime(new Date());
                    oaFinancingAuditing1.setResult(2);
                    oaFinancingAuditing1.setReason(financingChangeParam.getReason());
                    oaFinancingAuditing1.setAuditUsername(authUser.getName());
                    oaFinancingAuditingService.save(oaFinancingAuditing1);
                    break;
                default:
                    break;
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取融资项目审核列表", notes = "分页获取融资项目审核列表")
    @PostMapping("/listFinancingAuditing/{pageNum}/{pageSize}")
    @SystemLog(description = "分页获取融资项目审核列表")
    public Result<IPage<OaFinancingInfoVo>> listFinancingAuditing(@PathVariable("pageNum") int pageNum,
                                                                  @PathVariable("pageSize") int pageSize,
                                                                  @RequestBody FinancingSearchParam param){
        Page<OaFinancingInfoVo> page = new Page<OaFinancingInfoVo>(pageNum, pageSize);
        IPage<OaFinancingInfoVo> iPage = page.setRecords(oaFinancingInfoService.selectlistFinancingAuditing(page,param));
        return Result.returnOk(iPage);
    }




























	
}
