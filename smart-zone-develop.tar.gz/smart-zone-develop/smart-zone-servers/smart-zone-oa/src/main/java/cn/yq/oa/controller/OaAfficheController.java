package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.CommonFiles;
import cn.yq.oa.entity.OaAffiche;
import cn.yq.oa.entity.OaAfficheBuiilding;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.param.AfficheSearchParam;
import cn.yq.oa.param.CleanUpAttachmentParam;
import cn.yq.oa.param.LiveSearchParam;
import cn.yq.oa.param.OaAfficheParam;
import cn.yq.oa.service.ICommonFilesService;
import cn.yq.oa.service.IOaAfficheBuiildingService;
import cn.yq.oa.service.IOaAfficheService;
import cn.yq.oa.service.ISysDictDataService;
import cn.yq.oa.vo.AfficheAPPVO;
import cn.yq.oa.vo.AfficheVO;
import cn.yq.oa.vo.BuildingInfo;
import cn.yq.oa.vo.LivePageInfoVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qiniu.util.Auth;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.java.Log;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 公告信息表 前端控制器
 * </p>
 *
 * @author ggl
 * @since 2019-04-12
 */
@RestController
@RequestMapping("/oa-affiche")
@AllArgsConstructor
@Api(value = "公告信息管理", description = "ggl公告信息管理 API", position = 100, protocols = "http")
public class OaAfficheController {

	private IOaAfficheBuiildingService oaAfficheBuiildingService;

	private IOaAfficheService oaAfficheService;

	private ISysDictDataService sysDictDataService;

	private ICommonFilesService commonFilesService;

    @ApiOperation(value = "添加（id传0）/编辑（id传实际得值）公信息", notes = "添加/编辑公告信息")
    @PostMapping("/addOaAffiche")
    @LoginUser
    @SystemLog(description = "添加公告信息")
	public Result addOaAffiche(@ApiIgnore AuthUser authUser, @RequestBody OaAfficheParam param){
        if(null != param){
            OaAffiche oaAffiche = new OaAffiche();
            CopyUtils.copyProperties(param,oaAffiche);
            if(param.getId() != 0){
                oaAffiche.setUpdateBy(authUser.getName());
                oaAfficheService.updateById(oaAffiche);
                //删除当前公告下的发布范围
                QueryWrapper<OaAfficheBuiilding> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("is_del",0);
                queryWrapper.eq("affiche_id",oaAffiche.getId());
                oaAfficheBuiildingService.remove(queryWrapper);
                if(oaAffiche.getPublishRange() == 1){//发布范围是指定楼宇时
                    //维护发布范围
                    for(Integer id : param.getBuildingIds()){
                        OaAfficheBuiilding oaAfficheBuiilding = new OaAfficheBuiilding();
                        oaAfficheBuiilding.setAfficheId(oaAffiche.getId());
                        oaAfficheBuiilding.setBuildingId(id);
                        oaAfficheBuiildingService.save(oaAfficheBuiilding);
                    }
                }
                //删除之前得图片
                QueryWrapper<CommonFiles> wrapper = new QueryWrapper<>();
                wrapper.eq("is_del",0);
                wrapper.eq("relation_id",oaAffiche.getId());
                wrapper.eq("relation_type","notice_img");
                commonFilesService.remove(wrapper);
            }else{
                oaAffiche.setCreateBy(authUser.getName());
                oaAffiche.setStatus(1);
                oaAfficheService.save(oaAffiche);
                if(oaAffiche.getPublishRange() == 1){//发布范围是指定楼宇时
                    //维护发布范围
                    for(Integer id : param.getBuildingIds()){
                        OaAfficheBuiilding oaAfficheBuiilding = new OaAfficheBuiilding();
                        oaAfficheBuiilding.setAfficheId(oaAffiche.getId());
                        oaAfficheBuiilding.setBuildingId(id);
                        oaAfficheBuiildingService.save(oaAfficheBuiilding);
                    }
                }
            }
            //添加公告图片
            for(CleanUpAttachmentParam clean : param.getList()){
                CommonFiles commonFiles = new CommonFiles();
                CopyUtils.copyProperties(clean,commonFiles);
                commonFiles.setRelationId(oaAffiche.getId());
                commonFiles.setRelationType("notice_img");
                commonFilesService.save(commonFiles);
            }
        }
	    return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取公告类型(取dictValue和dictLabel)", notes = "获取公告类型")
    @GetMapping("/getOaAfficheCategory")
    @SystemLog(description = "获取公告类型")
    public Result getOaAfficheCategory(){
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("dict_type","affiche_category");
        List<SysDictData> list = sysDictDataService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "获取所有楼宇信息（即发布范围）", notes = "获取所有楼宇信息")
    @GetMapping("/getAllBuildingInfo")
    @SystemLog(description = "获取所有楼宇信息")
    public Result<List<BuildingInfo>> getAllBuildingInfo(){
        List<BuildingInfo> list = oaAfficheService.selectBuildingInfo();
        return Result.returnOk(list);
    }

    @ApiOperation(value = "分页获取公告信息", notes = "分页获取公告信息")
    @PostMapping("/listAffiche/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页查询公告信息")
    public Result<IPage<AfficheVO>> listAffiche(@ApiIgnore AuthUser authUser,
                                                  @PathVariable("pageNum") int pageNum,
                                                  @PathVariable("pageSize") int pageSize,
                                                  @RequestBody AfficheSearchParam param){
        Page<AfficheVO> page = new Page<AfficheVO>(pageNum,pageSize);
        IPage<AfficheVO> iPage = page.setRecords(oaAfficheService.listAffiche(page,param));
        for (AfficheVO afficheVO : iPage.getRecords()){
            List<BuildingInfo> list = oaAfficheService.selectpublishRange(afficheVO.getId());
            afficheVO.setList(list);
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "公告信息详情", notes = "公告信息详情")
    @GetMapping("/viewAfficheInfo/{id}")
    @SystemLog(description = "公告信息详情")
    public Result<AfficheVO> viewAfficheInfo(@PathVariable("id")Integer id){
        AfficheVO afficheVO = oaAfficheService.viewAfficheInfo(id);
        List<BuildingInfo> list = oaAfficheService.selectpublishRange(afficheVO.getId());
        afficheVO.setList(list);
        //获取图片
        QueryWrapper<CommonFiles> wrapper = new QueryWrapper<>();
        wrapper.eq("is_del",0);
        wrapper.eq("relation_id",afficheVO.getId());
        wrapper.eq("relation_type","notice_img");
        List<CommonFiles> listImg = commonFilesService.list(wrapper);
        List<CleanUpAttachmentParam> list1 = new ArrayList<>();
        for(CommonFiles commonFiles : listImg){
            CleanUpAttachmentParam cleanUpAttachmentParam = new CleanUpAttachmentParam();
            CopyUtils.copyProperties(commonFiles,cleanUpAttachmentParam);
            list1.add(cleanUpAttachmentParam);
        }
        afficheVO.setListImg(list1);
        return Result.returnOk(afficheVO);
    }

    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/removeAffiche/{id}")
    @SystemLog(description = "删除公告信息")
    public Result removeAffiche(@PathVariable("id")Integer id){
        oaAfficheService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "撤回（传1）/发布(传2)", notes = "撤回（传1）/发布(传2)")
    @GetMapping("/updateAffiche/{id}/{status}")
    @LoginUser
    @SystemLog(description = "公告信息状态变更")
    public Result updateAffiche(@ApiIgnore AuthUser authUser,@PathVariable("id")Integer id,@PathVariable("status")Integer status){
        OaAffiche oaAffiche = new OaAffiche();
        oaAffiche.setId(id);
        oaAffiche.setStatus(status);
        if(status == 2){
            oaAffiche.setPublishTime(new Date());
            oaAffiche.setPublishUserId(authUser.getId());
        }
        oaAfficheService.updateById(oaAffiche);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "APP公告列表", notes = "APP公告列表")
    @GetMapping("/listAPPAfficheInfo")
    @LoginUser
    @SystemLog(description = "app端查询公告信息列表")
    public Result<List<AfficheAPPVO>> listAPPAfficheInfo(@ApiIgnore AuthUser authUser){
        List<AfficheAPPVO> list = oaAfficheService.listAPPAfficheInfo(authUser.getOrganizationId());
        return Result.returnOk(list);
    }

    @ApiOperation(value = "游客登陆公告列表", notes = "游客登录公告列表")
    @GetMapping("/listAPPAfficheNotUser")
    public Result<List<AfficheAPPVO>> listAPPAfficheUserInfo(){
        List<AfficheAPPVO> list = oaAfficheService.listAPPAffiche();
        return Result.returnOk(list);
    }
}
