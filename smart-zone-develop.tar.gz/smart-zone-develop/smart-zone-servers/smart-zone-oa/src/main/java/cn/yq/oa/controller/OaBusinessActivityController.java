package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.constant.LogTableConstant;
import cn.yq.common.result.Result;
import cn.yq.oa.dto.ActivitySeachDTO;
import cn.yq.oa.entity.OaBusinessActivity;
import cn.yq.oa.entity.OaBusinessCooperative;
import cn.yq.oa.param.BusinessSearchParam;
import cn.yq.oa.param.OaActivityParam;
import cn.yq.oa.param.OaBusinessParam;
import cn.yq.oa.service.IOaBusinessActivityService;
import cn.yq.oa.service.IOaBusinessCooperativeService;
import cn.yq.oa.vo.oabusiness.ActivityAPPInfoVO;
import cn.yq.oa.vo.oabusiness.CooperativeVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import java.util.Date;
import java.util.List;

/**
 * <p>
 * 商家活动表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-03-31
 */
@RestController
@RequestMapping("/oa-business-activity")
@Slf4j
@Api(value = "zhengjh合作商家管理PC端", description = "zhengjh合作商家管理PC端")
public class OaBusinessActivityController {

    @Autowired
    private IOaBusinessActivityService oaBusinessActivityService;
    @Autowired
    private IOaBusinessCooperativeService oaBusinessCooperativeService;

    @ApiOperation(value = "商家信息置顶isTop 0:不置顶 1：置顶", notes = "商家信息置顶isTop 0:不置顶 1：置顶")
    @GetMapping(value = "/topBusiness/{id}/{isTop}")
    @SystemLog(description = "商家信息置顶",table = LogTableConstant.OA_BUSINESS_COOPERATIVE)
    public Result topBusiness(@PathVariable("id")Integer id,@PathVariable("isTop") Integer isTop) {
        OaBusinessCooperative cooperative = new OaBusinessCooperative();
        cooperative.setId(id);
        if(isTop==1){
            cooperative.setTopTime(new Date().getTime());
        }else {
            cooperative.setTopTime(new Long(0));
        }
        oaBusinessCooperativeService.updateById(cooperative);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "优惠活动置顶isTop 0:不置顶 1：置顶", notes = "优惠活动置顶isTop 0:不置顶 1：置顶")
    @GetMapping(value = "/topActivity/{id}/{isTop}")
    @SystemLog(description = "优惠活动置顶",table = LogTableConstant.OA_BUSINESS_ACTIVITY)
    public Result topActivity(@PathVariable("id")Integer id,@PathVariable("isTop") Integer isTop) {
        OaBusinessActivity activity = new OaBusinessActivity();
        activity.setId(id);
        if(isTop==1){
            activity.setTopTime(new Date().getTime());
        }else {
            activity.setTopTime(new Long(0));
        }
        oaBusinessActivityService.updateById(activity);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "根据商家名称模糊查询商家", notes = "根据商家名称模糊查询商家")
    @GetMapping(value = "/getBusinessByName")
    @SystemLog(description = "根据商家名称模糊查询商家",table = LogTableConstant.OA_BUSINESS_COOPERATIVE)
    public Result getBusinessByName(@RequestParam("name")String name) {
        QueryWrapper<OaBusinessCooperative> queryWrapper=new QueryWrapper<>();
        queryWrapper.like("shops_name","%"+name+"%")
                .eq("is_del",0);
        List<OaBusinessCooperative> list = oaBusinessCooperativeService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "分页获取优惠活动", notes = "分页获取优惠活动")
    @PostMapping("/listActivity/{pageNum}/{pageSize}")
    @SystemLog(description = "分页获取优惠活动")
    public Result<IPage<ActivityAPPInfoVO>> listActivity(@PathVariable("pageNum") int pageNum,
                               @PathVariable("pageSize") int pageSize,
                               @RequestBody ActivitySeachDTO dto) {
        Page<ActivityAPPInfoVO> page = new Page<>(pageNum, pageSize);
        IPage<ActivityAPPInfoVO> iPage = page.setRecords(oaBusinessActivityService.listActivity(page, dto));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "添加和编辑商户信息", notes = "添加和编辑商户信息")
    @PostMapping(value = "/addBusinessInfo", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @SystemLog(description = "添加和编辑商户信息",table = LogTableConstant.OA_BUSINESS_ACTIVITY)
    public Result addBusinessInfo(@RequestBody OaBusinessParam param) {
        oaBusinessActivityService.addBusinessInfo(param);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "分页获取商家信息", notes = "分页获取商家信息")
    @PostMapping("/listBusiness/{pageNum}/{pageSize}")
    @SystemLog(description = "分页获取商家信息")
    public Result listBusiness(@PathVariable("pageNum") int pageNum,
                               @PathVariable("pageSize") int pageSize,
                               @RequestBody BusinessSearchParam param) {
        Page<CooperativeVO> page = new Page<>(pageNum, pageSize);
        IPage<CooperativeVO> iPage = page.setRecords(oaBusinessActivityService.listBusiness(page, param));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "删除商户信息", notes = "删除商户信息")
    @GetMapping("/deleteBusiness/{id}")
    @SystemLog(description = "删除商户信息",table = LogTableConstant.OA_BUSINESS_ACTIVITY)
    public Result deleteBusiness(@PathVariable("id") Integer id) {
        oaBusinessActivityService.deleteBusiness(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "添加优惠信息", notes = "添加优惠信息")
    @PostMapping(value = "/addActivityInfo")
    @SystemLog(description = "添加优惠信息",table = LogTableConstant.OA_BUSINESS_ACTIVITY)
    public Result addActivityInfo(@RequestBody OaActivityParam param) {
        oaBusinessActivityService.addActivityInfo(param);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "PC修改状态", notes = "PC修改状态")
    @GetMapping(value = "/changeStatus/{id}/{status}")
    @SystemLog(description = "合作商家信息状态变更")
    public Result changeStatus(@PathVariable("id") Integer id, @PathVariable("status") Integer status) {
        //状态 0:未发布 1：已发布 2：已下架
        OaBusinessCooperative cooperative = new OaBusinessCooperative();
        cooperative.setId(id);
        cooperative.setStatus(status);
        if (status == 1) {
            cooperative.setPublishTime(new Date());
            OaBusinessCooperative cooperative1 = oaBusinessCooperativeService.getById(id);
            if(cooperative1.getStatus()==2){
                cooperative.setCreateTime(new Date());
            }
        }
        oaBusinessCooperativeService.updateById(cooperative);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "PC编辑优惠", notes = "PC编辑优惠")
    @PostMapping(value = "/editActivity")
    @SystemLog(description = "编辑优惠活动",table = LogTableConstant.OA_BUSINESS_ACTIVITY)
    public Result editActivity(@RequestBody OaActivityParam oaActivityParam) {
        OaBusinessActivity activity = new OaBusinessActivity();
        BeanUtils.copyProperties(oaActivityParam, activity);
        String activityImg = activity.getActivityImg();
        if (StringUtils.endsWith(activityImg, ",")) {
            String substring = StringUtils.substring(activityImg, 0, activityImg.length() - 1);
            activity.setActivityImg(substring);
        }
        oaBusinessActivityService.updateById(activity);
        return Result.returnOk();
    }

    @ApiOperation(value = "PC删除优惠", notes = "PC删除优惠")
    @GetMapping(value = "/removeActivity/{id}")
    @SystemLog(description = "删除优惠活动",table = LogTableConstant.OA_BUSINESS_ACTIVITY)
    public Result removeActivity(@PathVariable("id") Integer id) {
        oaBusinessActivityService.removeById(id);
        return Result.returnOk();
    }


}
