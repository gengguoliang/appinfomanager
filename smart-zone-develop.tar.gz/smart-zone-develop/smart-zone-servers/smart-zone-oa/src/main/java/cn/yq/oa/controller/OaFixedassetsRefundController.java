package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.PrimaryGenerater;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaFixedassets;
import cn.yq.oa.entity.OaFixedassetsBizDetail;
import cn.yq.oa.entity.OaFixedassetsReception;
import cn.yq.oa.entity.OaFixedassetsRefund;
import cn.yq.oa.param.OaFixedassetsReceptionParam;
import cn.yq.oa.param.OaFixedassetsRefundParam;
import cn.yq.oa.param.ReceptionSearchParam;
import cn.yq.oa.param.RefundSearchParam;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsRefundService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.impl.OrderNumberServiceImpl;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 固定资产退库表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-01
 */
@RestController
@RequestMapping("/oa-fixedassets-refund")
@AllArgsConstructor
public class OaFixedassetsRefundController {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    private IOaFixedassetsRefundService oaFixedassetsRefundService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsService oaFixedassetsService;

    @Resource(name = "orderNumberServiceImpl")
    OrderNumberServiceImpl orderNumberService;

    @GetMapping("/getCurrentUser")
    @LoginUser
    public Result getCurrentUser(AuthUser authUser){
        String name = authUser.getName();
        return  Result.returnOk(name);
    }

    @PostMapping("/addRefund")
    @LoginUser
    @SystemLog(description = "添加固定资产退库信息")
    public Result addRefund(AuthUser authUser,@RequestBody OaFixedassetsRefundParam oaFixedassetsRefundParam){

        OaFixedassetsRefund oaFixedassetsRefund = new OaFixedassetsRefund();
        BeanUtils.copyProperties(oaFixedassetsRefundParam,oaFixedassetsRefund);
        oaFixedassetsRefund.setCreateBy(authUser.getName());
        //退库单号
//        String dh = "TKD" + PrimaryGenerater.geneterNextNumber(sdf.format(new Date()));
        String dh = orderNumberService.getOneOrderNumber("TKD");
        oaFixedassetsRefund.setNo(dh);
       //保存退库表数据
        oaFixedassetsRefundService.saveOrUpdate(oaFixedassetsRefund);
        //获取退库单id
        int id = oaFixedassetsRefund.getId();
        //保存业务明细表数据
        List<Integer> list = oaFixedassetsRefundParam.getIds();

        for (Integer temp:list){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //退库
            oaFixedassetsBizDetail.setBizType(1);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp);
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
        //修改资产状态(根据资产id)
        for (Integer temp:list){
            OaFixedassets oaFixedassets = new OaFixedassets();
            oaFixedassets.setId(temp);
            //闲置
            oaFixedassets.setStatus(0);
            oaFixedassetsService.updateById(oaFixedassets);
        }
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllRefunds/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产退库信息")
    public Result getAllRefunds(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody RefundSearchParam refundSearchParam){

        Page<OaFixedassetsRefund> page= new Page<OaFixedassetsRefund>(pageNum,pageSize);
        IPage<OaFixedassetsRefund> list = oaFixedassetsRefundService.selectRefundsPage(page,refundSearchParam);
        return Result.returnOk(list);
    }

    /**
     * 导出功能
     */
    @PostMapping("/getRefunds")
    @SystemLog(description = "固定资产退库信息导出")
    public Result getRefunds( @RequestBody RefundSearchParam refundSearchParam){
        List<OaFixedassetsRefund> refunds = oaFixedassetsRefundService.selectRefunds(refundSearchParam);
        return Result.returnOk(refunds);
    }


    /**
     * 删除功能
     */
    @GetMapping("/deleteRefunds/{id}")
    @SystemLog(description = "删除固定资产退库信息")
    public Result deleteRefunds(@PathVariable("id") int id){
        oaFixedassetsRefundService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 导出Excel
     */
    @PostMapping("/exportExcel")
    @SystemLog(description = "固定资产退库信息导出Excel")
    public Result exportExcel( @RequestBody RefundSearchParam refundSearchParam){
        List list = oaFixedassetsRefundService.exportExcel(refundSearchParam);
        return Result.returnOk(list);
    }


    /**
     * 查看详情
     */
    @GetMapping("/getRefundById/{id}")
    @SystemLog(description = "固定资产退库信息详情")
    public Result getRefundById(@PathVariable("id") int id){
        Map map = new HashMap<>();
        OaFixedassetsRefund refund = oaFixedassetsRefundService.getById(id);
        map.put("refundInfo",refund);
        //固定资产列表
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",1);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        //查询固定资产表
        Collection list1 = null;
        if (ids.size()>0){
            list1 = oaFixedassetsService.listByIds(ids);
        }
        map.put("list",list1);
        return Result.returnOk(map);
    }

}
