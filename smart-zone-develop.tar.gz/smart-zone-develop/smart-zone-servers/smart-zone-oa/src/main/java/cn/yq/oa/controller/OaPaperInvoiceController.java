package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.QnyUtil;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.electronicinvoice.ResponseData;
import cn.yq.oa.dto.invoice.InvoiceDTO;
import cn.yq.oa.dto.invoice.PaperInvoiceDTO;
import cn.yq.oa.dto.invoice.SeachInvoiceDTO;
import cn.yq.oa.entity.OaInvoiceInfo;
import cn.yq.oa.entity.OaOnlineInvoice;
import cn.yq.oa.entity.OaPaperInvoiceReceive;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.service.IOaInvoiceInfoService;
import cn.yq.oa.service.IOaOnlineInvoiceService;
import cn.yq.oa.service.IOaPaperInvoiceService;
import cn.yq.oa.service.ISysDictDataService;
import cn.yq.oa.service.impl.SampleMailService;
import cn.yq.oa.vo.invoice.BillHistoryVO;
import cn.yq.oa.vo.invoice.BillInvoiceVO;
import cn.yq.oa.vo.invoice.InvoiceInfoVO;
import cn.yq.oa.vo.invoice.OaOnlineInvoiceVO;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

/**
 * <p>
 * 账单纸质发票表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-05-23
 */
@RestController
@RequestMapping("/oa-paper-invoice")
@Api(value = "zjh发票模块", description = "zjh发票模块")
@Slf4j
public class OaPaperInvoiceController {

    @Autowired
    private IOaPaperInvoiceService oaPaperInvoiceService;
    @Autowired
    private ISysDictDataService sysDictDataService;
    @Autowired
    private IOaInvoiceInfoService oaInvoiceInfoService;
    @Autowired
    private IOaOnlineInvoiceService oaOnlineInvoiceService;
    @Autowired
    private SampleMailService sampleMailService;


    /**
     * @Description APP发票列表
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "APP发票列表", notes = "APP发票列表")
    @GetMapping(value = "/invoiceBill/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "APP发票列表")
    public Result<IPage<BillInvoiceVO>> invoiceBill(@ApiIgnore AuthUser authUser,
                                                    @PathVariable("pageNum") Integer pageNum,
                                                    @PathVariable("pageSize") Integer pageSize) {
        Page<BillInvoiceVO> page = new Page<>(pageNum, pageSize);
        IPage<BillInvoiceVO> iPage = page.setRecords(oaPaperInvoiceService.invoiceBill(page, authUser));
        return Result.returnOk(iPage);
    }


    /**
     * @Description APP端发票申请
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "APP端发票申请", notes = "APP端发票申请")
    @PostMapping(value = "/addInvoice")
    @LoginUser
    @SystemLog(description = "APP端发票申请")
    public Result addInvoice(@ApiIgnore AuthUser authUser, @RequestBody InvoiceDTO invoiceDTO) {
        Result result = oaPaperInvoiceService.addInvoice(authUser, invoiceDTO);
        return result;
    }

    /**
     * @Description APP端添加申请时发票基本信息的展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "APP端添加申请时发票基本信息的展示", notes = "APP端添加申请时发票基本信息的展示")
    @GetMapping(value = "/addInvoiceShow")
    @LoginUser
    @SystemLog(description = "APP端添加申请时发票基本信息的展示")
    public Result<OaInvoiceInfo> addInvoiceShow(@ApiIgnore AuthUser authUser) {
        OaInvoiceInfo oaInvoiceInfo = oaPaperInvoiceService.addInvoiceShow(authUser);
        return Result.returnOk(oaInvoiceInfo);
    }

    /**
     * @Description APP开票历史
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "APP开票历史", notes = "APP开票历史")
    @GetMapping(value = "/invoiceHistory/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "APP开票历史")
    public Result<IPage<BillHistoryVO>> invoiceHistory(@ApiIgnore AuthUser authUser,
                                                       @PathVariable("pageNum") Integer pageNum,
                                                       @PathVariable("pageSize") Integer pageSize) {
        Page<BillHistoryVO> page = new Page<>(pageNum, pageSize);
        IPage<BillHistoryVO> iPage = page.setRecords(oaPaperInvoiceService.invoiceHistory(page, authUser));
        return Result.returnOk(iPage);
    }


    /**
     * @Description APP详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "APP详情", notes = "APP详情")
    @GetMapping(value = "/invoiceDeatil/{ooiId}")
    @SystemLog(description = "APP详情")
    public Result<InvoiceInfoVO> invoiceDeatil(@PathVariable("ooiId") Integer ooiId) {
        InvoiceInfoVO invoiceInfoVO = oaPaperInvoiceService.invoiceDeatil(ooiId);
        return Result.returnOk(invoiceInfoVO);
    }

    /**
     * @Description PC字纸发票列表
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC字纸发票列表", notes = "PC字纸发票列表")
    @PostMapping(value = "/paperInvoice/{pageNum}/{pageSize}")
    @SystemLog(description = "纸质发票列表")
    public Result<IPage<OaOnlineInvoiceVO>> paperInvoice(@PathVariable("pageNum") Integer pageNum,
                                                         @PathVariable("pageSize") Integer pageSize,
                                                         @RequestBody SeachInvoiceDTO dto) {
        Page<OaOnlineInvoiceVO> page = new Page<>(pageNum, pageSize);
        IPage<OaOnlineInvoiceVO> iPage = page.setRecords(oaPaperInvoiceService.paperInvoice(page, dto));
        return Result.returnOk(iPage);
    }

    /**
     * @Description PC字纸发票登记
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC字纸发票登记", notes = "PC字纸发票登记")
    @PostMapping(value = "/paperRegister")
    @LoginUser
    @SystemLog(description = "纸质发票列表")
    public Result paperRegister(@ApiIgnore AuthUser authUser, @RequestBody PaperInvoiceDTO dto) {
        oaPaperInvoiceService.paperRegister(authUser, dto);
        return Result.returnOk();
    }

    /**
     * @Description PC发票领用
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC发票领用", notes = "PC发票领用")
    @PostMapping(value = "/paperUse")
    @SystemLog(description = "发票领用")
    public Result paperUse(@RequestBody OaPaperInvoiceReceive receive) {
        oaPaperInvoiceService.paperUse(receive);
        return Result.returnOk();
    }

    /**
     * @Description PC发票申请和发票信息和发票领用信息
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC发票申请和发票信息和发票领用信息", notes = "PC发票申请和发票信息和发票领用信息")
    @GetMapping(value = "/infoShow/{id}")
    @SystemLog(description = "发票申请和发票信息和发票领用信息")
    public Result<Map<String, Object>> infoShow(@PathVariable("id") Integer id) {
        Map<String, Object> map = oaPaperInvoiceService.infoShow(id);
        return Result.returnOk(map);
    }

    /**
     * @Description PC查询分类
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC查询分类", notes = "PC查询分类")
    @GetMapping(value = "/getCatogery")
    public Result getCatogery() {
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dict_type", "oabill_category_id")
                .eq("is_del", 0);
        List<SysDictData> list = sysDictDataService.list(queryWrapper);
        return Result.returnOk(list);
    }

    /**
     * @Description PC查询盛元抬头信息
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC查询盛元抬头信息", notes = "PC查询盛元抬头信息")
    @GetMapping(value = "/getShengYuan/{id}")
    @SystemLog(description = "查询盛元抬头信息")
    public Result<Map<String, Object>> getShengYuan(@PathVariable("id") Integer id) {
        Map<String, Object> map = new HashMap<>();
        //盛元的信息
        QueryWrapper<OaInvoiceInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("org_type", "1")
                .eq("is_del", 0);
        OaInvoiceInfo oaInvoiceInfo = oaInvoiceInfoService.getOne(queryWrapper);
        map.put("shengYuan", oaInvoiceInfo);
        //客户的信息
        OaOnlineInvoice oaOnlineInvoice = oaOnlineInvoiceService.getById(id);
        OaInvoiceInfo oaInvoiceInfo1 = oaInvoiceInfoService.getById(oaOnlineInvoice.getInvoiceId());
        map.put("customer", oaInvoiceInfo1);
        return Result.returnOk(map);
    }


    /**
     * @Description 电子发票回调接口
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @PostMapping(value = "/invoice")
    public Result invoice(@RequestBody ResponseData responseData) {
        log.info("进入电子发票回调==================");
        log.info("电子发票回调请求参数：" + JSONObject.toJSONString(responseData));
        if (responseData == null) {
            return new Result(ResultEnum.FAIL.getCode(), "回调参数为空");
        }
        OaOnlineInvoice oaOnlineInvoice = new OaOnlineInvoice();
        if (responseData.getCode() != 0) {
            log.error("电子发票回调错误结果：" + responseData.getMessage());
            if (StringUtils.isNotBlank(responseData.getSerialNo())) {
                //开票失败的业务处理
                QueryWrapper<OaOnlineInvoice> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("bill_no", responseData.getSerialNo());
                oaOnlineInvoice.setStatus(3);//开票失败
                oaOnlineInvoiceService.update(oaOnlineInvoice, queryWrapper);
            }
            return new Result(ResultEnum.FAIL.getCode(), responseData.getMessage());
        }
        /**
         * 业务处理（注意幂等性）
         */
        //修改开票记录表
        String invoiceCode = StringUtils.substring(responseData.getInvoices()[0].getCode(), 0, 12);
        String invoiceNum = StringUtils.substring(responseData.getInvoices()[0].getCode(), 12);
        String pdfUnsignedUrl = responseData.getInvoices()[0].getPdfUnsignedUrl();
        oaOnlineInvoice.setInvoiceCode(invoiceCode);
        oaOnlineInvoice.setInvoiceNum(invoiceNum);
        oaOnlineInvoice.setInvoiceFile(pdfUnsignedUrl);
        oaOnlineInvoice.setInvoicePerson("盛元");
        //税率，税额
        oaOnlineInvoice.setTaxRate(new BigDecimal(responseData.getInvoices()[0].getItems().get(0).getTaxRate()));
        oaOnlineInvoice.setTaxAmount(new BigDecimal(responseData.getInvoices()[0].getItems().get(0).getTaxAmount()));
        oaOnlineInvoice.setStatus(2);//已开票

        QueryWrapper<OaOnlineInvoice> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("bill_no", responseData.getSerialNo());
        /**
         * 上传发票至七牛云
         */
        InputStream inputStream = QnyUtil.getInputStream(pdfUnsignedUrl);
        String qnyUrl = QnyUtil.uploadByInputStream(inputStream);
        oaOnlineInvoice.setQnyUrl(qnyUrl);
        oaOnlineInvoiceService.update(oaOnlineInvoice, queryWrapper);
        /**
         * 自己实现的发送邮件
         */
        List<OaOnlineInvoice> invoices = oaOnlineInvoiceService.list(queryWrapper);
        if (!ObjectUtils.isEmpty(invoices)) {
            //发送邮件
            sampleMailService.sendInvoice(responseData, invoices.get(0).getMailbox());
        }

        return Result.returnOk();
    }


}
