package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.utils.QnyUtil;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.common.VhallException;
import cn.yq.oa.dto.RecordListDTO;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.ICommonFilesService;
import cn.yq.oa.service.IOaLiveCommentService;
import cn.yq.oa.service.IOaLiveInfoService;
import cn.yq.oa.service.ISysDictDataService;
import cn.yq.oa.service.vhall.IVhallService;
import cn.yq.oa.vo.vhall.Base64DecodeMultipartFile;
import cn.yq.oa.vo.LivePageInfoVO;
import cn.yq.oa.vo.ViewLiveInfoVO;
import cn.yq.oa.vo.vhall.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;
import springfox.documentation.annotations.ApiIgnore;

import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 大咖秀信息管理表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-10
 */
@RestController
@RequestMapping("/oa-live-info")
@Api(value = "大咖秀信息管理", description = "大咖秀信息管理 API", position = 100, protocols = "http")
@AllArgsConstructor
@Slf4j
public class OaLiveInfoController {

    private ISysDictDataService sysDictDataService;

    private IOaLiveInfoService oaLiveInfoService;

    private ICommonFilesService commonFilesService;

    private IVhallService vhallService;

    private IOaLiveCommentService oaLiveCommentService;

    @ApiOperation(value = "创建(id传0)/编辑直播（id传实际的值）", notes = "创建/编辑直播")
    @PostMapping(value = "/addorUpdateLive", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    public Result addorUpdateLive(@ApiIgnore AuthUser authUser, @RequestBody LiveParam param) {
        if (null != param) {
            OaLiveInfo oaLiveInfo = new OaLiveInfo();
            CopyUtils.copyProperties(param, oaLiveInfo);
            if (param.getId() != 0) {
                oaLiveInfoService.updateById(oaLiveInfo);
                //获取当前直播下的海报文件集合
                QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("is_del", 0);
                queryWrapper.eq("relation_id", oaLiveInfo.getId());
                queryWrapper.eq("relation_type", "poster_type");
                List<CommonFiles> list = commonFilesService.list(queryWrapper);
                for (CommonFiles commonFiles : list) {
                    commonFilesService.removeById(commonFiles.getId());
                }
                //添加直播海报
                for (CleanUpAttachmentParam cleanUpAttachmentParam : param.getList()) {
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(cleanUpAttachmentParam, commonFiles);
                    commonFiles.setRelationId(oaLiveInfo.getId());
                    commonFiles.setRelationType("poster_type");
                    commonFilesService.save(commonFiles);
                }
                try {
                    if(param.getList().size()> 0){
                        CleanUpAttachmentParam param1 = param.getList().get(0);
                        //设置直播封面
                        ActiveRequest activeRequest = new ActiveRequest();
                        activeRequest.setWebinarId(param.getWebinarId());
                        activeRequest.setFileName(param1.getFileName());
                        activeRequest.setFileUrl(param1.getFileUrl());
                        vhallService.activeImage(activeRequest);
                    }
                } catch (VhallException vhallException) {
                    //log.error(vhallException.getMessage(), vhallException);
                    return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
                }
            } else {
                int webinarId;
                try {
                    //获取直播id
                    CreateRequest createRequest = new CreateRequest();
                    createRequest.setStartTime(oaLiveInfo.getLiveTime());
                    createRequest.setSubject(oaLiveInfo.getTitle());
                    createRequest.setIntroduction(param.getIntroduction());
                    webinarId = vhallService.create(createRequest);
                    if(param.getList().size()> 0){
                        CleanUpAttachmentParam param1 = param.getList().get(0);
                        //设置直播封面
                        ActiveRequest activeRequest = new ActiveRequest();
                        activeRequest.setWebinarId(webinarId);
                        activeRequest.setFileName(param1.getFileName());
                        activeRequest.setFileUrl(param1.getFileUrl());
                        vhallService.activeImage(activeRequest);
                    }
                } catch (VhallException vhallException) {
                    //log.error(vhallException.getMessage(), vhallException);
                    return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
                }
                oaLiveInfo.setStatus(1);
                oaLiveInfo.setPageAddress("http://e.vhall.com/webinar/inituser/" + webinarId);
                oaLiveInfo.setWebinarId(webinarId);
                oaLiveInfo.setCreateBy(authUser.getName());
                oaLiveInfoService.save(oaLiveInfo);
                //添加直播海报
                for (CleanUpAttachmentParam cleanUpAttachmentParam : param.getList()) {
                    CommonFiles commonFiles = new CommonFiles();
                    CopyUtils.copyProperties(cleanUpAttachmentParam, commonFiles);
                    commonFiles.setRelationId(oaLiveInfo.getId());
                    commonFiles.setRelationType("poster_type");
                    commonFilesService.save(commonFiles);
                }
            }
        }
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取直播类别(取dictValue和dictLabel)", notes = "获取直播类别")
    @GetMapping(value = "/getDicInfo")
    public Result getDicInfo() {
        QueryWrapper<SysDictData> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del", 0);
        queryWrapper.eq("dict_type", "live_type");
        List<SysDictData> list = sysDictDataService.list(queryWrapper);
        return Result.returnOk(list);
    }

    @ApiOperation(value = "分页获取直播信息", notes = "分页获取直播信息")
    @PostMapping("/listLive/{pageNum}/{pageSize}")
    @LoginUser
    public Result<IPage<LivePageInfoVO>> listLive(@ApiIgnore AuthUser authUser,
                                                  @PathVariable("pageNum") int pageNum,
                                                  @PathVariable("pageSize") int pageSize,
                                                  @RequestBody LiveSearchParam param) {
        Page<LivePageInfoVO> page = new Page<LivePageInfoVO>(pageNum, pageSize);
        IPage<LivePageInfoVO> iPage = page.setRecords(oaLiveInfoService.listLive(page, param));
        List<LivePageInfoVO> list = new ArrayList<LivePageInfoVO>();
        for (LivePageInfoVO livePageInfoVO : iPage.getRecords()) {
            try {
                //获取直播状态（1.进行中2.预约中3.直播结束4.直播为当前点播5.结束且有回放）
                RecordRequest recordRequest = new RecordRequest();
                recordRequest.setWebinarId(livePageInfoVO.getWebinarId());
                int liveStatus = vhallService.state(recordRequest);
                livePageInfoVO.setLiveStatus(liveStatus);
                //获取直播地址
                StartRequest request = new StartRequest();
                request.setWebinarId(livePageInfoVO.getWebinarId());
                String liveUrl = vhallService.start(request);
                livePageInfoVO.setLiveUrl(liveUrl);
                list.add(livePageInfoVO);
            } catch (VhallException vhallException) {
                //log.error(vhallException.getMessage(), vhallException);
                return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
            }
        }
        if (null != list && list.size() > 0) {
            iPage.setRecords(list);
        }
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "查看直播信息", notes = "查看直播信息")
    @GetMapping("/viewLive/{id}")
    public Result<ViewLiveInfoVO> viewLive(@PathVariable("id") Integer id) {
        ViewLiveInfoVO viewLiveInfoVO = oaLiveInfoService.selectviewLive(id);
        List<CleanUpAttachmentParam> list1 = new ArrayList<>();
        if (null != viewLiveInfoVO) {
            //获取当前直播下得海报信息
            QueryWrapper<CommonFiles> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("is_del", 0);
            queryWrapper.eq("relation_id", id);
            queryWrapper.eq("relation_type", "poster_type");
            List<CommonFiles> list = commonFilesService.list(queryWrapper);
            for (CommonFiles commonFiles : list) {
                CleanUpAttachmentParam param = new CleanUpAttachmentParam();
                CopyUtils.copyProperties(commonFiles, param);
                list1.add(param);
            }
            //获取直播统计信息
            try {
                RecordRequest recordRequest = new RecordRequest();
                recordRequest.setWebinarId(viewLiveInfoVO.getWebinarId());
                Object obj = vhallService.getReort(recordRequest);
                viewLiveInfoVO.setObj(obj);
            } catch (VhallException vhallException) {
                //log.error(vhallException.getMessage(), vhallException);
                return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
            }
            viewLiveInfoVO.setList(list1);
        }
        return Result.returnOk(viewLiveInfoVO);
    }

    @ApiOperation(value = "删除直播信息", notes = "删除直播信息")
    @GetMapping("/deleteLive/{id}")
    public Result deleteLive(@PathVariable("id") Integer id) {
        oaLiveInfoService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "更改直播信息状态(发布status传2下架传3)", notes = "更改直播信息状态")
    @GetMapping("/changeLiveStatus/{id}/{status}")
    @LoginUser
    public Result changeLiveStatus(@ApiIgnore AuthUser authUser, @PathVariable("id") Integer id, @PathVariable("status") Integer status) {
        OaLiveInfo oaLiveInfo = new OaLiveInfo();
        oaLiveInfo.setId(id);
        oaLiveInfo.setStatus(status);
        if (status == 2) {
            oaLiveInfo.setPublisher(authUser.getName());
            oaLiveInfo.setPublishtime(new Date());
        }
        oaLiveInfoService.updateById(oaLiveInfo);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "获取直播回放列表", notes = "获取直播回放列表")
    @GetMapping("/getRecordList/{webinarId}")
    public Result<List> getRecordList(@PathVariable("webinarId") Integer webinarId) {
        try {
            RecordRequest recordRequest = new RecordRequest();
            recordRequest.setWebinarId(webinarId);
            return Result.returnOk(vhallService.getRecordList(recordRequest));
        } catch (VhallException vhallException) {
            //log.error(vhallException.getMessage(), vhallException);
            return new Result<>(ResultEnum.FAIL.getCode(), vhallException.getMessage());
        }
    }

    @ApiOperation(value = "APP大咖秀列表", notes = "APP大咖秀列表")
    @PostMapping("/listAPPLiveInfo")
    @LoginUser
    public Result<List<ViewLiveInfoVO>> listAPPLiveInfo(@ApiIgnore AuthUser authUser, @RequestBody LiveSearchAPPParam params) {
        List<ViewLiveInfoVO> list = oaLiveInfoService.listAPPLiveInfo(params);
        List<ViewLiveInfoVO> list1 = new ArrayList<>();
        for (ViewLiveInfoVO viewLiveInfoVO : list) {
            List<CleanUpAttachmentParam> listparam = new ArrayList<>();
            //获取当前直播下得海报信息
            QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("is_del", 0);
            queryWrapper1.eq("relation_id", viewLiveInfoVO.getId());
            queryWrapper1.eq("relation_type", "poster_type");
            List<CommonFiles> comlist = commonFilesService.list(queryWrapper1);
            for (CommonFiles commonFiles : comlist) {
                CleanUpAttachmentParam param = new CleanUpAttachmentParam();
                CopyUtils.copyProperties(commonFiles, param);
                listparam.add(param);
            }
            if (null != comlist && comlist.size() > 0) {
                viewLiveInfoVO.setList(listparam);
            }
            try {
                String url = viewLiveInfoVO.getPageAddress();
                StringBuffer pageUserAddress = new StringBuffer(url);
                pageUserAddress.append("?email=");
                pageUserAddress.append(viewLiveInfoVO.getId());
                pageUserAddress.append("@51yuqian.net&name=");
                pageUserAddress.append(authUser.getUsername());
                viewLiveInfoVO.setPageUserAddress(pageUserAddress.toString());
                //获取直播状态（1.进行中2.预约中3.直播结束4.直播为当前点播5.结束且有回放）
                RecordRequest recordRequest = new RecordRequest();
                recordRequest.setWebinarId(viewLiveInfoVO.getWebinarId());
                int liveStatus = vhallService.state(recordRequest);
                viewLiveInfoVO.setLiveStatus(liveStatus);
                //获取直播回放
                recordRequest.setLimit(1);
                recordRequest.setTime_seq(2);
                List<RecordListDTO> listRecord = vhallService.getRecordList(recordRequest);
                viewLiveInfoVO.setListRecord(listRecord);
                if (null != listRecord && listRecord.size() > 0) {
                    StringBuffer recordUserAddress = new StringBuffer(url);
                    recordUserAddress.append("?rid=");
                    recordUserAddress.append(listRecord.get(0).getId());
                    recordUserAddress.append("&email=");
                    recordUserAddress.append(viewLiveInfoVO.getId());
                    recordUserAddress.append("@51yuqian.net&name=");
                    recordUserAddress.append(authUser.getUsername());
                    viewLiveInfoVO.setRecordUserAddress(recordUserAddress.toString());
                }
            } catch (VhallException vhallException) {
                //log.error(vhallException.getMessage(), vhallException);
                return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
            }
            if (null != params) {
                if (params.getLiveStatus() != 0) {
                    if (viewLiveInfoVO.getLiveStatus() == params.getLiveStatus()) {
                        list1.add(viewLiveInfoVO);
                    }
                } else {
                    list1.add(viewLiveInfoVO);
                }
            } else {
                list1.add(viewLiveInfoVO);
            }
        }
        List<ViewLiveInfoVO> list2 = new ArrayList<>();
        list2 = list1.stream().filter(v -> {
            if(v.getLiveStatus() == 3 && StringUtils.isBlank(v.getRecordUserAddress())){
                return  false;
            }else{
                return  true;
            }
        }).collect(Collectors.toList());
        return Result.returnOk(list2);
    }

    @ApiOperation(value = "评论删除", notes = "评论删除")
    @GetMapping("/removeComment/{id}")
    public Result removeComment(@PathVariable("id") Integer id) {
        oaLiveCommentService.removeById(id);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "APP大咖秀游客登录", notes = "APP大咖秀游客登录")
    @PostMapping("/listAPPLiveNotUser")
    public Result<List<ViewLiveInfoVO>> listAPPLiveNotUser(@RequestBody LiveSearchAPPParam params) {
        List<ViewLiveInfoVO> list = oaLiveInfoService.listAPPLiveInfo(params);
        List<ViewLiveInfoVO> list1 = new ArrayList<>();
        for (ViewLiveInfoVO viewLiveInfoVO : list) {
            List<CleanUpAttachmentParam> listparam = new ArrayList<>();
            //获取当前直播下得海报信息
            QueryWrapper<CommonFiles> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("is_del", 0);
            queryWrapper1.eq("relation_id", viewLiveInfoVO.getId());
            queryWrapper1.eq("relation_type", "poster_type");
            List<CommonFiles> comlist = commonFilesService.list(queryWrapper1);
            for (CommonFiles commonFiles : comlist) {
                CleanUpAttachmentParam param = new CleanUpAttachmentParam();
                CopyUtils.copyProperties(commonFiles, param);
                listparam.add(param);
            }
            if (null != comlist && comlist.size() > 0) {
                viewLiveInfoVO.setList(listparam);
            }
            try {
                //获取直播状态（1.进行中2.预约中3.直播结束4.直播为当前点播5.结束且有回放）
                RecordRequest recordRequest = new RecordRequest();
                recordRequest.setWebinarId(viewLiveInfoVO.getWebinarId());
                int liveStatus = vhallService.state(recordRequest);
                viewLiveInfoVO.setLiveStatus(liveStatus);
                //获取直播回放
                recordRequest.setLimit(1);
                recordRequest.setTime_seq(2);
                List<RecordListDTO> listRecord = vhallService.getRecordList(recordRequest);
                viewLiveInfoVO.setListRecord(listRecord);
                if (null != listRecord && listRecord.size() > 0) {
                    StringBuffer recordUserAddress = new StringBuffer(viewLiveInfoVO.getPageAddress());
                    recordUserAddress.append("?rid=");
                    recordUserAddress.append(listRecord.get(0).getId());
                    viewLiveInfoVO.setRecordUserAddress(recordUserAddress.toString());
                }
            } catch (VhallException vhallException) {
                //log.error(vhallException.getMessage(), vhallException);
                return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
            }
            if (null != params) {
                if (params.getLiveStatus() != 0) {
                    if (viewLiveInfoVO.getLiveStatus() == params.getLiveStatus()) {
                        list1.add(viewLiveInfoVO);
                    }
                } else {
                    list1.add(viewLiveInfoVO);
                }
            } else {
                list1.add(viewLiveInfoVO);
            }
        }
        List<ViewLiveInfoVO> list2 = new ArrayList<>();
        list2 = list1.stream().filter(v -> {
            if(v.getLiveStatus() == 3 && StringUtils.isBlank(v.getRecordUserAddress())){
                return  false;
            }else{
                return  true;
            }
        }).collect(Collectors.toList());
        return Result.returnOk(list2);
    }

    @ApiOperation(value = "分页获取评论信息", notes = "分页获取评论信息")
    @GetMapping("/listComment/{pageNum}/{pageSize}/{webinarId}")
    public Result listComment(@PathVariable("pageNum") int pageNum,
                              @PathVariable("pageSize") int pageSize,
                              @PathVariable("webinarId") int webinarId) {
        Map map = new HashMap<>();
        int pos = (pageNum - 1) * pageSize + 1;
        ChatRequest chatRequest = new ChatRequest();
        chatRequest.setWebinarId(webinarId);
        chatRequest.setPos(pos);
        chatRequest.setLimit(pageSize);
        chatRequest.setType(1);
        List list = null;
        List list1 = null;
        try {
            ChatRequest chatRequest1 = new ChatRequest();
            chatRequest1.setWebinarId(webinarId);
            chatRequest1.setType(0);
            chatRequest1.setPos(1);
            list1 = vhallService.chat(chatRequest1);
            log.debug("评论总条数======================》" + list1.size());
            list = vhallService.chat(chatRequest);
            map.put("list", list);
            map.put("total", list1.size());
        } catch (VhallException vhallException) {
            //log.error(vhallException.getMessage(), vhallException);
            return new Result(ResultEnum.FAIL.getCode(), vhallException.getMessage());
        }
        return Result.returnOk(map);
    }
}
