package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.oa.dto.StockInDTO;
import cn.yq.oa.entity.OaOfficesuppliesStockIn;
import cn.yq.oa.entity.OaOfficesuppliesStockInDetail;
import cn.yq.oa.entity.OaOfficesuppliesStockOutDetail;
import cn.yq.oa.mapper.IOaOfficesuppliesStockMapper;
import cn.yq.oa.service.IOaOfficesuppliesStockInDetailService;
import cn.yq.oa.service.IOaOfficesuppliesStockInService;
import cn.yq.oa.vo.OaOfficesuppliesStockInVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 办公用品入库信息表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-01-31
 */
@Api(value = "办公用品入库", description = "办公用品入库")
@RestController
@RequestMapping("/oa-officesupplies-stock-in")
public class OaOfficesuppliesStockInController {

    @Autowired
    private IOaOfficesuppliesStockInService oaOfficesuppliesStockInService;
    @Autowired
    private IOaOfficesuppliesStockInDetailService oaOfficesuppliesStockInDetailService;
    @Autowired
    private IOaOfficesuppliesStockMapper oaOfficesuppliesStockMapper;
    
    
    /**
    *@Description 新增和编辑
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "新增和编辑", notes = "新增和编辑")
    @PostMapping(value = "/addOrEdit")
    @SystemLog(description = "新增和编辑办公用品入库")
    public Result addOrEdit(@RequestBody StockInDTO stockInDTO){
        oaOfficesuppliesStockInService.addOrEdit(stockInDTO);
        return Result.returnOk();
    }
    
    /**
    *@Description 入库单列表展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "入库单列表展示", notes = "入库单列表展示")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @SystemLog(description = "办公用品入库单列表展示")
    public Result showPage(@PathVariable("pageNum")Integer pageNum,@PathVariable("pageSize")Integer pageSize,@RequestBody OaOfficesuppliesStockInVO oaOfficesuppliesStockInVO){
        return Result.returnOk(oaOfficesuppliesStockInService.showPage(pageNum,pageSize,oaOfficesuppliesStockInVO));
    }
    
    /**
    *@Description 入库详情
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "入库详情", notes = "入库详情")
    @GetMapping(value = "/detial/{id}")
    @SystemLog(description = "办公用品入库详情")
    public Result detial(@PathVariable("id")Integer id){
        return Result.returnOk(oaOfficesuppliesStockInService.detial(id));
    }
    
    /**
    *@Description 删除
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "删除办公用品入库记录")
    public Result remove(@PathVariable("id")Integer id){
        OaOfficesuppliesStockIn stockIn = oaOfficesuppliesStockInService.getById(id);
        QueryWrapper<OaOfficesuppliesStockInDetail> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("stock_in_id",id)
                    .eq("is_del",0);
        List<OaOfficesuppliesStockInDetail> details = oaOfficesuppliesStockInDetailService.list(queryWrapper);
        //扣库存
        for (OaOfficesuppliesStockInDetail detail : details) {
            //扣库存
            oaOfficesuppliesStockMapper.updateByItemIdAndDepotId(detail.getItemId(), stockIn.getDepotId(), detail.getQuantity());
        }
        //删除入库单
        oaOfficesuppliesStockInService.removeById(id);
        //删除详情
        oaOfficesuppliesStockInDetailService.remove(queryWrapper);
        return Result.returnOk();
    }
}
