package cn.yq.oa.controller;


import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.CopyUtils;
import cn.yq.oa.entity.OaPropertyElevatorInformation;
import cn.yq.oa.entity.OaPropertyElevatorTimeSlot;
import cn.yq.oa.entity.OaPropertyElevatorUnit;
import cn.yq.oa.param.IsExistElevatorParam;
import cn.yq.oa.param.TimeSlotParam;
import cn.yq.oa.util.DateUtils;
import cn.yq.oa.vo.CorrelationUnitVO;
import cn.yq.oa.param.ElevatorInfoParam;
import cn.yq.oa.service.IOaPropertyElevatorInformationService;
import cn.yq.oa.service.IOaPropertyElevatorTimeSlotService;
import cn.yq.oa.service.IOaPropertyElevatorUnitService;
import cn.yq.oa.vo.ElevatorInfoVO;
import cn.yq.oa.vo.UnitInfoVO;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 货梯信息表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-06
 */
@Api(value = "货梯信息管理", description = "货梯信息管理")
@RestController
@RequestMapping("/oa-property-elevator-information")
public class OaPropertyElevatorInformationController {

    @Autowired
    private IOaPropertyElevatorInformationService oaPropertyElevatorInformationService;
    @Autowired
    private IOaPropertyElevatorTimeSlotService oaPropertyElevatorTimeSlotService;
    @Autowired
    private IOaPropertyElevatorUnitService oaPropertyElevatorUnitService;

    /**
     * 分页信息展示
     *
     * @param pageNum
     * @param pageSize
     * @param elevatorInfoParam 条件
     * @return
     */
    @ApiOperation(value = "分页信息展示", notes = "分页信息展示")
    @PostMapping("/getElevatorInfo/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查看货梯信息")
    public Result getElevatorInfo(@PathVariable("pageNum") Integer pageNum,
                                  @PathVariable("pageSize") Integer pageSize,
                                  @RequestBody ElevatorInfoParam elevatorInfoParam) {
        Page<ElevatorInfoVO> page = new Page<ElevatorInfoVO>(pageNum, pageSize);
        IPage<ElevatorInfoVO> iPage = oaPropertyElevatorInformationService.selectElevatorInfo(page, elevatorInfoParam);
        return Result.returnOk(iPage);
    }

    /**
     * 修改状态
     *
     * @param id     货梯id
     * @param status 状态
     * @return
     */
    @ApiOperation(value = "货梯状态管理", notes = "货梯状态管理")
    @GetMapping("/updateElevatorStatus/{id}/{status}")
    @SystemLog(description = "货梯信息状态变更")
    public Result updateElevatorStatus(@PathVariable("id") Integer id,@PathVariable("status") Integer status) {
        OaPropertyElevatorInformation oaPropertyElevatorInformation = new OaPropertyElevatorInformation();
        oaPropertyElevatorInformation.setId(id);
        if (status == 1) {
            oaPropertyElevatorInformation.setStatus(0);
        } else {
            oaPropertyElevatorInformation.setStatus(1);
        }
        oaPropertyElevatorInformationService.updateById(oaPropertyElevatorInformation);
        return Result.returnOk("操作成功");
    }

    /**
     * 删除
     *
     * @param id 货梯id
     * @return
     */
    @ApiOperation(value = "删除", notes = "删除")
    @GetMapping("/removeElevator/{id}")
    @SystemLog(description = "删除货梯信息")
    public Result removeElevator(@PathVariable("id") Integer id) {
        oaPropertyElevatorInformationService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 添加货梯信息
     *
     * @param oaPropertyElevatorInformation
     * @return
     */
    @ApiOperation(value = "添加货梯信息", notes = "添加货梯信息")
    @PostMapping("/addElevatorInfo")
    @SystemLog(description = "添加货梯信息")
    public Result addElevatorInfo(@RequestBody OaPropertyElevatorInformation oaPropertyElevatorInformation) {
        oaPropertyElevatorInformationService.save(oaPropertyElevatorInformation);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "货梯名称/货梯编号判重", notes = "货梯名称/货梯编号判重")
    @PostMapping("/IsExistElevatorName")
    @SystemLog(description = "货梯名称/货梯编号判重")
    public Result<Boolean> IsExistElevatorName(@RequestBody IsExistElevatorParam param){
        boolean flag = true;
        List<OaPropertyElevatorInformation> list = null;
        if(null != param){
            if(StringUtils.isNotEmpty(param.getElevatorName())){
                QueryWrapper<OaPropertyElevatorInformation> queryWrapper = new QueryWrapper<OaPropertyElevatorInformation>();
                queryWrapper.eq("elevator_name",param.getElevatorName());
                queryWrapper.eq("is_del",0);
                list = oaPropertyElevatorInformationService.list(queryWrapper);
                if(list.size()>0 && null != list){
                    flag = false;
                }
            }
            if(StringUtils.isNotEmpty(param.getElevatorNum())){
                QueryWrapper<OaPropertyElevatorInformation> queryWrapper = new QueryWrapper<OaPropertyElevatorInformation>();
                queryWrapper.eq("elevator_number",param.getElevatorNum());
                queryWrapper.eq("is_del",0);
                list = oaPropertyElevatorInformationService.list(queryWrapper);
                if(list.size()>0 && null != list){
                    flag = false;
                }
            }
        }
        return Result.returnOk(flag);
    }


    /**
     * 编辑货梯信息
     *
     * @param id 货梯id
     * @param oaPropertyElevatorInformation
     * @return
     */
    @ApiOperation(value = "编辑货梯信息", notes = "编辑货梯信息")
    @PostMapping("/updateElevatorInfo/{id}")
    @SystemLog(description = "编辑货梯信息")
    public Result updateElevatorInfo(@PathVariable("id") Integer id, @RequestBody OaPropertyElevatorInformation oaPropertyElevatorInformation) {
        QueryWrapper<OaPropertyElevatorInformation> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("is_del",0);
        queryWrapper.and(wrapper -> wrapper.eq("elevator_name",oaPropertyElevatorInformation.getElevatorName()).or().eq("elevator_number",oaPropertyElevatorInformation.getElevatorNumber()));
        queryWrapper.ne("id",id);
        List<OaPropertyElevatorInformation> list = oaPropertyElevatorInformationService.list(queryWrapper);
        if(null != list && list.size() > 0){
          return new Result(ResultEnum.FAIL.getCode(), "货梯名称或货梯编号重复，请重新输入");
        }
        oaPropertyElevatorInformation.setId(id);
        oaPropertyElevatorInformationService.updateById(oaPropertyElevatorInformation);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "查看货梯信息", notes = "查看货梯信息")
    @GetMapping("/getElevatorInfoById/{id}")
    @SystemLog(description = "查看货梯信息")
    public Result getElevatorInfoById(@PathVariable("id") Integer id){
        OaPropertyElevatorInformation oaPropertyElevatorInformation = oaPropertyElevatorInformationService.getById(id);
        return Result.returnOk(oaPropertyElevatorInformation);
    }

    /**
     * 添加预约时间
     *
     * @param
     * @return
     */
    @ApiOperation(value = "添加预约时间", notes = "添加预约时间")
    @PostMapping("/addElevatorTimeSlot")
    @SystemLog(description = "添加货梯预约时间")
    public Result addElevatorTimeSlot(@RequestBody TimeSlotParam TimeSlotParam) {
        OaPropertyElevatorTimeSlot oaPropertyElevatorTimeSlot = new OaPropertyElevatorTimeSlot();
        oaPropertyElevatorTimeSlot.setBeginTime(TimeSlotParam.getBeginTime());
        oaPropertyElevatorTimeSlot.setEndTime(TimeSlotParam.getEndTime());
        oaPropertyElevatorTimeSlotService.save(oaPropertyElevatorTimeSlot);
        return Result.returnOk("操作成功");
    }

    /**
     * 时间段查询
     *
     * @return
     */
    @ApiOperation(value = "时间段查询", notes = "时间段查询")
    @GetMapping("/getElevatorTimeSlot")
    public Result getElevatorTimeSlot() {
        QueryWrapper<OaPropertyElevatorTimeSlot> queryWrapper = new QueryWrapper<OaPropertyElevatorTimeSlot>();
        queryWrapper.eq("is_del",0);
        List<OaPropertyElevatorTimeSlot> list = oaPropertyElevatorTimeSlotService.list(queryWrapper);
        return Result.returnOk(list);
    }

    /**
     * 批量删除
     */
    @ApiOperation(value = "时间段删除", notes = "时间段删除")
    @GetMapping("/removeElevatorTimeSlot/{id}")
    @SystemLog(description = "货梯信息批量删除")
    public Result removeElevatorTimeSlot(@PathVariable("id") Integer id) {
        oaPropertyElevatorTimeSlotService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 所属楼宇下的单元信息
     * @param id 楼宇id
     * @return
     */
    @ApiOperation(value = "单元信息", notes = "单元信息")
    @GetMapping("/getUnitInfo/{id}/{elevatorId}")
    public Result getUnitInfo(@PathVariable("id") Integer id,@PathVariable("elevatorId") Integer elevatorId){
        Map map = new HashMap();
        List<Integer> unitIdList = null;
        //判断当前楼宇和货梯是否存在
        QueryWrapper<OaPropertyElevatorInformation>queryWrapper = new QueryWrapper<OaPropertyElevatorInformation>();
        queryWrapper.eq("is_del",0);
        queryWrapper.eq("building_id",id);
        queryWrapper.eq("id",elevatorId);
        OaPropertyElevatorInformation oaPropertyElevatorInformation = oaPropertyElevatorInformationService.getOne(queryWrapper);
        if(null != oaPropertyElevatorInformation){//不为空获取所有已关联单元id集合
             unitIdList = oaPropertyElevatorInformationService.selectElevatorUnit(elevatorId);
        }
        List<UnitInfoVO> unitInfoList = oaPropertyElevatorInformationService.selectUnitInfo(id);
        map.put("unitIdList",unitIdList);
        map.put("unitInfoList",unitInfoList);
        return  Result.returnOk(map);
    }

    /**
     * 添加关联单元
     * @param correlationUnitVO
     * @return
     */
    @ApiOperation(value = "添加关联单元", notes = "添加关联单元")
    @PostMapping("/addCorrelationUnit")
    public Result addCorrelationUnit(@RequestBody CorrelationUnitVO correlationUnitVO){
        if(null != correlationUnitVO){
            //获取当前货梯下的所有单元关系
            QueryWrapper<OaPropertyElevatorUnit> queryWrapper = new QueryWrapper<OaPropertyElevatorUnit>();
            queryWrapper.eq("elevator_id",correlationUnitVO.getElevatorId());
            List<OaPropertyElevatorUnit> list = oaPropertyElevatorUnitService.list(queryWrapper);
            //逻辑删除
            for(OaPropertyElevatorUnit elevatorUnit : list){
                oaPropertyElevatorUnitService.removeById(elevatorUnit.getId());
            }
            //维护货梯单元关系
            for (Integer initId : correlationUnitVO.getUnitId()) {
                OaPropertyElevatorUnit oaPropertyElevatorUnit = new OaPropertyElevatorUnit();
                oaPropertyElevatorUnit.setElevatorId(correlationUnitVO.getElevatorId());
                oaPropertyElevatorUnit.setUnitId(initId);
                oaPropertyElevatorUnitService.save(oaPropertyElevatorUnit);
            }
        }
        return Result.returnOk("操作成功");
    }
}
