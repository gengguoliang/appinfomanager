package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.oaproperty.CartApplicationTDO;
import cn.yq.oa.dto.oaproperty.ApplicationAddDTO;
import cn.yq.oa.dto.oaproperty.ApplicationUseAddDTO;
import cn.yq.oa.dto.oaproperty.UseAddDTO;
import cn.yq.oa.entity.*;
import cn.yq.oa.mapper.IOaPropertyCartApplicationMapper;
import cn.yq.oa.service.*;
import cn.yq.oa.vo.oaproperty.*;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 推车申请表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-03-06
 */
@Api(value = "推车申请领用归还", description = "推车申请领用归还")
@RestController
@RequestMapping("/oa-property-cart-application")
public class OaPropertyCartApplicationController {

    @Autowired
    private IOaPropertyCartApplicationService oaPropertyCartApplicationService;
    @Autowired
    private IOaPropertyPlaceService oaPropertyPlaceService;
    @Autowired
    private IOaPropertyCartService oaPropertyCartService;
    @Autowired
    private IOaPropertyCartUseDetailService oaPropertyCartUseDetailService;
    @Autowired
    private IOaPropertyCartUseService oaPropertyCartUseService;
    @Autowired
    private IOaPropertyCartApplicationMapper cartApplicationMapper;
    @Autowired
    private IOaPropertyCartApplicationDetailService oaPropertyCartApplicationDetailService;


    /**
     * @Description 添加申请的信息展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @LoginUser
    @ApiOperation(value = "添加申请的信息展示", notes = "添加申请的信息展示")
    @GetMapping(value = "/addApplicationShow")
    @SystemLog(description = "推车领用申请信息展示")
    public Result addApplicationShow(AuthUser authUser) {
        List<PropertyApplicationAddShowVO> propertyApplicationAddShowVOS = oaPropertyCartApplicationService.addApplicationShow(authUser);
        return Result.returnOk(propertyApplicationAddShowVOS);
    }

    /**
     * @Description 添加申请时领取地点   2：物业公司
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @LoginUser
    @ApiOperation(value = "添加申请时领取地点", notes = "添加申请时领取地点")
    @GetMapping(value = "/getReceivePlace/{buildingId}")
    @SystemLog(description = "推车申请领取地点信息")
    public Result<List<PropertyPlaceAndCartVO>> getReceivePlace(AuthUser authUser, @PathVariable("buildingId") Integer buildingId) {
        if (buildingId == 0) {
            QueryWrapper<OaPropertyPlace> queryWrapper1=new QueryWrapper<>();
            queryWrapper1.eq("is_del",0);
            List<OaPropertyPlace> list = oaPropertyPlaceService.list(queryWrapper1);
            List<PropertyPlaceAndCartVO> placeAndCartVOS = new ArrayList<>();
            for (OaPropertyPlace oaPropertyPlace : list) {
                PropertyPlaceAndCartVO placeAndCartVO = new PropertyPlaceAndCartVO();
                BeanUtils.copyProperties(oaPropertyPlace, placeAndCartVO);
                QueryWrapper<OaPropertyCart> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("receive_place_id", placeAndCartVO.getId())
                        .eq("is_del", 0).eq("status",0)
                        .gt("quantity", 0);
                List<OaPropertyCart> list1 = oaPropertyCartService.list(queryWrapper);
                if (list1 != null && list1.size() > 0) {
                    placeAndCartVO.setOaPropertyCarts(list1);
                    placeAndCartVOS.add(placeAndCartVO);
                }
            }
            return Result.returnOk(placeAndCartVOS);
        }
        if (oaPropertyCartApplicationService.getType(authUser.getId()) == 2) {//物业公司
            return Result.returnOk(oaPropertyCartApplicationService.getReceivePlace(buildingId, 0));
        }
        return Result.returnOk(oaPropertyCartApplicationService.getReceivePlace(buildingId, 1));
    }

    /**
     * @Description 添加申请
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "添加申请", notes = "添加申请")
    @PostMapping(value = "/addApplication")
    @LoginUser
    @SystemLog(description = "添加推车申请")
    public Result add(AuthUser authUser, @RequestBody ApplicationAddDTO applicationAddDTO) {
        oaPropertyCartApplicationService.add(authUser, applicationAddDTO);
        return Result.returnOk();
    }

    /**
     * @Description PC端添加申请领用
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC端添加申请领用", notes = "PC端添加申请领用")
    @PostMapping(value = "/addApplicationAndUse")
    @LoginUser
    @SystemLog(description = "添加推车申请领用")
    public Result addApplicationAndUse(AuthUser authUser, @RequestBody ApplicationUseAddDTO applicationUseAddDTO) {
        oaPropertyCartApplicationService.addApplicationAndUse(applicationUseAddDTO, authUser);
        return Result.returnOk();
    }

    /**
     * @Description PC端添加领用时根据楼宇ID获取当前登录人负责的领取地点
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC端添加领用时根据楼宇ID领取地点", notes = "PC端添加领用时根据楼宇ID领取地点")
    @GetMapping(value = "/getPlace/{buildingId}")
    @LoginUser
    public Result getPlace(@ApiIgnore AuthUser authUser,@PathVariable("buildingId") Integer buildingId) {
        List<OaPropertyPlace> oaPropertyPlaces = oaPropertyCartApplicationService.getPlace(authUser,buildingId);
        return Result.returnOk(oaPropertyPlaces);
    }

    /**
     * @Description PC端添加领用时的领取地点下的推车信息
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC端添加领用时的领取地点下的推车信息", notes = "PC端添加领用时的领取地点下的推车信息")
    @GetMapping(value = "/getCart/{placeId}")
    public Result getCart(@PathVariable("placeId") Integer placeId) {
        QueryWrapper<OaPropertyCart> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("receive_place_id", placeId)
                .gt("quantity",0)
                .eq("is_del", 0)
                .eq("status",0);
        List<OaPropertyCart> oaPropertyCarts = oaPropertyCartService.list(queryWrapper);
        return Result.returnOk(oaPropertyCarts);
    }

    /**
     * @Description PC端列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "PC端列表展示", notes = "PC端列表展示")
    @PostMapping(value = "/showPage/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页查看推车申请列表信息")
    public Result showPage(AuthUser authUser,
                           @PathVariable("pageNum") Integer pageNum,
                           @PathVariable("pageSize") Integer pageSize, @RequestBody CartApplicationTDO cartApplicationTDO) {
        Page page = new Page(pageNum, pageSize);
        IPage iPage = page.setRecords(oaPropertyCartApplicationService.showPage(authUser, cartApplicationTDO, page));
        return Result.returnOk(iPage);
    }

    /**
     * @Description 推车申请详情
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "推车申请详情", notes = "推车申请详情")
    @GetMapping(value = "/detail/{id}")
    @SystemLog(description = "推车申请详情")
    public Result detail(@PathVariable("id") Integer id) {
        CartApplicationVO detail = oaPropertyCartApplicationService.detail(id);
        return Result.returnOk(detail);
    }

    /**
     * @Description 推车申请删除
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "推车申请删除", notes = "推车申请删除")
    @GetMapping(value = "/remove/{id}")
    @SystemLog(description = "推车申请删除")
    public Result remove(@PathVariable("id") Integer id) {
        oaPropertyCartApplicationService.remove(id);
        return Result.returnOk();
    }

    /**
     * @Description 领用和归还登记  只需传ID就行
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "领用和归还登记", notes = "领用和归还登记")
    @PostMapping(value = "/addUse")
    @LoginUser
    @StatusChangedNotification(name = "推车信息")
    @SystemLog(description = "推车申请领用和归还登记")
    public Result addUse(AuthUser authUser, @RequestBody UseAddDTO useAddDTO) {
        oaPropertyCartApplicationService.addUse(authUser, useAddDTO);
        //消息推送
        String username = cartApplicationMapper.getUsername(useAddDTO.getId());
        PushUtil.setTargetUsername(username);
        return Result.returnOk();
    }

    /**
     * @Description APP端申请列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "APP端申请列表展示", notes = "APP端申请列表展示")
    @GetMapping(value = "/appShow/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "APP端推车申请列表展示")
    public Result appShow(@ApiIgnore AuthUser authUser,@PathVariable("pageNum")Integer pageNum,@PathVariable("pageSize")Integer pageSize) {
        Page page=new Page(pageNum,pageSize);
        List<ApplicationShowVO> applicationShowVOS = oaPropertyCartApplicationService.appShow(authUser,page);
        return Result.returnOk(page.setRecords(applicationShowVOS));
    }

    /**
     * @Description 领用登记和归还登记的列表展示
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @ApiOperation(value = "领用登记和归还登记的列表展示", notes = "领用登记和归还登记的列表展示")
    @GetMapping(value = "/useAndRevertShow/{id}")
    @SystemLog(description = "推车申请领用登记和归还登记的列表展示")
    public Result useAndRevertShow(@PathVariable("id") Integer id) {
        OaPropertyCartApplication application = oaPropertyCartApplicationService.getById(id);
        List<UseAndRevertVO> useAndRevertVOS = new ArrayList<>();
        if (application.getStatus() == 0) {
            QueryWrapper<OaPropertyCartApplicationDetail> queryWrapper2 = new QueryWrapper<>();
            queryWrapper2.eq("application_id", application.getId())
                    .eq("is_del", 0);
            List<OaPropertyCartApplicationDetail> details = oaPropertyCartApplicationDetailService.list(queryWrapper2);
            for (OaPropertyCartApplicationDetail detail : details) {
                UseAndRevertVO useAndRevertVO = new UseAndRevertVO();
                OaPropertyCart cart = oaPropertyCartService.getById(detail.getCartId());
                useAndRevertVO.setModel(cart.getModel());
                useAndRevertVO.setId(detail.getCartId());
                useAndRevertVO.setAmount(detail.getApplicationAmount());
                useAndRevertVOS.add(useAndRevertVO);
            }
        }
        if (application.getStatus() == 1) {
            QueryWrapper<OaPropertyCartUse> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("application_id", id)
                    .eq("is_del", 0);
            OaPropertyCartUse one = oaPropertyCartUseService.getOne(queryWrapper);
            QueryWrapper<OaPropertyCartUseDetail> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("use_id", one.getId())
                    .eq("is_del", 0);
            List<OaPropertyCartUseDetail> details = oaPropertyCartUseDetailService.list(queryWrapper1);
            for (OaPropertyCartUseDetail detail : details) {
                UseAndRevertVO useAndRevertVO = new UseAndRevertVO();
                OaPropertyCart cart = oaPropertyCartService.getById(detail.getCartId());
                useAndRevertVO.setModel(cart.getModel());
                useAndRevertVO.setId(detail.getCartId());
                useAndRevertVO.setAmount(detail.getUseAmount());
                useAndRevertVOS.add(useAndRevertVO);
            }
        }
        return Result.returnOk(useAndRevertVOS);
    }

}
