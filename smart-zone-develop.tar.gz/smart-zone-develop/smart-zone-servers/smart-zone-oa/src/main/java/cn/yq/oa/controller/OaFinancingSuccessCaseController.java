package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.CopyUtils;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.OaFinancingSuccessCase;
import cn.yq.oa.param.FinancingSearchParam;
import cn.yq.oa.param.OaFinancingParam;
import cn.yq.oa.param.OaFinancingSuccessCaseParam;
import cn.yq.oa.service.IOaFinancingSuccessCaseService;
import cn.yq.oa.vo.FinancingSuccessVO;
import cn.yq.oa.vo.OaFinancingInfoVo;
import cn.yq.oa.vo.OaFinancingSuccessCaseVo;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

/**
 * <p>
 * 投融资成功案例信息 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-04-02
 */
@RestController
@RequestMapping("/oa-financing-success-case")
@Api(value = "投融资成功案例", description = "ggl投融资成功案例 API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaFinancingSuccessCaseController {

    private IOaFinancingSuccessCaseService oaFinancingSuccessCaseService;

    @ApiOperation(value = "创建项目（id传0）/编辑项目（id传实际的值）", notes = "创建项目")
    @PostMapping(value = "/addProject", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE}, produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
    @LoginUser
    @SystemLog(description = "添加成功案例")
    public Result addProject(@ApiIgnore AuthUser authUser,@RequestBody OaFinancingSuccessCaseParam param) {
        if(null != param){
            OaFinancingSuccessCase oaFinancingSuccessCase = new OaFinancingSuccessCase();
            CopyUtils.copyProperties(param,oaFinancingSuccessCase);
            if(param.getId() != 0){
                oaFinancingSuccessCaseService.updateById(oaFinancingSuccessCase);
            }else{//新增
                oaFinancingSuccessCase.setOrgid(authUser.getOrganizationId());
                oaFinancingSuccessCaseService.save(oaFinancingSuccessCase);
            }
        }
        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "分页获取成功案例", notes = "分页获取成功案例")
    @PostMapping("/listFinancingCase/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "分页获取成功案例")
    public Result<IPage<FinancingSuccessVO>> listFinancingCase(@ApiIgnore AuthUser authUser,
                                                               @PathVariable("pageNum") int pageNum,
                                                               @PathVariable("pageSize") int pageSize,
                                                               @RequestBody FinancingSearchParam param){
        Page<FinancingSuccessVO> page = new Page<FinancingSuccessVO>(pageNum, pageSize);
        IPage<FinancingSuccessVO> iPage = page.setRecords(oaFinancingSuccessCaseService.listFinancingCase(page,param));
        return Result.returnOk(iPage);
    }

    @ApiOperation(value = "查看成功案例信息", notes = "查看成功案例信息")
    @GetMapping("/viewFinancingCase/{id}")
    @SystemLog(description = "查看成功案例信息")
    public Result<OaFinancingSuccessCaseVo> viewFinancingCase(@PathVariable("id") Integer id){
        OaFinancingSuccessCaseVo oaFinancingSuccessCaseVo =  oaFinancingSuccessCaseService.viewFinancingCase(id);
        return Result.returnOk(oaFinancingSuccessCaseVo);
    }

    @ApiOperation(value = "删除融资项目信息", notes = "删除融资项目信息")
    @GetMapping("/deleteFinancingCase/{id}")
    @SystemLog(description = "删除成功案例信息")
    public Result deleteFinancingCase(@PathVariable("id") Integer id){
        oaFinancingSuccessCaseService.removeById(id);
        return Result.returnOk("操作成功");
    }












}
