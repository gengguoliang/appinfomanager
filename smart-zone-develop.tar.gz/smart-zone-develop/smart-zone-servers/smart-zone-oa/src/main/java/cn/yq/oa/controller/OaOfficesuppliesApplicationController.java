package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.enumeration.PrivilegeCodeEnum;
import cn.yq.oa.mapper.IOaOfficesuppliesApplicationMapper;
import cn.yq.oa.service.IAuthUserService;
import cn.yq.push.annotations.Notification;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.dto.OaOfficesuppliesApplicationDTO;
import cn.yq.oa.entity.OaOfficesuppliesApplication;
import cn.yq.oa.service.IOaOfficesuppliesApplicationService;
import cn.yq.oa.vo.AplicationItemShowVO;
import cn.yq.oa.vo.OaOfficesuppliesApplicationVO;
import cn.yq.push.annotations.StatusChangedNotification;
import cn.yq.push.enumeration.PushRange;
import cn.yq.push.utils.PushUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 办公用品申请表 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-01-31
 */
@Api(value = "办公用品申请", description = "办公用品申请")
@RestController
@RequestMapping("/oa-officesupplies-application")
public class OaOfficesuppliesApplicationController {
    @Autowired
    private IOaOfficesuppliesApplicationService oaOfficesuppliesApplicationService;
    @Autowired
    private IOaOfficesuppliesApplicationMapper applicationMapper;
    @Autowired
    private IAuthUserService userService;
	
    
    /**
    *@Description 新增申请
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "新增申请", notes = "新增申请")
    @PostMapping(value = "/add")
    @LoginUser
    @Notification(name = "办公审批",range = PushRange.USER)
    @SystemLog(description = "添加办公用品申请")
    public Result add(AuthUser authUser, @RequestBody OaOfficesuppliesApplicationDTO oaOfficesuppliesApplicationDTO){
        oaOfficesuppliesApplicationService.add(authUser,oaOfficesuppliesApplicationDTO);
        //消息推送
        String[] names = applicationMapper.queryExamine(PrivilegeCodeEnum.office_approval.name());
        PushUtil.setTargetUsername(names);
        return Result.returnOk();
    }
    
    /**
    *@Description 查询申请和审批列表  flag: 0 为申请  1 为审批
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "查询申请和审批列表", notes = "查询申请和审批列表")
    @PostMapping(value = "/show/{flag}/{pageNum}/{pageSize}")
    @LoginUser
    @SystemLog(description = "查询办公用品申请和审批列表")
    public Result show(AuthUser authUser, @PathVariable("flag")Integer flag,
                       @PathVariable("pageNum")Integer pageNum,
                       @PathVariable("pageSize")Integer pageSize){
        Page page=new Page(pageNum,pageSize);
        List<OaOfficesuppliesApplicationVO> oaOfficesuppliesApplicationVOS = oaOfficesuppliesApplicationService.show(page,authUser, flag);
        IPage iPage=page.setRecords(oaOfficesuppliesApplicationVOS);
        return Result.returnOk(iPage);
    }

    /**
    *@Description 申请或审批详情
    *@Param
    *@Return
    *@Author zhengjianhui
    */
    @ApiOperation(value = "申请或审批详情", notes = "申请或审批详情")
    @GetMapping(value = "/detail/{id}")
    @SystemLog(description = "查询办公用品申请或审批详情")
    public Result detail(@PathVariable("id")Integer id){
        return Result.returnOk(oaOfficesuppliesApplicationService.detail(id));
    }
    
    /**
    *@Description 改变状态
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "改变状态", notes = "改变状态")
    @PostMapping(value = "/changeStatus")
    @LoginUser
    @StatusChangedNotification(name = "办公用品信息")
    @SystemLog(description = "办公用品状态变更")
    public Result changeStatus(AuthUser authUser,@RequestBody OaOfficesuppliesApplication oaOfficesuppliesApplication){
        oaOfficesuppliesApplication.setApproverId(authUser.getId());
        oaOfficesuppliesApplication.setApprovalTime(new Date());
        oaOfficesuppliesApplicationService.updateById(oaOfficesuppliesApplication);
        //消息推送
        OaOfficesuppliesApplication application = oaOfficesuppliesApplicationService.getById(oaOfficesuppliesApplication.getId());
        cn.yq.oa.entity.AuthUser user = userService.getById(application.getApplicantId());
        PushUtil.setTargetUsername(user.getUsername());
        return Result.returnOk();
    }
    
    /**
    *@Description APP端申请用品的展示
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @ApiOperation(value = "APP端申请用品的展示", notes = "APP端申请用品的展示")
    @GetMapping(value = "/showApplicationItem")
    @SystemLog(description = "app办公用品申请信息")
    public Result showApplicationItem(){
        List<AplicationItemShowVO> aplicationItemShowVOS = oaOfficesuppliesApplicationService.showApplicationItem();
        return Result.returnOk(aplicationItemShowVOS);
    }
}
