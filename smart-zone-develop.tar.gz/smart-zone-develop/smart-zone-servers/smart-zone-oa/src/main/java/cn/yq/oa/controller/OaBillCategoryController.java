package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.oa.entity.AuthUser;
import cn.yq.oa.entity.OaBillCategory;
import cn.yq.oa.entity.SysDictData;
import cn.yq.oa.param.BillCategoryParam;
import cn.yq.oa.param.InvoiceInfoParam;
import cn.yq.oa.service.IOaBillCategoryService;
import cn.yq.oa.service.ISysDictDataService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.apache.ibatis.annotations.Delete;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 账单分类信息 前端控制器
 * </p>
 *
 * @author zhengjianhui
 * @since 2019-05-23
 */
@RestController
@RequestMapping("/oa-bill-category")
@Api(value = "账单分类维护 ", description = "账单分类维护（lwl） API", position = 100, protocols = "http")
@AllArgsConstructor
public class OaBillCategoryController {


    IOaBillCategoryService oaBillCategoryService;
    ISysDictDataService sysDictDataService;

    @ApiOperation(value = "新增/编辑账单分类", notes = "新增/编辑账单分类")
    @PostMapping("/addBillCategory")
    @SystemLog(description = "新增/编辑账单分类")
    public Result addBillCategory(@RequestBody BillCategoryParam billCategoryParam) {
        OaBillCategory oaBillCategory = new OaBillCategory();
        BeanUtils.copyProperties(billCategoryParam, oaBillCategory);
        Integer dictid = billCategoryParam.getDictid();
        SysDictData sysDictData = new SysDictData();
        if (dictid != null) {
            //编辑
            //修改分类表
            QueryWrapper<OaBillCategory> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("dictid", dictid);
            oaBillCategoryService.update(oaBillCategory, queryWrapper);
            //修改字典表
            sysDictData.setId(dictid);
            sysDictData.setDictLabel(oaBillCategory.getName());
            sysDictDataService.updateById(sysDictData);
            return Result.returnOk("操作成功");
        }
        //新增
        //添加字典表
        int max = sysDictDataService.maxCatogery();
        sysDictData.setDictValue(max + 1);
        sysDictData.setDictType("oabill_category_id");
        sysDictData.setDictLabel(oaBillCategory.getName());
        sysDictDataService.save(sysDictData);
        //添加分类表
        oaBillCategory.setDictid(sysDictData.getId());
        oaBillCategoryService.save(oaBillCategory);
        return Result.returnOk("操作成功");
    }

    @ApiOperation(value = "账单分类列表", notes = "账单分类列表")
    @PostMapping("/listBillCategory")
    @SystemLog(description = "账单分类列表")
    public Result<List<OaBillCategory>> listBillCategory() {
        List<OaBillCategory> list = oaBillCategoryService.listBillCategory();
        return Result.returnOk(list);
    }


    @ApiOperation(value = "根据字典表id获取账单分类详情", notes = "根据字典表id获取账单分类详情")
    @PostMapping("/getBillCategoryByDictid/{dictid}")
    @SystemLog(description = "获取账单分类详情")
    public Result<OaBillCategory> getBillCategoryByDictid(@PathVariable("dictid") Integer dictid) {

        QueryWrapper<OaBillCategory> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dictid", dictid);
        OaBillCategory billCategory = oaBillCategoryService.getOne(queryWrapper);
        return Result.returnOk(billCategory);
    }

    @ApiOperation(value = "更改分类状态", notes = "更改分类状态")
    @GetMapping("/changeStatus/{dictid}/{status}")
    @SystemLog(description = "更改分类状态")
    public Result changeStatus(@PathVariable("dictid") Integer dictid, @PathVariable("status") Integer status) {
        QueryWrapper<OaBillCategory> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dictid", dictid);
        OaBillCategory billCategory = new OaBillCategory();
        billCategory.setStatus(status);
        oaBillCategoryService.update(billCategory, queryWrapper);
        return Result.returnOk("操作成功");
    }


    @ApiOperation(value = "删除", notes = "删除")
    @DeleteMapping("/removeOBCategory/{dictid}")
    @SystemLog(description = "删除账单信息")
    public Result removeOBCategory(@PathVariable("dictid") Integer dictid) {
        //删除分类表数据
        QueryWrapper<OaBillCategory> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("dictid", dictid);
        oaBillCategoryService.remove(queryWrapper);
        //删除对应字典表数据
        sysDictDataService.removeById(dictid);
        return Result.returnOk("操作成功");
    }


}
