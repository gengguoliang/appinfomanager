package cn.yq.oa.controller;


import cn.yq.common.annotations.LoginUser;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.utils.PrimaryGenerater;
import cn.yq.common.vo.AuthUser;
import cn.yq.oa.entity.*;
import cn.yq.oa.param.*;
import cn.yq.oa.service.IOaFixedassetsBizDetailService;
import cn.yq.oa.service.IOaFixedassetsService;
import cn.yq.oa.service.IOaFixedassetsTransferService;
import cn.yq.oa.service.impl.OrderNumberServiceImpl;
import cn.yq.oa.vo.OaFixedassetsTransferVo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 固定资产转移表 前端控制器
 * </p>
 *
 * @author LWL
 * @since 2019-02-02
 */
@RestController
@RequestMapping("/oa-fixedassets-transfer")
@AllArgsConstructor
public class OaFixedassetsTransferController {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    IOaFixedassetsTransferService oaFixedassetsTransferService;

    IOaFixedassetsBizDetailService oaFixedassetsBizDetailService;

    IOaFixedassetsService oaFixedassetsService;

    @Resource(name = "orderNumberServiceImpl")
    OrderNumberServiceImpl orderNumberService;

    @PostMapping("/addTransfer")
    @LoginUser
    @SystemLog(description = "添加固定资产转移信息")
    public Result addTransfer(AuthUser authUser, @RequestBody OaFixedassetsTransferParam oaFixedassetsTransferParam){
        OaFixedassetsTransfer oaFixedassetsTransfer = new OaFixedassetsTransfer();
        BeanUtils.copyProperties(oaFixedassetsTransferParam,oaFixedassetsTransfer);
        oaFixedassetsTransfer.setCreateBy(authUser.getName());
        //转移单号
//        String dh = "ZYD" + PrimaryGenerater.geneterNextNumber(sdf.format(new Date()));
        String dh = orderNumberService.getOneOrderNumber("ZYD");
        oaFixedassetsTransfer.setNo(dh);
        //保存转移表数据
        oaFixedassetsTransferService.saveOrUpdate(oaFixedassetsTransfer);
        //获取转移单id
        int id = oaFixedassetsTransfer.getId();
        //保存业务明细表数据
        List<TransferParam> list = oaFixedassetsTransferParam.getParams();

        for (TransferParam temp:list){
            OaFixedassetsBizDetail oaFixedassetsBizDetail = new OaFixedassetsBizDetail();
            //转移
            oaFixedassetsBizDetail.setBizType(3);
            oaFixedassetsBizDetail.setBizId(id);
            oaFixedassetsBizDetail.setAssetId(temp.getId());
            //保存转出部门id
            oaFixedassetsBizDetail.setOutdeptId(temp.getDeptId());
            oaFixedassetsBizDetailService.saveOrUpdate(oaFixedassetsBizDetail);
        }
//        //修改资产信息(根据资产id)
        for (TransferParam temp:list){
            OaFixedassets oaFixedassets = new OaFixedassets();

            oaFixedassets.setId(temp.getId());
            //转移
//            oaFixedassets.setStatus(2);
            //修改当前所在部门
            oaFixedassets.setDeptid(oaFixedassetsTransferParam.getDepartmentId());
            oaFixedassetsService.updateById(oaFixedassets);
        }
        return Result.returnOk("操作成功");
    }

    /**
     * 分页查询
     */
    @PostMapping("/getAllTransfers/{pageNum}/{pageSize}")
    @SystemLog(description = "分页查询固定资产转移信息")
    public Result getAllTransfers(@PathVariable("pageNum") int pageNum, @PathVariable("pageSize") int pageSize, @RequestBody TransferSearchParam transferSearchParam) {
        Page<OaFixedassetsTransferVo> page = new Page<OaFixedassetsTransferVo>(pageNum,pageSize);
//        IPage<OaFixedassetsTransfer> iPage = oaFixedassetsTransferService.selectTransfersPage(page, transferSearchParam);
        IPage<OaFixedassetsTransferVo> iPage = oaFixedassetsTransferService.selectTransfersVoPage(page, transferSearchParam);
        return Result.returnOk(iPage);
    }


    /**
     * 删除功能
     */
    @GetMapping("/deleteTranster/{id}")
    @SystemLog(description = "删除固定资产转移信息")
    public Result deleteTranster(@PathVariable("id") int id){
        oaFixedassetsTransferService.removeById(id);
        return Result.returnOk("操作成功");
    }

    /**
     * 查看详情
     */
    @GetMapping("/getTransferById/{id}")
    @SystemLog(description = "固定资产转移信息详情")
    public Result getTransferById(@PathVariable("id") int id){
        Map map = new HashMap<>();
        OaFixedassetsTransfer transfer = oaFixedassetsTransferService.getById(id);
        map.put("transferInfo",transfer);
        //固定资产列表
        QueryWrapper<OaFixedassetsBizDetail> queryWrapper = new QueryWrapper<OaFixedassetsBizDetail>();
        queryWrapper.eq("biz_type",3);
        queryWrapper.eq("biz_id",id);
        queryWrapper.eq("is_del",0);
        List<OaFixedassetsBizDetail> list = oaFixedassetsBizDetailService.list(queryWrapper);
        List ids = new ArrayList();
        for (OaFixedassetsBizDetail temp:list){
            ids.add(temp.getAssetId());
        }
        //查询固定资产表
        Collection list1 = null;
        if (ids.size()>0){
            list1 = oaFixedassetsService.listByIds(ids);
        }
        map.put("list",list1);
        return Result.returnOk(map);
    }
















}
