package cn.yq.auth.service;

import cn.yq.auth.domain.CustUserDetails;
import cn.yq.client.userapi.UserClient;
import cn.yq.common.constant.Constant;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.GsonUtil;
import cn.yq.common.utils.ObjectConvertUtil;
import cn.yq.common.vo.AuthUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server
 * @Description: 自定义用户信息
 * @date 2018/4/12 15:35
 */
@Slf4j
@Service
public class CustomUserDetailsService implements UserDetailsService {

    /**
     * 序列化id
     */
    private static final long serialVersionUID = 4125096758372084309L;

    @Resource
    private UserClient userClient;
    @Resource
    private RedisTemplate redisTemplate;

    @Override
    public UserDetails loadUserByUsername(String name) {
        Result<AuthUser> result = userClient.queryByName(name);
        if (ResultEnum.SUCCESS.getCode().equals(result.getCode())) {
            AuthUser authUser = result.getData();
            redisTemplate.opsForValue().set(Constant.AUTHUSER+Constant.USER+authUser.getUsername(), GsonUtil.createGsonString(authUser));
            redisTemplate.expire(Constant.AUTHUSER+Constant.USER+authUser.getUsername(),TimeUnit.DAYS.toSeconds(7),TimeUnit.SECONDS);
            CustUserDetails userDetails = ObjectConvertUtil.convert(authUser, CustUserDetails.class);
            return userDetails;
        } else {
            throw new UsernameNotFoundException(name);
        }
    }
}
