package cn.yq.auth.domain;

import cn.yq.common.vo.AuthRole;
import cn.yq.common.vo.UrlGrantedAuthority;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.awt.print.PrinterGraphics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.domain
 * @Description: ${TODO}(用一句话描述该文件做什么)
 * @date 2018/4/13 11:28
 */
@Data
public class CustUserDetails implements UserDetails {
    private Integer id;
    private String username;
    private String password;
    private List<String> roles;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        for (String urlAndMethod : roles) {
            authorities.add(new SimpleGrantedAuthority(urlAndMethod));
        }
        return authorities;
    }
    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}
