package cn.yq.client.userapi;

import cn.yq.client.userapi.fallback.UserClientFallBack;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.feign
 * @Description: UserClient
 * @date 2018/4/18 11:05
 */
@FeignClient(value = "smart-zone-userapi", fallback = UserClientFallBack.class)
public interface UserClient {

    /**
     * @Description 部门回显需要的List<Integer>
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @PostMapping(value = "/parkUser/getDeptIds", produces = "application/json;charset=UTF-8")
    List<Integer> getDeptIds(@RequestBody AuthUser authUser);

    /**
     * @Description 部门回显需要的List<Integer>  2
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @PostMapping(value = "/parkUser/getDeptIds2", produces = "application/json;charset=UTF-8")
    List<Integer> getDeptIds2(@RequestBody AuthUser authUser);

    @PostMapping(value = "/auth/query", produces = "application/json;charset=UTF-8")
    Result<AuthUser> queryByName(@RequestParam("name") String name);

    @GetMapping(value = "/auth/queryRoleName/{orgId}", produces = "application/json;charset=UTF-8")
    Result<List<String>> queryRoleName(@PathVariable("orgId") Integer orgId);

    /**
     * 获取组织是否冻结
     *
     * @param orgid
     * @return
     */
    @GetMapping(value = "/user/getOrgInfo/{orgid}", produces = "application/json;charset=UTF-8")
    Result<String> getOrgInfo(@RequestParam("orgid") Integer orgid);


    /**
     * @Description 根据用户ID获取组织的认证号
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @GetMapping(value = "/authOrg/getCertifyNum/{userId}", produces = "application/json;charset=UTF-8")
    Result<String> getCertifyNum(@PathVariable("userId") Integer userId);

    /**
     * @Description 根据用户ID查询个人身份证号
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @GetMapping(value = "/user/getIdentityNum/{userId}", produces = "application/json;charset=UTF-8")
    Result<String> getIdentityNum(@PathVariable("userId") Integer userId);

    @GetMapping(value = "/user/getOrgType/{orgId}", produces = "application/json;charset=UTF-8")
    Result<Integer> getOrgType(@PathVariable("orgId") Integer orgId);

    @GetMapping(value = "/user/getUname/{userId}", produces = "application/json;charset=UTF-8")
    Result<String> getUname(@PathVariable("userId") Integer userId);


}
