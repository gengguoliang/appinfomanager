package cn.yq.client.userapi;

import cn.yq.client.userapi.fallback.SysLogClientFallBack;
import cn.yq.client.userapi.fallback.UserClientFallBack;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.vo.SysLog;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.feign
 * @Description: UserClient
 * @date 2018/4/18 11:05
 */
@FeignClient(value = "smart-zone-userapi", fallback = SysLogClientFallBack.class)
public interface SysLogClient {

    @PostMapping(value = "/syslog", produces = "application/json;charset=UTF-8")
    Result insertSysLog(@RequestBody SysLog SysLog);
}
