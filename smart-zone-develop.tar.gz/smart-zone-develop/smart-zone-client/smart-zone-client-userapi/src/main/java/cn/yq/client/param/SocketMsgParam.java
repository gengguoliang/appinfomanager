package cn.yq.client.param;

import lombok.Data;

import java.util.List;

/**
 * @author: YQ-DGZ
 * @date: 2019/9/4 16:00
 * @description: TODO
 */
@Data
public class SocketMsgParam {
    private List<String> usernameList;
    private String content;
}
