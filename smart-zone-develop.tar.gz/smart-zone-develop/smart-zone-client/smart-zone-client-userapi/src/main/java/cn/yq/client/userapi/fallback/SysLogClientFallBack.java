package cn.yq.client.userapi.fallback;

import cn.yq.client.userapi.SysLogClient;
import cn.yq.client.userapi.UserClient;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.common.vo.SysLog;
import org.springframework.stereotype.Component;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.feign.fallback
 * @Description: UserClientFallBack
 * @date 2018/4/18 11:33
 */
@Component
public class SysLogClientFallBack implements SysLogClient {


    @Override
    public Result insertSysLog(SysLog SysLog) {
        return new Result(ResultEnum.FAIL.getCode(), "记录系统操作日志调用失败");
    }
}
