package cn.yq.client.rental.fallback;

import cn.yq.client.rental.UserApiClient;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import org.springframework.stereotype.Component;

/**
 * @Author: ggl
 * @Date: 2019/6/5 16:08
 * @Description:
 */
@Component
public class UserApiClientFallBack implements UserApiClient {
    /**
     * 获取当前用户的数据权限
     *
     * @return
     */
    @Override
    public Result getDataAuth() {
        return new Result(ResultEnum.FAIL);
    }
}
