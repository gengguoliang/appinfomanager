package cn.yq.client;

import cn.yq.client.rental.UserApiClient;
import cn.yq.common.annotations.PermissionAop;
import cn.yq.common.datapermission.DataPermissionContext;
import cn.yq.common.result.Result;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.mapping.MappedStatement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.lang.reflect.Method;


/**
 * @author: yinqk
 * @date: 2019-06-05 22:23
 * @description: 自定义权限相关工具类
 */
@Slf4j
@Component
public class PermissionUtils {

    @Autowired
    private UserApiClient userApiClient;
    private static PermissionUtils permissionUtils;

    @PostConstruct
    public void init() {
        permissionUtils = this;
        permissionUtils.userApiClient = this.userApiClient;
    }

    /**
     * 根据 StatementHandler 获取 注解对象
     */
    public static PermissionAop getPermissionByDelegate(MappedStatement mappedStatement) {
        PermissionAop permissionAop = null;
        try {
            String id = mappedStatement.getId();
            String className = id.substring(0, id.lastIndexOf("."));
            String methodName = id.substring(id.lastIndexOf(".") + 1, id.length());
            final Class cls = Class.forName(className);
            final Method[] method = cls.getMethods();
            for (Method me : method) {
                if (me.getName().equals(methodName) && me.isAnnotationPresent(PermissionAop.class)) {
                    permissionAop = me.getAnnotation(PermissionAop.class);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return permissionAop;
    }

    public static DataPermissionContext getDataPermissionContext() {
        Result result = permissionUtils.userApiClient.getDataAuth();
        if(result.getCode().equals(String.valueOf(0))){
            return (DataPermissionContext)result.getData();
        }
        return null;
    }
}
