package cn.yq.client.rental;

import cn.yq.client.rental.fallback.UserApiClientFallBack;
import cn.yq.common.config.FeignConfiguration;
import cn.yq.common.datapermission.DataPermissionContext;
import cn.yq.common.result.Result;
import cn.yq.common.vo.AuthUser;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author ggl
 * @Description: UserApiClient
 * @date 2019/6/5 11:05
 */
@FeignClient(value = "smart-zone-userapi", configuration = FeignConfiguration.class, fallback = UserApiClientFallBack.class)
public interface UserApiClient {

    /**
     * 获取当前用户的数据权限
     *
     * @return
     */
    @RequestMapping(value = "/data/auth", method = RequestMethod.POST)
    Result<DataPermissionContext> getDataAuth();
}
