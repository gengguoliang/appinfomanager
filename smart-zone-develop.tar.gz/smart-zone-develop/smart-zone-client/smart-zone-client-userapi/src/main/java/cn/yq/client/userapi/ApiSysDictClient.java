package cn.yq.client.userapi;

import cn.yq.client.userapi.fallback.ApiSysDictClientFallBack;
import cn.yq.client.userapi.fallback.OAuth2ServerClientHystrix;
import cn.yq.common.result.Result;
import cn.yq.common.vo.SysDictDataVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 *
 */
@FeignClient(value = "smart-zone-userapi", fallback = ApiSysDictClientFallBack.class)
public interface ApiSysDictClient {

    @GetMapping(value = "/api/dict/{dictionaryType}", produces = "application/json;charset=UTF-8")
    Result<List<SysDictDataVo>> queryByDictType(@RequestParam("dictionaryType") String dictionaryType);


}
