package cn.yq.client.userapi.fallback;

import cn.yq.client.userapi.UserClient;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.feign.fallback
 * @Description: UserClientFallBack
 * @date 2018/4/18 11:33
 */
@Component
public class UserClientFallBack implements UserClient {

    /**
     * @param authUser
     * @Description 部门回显需要的List<Integer>
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<Integer> getDeptIds(AuthUser authUser) {
        return null;
    }

    /**
     * @param authUser
     * @Description 部门回显需要的List<Integer>  2
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public List<Integer> getDeptIds2(AuthUser authUser) {
        return null;
    }

    @Override
    public Result<AuthUser> queryByName(String name) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }

    @Override
    public Result<List<String>> queryRoleName(Integer orgId) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }

    /**
     * @param userId
     * @Description 根据用户ID获取组织的认证号
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public Result<String> getCertifyNum(Integer userId) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }

    /**
     * @param userId
     * @Description 根据用户ID查询个人身份证号
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public Result<String> getIdentityNum(Integer userId) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }

    @Override
    public Result<Integer> getOrgType(Integer orgId) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }

    @Override
    public Result<String> getUname(Integer userId) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }

    @Override
    public Result<String> getOrgInfo(Integer orgid) {
        System.out.println("调用失败");
        return new Result(ResultEnum.FEIGN_FAIL);
    }
}
