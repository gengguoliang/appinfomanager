package cn.yq.client.userapi.fallback;

import cn.yq.client.userapi.ApiSysDictClient;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.common.vo.SysDictDataVo;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Auther: houqijun
 * @Date: 2018/12/13 13:47
 * @Description:
 */
@Component
public class ApiSysDictClientFallBack implements ApiSysDictClient {

    @Override
    public Result<List<SysDictDataVo>> queryByDictType(String typeName) {
        return new Result(ResultEnum.FEIGN_FAIL);
    }
}
