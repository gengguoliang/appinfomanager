package cn.yq.client.userapi;

import cn.yq.client.param.SocketMsgParam;
import cn.yq.client.userapi.fallback.OaClientFallBack;
import cn.yq.client.userapi.fallback.UserClientFallBack;
import cn.yq.common.result.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.feign
 * @Description: OaClient
 * @date 2018/4/18 11:05 */
@FeignClient(value = "smart-zone-oa", fallback = OaClientFallBack.class)
public interface OaClient {

    /**
    *@Description 生成单号
    *@Param 
    *@Return 
    *@Author zhengjianhui
    */
    @PostMapping(value = "/getOrder", produces = "application/json;charset=UTF-8")
    String getOrder(@RequestParam("prefix") String prefix);

    /**
     * 调用WebScoket
     */
    @GetMapping("/oa-websocket/sendGroupMsg")
    Result sendGroupMsg();

    @GetMapping("/oa-websocket/sendSingleMsg/{username}/{content}")
    Result sendSingleMsg(@PathVariable("username") String username,@PathVariable("content") String content);

    @PostMapping("/sendMultipleMsgByNames")
    Result sendMultipleMsgByNames(@RequestBody SocketMsgParam socketMsgParam);

    @GetMapping("/sendMultipleMsgByComp/{code}/{content}")
    Result sendMultipleMsgByComp(@PathVariable("code") String code,@PathVariable("content") String content);



}
