package cn.yq.client.userapi;

import cn.yq.client.userapi.fallback.OAuth2ServerClientHystrix;
import cn.yq.common.result.Result;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sun.awt.SunHints;

import java.security.PrivateKey;

/**
 * @author huangqi
 * @Package com.mycloud.admin.feign
 * @Description: ${TODO}(用一句话描述该文件做什么)
 * @date 2018/6/28 14:17
 */
@FeignClient(value = "smart-zone-auth", fallback = OAuth2ServerClientHystrix.class)
public interface OAuth2ServerClient {


    @RequestMapping(value = "/oauth/remove_token", method = RequestMethod.POST)
    Result removeToken(@RequestParam("token") String token);
}
