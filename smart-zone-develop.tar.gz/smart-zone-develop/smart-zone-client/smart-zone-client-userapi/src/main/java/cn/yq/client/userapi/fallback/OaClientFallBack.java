package cn.yq.client.userapi.fallback;

import cn.yq.client.param.SocketMsgParam;
import cn.yq.client.userapi.OaClient;
import cn.yq.common.result.Result;
import org.springframework.stereotype.Component;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.feign.fallback
 * @Description: OaClientFallBack
 * @date 2018/4/18 11:33
 */
@Component
public class OaClientFallBack implements OaClient {

    /**
     * @param prefix
     * @Description 生成单号
     * @Param
     * @Return
     * @Author zhengjianhui
     */
    @Override
    public String getOrder(String prefix) {
        System.out.println("调用失败");
        return "调用失败";
    }

    @Override
    public Result sendGroupMsg() {
        return Result.returnFail();
    }

    @Override
    public Result sendSingleMsg(String username, String content) {
        return Result.returnFail();
    }

    @Override
    public Result sendMultipleMsgByNames(SocketMsgParam socketMsgParam) {
        return Result.returnFail();
    }

    @Override
    public Result sendMultipleMsgByComp(String code, String content) {
        return Result.returnFail();
    }
}
