package cn.yq.zuul.exception;

import cn.yq.common.result.ResultEnum;
import lombok.Data;

/**
 * @Auther: houqijun
 * @Date: 2018/12/7 10:24
 * @Description:
 */
@Data
public class SmartZoneException extends RuntimeException {

    private ResultEnum resultEnum;

    public SmartZoneException(ResultEnum resultEnum){
        this.resultEnum = resultEnum;
    }

}
