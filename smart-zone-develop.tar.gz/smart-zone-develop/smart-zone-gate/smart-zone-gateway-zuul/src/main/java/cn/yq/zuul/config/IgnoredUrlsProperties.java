package cn.yq.zuul.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: houqijun
 * @Date: 2019/1/10 14:37
 * @Description:
 */
@Data
@Component
@ConfigurationProperties(prefix = "ignored")
@RefreshScope
public class IgnoredUrlsProperties {

    private List<String> urls = new ArrayList<>();
}
