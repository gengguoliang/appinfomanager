package cn.yq.zuul.controller;

import cn.yq.client.userapi.OAuth2ServerClient;
import cn.yq.client.userapi.UserClient;
import cn.yq.common.annotations.SystemLog;
import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.vo.AuthUser;
import cn.yq.push.service.PushService;
import cn.yq.zuul.store.MyRedisTokenStore;
import cn.yq.zuul.utils.BCryptUtil;
import cn.yq.zuul.vo.UserVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.security.oauth2.OAuth2ClientProperties;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.*;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.*;

/**
 * @author Administrator
 * @Package com.mycloud.admin
 * @Description: ${TODO}(用一句话描述该文件做什么)
 * @date 2018/5/4 10:26
 */
@Slf4j
@RestController
@RequestMapping(value = "/auth")
public class LoginController {

    @Resource
    private OAuth2ClientProperties oAuth2ClientProperties;
    @Resource
    private OAuth2ProtectedResourceDetails oAuth2ProtectedResourceDetails;
    @Resource
    private RestTemplate restTemplate;

    @Resource
    private UserClient userClient;

    @Resource
    private OAuth2ServerClient oAuth2ServerClient;

    @Resource
    private RedisTemplate redisTemplate;

    @Resource
    private PushService pushService;

    @Resource
    @Qualifier("myRedisTokenStore")
    private MyRedisTokenStore myRedisTokenStore;

    @GetMapping("/user")
    public Principal user(Principal user) {
        return user;
    }

    /**
     * 通过密码授权方式向授权服务器获取令牌
     *
     * @return
     * @throws Exception
     */
    @PostMapping(value = "/login")
    @SystemLog(description = "登录")
    public Result login(@RequestBody UserVo userVo) throws Exception {
        AuthUser authUser = new AuthUser();

        BeanUtils.copyProperties(userVo, authUser);
        log.debug("========>username" + authUser.getUsername() + "===password" + authUser.getPassword());
        //api验证用户名密码
        Result<AuthUser> result = userClient.queryByName(authUser.getUsername());

        if (!ResultEnum.SUCCESS.getCode().equals(result.getCode()) || result.getData() == null) {
            //登录失败
            return new Result(ResultEnum.LOGIN_USER_ERR);
        }
        AuthUser user = result.getData();
        //判断用户是否被禁用
        if (user.getIsLocked() == true) {
            return new Result(ResultEnum.IS_LOCKED);
        }
        //判断用户所属企业是否被冻结
        int orgid = user.getOrganizationId();
        Result<String> info = userClient.getOrgInfo(orgid);
        String status = info.getMsg();
        if ("0".equals(status)) {

        }
        if ("".equals(status)) {

        }
        if ("1".equals(status)) {
            return new Result(ResultEnum.FROZEN);
        }

        if (BCryptUtil.isMatch(authUser.getPassword(), user.getPassword())) {
            String username = "".equals(user.getUsername()) ? user.getMobile() : user.getUsername();
            ResponseEntity<OAuth2AccessToken> responseEntity = getToken(username, authUser.getPassword());
            if (HttpStatus.OK.equals(responseEntity.getStatusCode())) {
                DefaultOAuth2AccessToken body = (DefaultOAuth2AccessToken) responseEntity.getBody();
                Map<String, String> map = new HashMap<>();
                map.put("token", body.getValue());
                map.put("username", username);
                //公司类型
                Result<Integer> orgTypeResult = userClient.getOrgType(user.getOrganizationId());
                String orgType = null;
                if (orgTypeResult.getData() != null) {
                    orgType = String.valueOf(orgTypeResult.getData());
                }
                map.put("orgType", orgType);//组织类型，0：租赁企业，1：租赁个人，2：物业公司，3：装修施工单位，4：盛元
                log.debug("user====>{}", body);
                pushService.bind(user.getUsername(), userVo.getClientid());
                log.info("========>clientid" + userVo.getClientid());
                /*//如果isAdmin,则把当前人的所属组织的所有角色名字绑定
                if(user.getIsAdmin()!=null && user.getIsAdmin()==1){
                    //查询所有角色
                    Result<List<String>> listResult = userClient.queryRoleName(user.getOrganizationId());
                    List<String> roleNames = listResult.getData();
                    pushService.setClientTag(userVo.getClientid(),roleNames,String.valueOf(user.getOrganizationId()));
                }*/
                return Result.returnOk(map);
            } else {
                return new Result(ResultEnum.LOGIN_FAIL);
            }
        } else {
            return new Result(ResultEnum.LOGIN_USER_ERR);
        }
    }

    @PostMapping("/logout")
    @SystemLog(description = "退出登录")
    public Result exit(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        String tokenValue = authHeader.replace("bearer", "").trim();
        Result result = oAuth2ServerClient.removeToken(tokenValue);
        if (!ResultEnum.SUCCESS.getCode().equals(result.getCode())) {
            return new Result(ResultEnum.LOGOUT_FAIL);
        }
        return Result.returnOk("注销成功");
    }

    public ResponseEntity<OAuth2AccessToken> getToken(String userName, String passWord) {
        //Http Basic 验证
        String clientAndSecret = oAuth2ClientProperties.getClientId() + ":" + oAuth2ClientProperties.getClientSecret();
        //这里需要注意为 Basic 而非 Bearer
        clientAndSecret = "Basic " + Base64.getEncoder().encodeToString(clientAndSecret.getBytes());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", clientAndSecret);
        //授权请求信息
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.put("username", Collections.singletonList(userName));
        map.put("password", Collections.singletonList(passWord));
        map.put("grant_type", Collections.singletonList(oAuth2ProtectedResourceDetails.getGrantType()));
        map.put("scope", oAuth2ProtectedResourceDetails.getScope());
        //HttpEntity
        HttpEntity httpEntity = new HttpEntity(map, httpHeaders);
        //获取 Token
        ResponseEntity<OAuth2AccessToken> exchange = restTemplate.exchange(oAuth2ProtectedResourceDetails.getAccessTokenUri(), HttpMethod.POST, httpEntity, OAuth2AccessToken.class);
        return exchange;
    }

}
