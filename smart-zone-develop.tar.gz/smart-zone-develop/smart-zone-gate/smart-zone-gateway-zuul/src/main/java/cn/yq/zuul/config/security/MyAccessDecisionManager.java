package cn.yq.zuul.config.security;

import cn.yq.common.constant.Constant;
import cn.yq.common.utils.GsonUtil;
import cn.yq.common.vo.AuthUser;
import cn.yq.common.vo.UrlGrantedAuthority;
import cn.yq.zuul.config.IgnoredUrlsProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Auther: houqijun
 * @Date: 2018/12/4 12:03
 * @Description: 用户权限决策器，根据用户访问路径和用户所拥有的资源&按钮进行判断，是否放行
 * 如果不放行就抛出异常
 */
@Slf4j
@Component
public class MyAccessDecisionManager implements AccessDecisionManager {

    @Autowired
    private IgnoredUrlsProperties ignoredUrlsProperties;

    @Resource
    private RedisTemplate redisTemplate;

    @Override
    public void decide(Authentication authentication, Object o, Collection<ConfigAttribute> collection) throws AccessDeniedException, InsufficientAuthenticationException {
        Object principal = authentication.getPrincipal();
        HttpServletRequest request = ((FilterInvocation) o).getHttpRequest();

        List<String> urls = ignoredUrlsProperties.getUrls();
        for(String url : urls){
            if(matchers(url,request)){
                return;
            }
        }

        //从redis中取出用户所拥有的url以及method，因为 zuul————>auth,当zuul访问auth check_token 返回的用户的资源都变少，所以资源都存在redis里面
        /***
         *  1第一次登陆：auth 查询用户信息：之后存入redis
         *  2用户携带token请求网关，zuul访问auth取出用户信息时，用户权限信息不完整，（存入reids用户有30个权限，但是取出时只有20个）
         *  解决方案：用户的权限信息存入redis，
         *  在本类中，直接从redis取出用户的权限，进行判断
         */
        String authUser = (String) redisTemplate.opsForValue().get(Constant.AUTHUSER+Constant.USER + authentication.getPrincipal());
        AuthUser user = GsonUtil.changeGsonToBean(authUser, AuthUser.class);
        if(user == null){
            throw new AccessDeniedException("此用户无权限访问");
        }
        log.debug("当前用户==>{}",user);
        String url, method;
        return;
        /**
         * 根据用户自己的角色 和 访问此资源所需要的角色进行比对
         * 判断是否放行
         * authentication.getAuthorities() 当前登陆用户所拥有的权限资源
         */
//        for(String role : user.getRoles()){
//            String[] urlAndMethod = role.split(";");
//            //  使用zuul进行路由，原来在数据库配置的/user,需要变为/**/user,
//            //  因为request里面的请求路径是/user-api/user
//            //  matcher.matches(request) 才会匹配成功，否则匹配失败
//            url = "/**"+urlAndMethod[0];//用户拥有的资源路径
//            method = urlAndMethod[1];//用户拥有的按钮的请求方式（get|put|delete|post） 如果数据库不配置就默认为ALL，放行
//            log.debug("url=>{},method=>{}",url,method);
//            if (matchers(url, request)) {
//                if (method.equals(request.getMethod()) || "ALL".equals(method)) {
//                    log.debug("================>>当前用户可访问资源");
//                    return;
//                }
//            }
//        }

//        throw new AccessDeniedException("此用户无权限访问");
//
    }

    @Override
    public boolean supports(ConfigAttribute configAttribute) {
        return false;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return false;
    }

    private boolean matchers(String url, HttpServletRequest request) {
        AntPathRequestMatcher matcher = new AntPathRequestMatcher(url);
        if (matcher.matches(request)) {
            return true;
        }
        return false;
    }
}
