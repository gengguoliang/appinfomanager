package cn.yq.zuul.exception;

import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.nio.file.AccessDeniedException;

/**
 * @Auther: houqijun
 * @Date: 2018/12/7 10:26
 * @Description:
 */
@Slf4j
//@RestControllerAdvice
public class RestExcetionHandler {

    @ExceptionHandler(SmartZoneException.class)
    @ResponseStatus(value = HttpStatus.OK)
    public Result handleSmartZoneExcetion(SmartZoneException e) {
        if (e != null) {
            log.error("SmartZoneException===>{}", e);
        }

        return new Result(ResultEnum.SERVER_ERROR);
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.OK)
    public Result handleException(Exception e) {
        if (e != null) {
            if (e instanceof AccessDeniedException) {
                //未授权
                return new Result(ResultEnum.UNAUTHENTICATED);
            }
            log.error(ExceptionUtils.getRootCauseMessage(e), e);
        }

        return new Result(ResultEnum.SERVER_ERROR);
    }

}
