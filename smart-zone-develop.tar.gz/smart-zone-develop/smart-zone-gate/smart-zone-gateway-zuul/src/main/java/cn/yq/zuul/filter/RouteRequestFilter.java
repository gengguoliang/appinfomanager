package cn.yq.zuul.filter;

import cn.yq.common.constant.Constant;
import cn.yq.zuul.config.IgnoredUrlsProperties;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Objects;

import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.ROUTE_TYPE;

/**
 * @Auther: houqijun
 * @Date: 2018/12/5 12:09
 * @Description: 外部http请求到达api网关服务的时候，首先它会进入第一个阶段pre，
 * 在这里它会被pre类型的过滤器进行处理。该类型过滤器的主要目的是在进行请求路由之前做一些前置加工，
 * 比如请求的校验等。在完成了pre类型的过滤器处理之后，请求进入第二个阶段routing，
 * 也就是之前说的路由请求转发阶段，请求将会被routing类型的处理器处理。
 * 这里的具体处理内容就是将外部请求转发到具体服务实例上去的过程，当
 * 服务实例请求结果都返回之后，routing阶段完成，请求进入第三个阶段post。
 * 此时请求将会被post类型的过滤器处理，这些过滤器在处理的时候不仅可以获取到请求信息，
 * 还能获取到服务实例的返回信息，所以在post类型的过滤器中，
 * 我们可以对处理结果进行一些加工或转换等内容。另外，还有一个特殊的阶段error，
 * 该阶段只有在上述三个阶段中发生异常的时候才会触发，但是它的最后流向还是post类型的过滤器，
 * 因为它需要通过post过滤器将最终结果返回给请求客户端（对于error过滤器的处理，在spring cloud zuul的过滤链中实际上有一些不同）
 * <p>
 * 作者：二月_春风
 * 链接：https://www.jianshu.com/p/ff863d532767
 * 來源：简书
 * 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。
 */
@Slf4j
@Component
public class RouteRequestFilter extends ZuulFilter {

    @Resource
    private RedisTemplate redisTemplate;

    @Autowired
    private IgnoredUrlsProperties ignoredUrlsProperties;

    @Autowired
    private HttpServletRequest request;

    //无权限时的提示语
    private static final String INVALID_TOKEN = "invalid token";


    @Override
    public String filterType() {
        return ROUTE_TYPE;
    }

    @Override
    public int filterOrder() {
        return 10;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() {

        boolean flag = false;

        List<String> urls = ignoredUrlsProperties.getUrls();

        for (String url : urls) {
            if (matchers(url, request)) {
                flag = true;
            }
        }

        if (!flag) {
            log.debug("route过滤器===>{}");
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            RequestContext requestContext = RequestContext.getCurrentContext();

            if (Objects.isNull(authentication)) {
                setUnauthorizedResponse(requestContext, INVALID_TOKEN);
                return null;
            }

            Object o = authentication.getPrincipal();
            log.debug("传递给下游的对象", o);
            String authUser = (String) redisTemplate.opsForValue().get(Constant.AUTHUSER + Constant.USER + authentication.getPrincipal());
            log.debug("传递给下游的对象------当前登陆用户-----authUser------>{}", authUser);

            try {
                requestContext.addZuulRequestHeader("X-AUTH-ID", URLEncoder.encode(authUser, "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                log.error("url转码异常");
            }
        }

        return null;
    }

    private boolean matchers(String url, HttpServletRequest request) {
        AntPathRequestMatcher matcher = new AntPathRequestMatcher(url);
        if (matcher.matches(request)) {
            return true;
        }
        return false;
    }

    /**
     * 设置 401 无权限状态
     */
    private void setUnauthorizedResponse(RequestContext requestContext, String msg) {
        requestContext.setSendZuulResponse(false);
        requestContext.setResponseStatusCode(HttpStatus.UNAUTHORIZED.value());

        /*Result.returnFail()
        ResultVO vo = new ResultVO();
        vo.setCode(401);
        vo.setMsg(msg);

        requestContext.setResponseBody(result);*/
    }
}
