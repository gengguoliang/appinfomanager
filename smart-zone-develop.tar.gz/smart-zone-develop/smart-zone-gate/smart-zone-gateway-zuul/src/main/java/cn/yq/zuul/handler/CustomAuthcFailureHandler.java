package cn.yq.zuul.handler;

import cn.yq.common.result.Result;
import cn.yq.common.result.ResultEnum;
import cn.yq.common.utils.ResponseUtil;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Administrator
 * @Package com.mycloud.cloud.oauth2server.handler
 * @Description: CustomAuthcFailureHandler
 * @date 2018/4/20 10:37
 */
@Component
public class CustomAuthcFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
        //直接返回JSON字符串
        ResponseUtil.out(response,new Result(ResultEnum.LOGIN_FAIL));
    }
}
