package cn.yq.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.config.server.EnableConfigServer;

/**
 * @author yinqk
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableConfigServer
public class SmartZoneConfigApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartZoneConfigApplication.class, args);
        System.out.println("【【【【【【 SmartZoneConfigApplication微服务 】】】】】】已启动.");
    }
}
