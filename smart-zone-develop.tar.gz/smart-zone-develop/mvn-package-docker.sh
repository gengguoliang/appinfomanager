#!/bin/bash
git pull
echo "开始执行打包....[start]"

mvn clean
mvn install
cd ./smart-zone-auth
mvn package docker:build -Dmaven.test.skip=true

cd ../smart-zone-center/smart-zone-config
mvn package docker:build -Dmaven.test.skip=true

cd ../smart-zone-registry
mvn package docker:build -Dmaven.test.skip=true

cd ../../smart-zone-gate/smart-zone-gateway-zuul
mvn package docker:build -Dmaven.test.skip=true

cd ../../smart-zone-servers/smart-zone-api
mvn package docker:build -Dmaven.test.skip=true

cd ../../smart-zone-servers/smart-zone-rental
mvn package docker:build -Dmaven.test.skip=true

cd ../../smart-zone-servers/smart-zone-oa
mvn package docker:build -Dmaven.test.skip=true

docker rmi $(docker images | grep "none" | awk '{print $3}')
echo "执行打包结束.....[end]"